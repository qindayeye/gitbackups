<template>
	<view class="chioceBook">
		<!-- 头部 -->
		<view class="header">
			<view class="inp">
				<text class="eosfont search">&#xe600;</text>
				<input type="text" placeholder="图书搜索" @click="gotosearch"/>
			</view>
		</view>
		<!-- 选择 -->

		<view class="chioce_page">
			<block v-for="(item,index) in list" :key='index'>
				<view class="chioce_pagemain">
					<view class="choice_title">
						{{item.name}}
					</view>
					<view class="choice_tag" >
						<text :class="{'on': key.includes(index) && ind===activeClass[index]}" v-for="(el,ind) in item.arr" :key="ind" @click="add(el,ind,index)">{{el.cat_name}}</text>
					</view>
				</view>
			</block>
		</view>
		<button type="primary" class="btn" @click="startSelect">开始选书</button>
		<view class="main-content">
			<footer>
				<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view>
	</view>
</template>

<script>
	// import uniIcon from "@/components/uni-icon.vue";

    import Vue from 'vue'
	import bottomNav from "@/pages/navbar/navbar.vue";
	const selectArr = {};
	export default {
		components: {
			bottomNav,
			// on:true
			// uniIcon
		},
		data() {
			return {
				activeClass: [],
				key: [],
				list: [{
						id: 1,
						name: '年龄',
						arr: []
					},
					{
						id: 2,
						name: '语言',
						arr: []
					},
					{
						id: 3,
						name: '分类',
						arr: []
					},
					{
						id: 4,
						name: '有声',
						arr: [
							{
								av_type:1,
								cat_name:'含视频'
							},
							{
								av_type:2,
								cat_name:'含音频'
							},
							{
								av_type:3,
								cat_name:'伴读宝'
							},
							{
								av_type:4,
								cat_name:'小布壳'
							},
						]
					},
				],
				selectArr:{
					age:"",
					class:"",
					lang:""
				}
			};
		},
		onLoad() {
			this.getfenlei()
			  this.list.forEach(el => {
				this.activeClass.push(-1)
			  })
		},
		methods: {
			
			add: function(e, ind, index) {

				console.log(this.selectArr,'this.selectArr')
				
				this.key.push(index);
				if(index == 0){
					if(ind==this.activeClass[0]){
						this.activeClass[0]=-1
						this.selectArr.age= ''
					}else{
						this.activeClass[0] = ind
						this.selectArr.age= e.cat_id
					}
				}else if(index == 1){
					if(ind==this.activeClass[1]){
						this.activeClass[1]=-1
						this.selectArr.lang= ''
					}else{
						this.activeClass[1] = ind
						this.selectArr.lang= e.cat_id
					}
				}else if(index == 2){
					if(ind==this.activeClass[2]){
						this.activeClass[2]=-1
						this.selectArr.class= ''
					}else{
						this.activeClass[2] = ind
						this.selectArr.class= e.cat_id
					}
				}else if(index == 3){
					if(ind==this.activeClass[3]){
						this.activeClass[3]=-1
						this.av_type= ''
					}else{
						this.activeClass[3] = ind
						this.av_type= e.av_type
					}
				}
				console.log(this.selectArr,"selectArr",this.activeClass,"activeClass")

			},
			gotosearch(){
				uni.navigateTo({
					url:'/pages/search/search'
				})
			},
			startSelect(){
				console.log(this.selectArr)
				
				uni.navigateTo({
					url: `/pages/search/agesearch?data=${JSON.stringify({
					 ids: this.selectArr,
					 av_type:this.av_type
					})}`
				})
			},
			
			getfenlei() {
				let that = this;
				this.$api.quest('category/choiceBook', {
					cat_id: []
					
				}, (res) => {
					let list = res.data.data
					console.log(res)
					for (let k in list) {
						if (list[k]) {
							console.log(list[k])
							if (k == 'age_arr') {
								for (let i in list[k]) {
									that.list[0].arr.push(list[k][i])
								}
							}
							if (k == 'class_arr') {
								for (let j in list[k]) {
									that.list[2].arr.push(list[k][j])
								}

							}
							if (k == 'lang_arr') {
								for (let h in list[k]) {
									that.list[1].arr.push(list[k][h])
								}
							}
						}
					}
					console.log(that.list, 1111)
				})
			}
		}

	}
</script>

<style lang="scss">
	@import '../../static/css/choicBook.scss';
	page{
		width: 100vw;
		height: 100vh;
		background: #fff;
	}
	.btn{
		position: fixed;
		bottom: 200rpx;
		width: 710rpx;
		left: 50%;
		margin-left: -355rpx;
		border-radius: 50rpx;
		height: 88rpx;
		margin-top: 40rpx;
		background: linear-gradient(to right, #FEA364, #FA6C3A) !important;

	}
</style>
