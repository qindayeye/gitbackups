<template>
	<view v-if="loagings">
		<view class="searchs">
			<view class="searchtitle">
				<view class="right" @click='gotosearch'>
					<view>
						<text class="eosfont search" style="color: #666;font-size: 28rpx;">&#xe600;</text>
						<!-- 放大镜 -->
					</view>
					<input type="text" :value="searcon" placeholder="图书搜索" />
				</view>
			</view>
			<view class="pagehot" v-if="hotmain.length">
				<view class="hotmain">
					<block v-for="(item,index) in hotmain">
						<navigator  @click="navgetoDetail(item)" open-type="">
							<view class="hot_main_con">
								<image class="bookimg" :src="item.goods_thumb" mode=""></image>
								<view class="bookinfo">
									<text>{{item.goods_name}}</text>
									<view class="label">
										<text v-if="item.age">{{item.age}}</text>
										<text v-if="item.cat_name">{{item.cat_name}}</text>
									</view>

									<image @click.stop="addBook(item,item.goods_id,item.goods_stock)" :src="item.cat_status==2 && item.goods_number>0?'https://www.abcbook2019.com/mobile/public/img/new/jrsj.png':'https://www.abcbook2019.com//mobile/public/img/new/jrsj-h.png'"
									 mode=""></image>
								</view>
								<text class="topleftcorner" v-if="item.video_url">含视频</text>
								<text class="topleftcorner" v-else-if="item.audio_url">含音频</text>
							</view>
						</navigator>
					</block>
				</view>
			</view>
			<view v-else class="empty">
				<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
				<view class="empty-tips">
					<view>呀！没有找到呢</view>
					<view>可以上传您想看的书籍哦~</view>
					<view class="navigator" @click="navWish">上传心愿书单</view>
				</view>
			</view>
		</view>
		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		<!-- <view class="main-content">
			<footer>
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view> -->
			<goCar :carnum='goodsnum'></goCar>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "../navbar/navbar.vue";
	import goCar from '@/components/car.vue';
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		data() {
			return {
				hotmain: [],
				page: 1, // 上拉刷新页数
				classon: false, //判断模态框
				searcon: '',
				classoninfo:"" ,//加载展示内容
				loagings:false,
				goodsnum:0,
				hide:true
			}
		},
		components:{
			bottomNav,
			goCar,
			mixLoading
		},
		onLoad: function(options) {
			console.log(options)
			let that = this;
			that.searcon = options.name;
			this.$api.quest('goods/searchGoods', {
				page: that.page,
				keyword: that.searcon
			}, (res) => {
				console.log(res.data.data)
				that.hotmain.push(...res.data.data)
				this.loagings = true
			})
			this.timer=setInterval(()=>{
				this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
				this.goodsnum=uni.getStorageSync("total_number")
				// console.log(this.goodsnum)
			}, 500)
		},
		onUnload() {
			 if(this.timer) {  
			        clearInterval(this.timer);  
			        this.timer = null;  
			    }  
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
		 if(Object.scrollTop>800){
			 this.hide=false;
		 }else{
			 this.hide=true;
		 }
		},
		
		onReachBottom() {
			this.scroll();
		},
		methods: {
			// 进入详情页
			navgetoDetail(item){
				if(item.audio_url || item.video_url){
					uni.navigateTo({
						url:'/pages/voice/voicedetail?id='+item.goods_id
					})
				}else{
					uni.navigateTo({
						url:'/pages/detail/detail?id='+item.goods_id
					})
				}
				
			},
			
			navWish(){
				// uni.navigateBack()
				// this.$store.commit("change_page", 0)
				uni.navigateTo({
					url:'/pages/Wishlist/Wishlist'
				})
			},
			//回退页面
			goback() {
				uni.navigateBack({
					delta: 1,
				});
			},
			gotop(){
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			gotosearch() {
				uni.navigateTo({
					url: '/pages/search/search'
				})
			},
			addBook(e, id, num) {
				this.$api.addBook(e, id, num)
			},
			// 下拉加载
			scroll() {
				const that = this;
				console.log(that.classon)
				that.classon = true;
				that.classoninfo="正在努力加载..."
				this.loadingType = 1;
				const scrollrequest = this.$api.quest('goods/searchGoods', {
					page: ++that.page,
					keyword: that.searcon,
				}, (res) => {
					console.log(res.data)
					if (res.data.data.length==0) { //没有数据
						that.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
						// uni.hideNavigationBarLoading(); //关闭加载动画
						return;
					}
					this.hotmain.push(...res.data.data)
					// uni.hideNavigationBarLoading(); //关闭加载动画
					this.classon = false //判断模块框
					// console.log(that.hotmain, 'hot', that.page, 'page')
					// uni.hideNavigationBarLoading(); //关闭加载动画
				})
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/index.scss';
	page{
		background: #fff;
	}
	.empty{
		z-index: -1;
	}
	.navigator{
		width: auto !important;
		padding: 0 20rpx;
	}
	.search {
		color: #333;
		font-size: 24upx;
		line-height: 55upx;
	}
	.hot_main_con{
		box-shadow:0px 2rpx 22rpx 0px rgba(0,0,0,0.1);
		position: relative;
		.topleftcorner {
			position: absolute;
			top: 0;
			left: 0;
			width: 84rpx;
			height: 36rpx;
			background: -webkit-linear-gradient(315deg, #ffa57f 0%, #ff5252 100%);
			background: linear-gradient(135deg, #ffa57f 0%, #ff5252 100%);
			border-radius: 10rpx 0 20rpx 0;
			color: #fff;
			font-size: 20rpx;
			text-align: center;
			line-height: 36rpx;
		
		}
	}
	.searchs {
		display: flex;
		flex-direction: column;

		.searchtitle {
			width: 100%;
			display: flex;
			justify-content: space-around;
			height: 88upx;
			padding-top: 10upx;
			border-bottom: 1rpx solid #e6e6e6;
			align-item: center;

			.left {
				width: 8%;
				height: 60upx;
				line-height: 60upx;
				padding-left: 20upx;
			}

			.right {
				width: 95%;
				height: 60upx;
				display: flex;
				align-items: center;
				background: #f5f5f5;
				border-radius: 30upx;

				input {
					font-size: 30upx;
					color: lightgray;
					padding-left: 20upx;
				}

				view {
					margin-left: 20upx;
				}

			}

		}

		.pagehot {
			width: 100%;
			padding-top: 10upx;
			flex: 1;
			background: #fff;

		}
	}
</style>
