<template>
	<view v-if="loagings">
		<view class="searchs">
			<view class="searchtitle">
				<view class="right" @click='gotosearch'>
					<view><text class="eosfont search">&#xe600;</text>   <!-- 放大镜 --></view><input type="text" placeholder="图书搜索" />
				</view>
			</view>
			<view class="pagehot" v-if="hotmain.length">
				<view class="hotmain">
					<block v-for="(item,index) in hotmain" :key='index'>
						<view @click="navgetoDetail(item)" open-type="">
							<view class="hot_main_con">
								<image class="bookimg" :src="item.goods_thumb" mode=""></image>
								<view class="bookinfo">
									<text>{{item.goods_name}}</text>
									<view class="label">
										<text v-if="item.cat_name_t">{{item.cat_name_t}}</text>
										<text v-if="item.cat_name">{{item.cat_name}}</text>
						 			</view>
									<image @click.stop="addBook(item,item.goods_id,item.goods_stock)" :src="item.cat_status==2 && item.goods_number>0?'https://www.abcbook2019.com/mobile/public/img/new/jrsj.png':'https://www.abcbook2019.com//mobile/public/img/new/jrsj-h.png'" mode=""></image>
								</view>
								<text class="topleftcorner" v-if="item.video_url">含视频</text>
								<text class="topleftcorner" v-else-if="item.audio_url">含音频</text>
							</view>
						</view>
					</block>
				</view>
			</view>
			<view v-else class="empty">
				<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
				<view class="empty-tips">
					<view>没有搜索到你要的图书哦</view>
					<view>快去寻找自己喜欢的绘本吧~</view>
					<view class="navigator" @click="navToLogin">去逛逛</view>
				</view>
			</view>
			
		</view>
		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		
		<goCar :carnum='goodsnum'></goCar>
		
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "../navbar/navbar.vue";
	import goCar from '@/components/car.vue';
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default{
		data(){
			return{
				hotmain:[],
				page:1,  // 上拉刷新页数
				classon:false, //判断模态框
				data:{},
				loagings:false,
				classoninfo:"" ,//加载展示内容
				hide:true,
				goodsnum:0
			}
		},
		components: {
			bottomNav,
			goCar,
			mixLoading
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
		 if(Object.scrollTop>800){
			 this.hide=false;
		 }else{
			 this.hide=true;
		 }
		},
		
		onLoad: function(options) {
			let that = this;
			that.data = JSON.parse(options.data);
			console.log(that.data);
			that.data['ids']['page'] = that.page
			that.data['ids']['av_type'] = that.data.av_type
			console.log(that.data['ids']['av_type'])
			this.$api.quest('goods/intelSelectBooks',that.data.ids, (res) => {
				console.log(res.data.data)
				that.hotmain.push(...res.data.data) 
				this.loagings=true
			})
			this.timer=setInterval(()=>{
				this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
				this.goodsnum=uni.getStorageSync("total_number")
				// console.log(this.goodsnum)
			}, 500)
		},
		
		onReachBottom(){
			this.scroll();
		},
		
		onUnload:function(){  
		    if(this.timer) {  
		        clearInterval(this.timer);  
		        this.timer = null;  
		    }  
		},
		methods:{
			// 进入详情页
			navgetoDetail(item){
				if(item.audio_url || item.video_url){
					uni.navigateTo({
						url:'/pages/voice/voicedetail?id='+item.goods_id
					})
				}else{
					uni.navigateTo({
						url:'/pages/detail/detail?id='+item.goods_id
					})
				}
				
			},
			
			navToLogin(){
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			//回退页面
			goback(){
				uni.navigateBack({
					delta: 1,
				});
			},
			gotosearch(){
				uni.navigateTo({
					url:'/pages/search/search'
				})
			},
			addBook(e,id,num){
				this.$api.addBook(e,id,num)
			},
			gotop(){
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			// 下拉加载
			scroll(){
				const that = this;
				console.log(that.classon,"classon",that.searcon,that.data.ids)
				that.classon = true;
				that.classoninfo="正在努力加载..."
				this.loadingType = 1;
				console.log()
				const scrollrequest = this.$api.quest('goods/intelSelectBooks', {
					page: ++that.page,
					age:that.data.ids.age,
					class:that.data.ids.class,
					lang:that.data.ids.lang,
					av_type:that.data.ids.av_type
					// keyword: that.searcon,
				}, (res) => {
					console.log(res.data)
					if (res.data.data.length==0) { //没有数据
						that.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
						// uni.hideNavigationBarLoading(); //关闭加载动画
						return;
					}
					this.hotmain.push(...res.data.data)
					// uni.hideNavigationBarLoading(); //关闭加载动画
					this.classon = false //判断模块框
					// console.log(that.hotmain, 'hot', that.page, 'page')
					// uni.hideNavigationBarLoading(); //关闭加载动画
				})
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/index.scss';
	page{
		background: #fff;
	}
	.pagehot{
		
		background: #fff;
	}
	.empty{
		z-index: -1;
	}
	.search{
		color: #333;
		font-size: 24upx;
		line-height: 55upx;
	}
	.hot_main_con{
		box-shadow:0px 2rpx 22rpx 0px rgba(0,0,0,0.1);
		position: relative;
		.topleftcorner {
			position: absolute;
			top: 0;
			left: 0;
			width: 84rpx;
			height: 36rpx;
			background: -webkit-linear-gradient(315deg, #ffa57f 0%, #ff5252 100%);
			background: linear-gradient(135deg, #ffa57f 0%, #ff5252 100%);
			border-radius: 10rpx 0 20rpx 0;
			color: #fff;
			font-size: 20rpx;
			text-align: center;
			line-height: 36rpx;
		
		}
	}
	.searchs{
		display: flex;
		flex-direction: column;
		.searchtitle{
			width: 100%;
			display: flex;
			justify-content: space-around;
			height:88upx;
			padding-top: 10upx;
			align-item: center;
			.left{
				width: 8%;
				height: 60upx;
				line-height: 60upx;
				padding-left: 20upx;
			}
			.right{
				width: 95%;
				height: 60upx;
				display: flex;
				align-items: center;
				background: #f5f5f5;
				border-radius: 30upx;
				input{
					font-size: 30upx;
					color:lightgray;
					padding-left: 20upx;
				}
				view{
					margin-left:20upx;
				}
				
			}
			
		}
		.pagehot{
			width: 100%;
			padding-top: 10upx;
			flex: 1;
			
		}
	}
	
</style>
