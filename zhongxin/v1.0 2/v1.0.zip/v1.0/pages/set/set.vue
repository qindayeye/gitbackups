<template>
	<view class="container">
		<view class="fle list-cell b-b m-t clear" hover-class="cell-hover" :hover-stay-time="50">
			<image class="portrait fl" :src="userArr.user_picture || 'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/missing-face.png'"></image>
			<text class="cell-tit fl clefr" >{{userArr.nick_name}}</text>
		</view>
		<view class="list-cell clear flexw"  hover-class="cell-hover" :hover-stay-time="50">
			<text class="cell-tit fl">昵称:</text>
			<input class="inp fl" type="text" v-model="name"  />
		</view>
		<view class="list-cell clear flexw"  hover-class="cell-hover" :hover-stay-time="50">
			<text class="cell-tit fl">性别:</text>
			<input class="inp fl" type="text" v-model="babyon" placeholder="请选择您的性别" @click="getsex()"/>
		</view>
		<view class="list-cell b-b clear" @click="navTo('/pages/address/address')" hover-class="cell-hover" :hover-stay-time="50">
			<text class="cell-tit fl">收货地址</text>
			<text class="cell-more fr yticon icon-you"></text>
		</view>
		<view class="list-cell m-t b-b clear" @click="navTo('/pages/help/help')" hover-class="cell-hover" :hover-stay-time="50">
			<text class="cell-tit fl">使用帮助</text>
			<text class="cell-more fr yticon icon-you"></text>
		</view>
		
		<button class="btn" @click="btnn()">保存</button>
		<!-- #ifdef H5 -->
		<!-- <button class="btn" @click="outLogin()">退出登录</button> -->
		<!-- #endif -->
		<view class="message" v-if="success">
			<view class="seximg">
				<view class="sexinfo boy"  @click="getsex('男')">
					<image :class="babyon=='男'?'babyon':''"  src="https://www.abcbook2019.com/mobile/public/images/plan/boy.png" mode="widthFix"></image>
					<text>男孩</text>
				</view>
				<view class="sexinfo gril"   @click="getsex('女')">
					<image  :class="babyon=='女'?'babyon':''" src="https://www.abcbook2019.com/mobile/public/images/plan/gril.png" mode="widthFix"></image>
					<text>女孩</text>
				</view>
			</view>
		</view>
		
	
	</view>
</template>

<script>
	import {  
	    mapMutations  
	} from 'vuex';
	export default {
		data() {
			return {
				userArr:[],
				name:"",
				success:false,
				babyon:"",
				sex:""
			};
		},
		onLoad(option) {
			
			// console.log(us)
			
			this.$api.quest('user',{},(res)=>{
				if (res.data.data.error == 1) {
					//清数据 缓存  
					uni.clearStorage();
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}else{
					let us= res.data.data.userInfo
					this.userArr=us
					this.name=us.nick_name
					this.babyon=us.sex==2?'女':'男'
				}
			})
		},
		methods:{
			// #ifdef H5
			outLogin(){
				uni.clearStorageSync()
				uni.navigateTo({
					url:'../index/index'
				})
			},
			// #endif
			navTo(url){
				uni.navigateTo({
					url
				})
			},
			getsex(babyon){
				this.babyon=babyon
				this.success=!this.success
			},
			btnn(){
				this.sex=='男'?1:2
				this.$api.quest('user/updateUserNews',{
					sex:this.babyon=='男'?1:2,
					nick_name:this.name
				},(res)=>{
					console.log(res)
					if(res.data.code==0){
						uni.navigateTo({
							url:'/pages/user/user'
						})
					}
				})
			}
		}
	}
</script>

<style lang='scss'>
	.flexw{
		display: flex;
		align-items: center;
	}
	.btn{
		background: #ff824b;
		color: #fff;
		width: 90%;
		margin: 0 auto;
		margin-top: 50rpx;
	}
	.message{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
		.close{
			position: absolute;
			width: 30rpx;
			height: 30rpx;
			top: 25%;
			right: 50rpx;
		}
		.seximg{
			position: absolute;
			top: 30%;
			left: 50%;
			transform: translate(-50%,0);
			width: 710rpx;
			margin: 0 auto;
			display: flex;
			justify-content:space-around;
			image{
				width: 126rpx;
				height: 126rpx;
				border-radius: 50%;
				border: 2rpx solid #fff;
				margin-bottom: 20rpx;
			}
			.sexinfo{
				display: flex;
				flex-direction: column;
				align-items: center;
				text{
					font-size: 28rpx;
					color: #fff;
					margin-top: 2%;
				}
				.babyon{
					border: 2rpx solid #FF824B;
				}
		}
	}
	}
	.inp{
		color: #303133;
		font-size: 30rpx;
		line-height: 60rpx;
	}
	page{
		background: $page-color-base;
	}
	.portrait{
		width: 120rpx;
		height: 120rpx;
		border-radius: 50%;
	}
	.fle{
		display: block !important;
		
	}
	.clefr{
		margin: 0;
		margin-left: 50rpx;
		line-height: 120rpx;
	}
	.list-cell{
		/* display:flex; */
		width: 100%;
		/* align-items:baseline; */
		padding: 20upx $page-row-spacing;
		line-height:60upx;
		position:relative;
		background: #fff;
		/* justify-content: center; */
		&.log-out-btn{
			margin-top: 40upx;
			.cell-tit{
				color: $uni-color-primary;
				text-align: center;
				margin-right: 0;
			}
		}
		&.cell-hover{
			background:#fafafa;
		}
		&.b-b:after{
			left: 30upx;
		}
		&.m-t{
			margin-top: 16upx; 
		}
		.cell-more{
			align-self: flex-end !important;
			font-size:$font-lg;
			color:$font-color-light;
			margin-left:10upx;
		}
		.cell-tit{
			/* flex: 1; */
			align-self: flex-start;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			margin-right:10upx;
		}
		.cell-tip{
			font-size: $font-base;
			color: $font-color-light;
		}
		switch{
			transform: translateX(16upx) scale(.84);
		}
	}
</style>
