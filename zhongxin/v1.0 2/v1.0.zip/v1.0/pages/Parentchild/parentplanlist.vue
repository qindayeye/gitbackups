<template>
	<view class="Parentchild">
		<listCell :title.default="msg"></listCell>
		<view class="banner">
			<image src="https://www.abcbook2019.com/mobile/public/img/parenting/banner.png" mode=""></image>
		</view>
		<view class="evaluating">
			<h4>评估结果</h4>
			<view class="plan">您一年大约陪伴宝宝阅读<text>{{paList.year_num}}</text>本书籍哦</view>
			<view class="iconimg">
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/erke.png" mode=""></image>
					<text>更有效的陪伴</text>
				</view>
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/yuedu.png" mode=""></image>
					<text>更多的知识</text>
				</view>
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/toubu.png" mode=""></image>
					<text>促进智力发展</text>
				</view>
			</view>
			<view class="clockcard">
				<view class="expe">
					第<text>{{qishu}}</text>期
				</view>
				<h4>我和宝宝的10本阅读计划</h4>
				<view class="periods">
					<view class="num">
						<text class="numb">{{num?num:0}}</text>
						<text class="add">/{{paList.books.length}}</text>
						<text class="add font">本</text>
					</view>
					<view class="stocks">书单处标记已读完成打卡</view>
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/LOGO.png" mode=""></image>
				</view>
				<view class="progress">
					<view class="within" :style="'width:' + num*11 + '%'"></view>
					<view class="remark">
						<text class="remark_read">起点</text>
						<text>1</text>
						<text>2</text>
						<text>3</text>
						<text>4</text>
						<text>5</text>
						<text>6</text>
						<text>7</text>
						<text>8</text>
						<text>9</text>
					</view>
					
					<image v-if="num==paList.books.length" class="medal_j" src="https://www.abcbook2019.com/mobile/public/img/parenting/medal_j.png" mode=""  ></image>
					<image v-else class="medal_h" src="https://www.abcbook2019.com/mobile/public/img/parenting/medal_h.png" mode=""  ></image>
				</view>
			</view>
			<view class="Recommendation page">
				<view class="page_title title">
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
					<text>定制书单</text>
				</view>
				<view class="detailbooklist">
					<navigator url="" class="everybook" v-for="(item,index) in paList.books">
						<image class="bookimg" :src="item.goods_thumb" mode="widthFix"></image>
						<view class="hot_main_con">
							<view class="bookinfo">
								<view class="fl">
									<text class="bookinfotitl">{{item.goods_name}}</text>
									<view class="boxint">
										<text class="introduce">
										{{item.goods_brief}}
										</text>
									</view>
								</view>
								<button class="excha" :class="{read:item.is_read==1}" :disabled="item.is_read" @click.stop="Changeread(item,item.goods_id)">打卡</button>
							</view>
						</view>
						<view class="czdkuaile" v-if="item.fmbd==3">
							家长必读
						</view>
					</navigator>
				</view>
			</view>
		</view>
		<view class="floor_di">
			<view class="with btn" @click="gotohom()">返回首页</view>
			<button class="che btn" open-type="share" >分享书单</button>
		</view>
	</view>
</template>

<script>
	import Vue from 'vue'
	export default{
		data(){
			return {
				paList:[],
				num:"",
				qishu:1
			}
		},
		onLoad(option) {
			this.$api.quest('plan/planlist',{},(res)=>{
				console.log(res)
				this.paList=res.data.data;
				this.num=res.data.data.read_number
				this.qishu=res.data.data.qishu
			})
		},
		methods:{
			Changeread(item,id){
				this.$api.quest('plan/changeread',{
					// id:id,
					goods_id:id
				},(res)=>{
					console.log(res)
					Vue.set(item,"is_read",1)
					this.num=res.data.data.num
				})
			},
			gotohom(){
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			onShareAppMessage: function (res) {
						 let that = this;
			   if (res.from === 'button') {
			
			   }
			   return {
			     title: this.paList.share_data.title,
			     path: '/pages/index/index?cat_id='+that.cat_id+'&is_show='+that.is_show+'&u='+uni.getStorageSync("user_id"),
						  imageUrl: that.cat_icon,
			     success: function (res) {
			       console.log('成功', res)
			     }
			   }
			 },
			sharelist(){
				
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/Parentchild.scss';
	@import '../../static/css/detiallist.scss';
	.bookimg{
		width: 187rpx !important;
		height: 187rpx !important;
	}
	.czdkuaile{
			position: absolute;
			top: 0;
			left: 0;
			width: 128rpx;
			line-height: 39rpx;
			text-align: center;
			color: #fff;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
			border-radius:0px 100rpx 100rpx 0px;
			font-size: 24rpx;
		}
	.page .detailbooklist .everybook .hot_main_con .bookinfo .bookinfotitl{
		width: 300rpx !important;
	}
	.page .detailbooklist .everybook .hot_main_con .bookinfo .boxint {
		width: 300rpx !important;
	}
	.excha{
		width:124rpx;
		height:60rpx;
		background:rgba(255,255,255,1);
		border-radius:40rpx;
		border:1rpx solid rgba(255,130,75,1);
		color: #FF824B;
		font-size: 28rpx;
		line-height: 60rpx;
		text-align: center;
	}
	.read{
		background: #e6e6e6;
		color: #fff;
		box-shadow: none;
		border: none;
		outline-style:none;
	}
	.medal_j{
		position: absolute;
		top: -25rpx;
		right: -33rpx;
		width: 68rpx;
		height: 77rpx;
		z-index: 999;
	}
</style>
