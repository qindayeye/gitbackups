<template>
	<view class="account">
		<listCell :title.default="msg"></listCell>
		<view class="content">
			<view class="title">
				一、什么是糖豆？
			</view>
			<view class="description">
				糖豆是ABCbook平台专属积分，糖豆可以用于换购会员、兑换优惠券、糖豆商城抵现，参与糖豆抽奖等活动。
			</view>
			<view class="title">
				二、如何获取糖豆？
			</view>
			<view class="description">
				1、ABCbook借书及还书“交易成功”获得糖豆：还书完验成功后系统自动发放至对应账户。
			</view>
			<view class="description">
				2、ABCbook官方活动赠送：ABCbook组织的活动赠送糖豆，会在活动详情中明示具体发放时间及发放方法。
			</view>

			<view class="title">
				三、糖豆如何使用？
			</view>
			<view class="description">
				1、可以在ACBbook兑换优惠券、礼品等；
			</view>
			<view class="description">
				2、可以在 “会员中心”兑换糖豆权益；
			</view>
			<view class="description">
				3、参与平台举办的糖豆活动，如“小糖豆抽大奖”活动
			</view>
			<view class="title">
				四、糖豆的规则有哪些？
			</view>
			<view class="description">
				1、糖豆可以累积，有效期至少为1年，即从获得开始至次年年底，逾期自动作废（如若交易在使用的糖豆有效期之外发生退款，该部分糖豆不予退还）；
				
			</view>
			<view class="description">
				2、糖豆的数值精确到个位（小数点后全部舍弃，不进行四舍五入）），例如：原价169元的商品，返16（169*0.1=16）个糖豆；
				
			</view>
			<view class="description">
				4、会员在借书还书完成时，个人中心订单状态显示为“已完成”，才能得到此次交易的相应糖豆；	
			</view>
			<view class="description">
				5、会员在使用糖豆时，优先消耗旧糖豆（如会员糖豆由去年3月份和今年5月份共同累积，则优先消耗去年3月份的糖豆）；
				
			</view>
			<view class="description">
				6、糖豆不能兑现，不可转让。
			</view>
			
		</view>
	</view>
</template>

<script>
	import listCell from '@/components/title-top';
	export default {
		data() {
			return {
				msg: "糖豆规则",

			}
		},
		components: {
			listCell

		},

		methods: {

		}
	}
</script>

<style lang="scss">
	.account {
		background-color: #FFFFFF;

		.content {
			border-top: 1rpx solid #CCCCCC;
			padding:0 40rpx 0 40rpx ;

			.title {
				margin-top: 40rpx;
				margin-bottom: 20rpx;
				height: 50rpx;
				font-size: 32rpx;
				font-family: PingFangSC-Medium, PingFang SC;
				font-weight: 500;
				color: rgba(255, 130, 75, 1);
				line-height: 50rpx;
			}

			.description {
				margin-bottom: 20rpx;
				font-size: 28rpx;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: rgba(102, 102, 102, 1);
				line-height: 44rpx;
			}
		}

	}
</style>
