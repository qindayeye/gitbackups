<template>
	<view>
		<view  class="contentok">
			<view class="goods-section">
				<view class="g-header b-b">
					<image class="logo" src="https://ktoss.oss-cn-beijing.aliyuncs.com/mini/images/logo.png"></image>
					<text class="name">还书信息</text>
					<text class="fr shopname">京东物流上门取书</text>
				</view>
				<!-- 商品列表 -->
				<view class="g-item page_expert_main clear booksinfolist">
					<image v-for="(item,index) in goodsData" :src="item.goods_thumb" mode=""></image>
				</view>
			</view>
			<!-- 地址 -->
			<navigator url="/pages/address/address?source=3" class="address-section">
				<view class="order-content">
					<text class="yticon icon-shouhuodizhi"></text>
					<view class="cen">
						<view class="top">
							<text class="name">{{addressData.consignee}}</text>
							<text class="mobile">{{addressData.mobile}}</text>
						</view>
						<text class="address">{{addressData.user_address?addressData.user_address:''}}{{addressData.address}}</text>
					</view>
					<text class="yticon icon-you"></text>
				</view>
			</navigator>
			
			
			<!-- 备注 -->
			<view class="yt-list">
				<view class="yt-list-cell desc-cell">
					<text class="cell-tit clamp">订单备注</text>
					<input class="desc" type="text" v-model="desc" placeholder="选填,最多50个字" maxlength="50" placeholder-class="placeholder" />
				</view>
			</view>
			
		</view>
		<view class="contentok hint">
			<view class="h5">温馨提示</view>
			<view class="tex">1. 请确认上门取书的地址，如有调整请点击重新填写；</view>
			<view class="tex">2.请准备好此次订单的所有书籍及借阅清单，等待京东小哥上门取书；</view>
			<view class="tex">3. 客服电话：<text>400-850-8556</text>   客服微信：abcbook007</view>
		</view>
		<button type="primary" class="button" :disabled="btn" @click="primary()">提交</button>
	</view>
</template>

<script>
	import mpvueCityPicker from '@/components/mpvue-citypicker/mpvueCityPicker.vue'
	export default {
		data() {
			return {
				// mulLinkageTwoPicker: cityData,
				cityPickerValueDefault: [0, 0, 0],
				themeColor: '#007AFF',
				provinceDataList:[],
				addressData:[],
				pickerText: '请选择城市',
				address:"请输入详细地址",
				pickerValueDefault: [0],
				pickerValueArray:[],
				goodsData:[],
				rec_id:null,
				order_id:null,
				return_address:null,
				addressee:null,
				mobile:null,
				province:null, 
				country:null,
				city:null,
				district:null,
				consignee:null,
				returnaddress:"",
				btn:false
			}
		},
		components: {
			// mpvuePicker,
			mpvueCityPicker
		},
		onLoad(option) {
			console.log(option)
			// let rec=option.rec;
			
			if(option.rec){
				uni.setStorageSync('apprec',option.rec)
				uni.setStorageSync('apporder',option.order)
			}
			// let orderid=option.order;
			// this.rec=rec;
			// this.order=orderid;
			this.$api.quest('user/ApplyReturn', {
				rec_id:uni.getStorageSync('apprec'),
				order_id:uni.getStorageSync('apporder')
			}, (res) => {
				console.log(res.data.data)
				this.goodsData=res.data.data.goods
				this.address=res.data.data.consignee.address;
				this.addressData=res.data.data.consignee
				this.pickerText = res.data.data.userinfo.user_address
				this.return_address = "备注",
				this.addressee=res.data.data.consignee.address,
				this.consignee=res.data.data.userinfo.consignee
				this.mobile=res.data.data.userinfo.mobile
				this.country=res.data.data.consignee.country
				this.province=res.data.data.consignee.province, 
				this.city=res.data.data.consignee.city,
				this.district=res.data.data.consignee.district
				// this.provinceDataList=res.data.data
				if ( option.type == 'addre') {
					this.addressData = JSON.parse(option.addressData)
					
				}
			})
			
		
			console.log(this.addressData)
			
		},
		methods: {
			
			primary(){
				this.btn=true
				this.$api.quest('user/submitApplyReturn', {
					rec_id: uni.getStorageSync('apprec'),
					order_id:uni.getStorageSync('apporder'), 
					return_address:this.addressData.address,   //具体街道
					addressee:this.addressData.consignee,      //姓名
					mobile :this.addressData.mobile,           //手机号
					country: 1,
					province: this.addressData.province_id ||this.addressData.province,       //
					city :this.addressData.city_id ||this.addressData.city,
					district:this.addressData.district_id || this.addressData.district
				}, (res) => {
					// this.btn=false
					console.log(res)
					if(res.data.code==1){
						uni.navigateTo({
							url:'/pages/order/createOrder?id='+this.order
						})
						uni.removeStorageSync('apprec')
						uni.removeStorageSync('apporder')
						
					}else{
						this.$api.msg(res.data.data)
					}
					
				})
			}
			
		},
		onBackPress() {
		  // if (this.$refs.mpvuePicker.showPicker) {
		  // 	this.$refs.mpvuePicker.pickerCancel();
		  //   return true;
		  // }
		  if (this.$refs.mpvueCityPicker.showPicker) {
		  	this.$refs.mpvueCityPicker.pickerCancel();
		    return true;
		  }
		},
		onUnload() {
			// if (this.$refs.mpvuePicker.showPicker) {
			// 	this.$refs.mpvuePicker.pickerCancel()
			// }
			if (this.$refs.mpvueCityPicker.showPicker) {
				this.$refs.mpvueCityPicker.pickerCancel()
			}
		}
		
	}
</script>

<style lang="scss">
	.button{
		position: fixed;
		bottom: 100rpx;
		left: 50%;
		transform: translate(-50%,0);
		width:710rpx;
		height:88rpx;
		background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		box-shadow:0rpx 4rpx 10rpx 0rpx rgba(255,130,75,0.5);
		border-radius:49rpx;
		color: #fff;
		font-size: 32rpx;
	}
	.hint{
		padding:30rpx;
		.h5{
			font-size: 26rpx;
			color: #666;
		}
		.tex{
			font-size: 24rpx;
			color: #999;
			margin-top: 5rpx;
			line-height: 38rpx;
			text{
				color: #5078E1;
			}
		}
	}
	.contentok{
		width: 710rpx;
		background: #fff;
		border-radius: 10rpx;
		margin: 20rpx auto;
		box-shadow:0px 2rpx 8rpx 0px rgba(0,0,0,0.05);
		overflow: hidden;
	}
	page {
		background:#F5F5F5;
		padding-bottom: 100upx;
	}
	.nodiv{
		min-height: 30vh;
		max-height: 70vh;
		display: flex;
		align-items: center;
		justify-content: center;

	}
	.nocou{
		font-size: 28rpx;
		text-align: center;
		color: #999;
	}
	.list {
		// width: 750rpx;
		margin: 0 auto;
		box-sizing: border-box;
		// padding: 20rpx;
		margin: 0 30rpx;
		background: #fff;

		.ann {
			font-size: 28rpx;
			color: #FF824B;
			padding-bottom: 20rpx;
		}
			
		.cardli {
			width: 650rpx;
			height: 108rpx;
			display: flex;
			align-items: center;
			box-sizing: border-box;
			margin-top: 20rpx;
			// padding: 10rpx 20rpx;
			// height: 140rpx;
			border: 1rpx solid #e6e6e6;
			// margin-top: 20rpx;
			border-radius: 10rpx;
			.cardlimg{
				width: 132rpx;
				height: 84rpx;
				margin-right: 10rpx;
			}
			.cardlcon{
				flex: 1;
			}
			.fl {
				text {
					display: block;
					font-size: 26rpx;
					color: #666;
				}

				.tit {
					font-size: 26rpx;
					color: #666;
					font-weight: bold;
					margin-bottom: 10rpx;
				}

				.con {
					color: #666;
					font-size: 20rpx;
				}
			}

			.fr {
				display: flex;
				align-items: center;
				// align-self: flex-end;
				color: #f69b18;
				font-size: 28rpx;
				margin-right: 30rpx;

			}
		}
		.packup{
			display: flex;
			text-align: center;
			justify-content: center;
			content: center;
			font-size: 26rpx;
			color: #999;
			margin-top: 30rpx;
			.xiangx{
				text-align: center;
				transform:rotate(90deg);
			}
			.shang{
				text-align: center;
				transform:rotate(90deg);
			}
		}
		.active {
			border: 1rpx solid #FF824B;
			background: #FFF0D6;
			color: #FF824B;
			.tit,.con{
				color: #FF824B !important;
			}
		}
	}

	.booksinfolist {
		height: 206rpx;
		overflow-x: scroll;
		white-space: nowrap;
		border-bottom: 1rpx dashed #e6e6e6;
		padding: 0;
		
		image {
			width: 144rpx;
			height: 144rpx;
			margin-right: 10rpx;
			margin-top: 30rpx;
		}

		&::-webkit-scrollbar {
			display: none
		}
	}

	.address-section {
		margin:0 30upx;
		background: #fff;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;
		.order-content {
			display: flex;
			height: 133rpx;
			align-items: center;
		}

		.icon-shouhuodizhi {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 90upx;
			color: #888;
			font-size: 44upx;
		}

		.cen {
			display: flex;
			flex-direction: column;
			flex: 1;
			font-size: 28upx;
			color: $font-color-dark;
		}

		.name {
			font-size: 34upx;
			margin-right: 24upx;
		}

		.address {
			margin-top: 16upx;
			margin-right: 20upx;
			color: $font-color-light;
		}

		.icon-you {
			font-size: 32upx;
			color: $font-color-light;
			// margin-right: 30upx;
		}

		.a-bg {
			position: absolute;
			left: 0;
			bottom: 0;
			display: block;
			width: 100%;
			height: 5upx;
		}
	}

	.goods-section {
		// margin-top: 16upx;
		background: #fff;
		padding-bottom: 1px;

		.g-header {
			display: flex;
			align-items: center;
			height: 79upx;
			margin: 0 30upx;
			position: relative;
			border-bottom: 1rpx dashed #e6e6e6;
			.shopname{
				width: 215rpx;
				line-height: 44rpx;
				background:rgba(255,205,120,0.3);
				border-radius: 6rpx;
				color: #FF824B;
				font-size: 24rpx;
				text-align: center;
			}
		}

		.logo {
			display: block;
			width: 50upx;
			height: 50upx;
			border-radius: 100px;
		}

		.name {
			font-size: 28upx;
			color: $font-color-base;
			margin-left: 24upx;
			flex: 1;
		}

		.g-item {
			display: flex;
			margin:0upx 30upx;
			height: 206rpx;
			image {
				flex-shrink: 0;
				display: block;
				width: 140upx;
				height: 140upx;
				border-radius: 4upx;
			}

			.right {
				flex: 1;
				padding-left: 24upx;
				overflow: hidden;
			}

			.title {
				font-size: 30upx;
				color: $font-color-dark;
			}

			.spec {
				font-size: 26upx;
				color: $font-color-light;
			}

			.price-box {
				display: flex;
				align-items: center;
				font-size: 32upx;
				color: $font-color-dark;
				padding-top: 10upx;

				.price {
					margin-bottom: 4upx;
				}

				.number {
					font-size: 26upx;
					color: $font-color-base;
					margin-left: 20upx;
				}
			}

			.step-box {
				position: relative;
			}
		}
	}

	.yt-list {
		margin-top: 16upx;
		background: #fff;
		.nedmoney{
			font-size: 28rpx;
			color: #333;
			.price{
				font-weight: bold;
				margin-right: 30rpx;
				line-height: 90rpx;
			}
		}
	}

	.yt-list-cell {
		display: flex;
		align-items: center;
		margin: 10upx 30upx;
		line-height: 70upx;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;

		&.cell-hover {
			background: #fafafa;
		}
		&:last-child{
			border: none;
		}
		&.b-b:after {
			left: 30upx;
		}
		.shopname{
			width: 170rpx;
			margin-left: 20rpx;
			line-height: 44rpx;
			background:rgba(255,205,120,0.3);
			border-radius: 6rpx;
			color: #FF824B;
			font-size: 24rpx;
			text-align: center;
		}
		.cell-icon {
			height: 32upx;
			width: 32upx;
			font-size: 22upx;
			color: #fff;
			text-align: center;
			line-height: 32upx;
			background: #f85e52;
			border-radius: 4upx;
			margin-right: 12upx;

			&.hb {
				background: #ffaa0e;
			}

			&.lpk {
				background: #3ab54a;
			}

		}

		.cell-more {
			align-self: center;
			font-size: 24upx;
			color: $font-color-light;
			margin-left: 8upx;
			margin-right: -10upx;
		}

		.cell-tit {
			flex: 1;
			font-size: 26upx;
			color: $font-color-light;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: 26upx;
			color: $font-color-dark;

			&.disabled {
				color: $font-color-light;
			}

			&.active {
				color: $base-color;
			}

			&.red {
				color: $base-color;
			}
		}

		&.desc-cell {
			.cell-tit {
				max-width: 120upx;
			}
		}

		.desc {
			flex: 1;
			font-size: $font-base;
			color: $font-color-dark;
		}
	
	}

	/* 支付列表 */
	.pay-list {
		padding-left: 40upx;
		margin-top: 16upx;
		background: #fff;

		.pay-item {
			display: flex;
			align-items: center;
			padding-right: 20upx;
			line-height: 1;
			height: 110upx;
			position: relative;
		}

		.icon-weixinzhifu {
			width: 80upx;
			font-size: 40upx;
			color: #6BCC03;
		}

		.icon-alipay {
			width: 80upx;
			font-size: 40upx;
			color: #06B4FD;
		}

		.icon-xuanzhong2 {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 40upx;
			color: $base-color;
		}

		.tit {
			font-size: 32upx;
			color: $font-color-dark;
			flex: 1;
		}
	}

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 995;
		display: flex;
		align-items: center;
		width: 100%;
		height: 98upx;
		justify-content: space-between;
		font-size: 30upx;
		background-color: #fff;
		z-index: 998;
		color: $font-color-base;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, .1);

		.price-content {
			padding-left: 30upx;
		}

		.price-tip {
			color: $base-color;
			margin-left: 8upx;
		}

		.price {
			font-size: 36upx;
			color: $base-color;
		}

		.submit {
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 0;
			border-radius: 0;
			width: 296upx;
			height: 100%;
			color: #fff;
			font-size: 32upx;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		}
	}

	/* 优惠券面板 */
	.mask {
		display: flex;
		align-items: flex-end;
		position: fixed;
		left: 0;
		top: var(--window-top);
		bottom: 0;
		width: 100%;
		background: rgba(0, 0, 0, 0);
		z-index: 9995;
		transition: .3s;

		.mask-content {
			width: 100%;
			min-height: 30vh;
			max-height: 70vh;
			background: #f3f3f3;
			transform: translateY(100%);
			transition: .3s;
			overflow-y: scroll;
			-webkit-overflow-scrolling: touch;
		}

		&.none {
			display: none;
		}

		&.show {
			background: rgba(0, 0, 0, .4);

			.mask-content {
				transform: translateY(0);
			}
		}
	}

	/* 优惠券列表 */
	.coupon-item {
		display: flex;
		flex-direction: column;
		margin: 20upx 24upx;
		background: #fff;

		.con {
			display: flex;
			align-items: center;
			position: relative;
			height: 120upx;
			padding: 0 30upx;

			&:after {
				position: absolute;
				left: 0;
				bottom: 0;
				content: '';
				width: 100%;
				height: 0;
				border-bottom: 1px dashed #f3f3f3;
				transform: scaleY(50%);
			}
		}

		.left {
			display: flex;
			flex-direction: column;
			justify-content: center;
			flex: 1;
			overflow: hidden;
			height: 100upx;
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			margin-bottom: 10upx;
		}

		.time {
			font-size: 24upx;
			color: $font-color-light;
		}

		.right {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-size: 26upx;
			color: $font-color-base;
			height: 100upx;
		}

		.price {
			font-size: 44upx;
			color: $base-color;

			&:before {
				content: '￥';
				font-size: 34upx;
			}
		}

		.tips {
			font-size: 24upx;
			color: $font-color-light;
			line-height: 60upx;
			padding-left: 30upx;
		}

		.circle {
			position: absolute;
			left: -6upx;
			bottom: -10upx;
			z-index: 10;
			width: 20upx;
			height: 20upx;
			background: #f3f3f3;
			border-radius: 100px;

			&.r {
				left: auto;
				right: -6upx;
			}
		}
	}
</style>
