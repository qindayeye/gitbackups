<template>
	<!-- 双十二秒杀下单 -->
	<view class="container">
		<view class="carousel">
			<image :src="list.goods_img[0].img_url" class="loaded" mode=""></image>
			<view class="actEndTime">{{countDownList}}</view>
		</view>

		<view class="introduce-section">
			<text class="bttitle">{{list.presale.goods_name}}</text>
			<view class="price">￥{{list.presale.shop_price}}</view>
		</view>
		<view class="introduce-section clear">
			<text class="title fl">预售规则</text>
			<view class="infocon fl">
				<view class="confl fl">
					<text class="ti">定金</text>
					<text class="num">{{list.presale.deposit}}</text>
				</view>
				<view class="confl fl">
					<text class="ti">尾款</text>
					<text class="num">{{list.presale.final_payment}}</text>
				</view>
				<view class="confl fl">
					<text class="ti">立减</text>
					<text class="num">{{list.presale.discount}}</text>
				</view>
			</view>
		</view>
		<view class="detail-desc">
			<view class="d-header">
				<text>图文详情</text>
			</view>
			<rich-text :nodes="desc|formatRichText " class="imgdetail"></rich-text>
		</view>

		<!-- <uni-evaluate :list-data="listev" :rate="reted"/> -->
		<!-- 底部操作菜单 -->
		<view class="page-bottom">
				<button  type="primary" v-if="!finished"  class="btnf" @click.stop="paycheckout(list.goods_id)">支付定金</button>
				<button  type="primary" v-else  class="btnf ghui" >活动已结束</button>
		</view>

	</view>
</template>

<script>
	import share from '@/components/share';
	import uniEvaluate from '@/components/xiujun-evaluate/uni-evaluate.vue';

	export default {
		components: {
			share,
			uniEvaluate
		},
		data() {
			return {
				list: {},
				hotmain: [],
				is_collect: false,
				desc: ``,
				goods_id: 0,
				countDownList: '00天00时00分00秒',
				actEndTime: '2019-12-08 23:17:00',
				finished:true

			};
		},
		onShow() {
			this.$nextTick(()=>{
				this.countDown();
			})
		},
		onLoad(option) {
			// console.log(option.id, 'opt')

			var that = this;
			var id = option.id;
			
			this.$api.quest('goods/getPresaleDetail',{
				id:id
			},(res)=>{
					
					that.list = res.data.data
					that.goods_id = that.list.goods_id
					that.is_collect = that.list.is_collect ? true : false
					if (that.list.goods.goods_info.goods_desc.indexOf('style="float:none;"') > 0) {

						var str = that.list.goods.goods_info.goods_desc.replace('style="float:none;"', '')
						var reg = new RegExp('style="float:none;"', "gi");
						var a = str.replace(reg, "");
						console.log(a, 'desc')
						that.desc = a.replace(/<img/gi,
							'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
					} else {
						that.desc = that.list.goods.goods_info.goods_desc.replace(/<img/gi,
							'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
					}
					
					if(res.data.data.presale.status==0 || res.data.data.presale.status==2){
						this.finished=true
					}else{
						this.finished=false
					}
					// this.finished=res.data.data.presale.is_finished
					this.actEndTime=res.data.data.presale.end_time
					console.log(that.list, that.desc, res.data.data.root_path)


				})

		},

		methods: {
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			countDown(it) {
				var interval = setInterval(() => {
					// 获取当前时间，同时得到活动结束时间数组
					let newTime = new Date().getTime();
					// 对结束时间进行处理渲染到页面
					let endTime = new Date(this.actEndTime).getTime();
					let obj = null;
					// 如果活动未结束，对时间进行处理
					if (endTime - newTime > 0) {
						let time = (endTime - newTime) / 1000;
						// 获取天、时、分、秒
						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
					} else { // 活动已结束，全部设置为'00'
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00'
						};
						this.finished=true
						clearInterval(interval);
					}
					this.countDownList = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
				}, 1000);
			},
			gohome() {
				this.$store.commit("change_page", 0)
				uni.reLaunch({
					url: `/pages/index/index`
				})
			},
			bookshelf() {
				uni.reLaunch({
					url: `/pages/bookrack/bookrack`
				})
			},
			paycheckout(id) {
				let goid = id
				this.$api.quest('cart/addpresale', {
				id: id,
							num: 1,
							uid: uni.getStorageSync("user_id"),
							attr_id: 1,
							act_id: 0,
							rec_type: 5,
							extension_code: "presale",
							is_checked: 1
				}, (res) => {
						console.log(res)
							if (res.data.code == 0) {
								uni.navigateTo({
									url: '/pages/flow/doublemember?goid=' + goid
								})
							} else if (res.data.data.error) {
								this.$store.commit("change_page", 4)
								// #ifdef H5
								// 判断微信内外
								var ua = window.navigator.userAgent.toLowerCase();
								console.log(ua)
								// console.log(ua.indexOf('micromessenger') != -1)
								// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
								if (ua.match(/MicroMessenger/i) == 'micromessenger') {
									// 微信内浏览器（公众号）
									console.log("公众号")
									uni.navigateTo({
										url: '/pages/public/login'
									})
								
								} else {
									uni.navigateTo({
										url: '/pages/public/registerSJ'
									})
								}
								// #endif
								
								// #ifdef MP
								uni.navigateTo({
									url: '/pages/public/login'
								})
								// #endif
							}
					})
				
			},
			addBook() {
				if (uni.getStorageSync("token")) {
					const that = this;
					console.log(that.goods_id)
					this.$api.quest('cart/add', {
						id: that.goods_id,
						num: 1,
						uid: uni.getStorageSync("user_id"),
						attr_id: 1,
						rec_type: 0,
						is_checked: 1,
						act_id: 0
					}, (res) => {
						console.log(res, 'res')
						if (res.data.code == 0) {
							uni.showToast({
								title: "加入成功",
								icon: 'none',
								duration: 2000
							});
							uni.setStorageSync('total_number', res.data.data.total_number);
						}
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			//分享
			// share(){
			// 	this.$refs.share.toggleMask();	
			// },
			//收藏
			toFavorite(id) {
				if (uni.getStorageSync("token")) {
					this.$api.quest('user/collect/add', {
						id: id,
						uid: uni.getStorageSync("user_id")
					}, (res) => {
						if (res.data.data == 1) {
							this.is_collect = !this.is_collect;
						}

					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			}
		},
		filters: {
			/**
			 * 处理富文本里的图片宽度自适应
			 * 1.去掉img标签里的style、width、height属性
			 * 2.img标签添加style属性：max-width:100%;height:auto
			 * 3.修改所有style里的width属性为max-width:100%
			 * 4.去掉<br/>标签
			 * @param html
			 * @returns {void|string|*}
			 */
			formatRichText(html) { //控制小程序中图片大小
				let newContent = html.replace(/<img[^>]*>/gi, function(match, capture) {
					match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
					match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
					match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
					return match;
				});
				newContent = newContent.replace(/style="[^"]+"/gi, function(match, capture) {
					match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi, 'max-width:100%;');
					return match;
				});
				newContent = newContent.replace(/<br[^>]*\/>/gi, '');
				newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:10rpx"');
				return newContent;
			}
		}


	}
</script>

<style lang='scss' scoped>
	/* @import '../../static/css/public.scss'; */
	/* @import '../../../static/public.scss'; */
	page{
		padding: 0;
		margin: 0;
	}
	.actEndTime {
		background: rgba(0, 0, 0, .4);
		padding: 20rpx  40rpx;
		color: #fff;
		font-size: 28rpx;
		position: absolute;
		border-radius: 40rpx;
		position: absolute;
		bottom: 20rpx;
		left: 20rpx;
	}

	.container {
		width: 100%;
		display: flex;
		flex-direction: column;
		margin-bottom: 60upx;
	}

	.carousel {
		width: 100%;
		height: auto;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: relative;
	}

	/* 标题简介 */
	.introduce-section {
		background: #fff;
		padding: 30upx 30upx;

		.bttitle {
			font-size: 30rpx;
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			height: 60upx;
			line-height: 60upx;
		}

		.infocon {
			.confl {
				.ti {
					background: #FF824B;
					padding: 0 10rpx;
					color: #fff;
					line-height: 34rpx;
					font-size: 26rpx;
					border-radius: 20rpx;
					margin-left: 20rpx;
				}

				.num {
					color: #666;
					line-height: 34rpx;
					font-size: 26rpx;
				}
			}
		}

		.price-box {
			display: flex;
			align-items: baseline;
			height: 64upx;
			padding: 10upx 0;
			font-size: 26upx;
			color: $uni-color-primary;
		}

		.price {
			font-size: 42rpx;
			color: #FF824B;
			margin-top: 20rpx;
		}

		.m-price {
			margin: 0 12upx;
			color: $font-color-light;
			text-decoration: line-through;
		}

		.coupon-tip {
			align-items: center;
			padding: 4upx 10upx;
			background: $uni-color-primary;
			font-size: $font-sm;
			color: #fff;
			border-radius: 6upx;
			line-height: 1;
			transform: translateY(-4upx);
		}

		.bot-row {
			display: flex;
			align-items: center;
			height: 50upx;
			font-size: $font-sm;
			color: $font-color-light;

			text {
				flex: 1;
			}
		}
	}

	/* 分享 */
	.share-section {
		display: flex;
		align-items: center;
		color: $font-color-base;
		background: linear-gradient(left, #fdf5f6, #fbebf6);
		padding: 12upx 30upx;

		.share-icon {
			display: flex;
			align-items: center;
			width: 70upx;
			height: 30upx;
			line-height: 1;
			border: 1px solid $uni-color-primary;
			border-radius: 4upx;
			position: relative;
			overflow: hidden;
			font-size: 22upx;
			color: $uni-color-primary;

			&:after {
				content: '';
				width: 50upx;
				height: 50upx;
				border-radius: 50%;
				left: -20upx;
				top: -12upx;
				position: absolute;
				background: $uni-color-primary;
			}
		}

		.icon-xingxing {
			position: relative;
			z-index: 1;
			font-size: 24upx;
			margin-left: 2upx;
			margin-right: 10upx;
			color: #fff;
			line-height: 1;
		}

		.tit {
			font-size: $font-base;
			margin-left: 10upx;
		}

		.icon-bangzhu1 {
			padding: 10upx;
			font-size: 30upx;
			line-height: 1;
		}

		.share-btn {
			flex: 1;
			text-align: right;
			font-size: $font-sm;
			color: $uni-color-primary;
		}

		.icon-you {
			font-size: $font-sm;
			margin-left: 4upx;
			color: $uni-color-primary;
		}
	}

	.c-list {
		font-size: $font-sm + 2upx;
		color: $font-color-base;
		background: #fff;

		.c-row {
			display: flex;
			align-items: center;
			padding: 20upx 30upx;
			position: relative;
		}

		.tit {
			width: 140upx;
		}

		.con {
			flex: 1;
			color: $font-color-dark;

			.selected-text {
				margin-right: 10upx;
			}
		}

		.bz-list {
			height: 40upx;
			font-size: $font-sm+2upx;
			color: $font-color-dark;

			text {
				display: inline-block;
				margin-right: 30upx;
			}
		}

		.con-list {
			flex: 1;
			display: flex;
			flex-direction: column;
			color: $font-color-dark;
			line-height: 40upx;
		}

		.red {
			color: $uni-color-primary;
		}
	}

	/* 评价 */
	.eva-section {
		display: flex;
		flex-direction: column;
		padding: 20upx 30upx;
		background: #fff;
		margin-top: 16upx;

		.e-header {
			display: flex;
			align-items: center;
			height: 70upx;
			font-size: $font-sm + 2upx;
			color: $font-color-light;

			.tit {
				font-size: $font-base + 2upx;
				color: $font-color-dark;
				margin-right: 4upx;
			}

			.tip {
				flex: 1;
				text-align: right;
			}

			.icon-you {
				margin-left: 10upx;
			}
		}
	}

	.eva-box {
		display: flex;
		padding: 20upx 0;

		.portrait {
			flex-shrink: 0;
			width: 80upx;
			height: 80upx;
			border-radius: 100px;
		}

		.right {
			flex: 1;
			display: flex;
			flex-direction: column;
			font-size: $font-base;
			color: $font-color-base;
			padding-left: 26upx;

			.con {
				font-size: $font-base;
				color: $font-color-dark;
				padding: 20upx 0;
			}

			.bot {
				display: flex;
				justify-content: space-between;
				font-size: $font-sm;
				color: $font-color-light;
			}
		}
	}

	/*  详情 */

	.detail-desc {
		width: 100%;
		background: #fff;

		/* padding: 20upx 30upx; */
		img {
			width: 100%;
		}

		.imgdetail {
			width: 100%;
			text: 22upx;
			font-size: 30upx;
			line-height: 50upx;

		}

		.d-header {
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 80upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			position: relative;

			text {
				padding: 0 20upx;
				background: #fff;
				position: relative;
				z-index: 1;
			}

			&:after {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translateX(-50%);
				width: 300upx;
				height: 0;
				content: '';
				border-bottom: 1px solid #ccc;
			}
		}
	}

	/* 底部操作菜单 */
	.page-bottom {
		position: fixed;
		left: 30upx;
		bottom: 30upx;
		z-index: 95;
		display: flex;
		justify-content: space-around;
		align-items: center;
		width: 690upx;
		height: 100upx;
		/* background: rgba(255, 255, 255, .9); */
		box-shadow: 0 0 20upx 0 rgba(0, 0, 0, .5);
		border-radius: 16upx;
		.btnf{
			width:100%;
			line-height: 100rpx;
			background: #FF824B;
			color: #fff;
			font-size: 32rpx;
			
		}
		.ghui{
			background: #e6e6e6;
			color:#FF824B;
			font-weight: bold;
		}
		
		.p-b-btn {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: $font-sm;
			color: $font-color-base;
			width: 96upx;
			height: 80upx;

			.yticon {
				font-size: 40upx;
				line-height: 48upx;
				color: $font-color-light;
			}

			&.active,
			&.active .yticon {
				color: $uni-color-primary;
			}

			.icon-fenxiang2 {
				font-size: 42upx;
				transform: translateY(-2upx);
			}

			.icon-shoucang {
				font-size: 46upx;
			}
		}

		.action-btn-group {
			/* display: flex; */
			height: 76upx;
			border-radius: 100px;
			overflow: hidden;
			box-shadow: 0 20upx 40upx -16upx #fd8a54;
			box-shadow: 1px 2px 5px rgba(219, 63, 96, 0.4);
			/* background: linear-gradient(to right, #ffac30, #fd8a54, #F56C6C); */
			margin-left: 20upx;
			position: relative;

			.action-btn {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 95vw;
				height: 100%;
				font-size: $font-base;
				padding: 0;
				border-radius: 0;
				background: #FD2E32;
			}
		}
	}
</style>
