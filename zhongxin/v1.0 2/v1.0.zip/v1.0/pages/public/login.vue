<template>
	<view class="container">
		<view class="login-icon">
			<image class="login-img" src="https://ktoss.oss-cn-beijing.aliyuncs.com/mini/images/logo.png"></image>
		</view>
		<view class="login-icon">
			<text>ABCbook国际亲子阅读</text>
		</view>
		<view class="login-icon2">
			<text class="login-text">请完成微信授权以继续使用</text>
		</view>
		<view class="loginBtnView">
			<!-- #ifdef MP -->
			<button class="loginBtn" open-type="getUserInfo" @getuserinfo="getuserinfo" withCredentials="true">微信授权用户信息</button>
			<!-- #endif -->
			<!-- #ifdef H5 -->
			<button class="loginBtn" @click="GzhLogin()">微信授权用户信息</button>
			<!-- #endif -->
			<button class="loginBtn" @click="gotohome()" style="background: #1AAD19;">再去逛逛</button>
		</view>
	</view>
</template>

<script>
	import Vue from 'vue'
	export default {
		data() {
			return {
				mobile: '',
				password: '',
				logining: false,
				primarySize: 11,
				type: '' ,//跳转状态，返回当前页还是两页
				code:''
			}
		},
		onLoad(option) {
			var that = this
			console.log(option, 'option')
			this.type = option.type
			this.customer = option.customer
			// #ifdef H5
			let url =  window.location.href
			if (new RegExp(".*\\b" + 'code' + "\\b(\\s*=([^&]+)).*", "gi").test(url)) {
				that.code = RegExp.$2;
				that.$api.quest('user/getaccesstoken', {
					code: that.code
				}, (res) => {
					console.log(res, 'code')
					uni.setStorageSync('openid', res.data.openid);
					uni.setStorageSync('token', res.data.token);
					uni.setStorageSync('unionid', res.data.unionid);
					uni.setStorageSync('user_id', res.data.user_id);
					if(res.data.mobile){
						console.log('登录成功')
						uni.setStorageSync('mobile', res.data.mobile);
						if(uni.getStorageSync('HDurl')){
							window.location.href=uni.getStorageSync('HDurl')
						}else{
							window.location.href='https://www.abcbook2019.com/mobile/h5/#/pages/index/index'
						}												
						// uni.navigateTo({
						// 	url:'../index/index'
						// })			
					}else{
						uni.navigateTo({
							url:'./registerSJ'
						})
					}
				})
			}
			// #endif

		},
		methods: {
			GzhLogin(){
				// 微信内浏览器（公众号）
				console.log("公众号")
				this.$api.quest('user/getcode', {
					callback: "https://www.abcbook2019.com/mobile/h5/#/pages/public/login"
				}, (res) => {
					console.log(res, 'cobak')				
					// #ifdef H5
					window.location.href = res.data
					// #endif					
				})			
			},
			
			inputChange(e) {
				const key = e.currentTarget.dataset.key;
				this[key] = e.detail.value;
			},
			navTo(url) {
				uni.navigateTo({
					url
				})
			},
			navBack() {
				uni.navigateBack();
			},
			onGetPhoneNumber(e) {
				uni.getProvider({
					service: 'oauth',
					success: function(res) {
						// console.log(res.provider);
						//支持微信、qq和微博等
						if (~res.provider.indexOf('weixin')) {
							uni.login({
								provider: 'weixin',
								success: function(loginRes) {
									var that = this
									that.$api.quest('user/mobile', {
										'encryptedData': encodeURI(e.detail.encryptedData),
										'iv': encodeURI(e.detail.iv),
										'code': encodeURI(loginRes.code)
									}, (res) => {
										if (res.data.code == 1) {
											that.$api.msg('获取手机号失败，请手动输入')
										} else {
											console.log(res.data);
											console.log(res.data.phoneNumber);
										}
									})
								}
							});
						}
					}
				});
			},
			getuserinfo: function(e) {
				uni.getProvider({
					service: 'oauth',
					success: (res) => {
						console.log(res.provider);
						//支持微信、qq和微博等
						if (~res.provider.indexOf('weixin')) {
							uni.login({
								provider: 'weixin',
								success: (loginRes) => {
									uni.setStorageSync('code', res.code);
									// 获取用户信息 
									uni.getUserInfo({
										provider: 'weixin',
										success: (infoRes) => {
											infoRes.userInfo.customer = this.customer
											this.$api.quest('user/login', {
												'encryptedData': infoRes.encryptedData,
												'userinfo': infoRes.userInfo,
												'code': loginRes.code,
												'iv': infoRes.iv,
											}, (res) => {
												console.log(res, "res")
												uni.setStorageSync('user_info', infoRes.userInfo);
												uni.setStorageSync('mobile', res.data.mobile_phone);
												uni.setStorageSync('user_id', res.data.user_id);
												uni.setStorageSync('token', res.data.token);
												uni.setStorageSync('openid', res.data.openid);
												if (res.data.mobile_phone == "") {
													uni.navigateTo({
														url: '/pages/public/register?type=' + this.type
													})
												} else {
													 let pages = getCurrentPages(); // 当前页面
													 let beforePage = pages[pages.length - 2]; // 前一个页面
													 // console.log("beforePage");
													 // console.log(beforePage);
													 uni.navigateBack({
													     success: function() {
													         beforePage.onLoad(); // 执行前一个页面的onLoad方法
													     }
													 });
													
												}
											})
										}
									});
								}
							});
						}
					}
				});
			},
			gotohome() {
				uni.reLaunch({
					url: '/pages/index/index'
				})
			},
		},
	}
</script>

<style lang='scss'>
	page {
		height: 100%;
	}

	.container {
		height: 100%;
		display: flex;
		flex-direction: column;
		padding: 0;
		box-sizing: border-box;
		background-color: #F2F2F2
	}

	.login-icon {
		flex: none;
		width: 100%;
		text-align: center;
		margin-top: 10upx;
	}

	.login-icon2 {
		margin-top: 200upx;
		text-align: center;
	}

	.login-img {
		margin-top: 200upx;
		width: 200upx;
		height: 200upx;
		border-radius: 35upx;
		border: #DCDFE6 solid 1px;
	}

	.login-text {
		color: #4399FC;
		font-size: 14px;
	}



	.login-from {
		margin-top: 20upx;
		flex: auto;
		height: 100%;
	}

	.inputView {
		background-color: #fff;
		line-height: 44upx;
	}

	.nameImage,
	.keyImage {
		margin-left: 18upx;
		margin-top: 10upx;
		width: 20upx;
		height: 20upx
	}

	.loginLab {
		margin: 15upx 15upx 15upx 10upx;
		color: #545454;
		font-size: 14upx
	}

	.inputText {
		flex: block;
		float: right;
		text-align: right;
		margin-right: 22upx;
		margin-top: 11upx;
		color: #cccccc;
		font-size: 14upx
	}

	.line {
		width: 100%;
		height: 1upx;
		background-color: #cccccc;
		margin-top: 1upx;
	}

	.loginBtnView {
		width: 100%;
		height: auto;
		background-color: #f2f2f2;
		margin-top: 0upx;
		margin-bottom: 0upx;
		padding-bottom: 0upx;
	}

	.registerBtnView {
		width: 100%;
		height: auto;
		background-color: #f2f2f2;
		margin-top: 0upx;
		margin-bottom: 0upx;
		padding-bottom: 0upx;
		border: none;
	}

	.registerBtn::after {
		border: none;
	}

	.loginBtn {
		width: 80%;
		background-color: #FA6C3A;
		margin-top: 35upx;
		border-radius: 15upx;
		color: #ffffff;
	}

	.registerBtn {
		width: 50%;
		height: 40upx;
		color: #ffcc33;
		background-color: #f2f2f2;
		margin-top: 35upx;
		border: none;
	}
</style>
