<template>
	<view class="RecDetail">
		<!-- <listCell :title.default="msg"></listCell> -->
		<view class="banner">
			<image :src="RecDetail.cat_icon" mode=""></image>
		</view>
		<view class="booktitle">
			<view class="introduction">
				<h4>{{RecDetail.cat_name}}</h4>
				<!-- #ifdef MP -->
				<button class="btn" open-type="share">分享书单</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn" @click="H5share()">分享书单</button>
				<!-- #endif -->
			</view>
			<view class="writerinfo">
				<h5>书单简介：</h5>
				<view class="wr-info">
					{{RecDetail.cat_desc}}
					</view>
			</view>
		</view>
		<view class="page pagehot">
			<view class="title clear">
				<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
				<text>推荐书单</text>
			</view>
			<view class="detailbooklist">
				<block v-for="(item,index) in goods_list" :key='index'>
					<navigator class="everybook" :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
						<image class="bookimg" :src="item.goods_thumb" mode=""></image>
						<view class="hot_main_con">
							<view class="bookinfo">
								<view class="fl">
									<text class="bookinfotitl">{{item.goods_name}}</text>
									<view class="boxint">
										<view class="label">
											<text v-for="(item,index) in item.more_cat" :key='index'>{{item.cat_name}}</text>
										</view>
										<text class="information">{{item.author}}</text>
										<!-- <text class="introduce">
											{{item.goods_brief}}
										</text> -->
										
									</view>
								</view>
								<image class="add" @click.stop="addBook(item,item.goods_id,item.goods_stock)" :src="item.cat_status==2 && item.goods_number>0?'https://www.abcbook2019.com//mobile/public/img/recbooklist/z_liang.png':'https://www.abcbook2019.com/mobile/public/img/recbooklist/z_hui.png'" mode=""></image>
							</view>
						</view>
						<!-- <text class="topleftcor" v-if="item.cat_name">{{item.cat_name}}</text> -->
					</navigator>
				</block>
			</view>
			
		</view>
		
		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		<goCar :carnum='goodsnum'></goCar>
	</view>
</template>

<script>
	import Vue from 'vue'
	import listCell from '@/components/title-top';
	import goCar from '@/components/car.vue';
	export default {
		data() {
			return {
				H5Fx:false,
				RecDetail:{},
				page:1,  // 上拉刷新页数
				classon:false, //判断模态框
				msg:"书单详情",
				hide:true,
				cat_id:0,
				is_show:1,
				goods_list:[],
				cat_icon:'',
				cat_desc:'',
				cat_name:'',
				classoninfo:"" ,
				goodsnum:""
			}
		},
		components: {
			listCell,
			goCar	
		},
		onLoad: function(options) {
			let that = this;
			that.cat_id =options.cat_id;
			that.is_show =options.is_show;
			console.log(that.cat_id);
			this.$api.quest('index/getRecBooklistNews',{
				cat_id:that.cat_id,
				page:that.page,
				is_show:that.is_show,
				}, (res) => {
				console.log(res.data.data)
				that.RecDetail = res.data.data.rec
				that.cat_icon = that.RecDetail.cat_icon
				that.shareimg = that.RecDetail.share_icon
				that.cat_name = that.RecDetail.cat_name
				that.cat_desc = that.RecDetail.cat_desc
				that.goods_list = res.data.data.goods_list
			})
			this.timer=setInterval(()=>{
				this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
				this.goodsnum=uni.getStorageSync("total_number")
				// console.log(this.goodsnum)
			}, 500)
		},
		onUnload() {
			if(this.timer) {  
				clearInterval(this.timer);  
				this.timer = null;  
			}  
		},
		onReachBottom(){
			this.scroll();
			
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
		 if(Object.scrollTop>800){
			 this.hide=false;
		 }else{
			 this.hide=true;
		 }
		},
		
		 onShareAppMessage: function (res) {
			 let that = this;
		    return {
		      title: that.cat_name,
		      path: '/pages/RecDetail/RecDetail?cat_id='+that.cat_id+'&is_show='+that.is_show+'&u='+uni.getStorageSync("user_id"),
			  imageUrl:that.shareimg?that.shareimg:that.cat_icon,
		      success: function (res) {
		        console.log('成功', res)
		      }
		    }
		  },
		methods: {
			// #ifdef H5
			H5share(){
				uni.navigateTo({
					url:'../H5fxhb/H5fxhb?url='+window.location.href+'&cat_icon='+this.cat_icon+'&cat_name='+this.cat_name+'&cat_desc='+this.cat_desc
				})
			},
			// #endif
			gotop(){
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			addBook(e,id,num){
				this.$api.addBook(e,id,num)
			},
			// 下拉加载
			scroll(){
				const that=this;
				// console.log(that.classon)
				that.classon=true;
				that.classoninfo="正在努力加载..."
				this.loadingType=1;
				const scrollrequest=this.$api.quest('index/getRecBooklistNews',{
					cat_id:that.cat_id,
					page:++that.page,
					is_show:that.is_show,
					},(res)=>{
					// console.log(res.data.goods_list)
					if (res.data.data.goods_list.length==0) {  //没有数据
					    that.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
					    uni.hideNavigationBarLoading();//关闭加载动画
					    return;
					}
						this.goods_list.push(...res.data.data.goods_list) 
						  uni.hideNavigationBarLoading();//关闭加载动画
						 this.classon=false   //判断模块框
						// console.log(that.goods_list,'hot',that.page,'page')
						uni.hideNavigationBarLoading();//关闭加载动画
				})
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/RecDetail.scss';
	.classon{
		margin-top: 50rpx;
	}
</style>
