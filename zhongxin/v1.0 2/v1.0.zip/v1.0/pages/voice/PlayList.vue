<template>
	<view class="">
		<view v-if="ifPlayList" class="ceshi" @click="ceshi()"><image src="../../static/musiclist.png" mode=""></image></view>
		<view v-else class="H5mengB" @click.stop="ceshi()">
			<view class="play_list" @click.stop="ddd()">
				<view class="list_header">
					<view class="list_header_vip">
						<uni-notice-bar :show-icon="true" :scrollable="true" :single="true" text="加入会员畅听无阻,加入会员即可享受专业1对1书单推荐!" />
					</view>
					<view class="btn" @click="goutoaddjoin()">开通会员</view>
				</view>
				<view class="list_header">
					<view class="list_header_name_active" @click="PlayAll()" v-if="list.length > 0">播放全部({{ list.length }})</view>
					<view class="list_header_name" v-else>播放全部({{ list.length }})</view>
					<image class="PlayImg" @click="PlayIt()" v-if="!isPlayState" src="../../static/play.png" mode=""></image>
					<image class="PlayImg" @click="PlayIt()" v-else src="../../static/pause2.png" mode=""></image>
					<view class="three_btn">
						<image @click="gotoList()" src="https://www.abcbook2019.com/mobile/public/img/new/jrsj.png" mode=""></image>
						<text class="abcbook" style="font-size: 40rpx; margin-top: -9rpx;" @click="deleteList()">&#xe62f;</text>
					</view>
				</view>
				<scroll-view class="knowledgelsit" scroll-y>
					<view class="list_item" @click="gotoKnw(index)" v-for="(i, index) in list" :key="index">
						<view :class="[list_index == index ? 'list_item_title_active' : 'list_item_title']">{{ i.goods_name }}</view>
						<image v-if="list_index == index&&isPlayState" class="list_item_category_img" src="../../static/voiceing.gif" mode=""></image>
						<view v-else class="list_item_category">音频</view>
						<image class="closeImg" src="../../static/close.png" mode="" @click.stop="splice(index)"></image>
					</view>
					<view style="font-size: 26rpx;color: #999999;height: 100rpx;text-align: center;line-height: 100rpx;">{{ list.length > 0 ? '到底儿了哦~' : '空空如也~' }}</view>
				</scroll-view>
				<view class="showBtn" @click="isShow()">关闭~</view>
			</view>
		</view>
		<view class="message" v-if="nojoin">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="hopop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/addjoin.png" mode=""></image>
				<view class="poptitle">{{ poptitle }}</view>
				<view class="subhead">{{ subhead }}</view>
				<button type="primary" class="addjoin" v-if="ctivate" @click="addactivate()">立即激活</button>
				<button type="primary" class="addjoin" v-else @click="addjoin()">立即加入</button>
			</view>
		</view>
	</view>
</template>

<script>
let innerAudioContext = '';
import uniNoticeBar from '@/components/uni-notice-bar/uni-notice-bar.vue';
import Vue from 'vue';
export default {
	components: {
		uniNoticeBar
	},
	data() {
		return {
			poptitle: '加入会员畅听无阻',
			subhead: '加入会员即可享受专业1对1书单推荐',
			nojoin: false, //加入会员弹框
			ctivate: false,
			list: [],
			list_index: 0, //当前播放的音频
			ifPlayList: true, // 是否显示播放列表
			isPlayState: false
		};
	},
	created() {
		this.updateList();
	},
	methods: {
		// 关闭弹框
		close() {
			console.log('关闭弹框');
			this.nojoin = false;
		},
		// 跳转加入会员
		addjoin() {
			this.nojoin = true;
			uni.navigateTo({
				url: '/pages/index/addjoin'
			});
		},
		goutoaddjoin(){
			uni.navigateTo({
				url: '/pages/index/addjoin'
			});
		},
		// 跳转激活会员
		addactivate() {
			uni.navigateTo({
				url: '/pages/members/members'
			});
		},
		// 更新列表
		updateList() {
			console.log('开');
			// console.log(Vue)
			this.list = this.$store.state.music.Playlist;
			this.list_index = this.$store.state.music.music_index; // 列表中正在播放的音乐位置
			// console.log(this.list, this.list_index, this.list[this.list_index].audio_url);
			if (Vue.prototype.$innerAudioContext && !Vue.prototype.$innerAudioContext.paused) {
				// 如果有正在播放的音乐
				this.isPlayState = true
			} else {
				this.isPlayState = false
			}
		},
		PlayIt() {
			// 判断是不是会员
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				// 单独暂停或播放
				if (Vue.prototype.$innerAudioContext) {
					// 如果有音乐正在播放
					innerAudioContext = Vue.prototype.$innerAudioContext;
					console.log(innerAudioContext.paused, 'sssss');
					if (innerAudioContext.paused) {
						// 停止或暂停
						console.log('停止或暂停');
						innerAudioContext.play();
						this.$emit('updateVoivefodid', 1);
						this.isPlayState = true;
						console.log('走到着了', '73');
						innerAudioContext.onEnded(() => {
							//放完一首
							console.log('走到着了', '76');
							this.isPlayState = false;
							this.onended();
						});
					} else {
						//正在播放
						console.log('正在播放');
						innerAudioContext.pause();
						this.isPlayState = false;
						this.$emit('updateVoivefodid', -1);
					}
				} else {
					console.log('没有音乐播放');
					// 没有音乐播放
					if (this.list.length > 0) {
						this.updateList();
						setTimeout(() => {
							this.creatMusic();
						}, 500);
					} else {
						console.log('列表为空');
					}
				}
			} else if (uni.getStorageSync('no_apply') !== 0) {
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活的会员  激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
		},
		Play() {
			if (Vue.prototype.$innerAudioContext) {
				// 如果有音乐正在播放
				innerAudioContext = Vue.prototype.$innerAudioContext;
				console.log(innerAudioContext.paused, 'sssss');
				if (innerAudioContext.paused) {
					// 停止或暂停
					this.isPlayState = false;
					console.log('停止或暂停');
				} else {
					//正在播放
					console.log('正在播放');
					innerAudioContext.onEnded(() => {
						//放完
						console.log('走到着了', '65');
						this.isPlayState = false;
						this.onended();
					});
				}
			} else {
				console.log('没有音乐播放');
				// 没有音乐播放
				if (this.list.length > 0) {
					this.creatMusic();
				} else {
					console.log('列表为空');
				}
			}
		},
		// 从头开始播放全部
		PlayAll() {
			// 判断是不是会员
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				this.list_index = 0;
				this.$store.commit('setMusicIndex', 0); // 同上  必须同时执行
				this.list = this.$store.state.music.Playlist;
				if (Vue.prototype.$innerAudioContext) {
					// 如果有音乐正在播放
					// 结束
					innerAudioContext.destroy();
					innerAudioContext = '';
					delete Vue.prototype.$innerAudioContext;
					this.isPlayState = false;
					console.log('销毁成功否');
					this.$emit('updateVoivefodid', -1);
					if (this.list.length > 0) {
						this.$emit('updateVoivefodid', 1);
						this.creatMusic();
					} else {
						console.log('列表为空');
					}
				} else {
					console.log('没有音乐播放');
					// 没有音乐播放
					if (this.list.length > 0) {
						this.$emit('updateVoivefodid', 1);
						this.creatMusic();
					} else {
						console.log('列表为空');
					}
				}
			} else if (uni.getStorageSync('no_apply') !== 0) {
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活的会员  激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
		},
		ceshi() {
			this.ifPlayList = !this.ifPlayList;
			this.list = this.$store.state.music.Playlist;
		},
		ddd() {
			console.log('阻止冒泡');
		},
		// 关闭播放列表
		isShow() {
			this.ceshi();
		},
		gotoList() {
			// 跳转列表页
			uni.navigateTo({
				url: './index'
			});
		},
		deleteList() {
			//清空播放列表
			this.$store.commit('emptyPlaylist'); // 仓库当前组件必须都清空
			this.list = []; // 仓库当前组件必须都清空
			this.list_index = 0;
			this.$store.commit('setMusicIndex', 0); // 同上  必须同时执行
			if (Vue.prototype.$innerAudioContext) {
				// 如果有音乐正在播放
				// 结束
				innerAudioContext.destroy();
				innerAudioContext = '';
				delete Vue.prototype.$innerAudioContext;
				this.isPlayState = false;
				this.$emit('updateVoivefodid', -1);
			} else {
				console.log('没有音乐播放');
				// 没有音乐播放
			}
		},
		// 播放这一首
		gotoKnw(index) {
			console.log('你大爷');
			// 判断是不是会员
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				this.list_index = index;
				this.$store.commit('setMusicIndex', index); // 同上  必须同时执行
				this.list = this.$store.state.music.Playlist;
				if (Vue.prototype.$innerAudioContext) {
					// 如果有音乐正在播放
					// 结束
					innerAudioContext.destroy();
					innerAudioContext = '';
					delete Vue.prototype.$innerAudioContext;
					this.isPlayState = false;
					console.log('销毁成功否');
					this.$emit('updateVoivefodid', -1);
					if (this.list.length > 0) {
						this.$emit('updateVoivefodid', 1);
						this.creatMusic();
					} else {
						console.log('列表为空');
					}
				} else {
					console.log('没有音乐播放');
					// 没有音乐播放
					if (this.list.length > 0) {
						this.$emit('updateVoivefodid', 1);
						this.creatMusic();
					} else {
						console.log('列表为空');
					}
				}
			} else if (uni.getStorageSync('no_apply') !== 0) {
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活的会员  激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
			
			
		},
		splice(index) {
			//删除
			// this.list.splice(index, 1); // 删除
			console.log(this.list_index);
			this.$store.commit('subPlaylist', index); // 同上，效果一样 ,不能同时用
			//如果删除的音频是在正在播放的音频之前的
			if (this.list_index > index) {
				this.list_index--;
			} else if (this.list_index == index) {
				console.log('lll');
				innerAudioContext.destroy();
				innerAudioContext = '';
				delete Vue.prototype.$innerAudioContext;
				this.isPlayState = false;
				this.$emit('updateVoivefodid', -1);
				// 当要删除的是正在播放的音频时
				this.list_index = -1;
			}
			console.log(this.list_index);
			console.log(this.$store.state.music.Playlist);
		},
		//创建音频
		creatMusic() {
			console.log('走到着了');
			innerAudioContext = uni.createInnerAudioContext();
			innerAudioContext.obeyMuteSwitch = false;
			// innerAudioContext.autoplay = true;// 自动播放
			Vue.prototype.$innerAudioContext = innerAudioContext;
			innerAudioContext.src = this.list[this.list_index].audio_url;
			innerAudioContext.play();
			this.isPlayState = true;
			console.log('走到着了', '47');
			innerAudioContext.onEnded(() => {
				//放完一首
				console.log('走到着了', '50');
				this.isPlayState = false;
				this.onended();
			});
		},
		//触发音频结束事件
		onended() {
			if (this.list_index >= this.list.length) {
				// 列表循环结束
				this.list_index = 0;
				this.$store.commit('setMusicIndex', 0); // 同上  必须同时执行
				innerAudioContext.destroy();
				innerAudioContext = '';
				delete Vue.prototype.$innerAudioContext;
				this.$emit('updateVoivefodid', -1);
			} else {
				// 下一曲
				innerAudioContext.destroy();
				innerAudioContext = '';
				//销毁====================
				this.list_index++; // 同下 必须同时执行
				this.$store.commit('addMusicIndex'); // 同上  必须同时执行
				console.log(this.$store.state.music.music_index);
				console.log(this.list_index);
				this.creatMusic();
				this.$emit('updateVoivefodid', 1);
			}
		}
	},
	computed: {}
};
</script>
<style lang="scss" scoped>
// 不是会员加入会员
.message {
	width: 100vw;
	height: 100vh;
	position: fixed;
	top: 0;
	left: 0;
	background: rgba(0, 0, 0, 0.5);
	z-index: 99999999;

	.close {
		position: absolute;
		width: 30rpx;
		height: 30rpx;
		top: 25%;
		right: 50rpx;
	}

	.hopop {
		width: 488rpx;
		height: 628rpx;
		background: #fff;
		position: absolute;
		top: 30%;
		left: 50%;
		margin-left: -244rpx;
		border-radius: 24rpx;
		z-index: 4;
		text-align: center;

		image {
			width: 378rpx;
			height: 318rpx;
			margin: 35rpx auto 20rpx auto;
		}

		> .poptitle {
			font-size: 34rpx;
			color: #ff824b;
			letter-spacing: 1rpx;
			margin-bottom: 10rpx;
		}

		.subhead {
			font-size: 26rpx;
			color: #666;
			margin-bottom: 47rpx;
		}

		.addjoin {
			margin-top: -10rpx;
			margin-bottom: 40rpx;
			padding: 0;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			width: 408rpx;
			line-height: 88rpx;
			border-radius: 49rpx;
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			font-size: 32rpx;
			color: #fff;
		}
	}
}
.ceshi {
	z-index: 99999;
	height: 80rpx;
	width: 80rpx;
	border-radius: 50%;
	background: #fff;
	box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.3);
	border: 2rpx solid rgba(255, 205, 120, 1);
	position: fixed;
	top: 60%;
	right: 14rpx;
	display: flex;
	justify-content: center;
	align-items: center;
	image {
		height: 50rpx;
		width: 50rpx;
	}
}

.H5mengB {
	position: fixed;
	top: 0;
	left: 0;
	height: 100%;
	width: 100%;
	z-index: 998;
	background: rgba(0, 0, 0, 0.6);
}
.play_list {
	overflow: hidden;
	border: #ffffff;
	border-top-right-radius: 20rpx;
	border-top-left-radius: 20rpx;
	background-color: #ffffff;
	width: 710rpx;
	z-index: 9999;
	position: fixed;
	left: 20rpx;
	bottom: 0;
}
.list_header {
	height: 88rpx;
	width: 710rpx;
	display: flex;
	justify-content: space-between;
	align-items: center;
	.list_header_vip {
		margin-top: 20rpx;
		margin-left: 20rpx;
		width: 480rpx;
	}
	.PlayImg {
		height: 50rpx;
		width: 50rpx;
	}
	.btn {
		margin-right: 20rpx;
		height: 60rpx;
		padding: 0;
		background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
		width: 250rpx;
		text-align: center;
		line-height: 60rpx;
		border-radius: 30rpx;
		box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
		font-size: 28rpx;
		color: #fff;
	}
	.list_header_name {
		margin-left: 20rpx;
		color: #909399;
	}
	.list_header_name_active {
		margin-left: 20rpx;
		color: rgba(250, 108, 58, 1);
	}
	.three_btn {
		margin-right: 20rpx;
		height: 80rpx;
		width: 150rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		image {
			height: 38rpx;
			width: 38rpx;
		}
	}
}
.knowledgelsit {
	height: 650rpx;
	width: 710rpx;
}
.list_item {
	width: 100%;
	height: 80rpx;
	// border-top: #c0c0c0 solid 1rpx;
	border-bottom: #c0c0c0 solid 1rpx;
	display: flex;
	justify-content: space-around;
	align-items: center;
	
	.closeImg{
		height: 30rpx;
		width: 30rpx;
	}

	.list_item_category {
		width: 70rpx;
		height: 32rpx;
		font-size: 22rpx;
		font-family: PingFangSC-Regular, PingFang SC;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		text-align: center;
		line-height: 32rpx;
		border: #8f8f94 1rpx solid;
	}
	.list_item_category_img {
		width: 50rpx;
		height: 40rpx;
		background-color: #ffffff;
	}

	.list_item_title {
		width: 494rpx;
		height: 60rpx;
		font-size: 26rpx;
		font-family: PingFangSC-Medium, PingFang SC;
		font-weight: 900;
		color: #333333;
		line-height: 60rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.list_item_title_active {
		width: 494rpx;
		height: 60rpx;
		font-size: 26rpx;
		font-family: PingFangSC-Medium, PingFang SC;
		font-weight: 900;
		color: rgba(250, 108, 58, 1);
		line-height: 60rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	image {
		width: 36rpx;
		height: 36rpx;
	}
}
.showBtn {
	height: 80rpx;
	width: 100%;
	border-top: 1rpx solid #cccccc;
	color: #999999;
	font-size: 32rpx;
	font-weight: 300;
	text-align: center;
	line-height: 80rpx;
}
</style>
