<template>
	<view class="voiceindex">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg" vioc="true"></listCell>
		<!-- #endif -->
		<view class="navbar">
			<text class="nav-item" @click="chickList(888)" :class="{ active: tabCurrentIndex == 888 }">全部</text>
			<text v-for="(item, index) in navList" :key="index" @click="chickList(index)" class="nav-item" :class="{ active: tabCurrentIndex == index }">{{ item.listname }}</text>
		</view>
		<view class="dingb">
			<view class="listcon" v-for="(item, index) in chicList" :key="index">
				<view class="title">
					<image src="../../static/img/index/pageicon.png" mode=""></image>
					<text>{{ item.listname }}</text>
				</view>
				<view class="voivecon">
					<view class="everyvoice" v-for="(el, ind) in item.list" :key="ind" @click="gotolist(el.cat_id, el)">
						<view class="image">
							<!-- <view class="bgimg" :style='{backgroundImage: "url("+el.video_icon+")" } '>
							
							</view> -->
							<image class="bgimg" :src="el.video_icon" mode=""></image>
						</view>
						<view class="mian">
							<text class="tit">{{ el.cat_name }}</text>
							<text class="mincon">共 {{ el.cat_num }} 本</text>
						</view>
						<!-- <view class="state" v-if="el.playState" @click.stop="playall(el, el.cat_id, item.list)">
							<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/zanting.png" mode=""></image>
							<text class="payst">暂停</text>
						</view> -->
						<view class="state" @click.stop="playall(el, el.cat_id, item.list,el.cat_num)">
							<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/bofang.png" mode=""></image>
							<text class="payst">播放</text>
						</view>
					</view>
				</view>
			</view>
		</view>

		<view class="message" v-if="nojoin">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="hopop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/addjoin.png" mode=""></image>
				<view class="poptitle">{{ poptitle }}</view>
				<view class="subhead">{{ subhead }}</view>
				<button type="primary" class="addjoin" v-if="ctivate" @click="addactivate()">立即激活</button>
				<button type="primary" class="addjoin" v-else @click="addjoin()">立即加入</button>
			</view>
		</view>
		<!-- 测试用 -->
		<PlayList @updateVoivefodid="updateVoivefodid" ref="PlayList" v-if="isshowPlayList"></PlayList>
	</view>
</template>

<script>
let innerAudioContext;
import Vue from 'vue';
import PlayList from './PlayList.vue';
import listCell from '@/components/title-top';
export default {
	components: {
		listCell,
		PlayList
	},
	data() {
		return {
			poptitle: '加入会员畅听无阻',
			subhead: '加入会员即可享受专业1对1书单推荐',
			ctivate: false,
			msg: '有声绘本',
			tabCurrentIndex: 0,
			navList: [], //循环列表
			chicList: [], // 子循环列表
			hotmain: [], //点击分类下子分类
			audioPlaySrc: 0, //当前播放的歌曲index
			audioWay: 0, //播放方式 0顺序播放 1随机播放 2单曲循环
			playState: 0, //播放状态
			catid: '',
			nojoin: false, //加入会员弹框
			list: [], //点击分类子分类  判断catid  改变状态
			infolist: {
				type: 'voiceindex'
			},
			allmiao: 0,
			nowmiao: 0,
			isshowPlayList: false
		};
	},
	onReady() {
		console.log('onReady');
	},
	onShareAppMessage(res) {
		if (res.from === 'button') {
			// 来自页面内分享按钮
			console.log(res.target);
		}
		return {
			title: '有声绘本',
			path: '/pages/voice/index'
		};
	},
	onShow: function() {
		this.queryPlayList();
	},
	onLoad() {
		this.queryPlayList();
		// 获取会员等级
		this.$api.quest('user', {}, res => {
			uni.setStorageSync('user_ranks', res.data.data.userInfo.user_ranks);
			uni.setStorageSync('user_rank', res.data.data.userInfo.user_rank);
			uni.setStorageSync('no_apply', res.data.data.no_apply); //当前又没有待激活的卡
			if (res.data.data.error == 1) {
				//清数据 缓存
				uni.clearStorage();
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua);
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log('公众号');
					uni.navigateTo({
						url: '/pages/public/login'
					});
				} else {
					uni.navigateTo({
						url: '/pages/public/registerSJ'
					});
				}
				// #endif

				// #ifdef MP
				uni.navigateTo({
					url: '/pages/public/login'
				});
				// #endif
			}
			// console.log(res.data.data.error)
			// console.log(res.data.data)
			this.userArr = res.data.data;
			this.loading = true;
		});
		// console.log(111)
		this.$api.quest(
			'category/getcategorylist',
			{
				// page:1,
				// cat_id:0,
			},
			res => {
				if (res.data.data.error == 1) {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua);
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log('公众号');
						uni.navigateTo({
							url: '/pages/public/login'
						});
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						});
					}
					// #endif

					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					});
					// #endif
				} else {
					// console.log(res)
					this.tabCurrentIndex = 888;
					this.navList = res.data.data;
					this.chicList = res.data.data;
					// that.hotmain.push(...res.data.data)
					// this.loagings=true
				}
			}
		);
	},

	computed: {
		nowmiaoForc: function() {
			return this.$pubFuc.secondFormact(this.nowmiao);
		}
	},
	mounted() {
		this.audioPlaySrc = 0;
	},
	methods: {
		updateVoivefodid(isId) {
			// 更新当前正在播放的音频的id
			if (isId !== -1) {
				this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
			} else {
				this.voivegodid = isId;
				this.playState = 0;
			}
		},
		logincheck() {
			//登录验证
			if (uni.getStorageSync('token')) {
				return;
			} else {
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua);
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log('公众号');
					uni.navigateTo({
						url: '/pages/public/login'
					});
				} else {
					uni.navigateTo({
						url: '/pages/public/registerSJ'
					});
				}
				// #endif
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/public/login'
				});
				// #endif
			}
		},
		chickList(index) {
			if (index == 888) {
				this.tabCurrentIndex = index;
				this.chicList = this.navList;
			} else {
				this.tabCurrentIndex = index;
				this.chicList = [];
				this.chicList.push(this.navList[index]);
			}
		},
		plaState(el) {
			if (el.playState) {
				//暂停
				Vue.set(el, 'playState', 0);
				uni.setStorageSync('voivegodid', '');
				console.log(innerAudioContext, '==0');
				innerAudioContext.pause();
			} else {
				Vue.set(el, 'playState', 1);
				uni.setStorageSync('voivegodid', this.hotmain[this.audioPlaySrc].goods_id);
				console.log(innerAudioContext, '==1');
				innerAudioContext.play();
			}
		},
		// 关闭弹框
		close() {
			console.log('关闭弹框');
			this.nojoin = false;
		},
		// 跳转加入会员
		addjoin() {
			this.nojoin = true;
			uni.navigateTo({
				url: '/pages/index/addjoin'
			});
		},
		// 跳转激活会员
		addactivate() {
			uni.navigateTo({
				url: '/pages/members/members'
			});
		},
		gotolist(catid, el) {
			uni.navigateTo({
				url: '/pages/voice/voicelist?cat_id=' + catid + '&cat_name=' + el.cat_name
			});
		},
		// 查询播放列表是否为空
		queryPlayList(isPlay) {
			if (this.$store.state.music.Playlist.length > 0) {
				this.isshowPlayList = true;
				if (isPlay) {
					setTimeout(() => {
						//必须子组件完全渲染处理完成后才能调
						// console.log(this.playState,'ddddd')
						this.$refs.PlayList.PlayAll();
						// this.playState = 1;
						// this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
					}, 500);
				}
			} else {
				this.isshowPlayList = false;
			}
		},
		// 播放全部
		playAllTT() {
			if (this.$store.state.music.Playlist.length > 0) {
				// 如果列表中有数据
				// 先清空列表
				this.$refs.PlayList.deleteList();
				// 无音频 开始播放全部
				this.queryPlayList();
			}
			this.hotmain.forEach((item, index) => {
				if (item.audio_url) {
					this.$store.commit('addPlaylist', item);
				}
			});
			this.queryPlayList(true);
		},

		playall(el, cat_id, list,cat_num) {
			console.log(el, cat_id, list,cat_num)
			// 判断是不是会员
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				this.$api.quest(
					'goods/getpicturebook',
					{
						page: 1,
						cate: cat_id,
						type: 2,
						size: cat_num
					},
					res => {
						console.log(res, 'list');
						this.hotmain = res.data.data;
						this.list = list;
						console.log(this.hotmain);
						this.catid = cat_id;
						this.playAllTT();
					}
				);
			} else if (uni.getStorageSync('no_apply') !== 0) {
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活的会员  激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
		}
	}
};
</script>

<style lang="scss" scoped>
// 不是会员加入会员
.message {
	width: 100vw;
	height: 100vh;
	position: fixed;
	top: 0;
	left: 0;
	background: rgba(0, 0, 0, 0.5);
	z-index: 9;

	.close {
		position: absolute;
		width: 30rpx;
		height: 30rpx;
		top: 25%;
		right: 50rpx;
	}

	.hopop {
		width: 488rpx;
		height: 628rpx;
		background: #fff;
		position: absolute;
		top: 30%;
		left: 50%;
		margin-left: -244rpx;
		border-radius: 24rpx;
		z-index: 4;
		text-align: center;

		image {
			width: 378rpx;
			height: 318rpx;
			margin: 35rpx auto 20rpx auto;
		}

		> .poptitle {
			font-size: 34rpx;
			color: #ff824b;
			letter-spacing: 1rpx;
			margin-bottom: 10rpx;
		}

		.subhead {
			font-size: 26rpx;
			color: #666;
			margin-bottom: 47rpx;
		}

		.addjoin {
			margin-top: -10rpx;
			margin-bottom: 40rpx;
			padding: 0;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			width: 408rpx;
			line-height: 88rpx;
			border-radius: 49rpx;
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			font-size: 32rpx;
			color: #fff;
		}
	}
}

.dingb {
	margin-top: 88rpx;
}

.navbar {
	// margin-top: 60rpx;
	position: fixed;
	/* #ifdef MP */
	top: 0;
	/* #endif */
	/* #ifdef H5 */
	// top: 64rpx;
	/* #endif */
	width: 750rpx;
	line-height: 88rpx;
	background: #fff;
	overflow-x: scroll;
	-webkit-overflow-scrolling: touch;
	white-space: nowrap;
	z-index: 99;
	box-shadow: 0px 2rpx 8rpx 0px rgba(0, 0, 0, 0.1), 0px -1rpx 0px 0px rgba(230, 230, 230, 1);
	text {
		position: relative;
		display: inline-block;
		margin-left: 50rpx;
		color: #666;
		font-size: 30rpx;
		line-height: 50rpx;
	}
	.active {
		color: #ff824b;
		position: relative;
		font-size: 36rpx;
		font-weight: 900;
	}

	.active::before {
		display: block;
		content: '';
		position: absolute;
		width: 26rpx;
		height: 8rpx;
		bottom: -12rpx;
		left: 50%;
		transform: translate(-50%, 0%);
		background: #ff824b;
		border-radius: 4rpx;
	}

	&::-webkit-scrollbar {
		display: none;
	}
}

.title {
	height: 88upx;
	background: #f5f5f5;
	line-height: 88rpx;
	box-sizing: border-box;
	padding-left: 20rpx;

	// padding-top: 10rpx;
	image {
		width: 22upx;
		height: 26upx;
		margin-right: 10rpx;
	}

	text {
		font-size: 34rpx;
		font-weight: 600;
		color: rgba(51, 51, 51, 1);
		line-height: 48rpx;
	}

	.fr {
		text {
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	}
}

.voivecon {
	.everyvoice {
		display: flex;
		align-items: center;
		width: 710rpx;
		height: 194rpx;
		background: #fff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-bottom: 20rpx;
		box-shadow: 0rpx 2rpx 6rpx 0rpx rgba(0, 0, 0, 0.05);

		.image {
			position: relative;
			width: 134rpx;
			height: 134rpx;
			margin-left: 30rpx;

			.bgimg {
				position: relative;
				width: 134rpx;
				height: 134rpx;
				border-radius: 10rpx;
				background-size: 100%;
				background-repeat: no-repeat;
				background-position: 69% 20%;
				background-clip: content-box;
				z-index: 3;
			}

			&:after {
				position: absolute;
				top: 50%;
				right: -30rpx;
				margin-top: -46rpx;
				display: block;
				content: '';
				width: 134rpx;
				height: 94rpx;
				background: #f6f6f6;
				border-radius: 10rpx;
				z-index: 1;
			}

			&:before {
				position: absolute;
				top: 50%;
				right: -15rpx;
				margin-top: -57rpx;
				display: block;
				content: '';
				width: 134rpx;
				height: 114rpx;
				background: #e8e8e8;
				border-radius: 10rpx;
				z-index: 2;
			}
		}

		.mian {
			display: flex;
			flex: 1;
			justify-content: flex-start;
			margin-left: 50rpx;
			// align-items: center;
			flex-direction: column;

			.tit {
				font-size: 32rpx;
				color: #333;
				margin-bottom: 10rpx;
				font-weight: 500;
			}

			.mincon {
				font-size: 28rpx;
				color: #666;
			}
		}

		.state {
			display: flex;
			margin-right: 30rpx;
			flex-direction: column;
			align-items: center;

			image {
				width: 54rpx;
				height: 54rpx;
				margin-bottom: 5rpx;
			}

			.payst {
				font-size: 24rpx;
				color: #666;
			}
		}
	}
}
</style>
