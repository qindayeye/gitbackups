<template>
	<view class="sign">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="banner">
			<image src="https://www.abcbook2019.com/mobile/public/sign/images/qdbanner.png" mode=""></image>
			<view class="banner_info">
				<view>当前<text>{{pay_points?pay_points:0}}</text>糖豆</view>
				<view>坚持每天签到可获得更多糖豆</view>
			</view>
			<view class="bj">
				<view class="xx"></view>
			</view> 
		</view>
		<view class="calenDer">
			<uni-calendar :insert="true" :lunar="tags[0].checked" :disable-before="tags[3].checked" :start-date="startDate"
			 :end-date="endDate" :date="date" :selected="selected" />
			</uni-calendar>
			<view class="calendar_info">
				<view class="fl info">
					<view class="title">
						已连续签到{{continuity?continuity:0}}天
					</view>
					<view class="info_hint" v-if="continuity<=7">连续签到7天 得30颗糖豆</view>
					<view class="info_hint" v-else="continuity<=14">连续签到14天 得80颗糖豆</view>

					<!-- <view class="info_hint" v-else="continuity<=30">连续签到30天 送单次借阅卡一张</view> -->

				</view>
				<button type="primary" class="btn fr" :class="{intraday:intraday}" :disabled="intraday" @click="signed()">签到</button>
			</view>
		</view>
		<view class="page">
			<view class="noy">
				<text class="xl"></text>
				<text>连续签到奖励</text>
				<text class="xr"></text>
			</view>
			<view class="pagelist">
				<view class="listcon clear">
					<view class="day fl">
						<image src="https://www.abcbook2019.com/mobile/public/sign/images/num7.png" style="width: 32rpx;height: 48rpx;"></image>
						<text>天</text>
					</view>
					<view class="hint fl">
						送<text>30</text>颗糖豆
					</view>
					<button type="primary" class="getbtn fr" :class="{num7:num7}" :disabled="num7" @click.stop="draw(7)">{{num7?'已领取':'领取'}}</button>
				</view>
				<view class="listcon">
					<view class="day">
						<image src="https://www.abcbook2019.com/mobile/public/sign/images/num14.png" style="width: 54rpx;height: 48rpx;"></image>
						<text>天</text>
					</view>
					<view class="hint">
						送<text>80</text>颗糖豆
					</view>
					<button type="primary" class="getbtn" :class="{num14:num14}" :disabled="num14" @click.stop="draw(14)">{{num14?'已领取':'领取'}}</button>
				</view>
				<!-- <view class="listcon">
					<view class="day">
						<image src="https://www.abcbook2019.com/mobile/public/sign/images/num30.png" style="width: 60rpx;height: 48rpx;"></image>
						<text>天</text>
					</view>
					<view class="hint">
						<view class="">
							送<text>单次借阅卡</text>一张
						</view>
						<view class="tip">
							活动截止日期2020年2月1日
						</view>
					</view>
					<button type="primary" class="getbtn" v-if="!num30" :class="{num30:num30}" :disabled="num30" @click.stop="draw(30)">领取</button>
					<button type="primary" class="getbtn" v-else @click="gomenbers()">去查看</button>
				</view> -->
			</view>
		</view>
		<view class="page">
			<view class="noy">
				<text class="xl"></text>
				<text>糖豆兑换中心</text>
				<text class="xr"></text>
			</view>
			<view class="beansFor_info">
				<image src="https://www.abcbook2019.com/mobile/public/sign/images/left_sc.png" mode="widthFix" @click="navTo('/pages/Candy/CandyStore')"></image>
				<image src="https://www.abcbook2019.com/mobile/public/sign/images/right_hy.png" mode="widthFix" @click="hopeful()"></image>
			</view>
		</view>
		<view class="pop-up" v-if="sigIn">
			<view class="signIn">
				<image src="https://www.abcbook2019.com/mobile/public/img/pop-up/SignIn.png" mode=""></image>
				<view class="sinfo">您已连续签到<text>{{continuity}}</text>天</view>
				<button type="primary" @click="sigIng()">知道了</button>
			</view>
		</view>
		<view class="pop-up" v-if="sigInnum30 || sigInnum14 || sigInnum7">
			<view class="signIn">
				<image src="https://www.abcbook2019.com/mobile/public/img/pop-up/SignIn.png" mode=""></image>
				<view class="sinfo" style="margin-bottom: 10rpx;">恭喜获得签到奖励</view>
				<view class="coninfo" v-if="sigInnum30">您已连续签到够30天 获得一张体验卡</view>
				<view class="coninfo" v-if="sigInnum14">您已连续签到够14天 获得80颗糖豆</view>
				<view class="coninfo" v-if="sigInnum7">您已连续签到够7天 获得30颗糖豆</view>
				<view class="singbtn" v-if="sigInnum30">
					<button type="primary" @click="sigIng()">知道了</button>
					<button type="primary" @click="gomenbers()">去激活</button>
				</view>
				<button class="top40" type="primary" v-else @click="sigIng()">知道了</button>

			</view>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	
	// #endif
	// import calendar from "@/components/uni-calendar";
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	export default {
		components: {
			// #ifdef H5
			listCell,
			// #endif
			uniCalendar
		},

		data() {
			function getDate(date, AddMonthCount = 0, AddDayCount = 0) {
				if (typeof date !== 'object') {
					date = date.replace(/-/g, '/')
				}
				let dd = new Date(date)
				dd.setMonth(dd.getMonth() + AddMonthCount) // 获取AddDayCount天后的日期
				dd.setDate(dd.getDate() + AddDayCount) // 获取AddDayCount天后的日期
				let y = dd.getFullYear()
				let m = dd.getMonth() + 1 < 10 ? '0' + (dd.getMonth() + 1) : dd.getMonth() + 1 // 获取当前月份的日期，不足10补0
				let d = dd.getDate() < 10 ? '0' + dd.getDate() : dd.getDate() // 获取当前几号，不足10补0
				return y + '-' + m + '-' + d
			}
			let tags = [{
					id: 0,
					name: '农历',
					checked: false,
					attr: 'lunar'
				},
				{
					id: 1,
					name: '开始日期(' + getDate(new Date(), -1) + ')',
					checked: false,
					value: getDate(new Date(), -1),
					attr: 'startDate'
				},
				{
					id: 2,
					name: '结束日期(' + getDate(new Date(), 2) + ')',
					value: getDate(new Date(), 2),
					checked: false,
					attr: 'endDate'
				},
				{
					id: 3,
					name: '禁用今天之前的日期',
					checked: false,
					attr: 'disableBefore'
				},
				{
					id: 4,
					name: '自定义当前日期(' + getDate(new Date(), 1) + ')',
					value: getDate(new Date(), 1),
					checked: false,
					attr: 'date'
				},
				{
					id: 5,
					name: '范围选择',
					checked: false,
					attr: 'range'
				},
				{
					id: 6,
					name: '打点',
					value: getDate(new Date(), 0),
				}
			]

			return {
				msg: "签到",
				tags,
				date: '',
				sigIn: false, //弹框
				intraday: false, //今日是否签到
				logining: false,
				continuity: 0, //签到天数
				pay_points: "",
				startDate: '',
				endDate: '',
				num30: true,
				sigInnum30: false,
				sigInnum14: false,
				sigInnum7: false,
				num14: true,
				num7: true,
				timeData: {
					clockinfo: '',
					date: '',
					fulldate: '',
					lunar: '',
					month: '',
					range: '',
					year: ''
				},
				selected: [],
				infoShow: false,
				showCalendar: false,
			}
		},
		onShow() {
			this.sign()
		},
		onLoad() {},
		methods: {
			navTo(url) {
				if (uni.getStorageSync("token") == false) {
					// #ifdef MP
					url = '/pages/public/login';
					// #endif		
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
					url = '/pages/public/login';
					
					} else {
						url = '/pages/public/registerSJ';
					}
					// #endif
				}
				uni.navigateTo({
					url
				})
			},
			sign(){
				
					let dd = new Date()
					let y = dd.getFullYear()
					let m = dd.getMonth() + 1 < 10 ? '0' + (dd.getMonth() + 1) : dd.getMonth() + 1 // 获取当前月份的日期，不足10补0
					// 判断当天是否签到
					this.$api.quest('user/sign', {}, (res) => {
						if(res.data.data.error==1){
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}else{
							
								this.loading = true;
								this.pay_points = res.data.data.record.pay_points
								this.continuity = res.data.data.record.continuity
								// console.log(this.tags)
								// 判断当天是否签到
								if (res.data.data.record.status == 1) {
									this.intraday = true
								}
								// 拼接打卡日期  
								res.data.data.record.sign_record.forEach(el => {
									this.selected.push({
										date: y + '-' + m + '-' + el.signDay
									})
								})
							
								if (res.data.data.record.continuity >= 7) {
									this.num7 = false
								}
								if (res.data.data.record.continuity >= 14) {
									this.num14 = false
								}
								if (res.data.data.record.continuity >= 30) {
									this.num30 = false
								}
								// 判断连续签到奖励
								res.data.data.prize_record.forEach(el => {
									if (el == 1) {
										this.num7 = true
									}
									if (el == 2) {
										this.num14 = true
									}
									if (el == 3) {
										this.num30 = true
									}
								})
						}
					})
					// 一进页面初始化
					// this.$api.quest('', {}, (res) => {
					// 	if (res.data.code == 0) {} else {}
					// })
				
			},
			// 签到满30天领卡激活
			gomenbers() {
				uni.navigateTo({
					url: '/pages/members/members'
				})
			},
			hopeful() {
				this.$api.msg("加速开发中，敬请期待!")
			},
			// 签到
			signed() {
				this.$api.quest('user/signed', {
					sign_date: new Date().getDate()
				}, (res) => {

					if (res.data.code == 0) {
						this.sigIn = true
						this.continuity = res.data.data.continuity
						// this.continuity=14
						this.pay_points = res.data.data.pay_point
						this.intraday = true
						this.selected.push({
							date: this.tags[6].value
						})
					} else {
						this.$api.msg(res.data.msg)
					}
				})
			},
			// 弹框,知道了
			sigIng() {
				this.sigIn = false
				this.sigInnum30 = false
				this.sigInnum14 = false
				this.sigInnum7 = false
			},
			// 连续签到奖励 7 14 30
			draw(num) {
				// var num = 30;
				let ident = num == 7 ? 1 : num == 14 ? 2 : 3;
				// console.log(ident)
				this.$api.quest('user/draw', {
					identifier: ident
				}, (res) => {
					console.log(res)
					if (res.data.code == 0) {
						this.$api.msg(res.data.prize)
						if (num == 7) {
							this.num7 = true
							this.sigInnum7 = true
							this.pay_points = res.data.data.pay_point
						} else if (num == 14) {
							this.num14 = true
							this.sigInnum14 = true
							this.pay_points = res.data.data.pay_point
						} else {
							this.num30 = true
							this.sigInnum30 = true
						}
					} else {
						this.$api.msg(res.data.msg)
					}
				})
			}
		}
	};
</script>

<style lang="scss">
	page {
		background: #FF7436;
	}
	.tip{
		font-size: 22rpx;
		color: #999;
		margin-top: 5rpx;
	}
	.singbtn {
		display: flex;
		justify-content: space-between;
		margin-top: 40rpx;
		button {
			width: 40% !important;
			height: 60rpx !important;
			line-height: 60rpx;
			font-size: 28rpx;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			border-radius: 49rpx;
		}
	}

	.intraday,
	.num30,
	.num14,
	.num7 {
		background: rgba(201, 201, 201, .6) !important;
		color: #fff !important;
		border: none !important;
	}

	// 弹框
	.pop-up {
		position: fixed;
		background: rgba(0, 0, 0, .6);
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;

		.signIn {
			position: fixed;
			top: 25%;
			left: 50%;
			margin-left: -244rpx;
			width: 488rpx;
			// height: 394rpx;
			background: #fff;
			border-radius: 24rpx;
			padding-bottom: 20rpx;

			image {
				position: absolute;
				top: -100rpx;
				left: 50%;
				margin-left: -157rpx;
				width: 314rpx;
				height: 220rpx;
			}

			.sinfo {
				font-size: 34rpx;
				color: #FF824B;
				font-weight: bold;
				text-align: center;
				margin-top: 139rpx;
				margin-bottom: 50rpx;
			}

			.coninfo {
				font-size: 28rpx;
				color: #666;
				text-align: center;
			}

			>button {
				width: 408rpx;
				height: 88rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
				box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
				border-radius: 49rpx;
				margin-top: 40rpx;
			}
		}
	}

	@import '../../static/css/sign.scss';
</style>
