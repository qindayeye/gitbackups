<template>
	<view>
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view v-if="mess.length === 0" class="empty">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>您没有更多消息~</view>
				<view class="navigator" @click="navToLogin">去逛逛</view>
			</view>
		</view>
		<view class="head">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/shua.png" mode=""></image>
			<text @click="rozoon()">一键清空</text>
		</view>
		<view class="notice-item" v-for="(item,index) in mess">
			<text class="time">{{item.add_time}}</text>
			<view class="content">
				<text class="title">{{item.title}}</text>

				<text class="introduce">
					{{item.content}}
				</text>
			</view>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default {
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "通知",
				mess: []
			}
		},
		onLoad(option) {
			console.log(option)
			let us = JSON.parse(option.data)
			console.log(us)
			console.log(this.us)
			this.mess = us.mess
			this.id = us.type
		},
		methods: {
			navToLogin() {
				uni.navigateBack()
				// this.$store.commit("change_page", 0)
				// uni.navigateTo({
				// 	url:'/pages/index/index'
				// })
			},
			rozoon() {
				this.$api.quest('user/delMessage', {
					type: this.id
				}, (res) => {
					console.log(res)
					if (res.data.code == 2) {
						this.$api.msg(res.data.data)
						this.mess = []
					} else {
						this.$api.msg("请求失败")
					}
				})

			}
		}
	}
</script>

<style lang='scss'>
	page {
		background-color: #f7f7f7;
		padding-bottom: 30upx;
	}

	.head {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		height: 88rpx;
		background: #FFFFFF;

		image {
			width: 40rpx;
			height: 40rpx;
		}

		text {
			font-size: 28rpx;
			color: #666;
			margin-right: 20rpx;
			margin-left: 20rpx;
		}
	}

	.notice-item {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.time {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 80upx;
		padding-top: 10upx;
		font-size: 26upx;
		color: #7d7d7d;
	}

	.content {
		width: 710upx;
		padding: 0 24upx;
		background-color: #fff;
		border-radius: 4upx;
	}

	.title {
		display: flex;
		align-items: center;
		height: 90upx;
		font-size: 32upx;
		color: #303133;
	}

	.img-wrapper {
		width: 100%;
		height: 260upx;
		position: relative;
	}

	.pic {
		display: block;
		width: 100%;
		height: 100%;
		border-radius: 6upx;
	}

	.cover {
		display: flex;
		justify-content: center;
		align-items: center;
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, .5);
		font-size: 36upx;
		color: #fff;
	}

	.introduce {
		display: inline-block;
		padding: 16upx 0;
		font-size: 28upx;
		color: #606266;
		line-height: 38upx;
	}

	.bot {
		display: flex;
		align-items: center;
		justify-content: space-between;
		height: 80upx;
		font-size: 24upx;
		color: #707070;
		position: relative;
	}

	.more-icon {
		font-size: 32upx;
	}
</style>
