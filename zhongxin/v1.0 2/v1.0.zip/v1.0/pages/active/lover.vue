<template>
	<view class="twelve">
		<image v-for="(item,index) in oncead"  :class="'double'+(index+1)" :src="item" mode="widthFix" @click="gotodet('double'+(index+1))"></image>
		<!-- <view class="floor_di">
			<view class="price">
				<text>礼包价:</text>
				<text class="num">￥19.9</text>
				<text class="original">￥257</text>
			</view>
			<view class="button" @click="gotodet('double4')">
				立即抢购
			</view>
		</view> -->
		<!-- 弹框 -->
		<view class="popout" v-if="success">
			<view class="message">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="widthFix" @click.stop="close()"></image>
				<text class="tex">您已经购买过了 快去选书吧</text>
				<view class="btn">
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				oncead:[],
				// actEndTime:'2019-12-12 00:00:00',
				// finished:true,
				// id:'',
				success:false,
				// customer:'WXPYQ010'
			}
		},
		onLoad(option) {
			// console.log(option,'adoption')
			// this.customer=option.customer?customer:''
			for(var i=1;i<=11;i++){
				this.oncead.push(`http://www.abcbook2019.com/mobile/public/img/lover/lover_${i}.jpg`)
			}
		},
		mounted() {
			
		},
		methods:{
			gotodet(cla){
				if(uni.getStorageSync('token')){
					if(cla=='double6'){
						// this.id=4399
						this.confirm(4299)
					}
					if(cla=='double3'){
						// this.id=4399
						uni.navigateTo({
							url:'/pages/detail/detail?id=4299'
						})
					}
					if(cla=='double7' || cla=='double10'){
						// this.id=4399
						uni.navigateTo({
							url:'/pages/detail/detail?id=1859'
						})
					}
				}else{
					uni.navigateTo({
						url:'/pages/public/login?type=tocur&customer='+this.customer
					})
				}
			},
			onShareAppMessage(res) {
			if (res.from === 'button') {// 来自页面内分享按钮
			  console.log(res.target)
			}
			return {
			  title: '单次借阅卡圣诞礼包',
			  path: '/pages/active/adactive'
			}
		  },
			close(){
				this.success=false
			},
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			confirm(id) {
				this.$api.quest('flow/sdflow',{
					id: id,   //goodsid
					rec_type:83,
					open_id: uni.getStorageSync("openid"),           //openid
				},(res)=>{
					console.log(res)
					
					if(res.data.code==0){
						this.id=res.data.data.wxpay.order_id?res.data.data.wxpay.order_id:''
						this.payment=res.data.data.wxpay.goods_price?res.data.data.wxpay.goods_price:''
						this.$api.wePay(
						"abcbook国际亲子阅读", 
						res.data.data.wxpay.timestamp, 
						res.data.data.wxpay.nonce_str, 
						res.data.data.wxpay.packages, 
						"MD5", 
						res.data.data.wxpay.sign,
						res=>{
							console.log(JSON.parse(res))
							uni.navigateTo({
								url:'/pages/money/paySuccess?payok=0&id='+this.id
							})
							
						},fail=>{
							console.log(fail)
							
							uni.navigateTo({
								url:'/pages/money/paySuccess?payok=1&id='+this.id+'&payment='+this.payment
							})
							
						})
					}else{
						// 让弹框显示
						this.success=true
						// this.$api.msg(res.data.data)
					}
				})
			},
		}
	}
</script>

<style lang="scss">
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	page{
		padding: 0;
		margin: 0;
		margin-bottom: 98rpx;
	}
	.twelve{
		>image{
			width: 100vw;
			display: block;
			margin-top: -1rpx;
		}
	}
	.floor_di{
		height: 98rpx;
		width: 100%;
		background: #fff;
		position: fixed;
		align-items: center;
		bottom: 0;
		display: flex;
		.price{
			flex: 1;
			// text-align: center;
			margin-left:40rpx ;
			color: #333;
			font-size: 32rpx;
			.num{
				color: #E02020;
				font-size: 32rpx;
				font-weight: bold;
			}
			.original{
				position: relative;
				color: #666;
				font-size: 28rpx;
				margin-left: 20rpx;
				&:before{
					position: absolute;
					display: inline-block;
					content: "———";
					
				}
			}
		}
		.button{
			align-self: flex-end;
			line-height: 98rpx;
			align-items: center;
			width:296rpx;
			font-size: 32rpx;
			color: #fff;
			text-align: center;
			background: linear-gradient(135deg,rgba(255,96,96,1) 0%,rgba(255,45,45,1) 100%);
		}
	}
</style>
