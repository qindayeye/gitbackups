<template>
	<view class="twelve">
		<image v-for="(item,index) in christmas"  :class="'christmas'+(index+1)" :src="item" mode="widthFix" @click="gotodet('double'+(index+1))"></image>
		<!-- 弹框 -->
		<view class="popout" v-if="success">
			<view class="message">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="widthFix" @click.stop="close()"></image>
				<text class="tex">您已经购买过了 快去选书吧</text>
				<view class="">
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				christmas:[],
				actEndTime:'2019-12-12 00:00:00',
				finished:true,
				gtoimg:[],
				success:false,
				customer:'WXPYQ010'
			}
		},
		mounted(){
			
		},
		
		onLoad(option) {
			for(var i=1;i<=13;i++){
				this.christmas.push(`https://www.abcbook2019.com/mobile/public/img/newyear/new_year${i}.jpg`)
			}
			if(option.type!='banner'){
				this.christmas[13]='https://www.abcbook2019.com/mobile/public/img/newyear/new_year_15.jpg'
				this.christmas[14]='https://www.abcbook2019.com/mobile/public/img/newyear/new_year_14.jpg'
			}else{
				this.christmas[13]='https://www.abcbook2019.com/mobile/public/img/newyear/new_year14.jpg'
				this.christmas[14]='https://www.abcbook2019.com/mobile/public/img/newyear/new_year15.jpg'
			}
		},
		onShareAppMessage(res) {
			if (res.from === 'button') {// 来自页面内分享按钮
			  console.log(res.target)
			}
			return {
			  title: '元旦迎新活动',
			  path: '/pages/active/newyear?type=fx'
			}
		},
		mounted() {},
		methods:{
			close(){
				this.success=false
			},
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			gotodet(cla){
				// console.log(cla)
				if(uni.getStorageSync("token")){
						if(cla=='double5'){
							this.$api.quest('flow/sdflow',{
								id: 4299,   //goodsid
								rec_type:77,
								open_id: uni.getStorageSync("openid"),           //openid
							},(res)=>{
								if(res.data.code==0){
									this.id=res.data.data.wxpay.order_id?res.data.data.wxpay.order_id:''
									this.payment=res.data.data.wxpay.goods_price?res.data.data.wxpay.goods_price:''
									this.$api.wePay(
									"abcbook国际亲子阅读", 
									res.data.data.wxpay.timestamp, 
									res.data.data.wxpay.nonce_str, 
									res.data.data.wxpay.packages, 
									"MD5", 
									res.data.data.wxpay.sign,
									res=>{
										uni.navigateTo({
											url:'/pages/money/paySuccess?payok=0&id='+this.id
										})
										
									},fail=>{
										uni.navigateTo({
											url:'/pages/money/paySuccess?payok=1&id='+this.id+'&payment='+this.payment
										})
										
									})
								}else{
									this.success=true
								}
							})
						}else if(cla=='double11'){
							uni.navigateTo({
								url:'/pages/detail/detail?id=1859'
							})
						}
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
				
			}
		}
	}
</script>

<style lang="scss">
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	page{
		padding: 0;
		margin: 0;
	}
	.twelve{
		>image{
			width: 100vw;
			display: block;
			margin-top: -1rpx;
		}
	}
</style>
