<template>
	<view class="twelve">
		<image v-for="(item,index) in christmas" :key="item"  :class="'christmas'+(index+1)" :src="item" mode="widthFix" @click="gotodet(index)"></image>
 
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				christmas:[],				
			}
		},	
		onLoad(option) {
			for(var i=1;i<=6;i++){
				this.christmas.push(`http://www.abcbook2019.com/mobile/public/img/depositfree/deposit_${i}.png`)
			}
		},	
		methods:{
			gotodet(cla){
				console.log(cla)
				if(uni.getStorageSync("token")){
						if(cla=='4'){
							uni.navigateTo({
								url:"/pages/index/index"
							})
						}
						if(cla=='5'){
							uni.navigateTo({
								url:"/pages/index/addjoin"
							})
						}
						
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
				
			}
		}
	}
</script>

<style lang="scss">
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	page{
		padding: 0;
		margin: 0;
	}
	.twelve{
		margin: 0;
		padding: 0;
		font-size: 0;
		>image{
			width: 100vw;
			display: block;
			/* #ifdef MP */ 
			margin-top: -1rpx;
			/* #endif */
		}
	}
</style>

