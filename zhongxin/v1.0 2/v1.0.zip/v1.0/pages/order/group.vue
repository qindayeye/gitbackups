<template>
	<view class="grouporder">
		拼团订单
	</view>
</template>

<script>
</script>

<style>
</style>
