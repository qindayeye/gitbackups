<template>
	<view class="content">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="navbar">
			<text v-for="(item, index) in navList" :key="index" class="nav-item" :class="{active:tabCurrentIndex==index}"
			 @click="tabClick(index,item.states)">
				{{item.text}}
			</text>
		</view>

		<!-- <empty v-if="orderList.length === 0"></empty> -->
		<view class="tablist" v-if="loading">
			<!-- 空白页 -->
			<view v-if="orderList.length === 0" class="empty" style="position:fixed;top:80rpx;height:100vh;overflow: hidden;">
				<image src="https://www.abcbook2019.com/mobile/public/img/icon/boxs.png" mode="aspectFit"></image>
				<view class="empty-tips">
					<view>订单什么也没有</view>
					<view>快去寻找自己喜欢的绘本吧~</view>
					<view class="navigator" @click="navToindx()">去逛逛</view>
				</view>
			</view>
			<!-- 订单列表 -->

			<view v-else v-for="(item,index) in orderList" :key="index" class="order-item" @click="gotoordetil(item.order_id)">
				<view class="i-top b-b" v-if="tabCurrentIndex!=7">
					<text class="time">编号:{{item.order_sn}}</text>
					<text class="state" v-if="item.detail_status==7" :style="{'color':'#666666'}">{{item.order_status}}</text>

					<text class="state" v-else-if="item.detail_status==6" :style="{'color':'#46A02D'}">{{item.order_status}}</text>
					<text class="state" v-else>{{item.order_status}}</text>

				</view>
				<view class="con" v-if="tabCurrentIndex!=7">
					<!-- <scroll-view v-if="item.hyk === 0 || item.ru_id > 0" class="goods-box fl" scroll-x>
						<view v-for="(goodsItem, goodsIndex) in item.goods" :key="goodsIndex" class="goods-item">
							<image class="goods-img" :src="goodsItem.goods_thumb" mode="aspectFill"></image>
						</view>
					</scroll-view> -->
					<view v-if="item.hyk === 1 || item.ru_id>0" class="goods-box-single fl" v-for="(goodsItem, goodsIndex) in item.goods" :key="goodsIndex">
						<image class="goods-img" :src="goodsItem.goods_thumb" mode="aspectFill"></image>
						<view class="right">
							<text class="title clamp">{{goodsItem.goods_name}}</text>
							<text class="price">{{goodsItem.goods_price_formated}}</text>
						</view>
					</view>

					<!-- <view class="price-box fr"> -->
					<!-- 	共
						<text class="num">{{item.total_number}}</text>
						本 -->
						<!-- <text class="price">143.7</text> -->
					<!-- </view> -->
				</view>
				<view class="evaluale" v-else>
					<view class="imageg">
						<image :src="item.goods_thumb"></image>
					</view>
					<text>{{item.goods_name}}</text>
				</view>
				<!-- 根据订单状态判断显示按钮 待付款-->
				<view class="action-box b-t" v-if="item.detail_status == 1">
					<button class="action-btn" @click.stop="cancelOrder(item,index)">取消订单</button>
					<button class="action-btn recom" type="primary" v-if="item.goods_amount>0 || item.deposit_type==1" @click="nopayscore(item)">立即支付</button>
					<!-- <button class="action-btn recom" v-if="item.goods_amount>0 || item.deposit_type==1" @click.stop="gotopay(item)">立即支付</button> -->
					<!-- <button class="action-btn recom" v-else @click.stop="navToindx()">返回首页</button> -->
					<!-- #ifdef H5 -->
					<button class="action-btn recom" v-else @click.stop="navToindx()">返回首页</button>
					<!-- #endif  -->
					<!-- #ifdef MP -->
					<button class="action-btn recom" v-else open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
				</view>
				<!-- 根据订单状态判断显示按钮 待收货 -->
				<view class="action-box b-t" v-if="item.detail_status == 2">
					<!-- <button class="action-btn" open-type="contact" @click.stop="">联系客服</button> -->
					<button class="action-btn" @click.stop="cancelOrder(item,index)">取消订单</button>
					<button class="action-btn">查看物流</button>
				</view>
				<!-- 根据订单状态判断显示按钮 待归还-->
				<view class="action-box b-t" v-if="item.detail_status == 3">
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!--#endif -->
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!--#endif -->
					<button class="action-btn">查看物流</button>
				</view>
				<!-- 根据订单状态判断显示按钮 待评价-->
				<view class="action-box b-t" v-if="item.detail_status == 4">
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!--#endif -->
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!--#endif -->
					<button class="action-btn recom" v-if="item.ru_id == 0" @click.stop="yoreturn(item.rec_id,item.order_id)">预约还书</button>
					<button class="action-btn recom" v-else @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- 根据订单状态判断显示按钮 已完成-->
				<view class="action-box b-t" v-if="item.detail_status == 5">
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!--#endif -->
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">返回首页</button>
					<!--#endif -->
					<button class="action-btn recom" @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- 根据订单状态判断显示按钮 已关闭-->
				<view class="action-box b-t" v-if="item.detail_status == 6">
					<view class="" v-if="item.hyk==1" style="display: flex;">
						<view class="" v-if="item.member_status!==88" style="display: flex;">
							<button v-if="item.pay_id > 0 && item.money_paid>0" class="action-btn">申请退款</button>
							<button v-else class="action-btn" @click.stop="navToindx()">重新下单</button>
							<button class="action-btn">立即激活</button>
						</view>
						<view class="" v-else style="display: flex;">
							<button class="action-btn" @click.stop="navToindx()">前去选书</button>
							<button class="action-btn">已激活</button>
						</view>
					</view>
					<view class="" v-else style="display: flex;">
						<!-- #ifdef MP -->
						<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
						<!-- #endif -->
						<!-- #ifdef H5 -->
						<button class="action-btn" @click.stop="navToindx()">返回首页</button>
						<!--#endif -->
						<button class="action-btn" @click.stop="navToindx()">重新下单</button>
					</view>
				</view>

				<view class="action-box b-t" v-if="item.detail_status == 7">
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">返回首页</button>
					<!--#endif -->
					<button class="action-btn" @click.stop="navToindx()">重新下单</button>
				</view>
				<view class="action-box b-t" v-if="item.detail_status == 8">
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">返回首页</button>
					<!--#endif -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- <view class="action-box b-t" v-if="item.detail_status == 101">
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<button class="action-btn" @click.stop="navdeti(item.order_id)">前去支付</button>
				</view> -->
				<view class="action-box b-t" v-if="tabCurrentIndex == 7">
					<button class="action-btn recom" @click.stop="navToevlu(item.rec_id)">评价晒单</button>
				</view>


			</view>
			<view class="flocon" v-if="classon">{{classoninfo}}</view>
			
			<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
			</view>
			<goHome></goHome>
			
			<!-- 弹框 -->
			<view class="pop-up" v-if="popup">
				
				<view class="upcon">
					<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/upcon.png" mode="widthFix"></image>
					<view class="upopinion">
						<text @click="opinion('n')">先不用</text>
						<text class="main" @click="opinion('y')">免押金租书</text>
					</view>
				</view>
			</view>
		</view>
		<mixLoading v-else></mixLoading>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	
	
	// #endif
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import bottomNav from "../navbar/navbar.vue";
	import goHome from '@/components/home.vue';
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		components: {
			bottomNav,
			uniLoadMore,
			goHome,
			mixLoading,
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "我的订单",
				optst: 0,
				popup:false,
				loading: false,
				page: 1,
				type: '',
				classon: false, //判断模态框
				tabCurrentIndex: 0,
				orderList: [],
				itemclick:null,
				hide: true,
				classoninfo: "正在努力加载...", //加载展示内容
				navList: [{
						states: 0,
						text: '全部',
					},
					{
						states: 500,
						text: '待付款',
						loadingType: 'more'
					},
					{
						states: 502,
						text: '待发货',
						loadingType: 'more'
					},
					{
						states: 512,
						text: '待收货',
						loadingType: 'more'
					},
					{
						states: 522,
						text: '已收货',
						loadingType: 'more'
					},
					{
						states: 400,
						text: '退换货',
						loadingType: 'more'
					},
					// {
					// 	states: 5,
					// 	text: '我的预售',
					// 	loadingType: 'more'
					// },
				],
			};
		},

		onLoad(options) {
			/**
			 * 修复app端点击除全部订单外的按钮进入时不加载数据的问题
			 * 替换onLoad下代码即可
			 */
			// console.log(options);
			this.optst = options.states;
			this.type = options.type
			// #ifdef H5
			this.loadData(options.index)
			// #endif
			// #ifdef MP
			// this.loadData(options.index)
			if (options.index == 7) {
				this.tabCurrentIndex = 7
				this.commentList()
			} else {
				// this.tabCurrentIndex=options.index
				this.loadData(options.index)
			}

			// #endif

		},
		onReachBottom() {
			this.scroll();
		},
		onPullDownRefresh: function() {
			if (this.tabCurrentIndex == 7) {
				this.commentList()
			} else {
				this.loadData()
			}
			setTimeout(function() {
				uni.stopPullDownRefresh(); //停止下拉刷新动画
			}, 1000);

		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			if (Object.scrollTop > 400) {
				this.hide = false;
			} else {
				this.hide = true;
			}
			if (this.classoninfo == "我也是有底线的哦~") {
				this.classon = false
			}
		},
		methods: {
			// 弹框
			close(){
				console.log('关闭弹框')
				this.popup=false;
			},
			// 判断是否是支付分
			opinion(type){
				this.$api.quest('flow/againorder',{
					order_id:this.itemclick.order_id,
					type:type=='y'?1:0
				},(res)=>{
					if(res.data.code==0){
						// this.payment=options.payment
						uni.setStorageSync('ordersn',res.data.error)
					}
					if(type=='y'){
						// console.log('调用支付分')
						this.gopay()
						this.deposittype=1
					}else{
						console.log('没有使用支付分')
						
						this.nopayscore()
					}
				})
			},
			// 微信支付  没有使用支付分
			nopayscore(itemclick){
				uni.navigateTo({
					url:'/pages/money/pay?id='+itemclick.order_id+'&payment='+itemclick.goods_amount,
					// #ifdef H5
						success: (res) => {
							if (res.errMsg == 'navigateTo:ok') {
								window.location.reload(true);
							}
						}
						// #endif
				})
				// if(this.itemclick.extension_code=='presale'){
				// 	uni.navigateTo({
				// 		url:'/pages/money/pay?id='+this.itemclick.order_id+'&payment='+this.itemclick.order_amount
				// 	})
				// }else{
					
				// }
				
			},
			gotopay(payli) {
				this.popup=true
				this.itemclick=payli
				// uni.navigateTo({
				// 	url: '/pages/money/pay?id=' + payli.order_id + '&payment=' + payli.goods_amount
				// })
			},
			// 获取订单列表
			commentList() {
				this.$api.quest('user/order/commentList', {
					page: 1,
				}, (res) => {
					console.log(res)
					this.orderList = res.data.data
					this.loading = true
				})
			},
			// 去评价
			navToevlu(id) {
				uni.navigateTo({
					url: '/pages/detail/evaluate?rec=' + id
				})
			},
			//获取订单列表
			loadData(index, states) {

				this.tabCurrentIndex = index
				if (this.tabCurrentIndex == 7) {
					this.commentList()
				} else {
					this.$api.quest('user/order/list', {
						page: 1,
						size: 10,
						status: this.optst,
						type: "",
						ru_id:1
					}, (res) => {
						this.orderList = res.data.data
						this.loading = true
					})
				}

			},
			// 预约还书跳转
			yoreturn(rec, order) {
				this.$api.quest('user/checkReturn', {
					rec_id: rec
				}, (res) => {
					console.log(res)
					if (res.data.code == 1) {
						uni.navigateTo({
							url: '/pages/appoint/appoint?rec=' + rec + '&order=' + order
						})
					} else {
						this.$api.msg(res.data.data)
					}
				})
			},
			// 前去支付
			navdeti(id) {
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + id
				})
			},
			// 去订单页
			gotoordetil(id) {
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + id
				})
			},
			// 返回首页
			navToindx() {
				// uni.navigateBack()
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
			// 下拉加载
			scroll() {
				if (this.tabCurrentIndex == 7) {
					const that = this;
					that.classon = true;
					this.loadingType = 1;
					this.$api.quest('user/order/commentList', {
						page: ++that.page,
					}, (res) => {
						// console.log(res.data.data)
						if (res.data.data.length == 0) { //没有数据
							this.loadingType = 2;
							that.classon = true;
							that.classoninfo = "我也是有底线的哦~"
							uni.hideNavigationBarLoading(); //关闭加载动画
							return;
						}
						that.orderList.push(...res.data.data)
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
					})
				} else {
					const that = this;
					that.classon = true;
					this.loadingType = 1;
					this.$api.quest('user/order/list', {
						page: ++that.page,
						size: 10,
						status: this.optst,
						type: "",
						ru_id:1
					}, (res) => {
						// console.log(res.data.data)
						if (res.data.data.length == 0) { //没有数据
							this.loadingType = 2;
							that.classon = true;
							that.classoninfo = "我也是有底线的哦~"
							uni.hideNavigationBarLoading(); //关闭加载动画
							return;
						}
						that.orderList.push(...res.data.data)
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
					})
				}

			},
			//顶部tab点击
			tabClick(index, states) {
				console.log(index, states)

				this.tabCurrentIndex = index;
				this.optst = states
				this.page = 1

				if (this.optst == 5) {
					this.type = "presale"
				} else {
					this.type = ""
				}
				// this.loadData(index, states);
				if (index == 7) {
					this.commentList()
				} else {
					this.loadData(index, states);
				}
			},
			//删除订单
			deleteOrder(item, index) {
				this.$api.quest('user/order/del', {
					id: item.order_id
				}, (res) => {
					console.log(res)
					this.orderList.splice(index, 1);
				})
			},
			//取消订单
			cancelOrder(item, index) {
				this.$api.quest('user/order/cancel', {
					id: item.order_id
				}, (res) => {
					console.log(res)
					if (res.data.code == 1) {
						this.$api.msg(res.data.data)
						this.orderList.splice(index, 1);
					} else {
						this.$api.msg(res.data.data)
					}
				})

			},
			// 返回顶部
			gotop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			}
		},
	}
</script>

<style lang="scss" scoped>
	.pop-up{
		width: 100vw;
		height: 100vh;
		background: rgba(0,0,0,.6);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;
		
		.upcon{
			/* height: 500rpx; */
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			background: #fff;
			border-radius: 24rpx;
			text-align: center;
			image{
				width: 660rpx;
				height: 752rpx;
			}
			.close{
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				top: 20rpx;
				right: 25rpx;
				z-index: 9;
			}
			.upopinion{
				display: flex;
				width: 660rpx;
				margin: 0 auto;
				height: 148rpx;
				justify-content: space-around;
				align-items: center;
				text{
					width:300rpx;
					line-height: 84rpx;
					border: 2rpx solid #666;
					border-radius: 44rpx;
					font-size: 32rpx;
					color: #666;
				}
				.main{
					color: #fff;
					line-height: 88rpx;
					border: none;
					background: linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				}
			}
			
		}
	}
	page,
	.content {
		background: $page-color-base;
		height: 100%;
	}

	.empty {
		position: static;
	}

	.swiper-box {
		height: calc(100% - 40px);
	}

	.list-scroll-content {
		height: 100%;
	}

	.navbar {
		position: fixed;
		/* #ifdef MP */
		top: 0;
		/* #endif */
		/* #ifdef H5 */
		top: 88rpx;
		/* #endif */
		width: 750rpx;
		line-height: 88rpx;
		background: #fff;
		overflow-x: scroll;
		white-space: nowrap;
		z-index: 99;
		box-shadow:0px 2rpx 8rpx 0px rgba(0,0,0,0.1),0px -1rpx 0px 0px rgba(230,230,230,1);
		text {
			position: relative;
			display: inline-block;
			margin-left: 50rpx;
			color: #666;
			font-size: 30rpx;
			line-height: 50rpx;
		}
		.active {
			color: #FF824B;
			position: relative;
			font-size: 36rpx;
			font-weight: bold;
		}
			
		.active::before {
			display: block;
			content: "";
			position: absolute;
			width: 26rpx;
			height: 8rpx;
			bottom: -12rpx;
			left: 50%;
			transform: translate(-50%, 0%);
			background: #FF824B;
			border-radius: 4rpx;
		}
		// .nav-item {
		// 	display: inline-block;
		// 	width: 150rpx;
		// 	line-height: 88rpx;
		// 	font-size: 15px;
		// 	text-align: center;
		// 	color: $font-color-dark;
		// 	position: relative;
	
		// 	&.current {
		// 		color: $base-color;
	
		// 		&:after {
		// 			content: '';
		// 			position: absolute;
		// 			left: 50%;
		// 			bottom: 0;
		// 			transform: translateX(-50%);
		// 			width: 44px;
		// 			height: 0;
		// 			border-bottom: 2px solid $base-color;
		// 		}
		// 	}
		// }
	
		&::-webkit-scrollbar {
			display: none
		}
	}
	
	
	.tablist {
		padding-top: 88rpx;
		// padding-bottom: 200rpx;
	}

	.flocon {
		position: fixed;
		bottom: 120rpx;
		left: 50%;
		transform: translate(-50%, 0);
		font-size: 26rpx;
		color: #999999;
		text-align: center;

	}

	.uni-swiper-item {
		height: auto;
	}

	.action-box {
		display: flex;
	}

	.order-item {
		display: flex;
		flex-direction: column;
		width: 710rpx;
		// height: 389rpx;
		margin: 0 auto;
		// padding-left: 30upx;
		background: #fff;
		margin-top: 16upx;
		box-sizing: border-box;
		padding: 0 20rpx;
		box-shadow: 0px 2rpx 8rpx 0px rgba(0, 0, 0, 0.1);
		border-radius: 10rpx;

		.i-top {
			display: flex;
			align-items: center;
			width: 670rpx;
			height: 80upx;
			font-size: $font-base;
			color: $font-color-dark;
			border-bottom: 1rpx dashed #e6e6e6;
			position: relative;

			.time {
				flex: 1;
			}

			.state {
				color: $base-color;
			}

			.del-btn {
				padding: 10upx 0 10upx 36upx;
				font-size: $font-lg;
				color: $font-color-light;
				position: relative;

				&:after {
					content: '';
					width: 0;
					height: 30upx;
					border-left: 1px solid $border-color-dark;
					position: absolute;
					left: 20upx;
					top: 50%;
					transform: translateY(-50%);
				}
			}


		}

		.con {
			display: flex;
			height: 200rpx;
			align-items: center;
			justify-content: space-between;
		}

		/* 多条商品 */
		.goods-box {
			width: 520rpx;
			height: 160upx;
			padding: 20upx 0;
			white-space: nowrap;

			.goods-item {
				width: 120upx;
				height: 120upx;
				display: inline-block;
				margin-right: 24upx;
			}

			.goods-img {
				display: block;
				width: 100%;
				height: 100%;
			}
		}

		/* 单条商品 */
		.goods-box-single {
			display: flex;
			padding: 20upx 0;

			.goods-img {
				display: block;
				width: 120upx;
				height: 120upx;
			}

			.right {
				flex: 1;
				display: flex;
				flex-direction: column;
				height: 140upx;
				justify-content: space-around;
				// align-items: center;
				// justify-content: center;
				// padding: 0 30upx 0 24upx;
				overflow: hidden;

				.title {
					font-size: 28rpx;
					color: #333;
					align-items: center;
					margin-left: 20rpx;
				}

				.attr-box {
					font-size: $font-sm + 2upx;
					color: $font-color-light;
					padding: 10upx 12upx;
				}

				.price {
					font-size:28rpx;
					color:#333;
					margin-left: 20rpx;
					// &:before {
					// 	content: '￥';
					// 	font-size: $font-sm;
					// 	margin: 0 2upx 0 8upx;
					// }
				}
			}
		}

		.price-box {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 160rpx;
			font-size: $font-sm + 2upx;
			color: $font-color-light;

			.num {
				margin: 0 8upx;
				color: $font-color-dark;
			}

			.price {
				font-size: $font-lg;
				color: $font-color-dark;

				&:before {
					content: '￥';
					font-size: $font-sm;
					margin: 0 2upx 0 8upx;
				}
			}
		}

		.action-box {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 100upx;
			position: relative;
			border-top: 1rpx dashed #e6e6e6;
		}

		.action-btn {
			width: 160upx;
			// height: 60upx;
			margin: 0;
			margin-left: 24upx;
			padding: 0;
			text-align: center;
			line-height: 60upx;
			font-size: $font-sm + 2upx;
			color: $font-color-dark;
			background: #fff;
			border-radius: 100px;
			border: 1rpx solid #999;

			&:after {
				border-radius: 100px;
			}

			&.recom {
				background: #fff9f9;
				color: $base-color;
				border: 1rpx solid #FF824B;

				&:after {
					border-color: #f7bcc8;
				}
			}
		}
	}


	/* load-more */
	.uni-load-more {
		display: flex;
		flex-direction: row;
		height: 80upx;
		align-items: center;
		justify-content: center
	}

	.uni-load-more__text {
		font-size: 28upx;
		color: #999
	}

	.uni-load-more__img {
		height: 24px;
		width: 24px;
		margin-right: 10px
	}

	.uni-load-more__img>view {
		position: absolute
	}

	.uni-load-more__img>view view {
		width: 6px;
		height: 2px;
		border-top-left-radius: 1px;
		border-bottom-left-radius: 1px;
		background: #999;
		position: absolute;
		opacity: .2;
		transform-origin: 50%;
		animation: load 1.56s ease infinite
	}

	.uni-load-more__img>view view:nth-child(1) {
		transform: rotate(90deg);
		top: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(2) {
		transform: rotate(180deg);
		top: 11px;
		right: 0
	}

	.uni-load-more__img>view view:nth-child(3) {
		transform: rotate(270deg);
		bottom: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(4) {
		top: 11px;
		left: 0
	}

	.load1,
	.load2,
	.load3 {
		height: 24px;
		width: 24px
	}

	.load2 {
		transform: rotate(30deg)
	}

	.load3 {
		transform: rotate(60deg)
	}

	.load1 view:nth-child(1) {
		animation-delay: 0s
	}

	.load2 view:nth-child(1) {
		animation-delay: .13s
	}

	.load3 view:nth-child(1) {
		animation-delay: .26s
	}

	.load1 view:nth-child(2) {
		animation-delay: .39s
	}

	.load2 view:nth-child(2) {
		animation-delay: .52s
	}

	.load3 view:nth-child(2) {
		animation-delay: .65s
	}

	.load1 view:nth-child(3) {
		animation-delay: .78s
	}

	.load2 view:nth-child(3) {
		animation-delay: .91s
	}

	.load3 view:nth-child(3) {
		animation-delay: 1.04s
	}

	.load1 view:nth-child(4) {
		animation-delay: 1.17s
	}

	.load2 view:nth-child(4) {
		animation-delay: 1.3s
	}

	.load3 view:nth-child(4) {
		animation-delay: 1.43s
	}

	@-webkit-keyframes load {
		0% {
			opacity: 1
		}

		100% {
			opacity: .2
		}
	}

	.evaluale {
		height: 300rpx;
		display: flex;
		align-items: center;

		.imageg {
			width: 250rpx;
			height: 250rpx;
			margin-right: 15rpx;

			image {
				width: 250rpx;
				height: 250rpx;
				margin: 0 auto;
			}
		}

		text {
			font-size: 28rpx;
			color: #666;
		}
	}
</style>
