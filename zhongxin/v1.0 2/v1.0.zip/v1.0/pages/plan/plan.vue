<template>
	<view class="plan">
		<view class="pageimg">
			<image :src="planimg" mode="widthFix"></image>
			<text>{{plannum}}/3</text>
		</view>
		<view class="plan1 page" v-if="page1">
			<view class="planTil">
				<view class="titl">为哪个宝宝定制阅读计划?</view>
				<text class="hin">(可多选)</text>
			</view>
			<view class="babylist">
				<text :class="item.cur?'cur':''" v-for="(item,index) in plan1" @click="getcur(item,index)">{{item.name}}</text>
			</view>
			<view class="btnn" @click="onenext()">
				下一步
			</view>
		</view>
		<view class="plan2 page" v-if="page2">
			<swiper class="swiper"  vertical=true>
				<swiper-item v-for="(item,index) in pageNum" :key="index">
					<view class="info birthday">
						<view class="p2titl">{{item.name}}生日</view>
						<picker mode="date" :value="item.date" :start="startDate" :end="endDate" @change="bindDateChange($event,index)">
							<view class="uni-input">{{item.date}}</view>
						</picker>
					</view>
					<view class="info sex">
						<view class="p2titl">{{item.name}}性别</view>
						<view class="seximg">
							<view class="sexinfo boy"  @click="getsex(item,'boy')">
								<image :class="item.babyon=='boy'?'babyon':''"  src="https://www.abcbook2019.com/mobile/public/images/plan/boy.png" mode="widthFix"></image>
								<text>男孩</text>
							</view>
							<view class="sexinfo gril"   @click="getsex(item,'gril')">
								<image  :class="item.babyon=='gril'?'babyon':''" src="https://www.abcbook2019.com/mobile/public/images/plan/gril.png" mode="widthFix"></image>
								<text>女孩</text>
							</view>
						</view>
					</view>
					<view class="info character">
						<view class="p2titl">{{item.name}}性格</view>
						<view class="hin">(最多选3个)</view>
						<view class="baby_character">
							<view class="txt"  v-for="(el,ind) in item.characterList" :key="ind" :class="el.charact?'charact':''"  @click="charact(el,item,ind,index)">{{el.name}}</view>
						</view>
					</view>
					
					<view class="btnn di" v-if="index==pageNum.length-1">
						<text class="p2pr" @click="p2pr()">上一步</text>
						<text class="p2nx" @click="p2nx()">下一步</text>
					</view>
					<view class="di" v-else>上划填写更多宝宝信息</view>
				</swiper-item>
			</swiper>
		</view>
		<view class="plan3 page" v-if="page3">
			<view class="planTi3">
				<view class="titl">您希望每天陪伴宝宝阅读几本书?</view>
			</view>
			<view class="readList">
				<view class="tex" :class="{readnum : index===readId}" v-for="(item,index) in readlist" @click="readind(item,index)">{{item}}</view>
			</view>
			<view class="btnn di">
				<text class="p3pr" @click="p3pr()">上一步</text>
				<text class="oknx" @click="oknx()">完成</text>
			</view>
		</view>
		<view class="poup" v-if="success">
			<view class="message" >
				<text class="messageTit">很遗憾！</text>
				<!-- <image src="https://www.abcbook2019.com/mobile/public/img/bcustome/success.png" mode="widthFix"></image> -->
				<text class="tex">本次刷选结果数量不足10本</text>
				<button class="btn" type="primary" @click="gotoind()">更改刷选条件</button>
			</view>
		</view>
	</view>
</template>

<script>
	import Vue from 'vue'
	function getDate(type) {
		const date = new Date();
	
		let year = date.getFullYear();
		let month = date.getMonth() + 1;
		let day = date.getDate();
	
		if (type === 'start') {
			year = year - 12;
		} else if (type === 'end') {
			year = year;
		}
		month = month > 9 ? month : '0' + month;;
		day = day > 9 ? day : '0' + day;
	
		return `${year}-${month}-${day}`;
	}
	export default {
		data() {
			return {
				readId:0,
				success:false,
				readlist:["1本","2本","3本","4本","5本","6本"],
				page1:true,
				pageNum:[],   //选了几个孩子
				page2:false,
				page3:false,
				plan1: [{
						"name": "大宝"
					},
					{
						"name": "二宝"
					},
					{
						"name": "三宝"
					},
					{
						"name": "四宝"
					}
				],
				data:{
					"Baby_number": null,
					"Read_num":"1本",
					"one": {
						"birthday": [null, null],
						"sex": "",
						"characterarrlist": null,
						"charactermerge":null
					},
					"two": {
						"birthday": [null, null],
						"sex": "",
						"characterarrlist": null,
						"charactermerge": null
					},
					"three": {
						"birthday": [null, null],
						"sex": "",
						"characterarrlist": null,
						"charactermerge": null
					},
					"four": {
						"birthday": [null, null],
						"sex": "",
						"characterarrlist": null,
						"charactermerge": null
					}
				},
				characterList:[
					{"name":"活泼好动",
					"idarr": [12, 5, 4]
					},
					{"name":"个性调皮",
					"idarr": [12, 4, 5, 29, 7],
					},
					{"name":"好奇心强",
					"idarr": [12, 9, 6, 18],
					},
					{"name":"自信独立",
					"idarr": [12, 14, 28],
					},
					{"name":"文静内向",
					"idarr":  [12, 5, 9, 8, 14, 145],
					},
					{"name":"容易害羞",
					"idarr":  [12, 5, 29, 8],
					},
					{"name":"爱听故事",
					"idarr": [12, 145],
					},
					{"name":"喜欢表达",
					"idarr":[12, 27],
					},
					{"name":"热爱艺术",
					"idarr":  [12, 17, 31]
					}
					],
				date: getDate({
					format: true
				}),
				startDate:getDate('start'),
				endDate:getDate('end'),
				planimg:'https://www.abcbook2019.com/mobile/public/images/plan/plan1.png',
				plannum:1
			}
		},
		onLoad() {
			console.log(this.plan1)
		},
		methods: {
			// 将字符分割
			func(source, count){
				let arr = [];
				for (let i = 0, len = source.length / count; i < len; i++) {
					let subStr = source.substr(0, count);
					arr.push(subStr);
					source = source.replace(subStr, "");
				}
				return arr;
			},
			// 数组去重
			merge(bigArray){
				let array = [];
				const middeleArray = bigArray.reduce((a, b) => {
					return a.concat(b);
				});
				middeleArray.forEach((arrItem) => {
					if (array.indexOf(arrItem) == -1) {
						array.push(arrItem);
					}
				});
			
				return array;
			},
			gotoind(){
				// uni.redirectTo("/pages/plan/plan");
				uni.redirectTo({
					url:'/pages/plan/plan'
				})
			},
			// 点击宝宝日期选择
			bindDateChange: function(e,index) {
				this.date = e.target.value
				Vue.set(this.pageNum[index], 'date', e.target.value);
				// console.log(index,this.pageNum[index])
			},
			// 第二页点击上一页
			p2pr(){
				this.page2=false;
				this.page1=true;
				this.plannum=1;
				this.planimg='https://www.abcbook2019.com/mobile/public/images/plan/plan1.png'
			},
			// 第二页点击下一页
			p2nx(){
				this.page2=false;
				this.page3=true;
				this.plannum=3;
				this.planimg='https://www.abcbook2019.com/mobile/public/images/plan/plan3.png'
				console.log(this.pageNum)
				let arr=["one","two","three","four"]
				this.pageNum.forEach((el,index)=>{
					console.log(el,index)
					if(el.binds){
						let characterarrlist=[];
						let arr1=[];
						el.chareList.forEach(e=>{
							characterarrlist.push(e.name)
							arr1.push(e.idarr)
						})
						if(index==0){
							// console.log(this.data.arr[index])
							this.data.one.birthday[0]=el.date
							this.data.one.birthday[1]=this.func(el.date,4)[0]
							this.data.one.sex=el.babyon
							this.data.one.characterarrlist=characterarrlist
							this.data.one.charactermerge=this.merge(arr1)
						}else if(index==1){
							this.data.two.birthday[0]=el.date
							this.data.two.birthday[1]=this.func(el.date,4)[0]
							this.data.two.sex=el.babyon
							this.data.two.characterarrlist=characterarrlist
							this.data.two.charactermerge=this.merge(arr1)
						}else if(index==2){
							this.data.three.birthday[0]=el.date
							this.data.three.birthday[1]=this.func(el.date,4)[0]
							this.data.three.sex=el.babyon
							this.data.three.characterarrlist=characterarrlist
							this.data.three.charactermerge=this.merge(arr1)
						}else{
							this.data.four.birthday[0]=el.date
							this.data.four.birthday[1]=this.func(el.date,4)[0]
							this.data.four.sex=el.babyon
							this.data.four.characterarrlist=characterarrlist
							this.data.four.charactermerge=this.merge(arr1)
						}
						
					}
				})
			},
			// 第三页返回上一页
			p3pr(){
				this.page2=true;
				this.page3=false;
				this.plannum=2;
				this.planimg='https://www.abcbook2019.com/mobile/public/images/plan/plan2.png'
			},
			// 点击完成
			oknx(){
				console.log(this.data)
				 // let arr=[]
				
				 // arr.push(this.data)
				 // var new_data=JSON.stringify(this.data)
				  // console.log(arr)
					this.$api.quest('plan/planResults',{
						data:this.data
					},(res)=>{
						console.log(res)
						let list= encodeURIComponent (JSON.stringify(res.data.data))
						if(res.data.code==0){
							if(res.data.data.buzu==1){
								this.success=true
							}else{
								uni.navigateTo({
									url: `/pages/Parentchild/Parentchild?list=${list}`
								   })
							}
							
						}else{
							if(res.data.data.error){
								this.$store.commit("change_page", 4)
								// #ifdef H5
								// 判断微信内外
								var ua = window.navigator.userAgent.toLowerCase();
								console.log(ua)
								// console.log(ua.indexOf('micromessenger') != -1)
								// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
								if (ua.match(/MicroMessenger/i) == 'micromessenger') {
									// 微信内浏览器（公众号）
									console.log("公众号")
									uni.navigateTo({
										url: '/pages/public/login'
									})
								
								} else {
									uni.navigateTo({
										url: '/pages/public/registerSJ'
									})
								}
								// #endif
									// #ifdef MP
								uni.navigateTo({
								
									url:'/pages/public/login',
									
								})
								// #endif
							}else{
								this.$api.msg("您有未填完的信息")
							}
							
						}
					})
				
			
			},
			// 宝宝性格
			charact(e,item,ind,index){
					if (e.charact) {
						Vue.set(e, 'charact', false);  
						item.chareList.forEach((el,indexx)=>{
							if(el==e){
								// console.log(indexx)
								item.chareList.splice(indexx,1)
							}
						})
					}else{
						if(item.chareList.length>=3){
							this.$api.msg("宝宝性格标签只能选择三个哦")
							Vue.set(e, 'charact', false);  
						}else{
							Vue.set(e, 'charact', true);
							item.chareList.push(e)
						}
						
					}
			},
			
			getsex(item,sex){
				Vue.set(item, 'babyon', sex);  
				// console.log(item)
				// console.log(item.babyon=='boy')
			},
			getcur(e) {
				if (e.cur) {
					Vue.set(e, 'cur', false); 
				} else {
					Vue.set(e, 'cur', true);
				}
			},
			onenext(){
				// 判断有没有选择宝宝
				// 关闭第一个问题  展开第二个问题
				this.plan1.forEach((item,index)=>{
					var arr=JSON.parse(JSON.stringify(this.characterList))
					var newArr=[]
					if(item.cur){
						Vue.set(item, 'characterList',arr);
						Vue.set(item, 'date', this.date);
						Vue.set(item, 'binds', "bonds"+index);
						Vue.set(item,"chareList",newArr);
						this.pageNum.push(item)
					}
				})
				if(this.pageNum.length==0){
					this.$api.msg("请选择为哪个宝宝定制计划")
				}else{
					this.data.Baby_number=this.pageNum.length
					this.page1=false;
					this.page2=true;
					this.planimg='https://www.abcbook2019.com/mobile/public/images/plan/plan2.png';
					this.plannum=2
				}
					// console.log(this.pageNum)
				
			},
			readind(el,index){
				this.readId=index
				// console.log(el)
				this.data.Read_num=el
			}
		}
	}
</script>

<style lang="scss">
	page {
		background: #fff;
	}
	.uni-input{
		font-size: 30rpx;
		color: #333;
	}
	.plan {
		.pageimg {
			position: fixed;
			top: 30rpx;
			left: 35rpx;
			width: 88rpx;
			height: 88rpx;
			z-index: 2;

			image {
				width: 88rpx;
				height: 88rpx;
			}

			text {
				position: absolute;
				font-size: 34rpx;
				color: #333;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
			}
		}

		.page {
			position: fixed;
			top: 0;
			width: 100vw;
			height: 100vh;
		}

		.plan1,.plan3 {
			.planTil,.planTi3{
				margin: 0 auto;
				text-align: center;
				margin-top: 24%;

				.titl {
					font-size: 38rpx;
					color: #333;
					font-weight: bold;
					text-align: center;
				}

				.hin {
					font-size: 28rpx;
					color: #999;
					margin-bottom:2%;
				}
			}

			.babylist {
				display: flex;
				justify-content: space-around;
				margin-top: 50rpx;

				text {
					box-sizing: border-box;
					border: 1rpx solid #999;
					font-size: 30rpx;
					width: 162rpx;
					line-height: 80rpx;
					text-align: center;
					color: #666;
				}
				
				.cur {
					font-weight: bold;
					border: 3rpx solid #FF824B;
					color: #FF824B;
				}
			}

			.btnn {
				position: fixed;
				bottom: 50rpx;
				width: 710rpx;
				line-height: 88rpx;
				left: 50%;
				text-align: center;
				margin-left: -355rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
				box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
				border-radius: 49rpx;
				font-size: 32rpx;
				color: #fff;
			}
		}
		.plan2{
			text-align: center;
			.birthday{
				margin-top: 12%;
				
				picker{
					width: 710rpx;
					line-height: 80rpx;
					border: 1rpx solid #979797;
					margin: 4% auto 6% auto;
				}
			}
			.p2titl{
				font-size: 38rpx;
				color: #333;
			}
			.p2tit2{
				margin-bottom: 3%;
			}
			.sexinfo{
				display: flex;
				flex-direction: column;
				text{
					font-size: 28rpx;
					color: #333;
					margin-top: 2%;
				}
				.babyon{
					border: 2rpx solid #FF824B;
				}
			}
			.seximg{
				width: 710rpx;
				margin: 0 auto;
				display: flex;
				justify-content:space-around;
			}
			.swiper{
				width: 100vw;
				height: 100vh;
			}
			.sex{
				image{
					width: 126rpx;
					height: 126rpx;
					border-radius: 50%;
					border: 2rpx solid #fff;
				}
				
			}
			.character{
				
				.hin{
					font-size: 28rpx;
					color: #999;
					
				}
				.baby_character{
					width: 94%;
					height: 20%;
					margin: 0 auto;
					margin-top:30rpx;
					display: flex;
					flex-wrap: wrap;
					justify-content: space-between;
					align-items: center;
					.txt{
						width:224rpx;
						line-height:80rpx;
						font-size: 30rpx;
						color: #666;
						border: 1rpx solid #999;
						margin-bottom: 20rpx;
					}
					.charact{
						color: #FF824B;
						border: 1rpx solid #FF824B;
					}
				}
			}
			.di{
				width: 710rpx;
				position: fixed;
				bottom: 50rpx;
				left: 50%;
				margin-left: -355rpx;
				line-height: 88rpx;
				color: #999;
				font-size: 28rpx;
				text-align:center;
			}
			.btnn{
				width: 710rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				// margin: 0 auto;
			}
			.p2pr{
				width: 343rpx;
				height: 88rpx;
				border: 2rpx solid #999;
				background: #fff;
				border-radius: 49rpx;
				color: #333;
			}
			.p2nx{
				width:343rpx;
				height:88rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0px 4rpx 8rpx 0px rgba(255,130,75,0.5);
				border-radius:49rpx;
				color: #fff;
			}
		}
		.plan3{
			.readnum{
				border: 1rpx solid #FF824B;
				color: #ff824B;
			}
			.readList{
				width: 710rpx;
				display: flex;
				justify-content:space-between;
				flex-wrap: wrap;
				margin: 0 auto;
				margin-top: 80rpx;
				.tex{
					width: 224rpx;
					line-height: 80rpx;
					color: #666;
					border: 1rpx solid #999;
					font-size: 30rpx;
					text-align: center;
					margin-bottom: 20rpx;
					
				}
				.readnum{
					border: 3rpx solid #FF824B;
					color:#FF824B;
				}
			}
			.di{
				width: 710rpx;
				position: fixed;
				bottom: 50rpx;
				left: 50%;
				margin-left: -355rpx;
				line-height: 88rpx;
				color: #999;
				font-size: 28rpx;
				text-align:center;
				background:transparent;
			}
			.btnn{
				width: 710rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				text-align: center;
				background:transparent;
				box-shadow: none;
			}
			.p3pr{
				width: 343rpx;
				height: 88rpx;
				border: 2rpx solid #999;
				background: #fff;
				border-radius: 49rpx;
				color: #333;
			}
			.oknx{
				width:343rpx;
				height:88rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0px 4rpx 8rpx 0px rgba(255,130,75,0.5);
				border-radius:49rpx;
				color: #fff;
			}
		}
		
	}
	.poup{
		position: fixed;
		width: 100vw;
		height: 100vh;
		top: 0;
		left: 0;
		z-index: 99;
		background: rgba(0,0,0,.6);
		.message{
			position: fixed;
			top: 30%;
			left: 50%;
			width: 488rpx;
			height: 316rpx;
			margin-left: -244rpx;
			background:#fff;
			border-radius: 24rpx;
			z-index: 999;
			text-align: center;
			.messageTit{
				display: block;
				color: #FF824B;
				font-size: 36rpx;
				font-weight:bold;
				margin-top: 50rpx;
				margin-bottom: 20rpx;
			}
			.tex{
				display: block;
				font-size: 28rpx;
				color: #666;
				font-weight: 400;
			}
			.btn{
				width: 404rpx;
				height: 84rpx;
				background:#FF824B;
				border-radius: 42rpx;
				font-size: 34rpx;
				color: #fff;
				margin-top: 30rpx;
			}
		}
	}
	
</style>
