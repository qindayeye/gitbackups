<template>
	<view>
		<view class="navbar">
			<view :class="type==0?'active':'navbar_item'" @click="commentList(0)">
				正在拼团
			</view> 
			<view :class="type==1?'active':'navbar_item'" @click="commentList(1)">
				成功团
			</view>
			<view :class="type==2?'active':'navbar_item'" @click="commentList(2)">
				失败团
			</view>
		</view>
		<view v-if="orderList.length === 0" class="empty" style="position:fixed;top:80rpx;height:100vh;overflow: hidden;">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>什么也没有</view>
				<view>快去寻找自己喜欢的绘本吧~</view>
				<view class="navigator" @click="navToindx()">去逛逛</view>
			</view>
		</view>
		<!-- 订单列表 -->
		<view class="goods-item" v-for="item in orderList" :key="item.order_id">
			<view class="goods-item-dsc" @click="Gotodetail()">
				<image :src="item.goods_thumb" mode=""></image>
				<view class="goods-dsc">
					<text>{{item.goods_name}}</text>
					<text>已有{{item.limit_num}}人参团</text>
					<text>{{item.team_price}}</text>
				</view>
				<view v-if="type==0" style="height: 180rpx;width: 180rpx;">

				</view>
				<image v-if="type==1" src="https://simon.abcbook2019.com/mobile/public/img/s-bg.png" mode=""></image>
				<image v-if="type==2" src="https://simon.abcbook2019.com/mobile/public/img/sb-bg.png" mode=""></image>
			</view>

			<view class="goods-item-btn">
				<text @click="gotoordetil(item.order_id)">查看订单</text>
				<text @click="gotoGroupPlan(item.team_id)">拼团进度</text>
			</view>
		</view>
		<view class="flocon" v-if="classon">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				type: 0,
				page:1,
				hide: true,
				classon: false, //判断模态框
				classoninfo: "正在努力加载...", //加载展示内容
				orderList: []
			}
		},
		onLoad: function() {

			this.commentList(0)
		},
		onReachBottom() {
			this.scroll();
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			if (Object.scrollTop > 800) {
				this.hide = false;
			} else {
				this.hide = true;
			}
			if (this.classoninfo == "我也是有底线的哦~") {
				this.classon = false
			}
		},
		methods: {
			navToindx() {
				uni.navigateTo({
					url: '../index/index'
				})
			},
			// 查看进度
			gotoGroupPlan(id) {
				let user_id = uni.getStorageSync("user_id")
				uni.navigateTo({
					url: '/pages/groupList/groupPlan?id=' + id+'&user_id='+user_id
				})
			},
			// 查看订单
			gotoordetil(id) {
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + id
				})
			},
			// 进入详情页
			Gotodetail() {
				uni.navigateTo({
					url: "../detail/groupdetail"
				})
			},
			commentList(type) {
				if (uni.getStorageSync("token")) {
					this.type = type
					this.page=1
					this.$api.quest('team/teamUserOrder', {
						page: this.page,
						type: type,
						size: 10,
					}, (res) => {
						console.log(res)
						this.orderList = res.data.data
						// this.loading = true
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}

			},
			// 下拉加载
			scroll() {
				const that = this;
				that.classon = true;
				this.loadingType = 1;
				this.$api.quest('team/teamUserOrder', {
					page: ++that.page,
					type: that.type,
					size: 10,
				}, (res) => {
					// console.log(res,'1')
					// console.log(res.data.data)
					if (res.data.data.length == 0) { //没有数据
						this.loadingType = 2;
						that.classon = true;
						that.classoninfo = "我也是有底线的哦~"
						uni.hideNavigationBarLoading(); //关闭加载动画
					}else{
						that.orderList.push(...res.data.data)
						// console.log(that.orderList,"w")
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
						// this.loading = true
					}
					
				})
			
			},
		}
	}
</script>

<style lang="scss" scoped>
	.navbar {
		margin-bottom: 20rpx;
		background-color: #FFFFFF;
		height: 80rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;

		.active {
			color: red;
		}

		.nav-item {}

	}

	.goods-item {
		margin-bottom: 10rpx;
		height: 280rpx;
		width: 100%;
		background-color: #FFFFFF;

		.goods-item-dsc {
			height: 200rpx;
			width: 100%;
			display: flex;
			justify-content: space-around;
			align-items: center;

			.goods-dsc {
				display: flex;
				justify-content: space-around;
				align-items: center;
				flex-direction: column;
			}

			image {
				width: 180rpx;
				height: 180rpx;
			}
		}

		.goods-item-btn {
			height: 70rpx;
			width: 100%;
			display: flex;
			justify-content: flex-end;
			align-items: center;
			border-top: 1rpx solid #E6E6E6;
			text {
				height: 50rpx;
				width: 150rpx;
				line-height: 50rpx;
				text-align: center;
				font-size: 31rpx;
				margin-right: 20rpx;
				border: 1rpx solid #FF824B;
				border-radius: 8rpx;
				color: #FF824B;
			}
		}
	}
</style>
