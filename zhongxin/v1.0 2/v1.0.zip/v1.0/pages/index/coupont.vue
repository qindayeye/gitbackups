<template>
	<view class="coupont" >
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<block v-if="qcj.length!=0">
			<view class="noy">
				<text class="xl"></text>
				<text>全场券</text>
				<text class="xr"></text>
			</view>
			<!-- 全场券 -->
			<view class="disbox">
				<block v-for="(item,index) in qcj" :key='index'>
					<view class="boxeve" :class="(item.enable_ling === 1 && item.cou_is_receive === 0) || (item.is_use === 1 && item.cou_is_receive == 1) ?'onbox':''">
						<view class="fl boxfl">
							<view class="pirc fl">
								<view class="to">
									￥<text>{{item.cou_money*1}}</text>
								</view>
								<text class="man">满{{item.cou_man}}元使用</text>
							</view>
							<view class="cardtitl ">
								<view class="catit">
									{{item.cou_title}}
								</view>
								<view class="cartime">
									{{item.begintime}}-{{item.endtime}}
								</view>
								<image class="is_use" v-if="item.is_use === 0 && item.cou_is_receive == 1"  src="https://www.abcbook2019.com//mobile/public/img/coupons-print.png" mode=""></image>
							</view>
						</view>
						<view class="use fr">
							<view class="tex" v-if="item.is_use === 1 && item.cou_is_receive == 1">
								已使用
							</view>
							<view class="tex" v-else-if="item.is_use === 0 && item.cou_is_receive == 1" @click="usecou()">
								立即<br>
								使用
							</view>
							<view class="tex" v-else-if="item.enable_ling === 1">
								已抢完
							</view>
							<view class="tex" v-else @click="getcou(item.cou_id)">
								立即<br>
								领取
							</view>
						</view>
					</view>
				</block>
			</view>
		</block>
		<block v-if="hyj.length!=0">
			<view class="noy">
				<text class="xl"></text>
				<text>会员券</text>
				<text class="xr"></text>
			</view>
			<!-- 全场券 -->
			<view class="disbox">
				<block v-for="(item,index) in hyj" :key='index'>
					<view class="boxeve" :class="(item.enable_ling === 1 && item.cou_is_receive === 0) || (item.is_use === 1 && item.cou_is_receive == 1) ?'onbox':''">
						<view class="fl boxfl">
							<view class="pirc fl">
								<view class="to">
									￥<text>{{item.cou_money*1}}</text>
								</view>
								<text class="man">满{{item.cou_man}}元使用</text>
							</view>
							<view class="cardtitl ">
								<view class="catit">
									{{item.cou_title}}
								</view>
								<view class="cartime">
									{{item.begintime}}-{{item.endtime}}
								</view>
								<image class="is_use" v-if="item.is_use === 0 && item.cou_is_receive == 1"  src="https://www.abcbook2019.com//mobile/public/img/coupons-print.png" mode=""></image>
							</view>
						</view>
						<view class="use fr">
							
							<view class="tex" v-if="item.is_use === 1 && item.cou_is_receive == 1">
								已使用
							</view>
							<view class="tex" v-else-if="item.is_use === 0 && item.cou_is_receive == 1" @click="usecou()">
								立即<br>
								使用
							</view>
							<view class="tex" v-else-if="item.enable_ling === 1">
								已抢完
							</view>
							<view class="tex" v-else @click="getcou(item.cou_id)">
								立即<br>
								领取
							</view>
						</view>
					</view>
				</block>
			</view>
		</block>
		<block v-if="grj.length!=0">
			<view class="noy">
				<text class="xl"></text>
				<text>个人劵</text>
				<text class="xr"></text>
			</view>
			<!-- 个人券 -->
			<view class="disbox">
				<block v-for="(item,index) in grj" :key='index'>
					<view class="boxeve" :class="(item.enable_ling === 1 && item.cou_is_receive === 0) || (item.is_use === 1 && item.cou_is_receive == 1) ?'onbox':''">
						<view class="fl boxfl">
							<view class="pirc fl">
								<view class="to">
									￥<text>{{item.cou_money*1}}</text>
								</view>
								<text class="man">满{{item.cou_man}}元使用</text>
							</view>
							<view class="cardtitl ">
								<view class="catit">
									{{item.cou_title}}
								</view>
								<view class="cartime">
									{{item.begintime}}-{{item.endtime}}
								</view>
								<image class="is_use" v-if="item.is_use === 0 && item.cou_is_receive == 1"  src="https://www.abcbook2019.com//mobile/public/img/coupons-print.png" mode=""></image>
							</view>
							
						</view>
						<view class="use fr">
							
							<view class="tex" v-if="item.is_use === 1 && item.cou_is_receive == 1">
								已使用
							</view>
							<view class="tex" v-else-if="item.is_use === 0 && item.cou_is_receive == 1" @click="usecou()">
								立即<br>
								使用
							</view>
							<view class="tex" v-else-if="item.enable_ling === 1">
								已抢完
							</view>
							<view class="tex" v-else @click="getcou(item.cou_id)">
								立即<br>
								领取
							</view>
						</view>
					</view>
				</block>
			</view>
		</block>
		<view v-if="qcj.length==0&hyj.length==0&&grj.length==0" class="empty">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>您还没有可以使用的优惠券哦</view>
				<view class="navigator" @click="usecou">去逛逛</view>
			</view>
		</view>
	</view>
	
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default{
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data(){
			return {
				msg: "优惠券",
				qcj:[],
				hyj:[],
				grj:[],
				myj:[],
				page:1,  // 上拉刷新页数
				classon:false, //判断模态框
			}
		},
		onPullDownRefresh:function(){
		  this.load()
		  setTimeout(function () {
			  uni.stopPullDownRefresh();  //停止下拉刷新动画
		  }, 1000);
		
		 },
		onLoad:function(option){
			// 年卡立减150
			// this.load()
			console.log(option)
			if(option.type=='ticket'){
				this.$api.quest('user/conpont',{
					page:this.page,
					},(res)=>{
						console.log(res)
						console.log(res.data.data.hyj)
					if(res.data.data.hyj != null){
						this.hyj= res.data.data.hyj
					}
					console.log(this.hyj,this.hyj.length)
				})
			}else{
				this.load()
			}
		},
		methods:{
			// 点击立即使用
			load(){
					let that = this;
					this.$api.quest('user/conpont',{
						page:that.page,
						},(res)=>{
						console.log(res)
						if(res.data.data.error==1){
							uni.navigateTo({
								url:'/pages/public/login'
							})
						}else{
							if(res.data.data.qcj != null){
								that.qcj= res.data.data.qcj
							}
							if(res.data.data.hyj != null){
								that.hyj= res.data.data.hyj
							}
							if(res.data.data.myj != null){
								that.myj= res.data.data.myj
							}
							if(res.data.data.grj != null){
								that.grj= res.data.data.grj
							}
						}
					})
			},
			usecou(){
				// this.$store.commit("change_page", 0)
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			getcou(id){
				this.$api.quest('user/getcoupons',{id:id},(res)=>{
					if(res.data.code==0){
						this.$api.msg(res.data.data)
						this.load()
					}else{
						this.$api.msg(res.data.data)
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.is_use{
		position: absolute;
		bottom: 0;
		right: 2rpx;
		width: 100rpx;
		height: 100rpx;
	}
	.onbox{
		filter: grayscale(100%);
		-webkit-filter: grayscale(100%);
		opacity: .6;

	}
	.coupont{
		.noy{
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 30rpx;
			width:710rpx;
			margin: 20rpx auto;
			text{
				position: relative;
				display: block;
				font-size: 24rpx;
				color: #999;
			}
			.xl,.xr{
				width: 275rpx;
				height: 1rpx;
				background: #e6e6e6;
			}
		}
		.disbox{
			.boxeve{
				position: relative;
				background-image: url('https://www.abcbook2019.com/mobile/public/img/redenvelope/card_bj.png');
				background-size: cover;
				width: 710rpx;
				height: 192rpx;
				margin: 0 auto;
				margin-bottom: 20rpx;
				.boxfl{
					width: 560rpx;
					.pirc{
						width: 219rpx;
						height: 192rpx;
						display: flex;
						align-items: center;
						justify-content: center;
						flex-direction: column;
						background-repeat:no-repeat;
						.to{
							font-size: 38rpx;
							color: #FF824B;
							text{
								font-size: 60rpx;
								font-family: DIN Alternate Bold;
								letter-spacing:-2px;
							}
						}
						.man{
							font-size: 24rpx;
							color: #333;
						}
					}
					.cardtitl{
						position: relative;
						width: 340rpx;
						height: 192rpx;
						display: flex;
						// align-items: center;
						flex-direction: column;
						justify-content: center;
						box-sizing: border-box;
						padding-left: 30rpx;
						.catit{
							font-size: 32rpx;
							color: #333;
							font-weight: bold;
							margin-bottom: 20rpx;
						}
						.cartime{
							font-size: 24rpx;
							color: #999;
						}
					}
				}
				.use{
					display: flex;
					width: 150rpx;
					height: 192rpx;
					.tex{
						color: #fff;
						font-size: 30rpx;
						text-align: center;
						margin: auto;
					}
				}
				.expire{
					position: absolute;
					top: 0;
					left: 0;
					width:110rpx;
					height: 38rpx;
					background:linear-gradient(135deg,rgba(250,108,58,1) 0% ,rgba(254,163,100,1) 100%);
					font-size: 20rpx;
					color: #fff;
					line-height: 38rpx;
					text-align: center;
					border-radius: 10rpx 0;
				}
			}
			
		}
		
	}
</style>
