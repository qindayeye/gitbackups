<template>
	<view v-if="loading" class="container">
		<view class="mp-search-box">
			<!-- 头部 -->
			<view class="head">
				<view @click="cityse" class="eosfont location">&#xe606;
					<text>北京</text>
				</view> <!-- 定位 -->
				<view class="inp">
					<text class="eosfont search">&#xe600;</text> <!-- 放大镜 -->
					<input type="text" placeholder="学乐" @click="gotoban('/pages/search/search')" />
				</view>
				<image v-if="godid" class="voimg" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/voiceing2.gif" @click="gotoban('/pages/voice/voicedetail?id='+godid)"
				 mode=""></image>
				<!-- godid -->
			</view>
			<!-- 导航 -->
			<view class="nav">
				<text :class="{active : index===curId}" v-for="(item,index) in indexArr.top_nav" :key="index" @click="gotoactivity(index,item)">{{item.cat_name}}</text>
			</view>
		</view>
		<!-- 头部轮播 -->
		<view class="carousel-section">
			
			<swiper class="swiper-box" :indicator-dots="indicator" :current="cur" :circular="circular" :autoplay="autoplay"
			 :interval="interval" :duration="duration">
			
				<block v-for="(item,index) in indexArr.banner" :key='index'>
					
					 <swiper-item  @click="gotoban(item.app_link,index)">
						 <image class="banner-img" :src="item.pic"  mode="widthFix"></image>
					 </swiper-item>
					
				</block>
				
			</swiper>
		</view>
		
		<!-- 分类 -->
		<view class="navlist">
			<view class="list">
				<block v-for="(item,index) in indexArr.nav" :key='index'>
					<view @click="goto(item,index)" class="goto">
						<image :src="item.pic" mode="widthFix" lazy-load='true'></image>
						<text>{{item.ad_name}}</text>
					</view>
				</block>
			
			</view>
		</view>

		
		<!-- #ifdef MP -->
		<button class="service" open-type="contact">
			<view class="bjse">
				<image src="https://www.abcbook2019.com/mobile/public/img/service2.png" mode=""></image>
			</view>
		</button>
		<!-- #endif -->
		<!-- 热门推荐 -->
		<view class="page pagehot">
		        <view class="hotmain">
		            <!-- <bookdetail ></bookdetail> -->
		         <block v-for="(item,index) in hotmain" :key='index'>
		                 <navigator :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
		                    <view class="hot_main_con">
		                         <image class="bookimg" :src="item.goods_thumb" mode=""></image>
		                        <view class="bookinfo">
		                             <text class="bookinfotitl">{{item.goods_name}}</text>
		                            <view class="bom_btn">
		                                <view class="label_btn">
		                                    <view class="label_btn1">
		                                        <image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/zan.png" mode=""></image>
		                                        <view class="">小编推荐</view>
		                                    </view>
		                                    <view class="label_btn2">急速退款</view>
		                                </view>
		                                <view class="label">
		                                    <text class="label_1">{{item.shop_price}}</text>
		                                    <text class="label_2">{{item.market_price}}</text>
		                                </view>
		                                <view class="bangdan">
		                                    入选牛排畅销榜
		                                    <image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/xiangyou.png" mode=""></image>
		                                </view>
		                            </view>
		                        </view>
		                    </view>
		                </navigator>
		            </block>
		        </view>
		    </view>

		<!-- dibu -->
		<view class="main-content">
			<footer>
				<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view>

		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		<!-- success -->
		<view class="message" v-if="success">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="con">
				<view class="fl">
					<image class="gift" src="https://www.abcbook2019.com/mobile/public/img/pop-up/giftCard.png" mode=""></image>
				</view>
				<view class="fr">
					<image class="free" src="https://www.abcbook2019.com/mobile/public/img/pop-up/FreeToBorrow.png" mode="" @click="gotoban('/pages/invitation/invitation')"></image>
					<image class="addvip" src="https://www.abcbook2019.com/mobile/public/img/pop-up/Invite.png" mode=""></image>
				</view>
			</view>
		</view>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "../navbar/navbar.vue";
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		data() {
			return {
				loading: false,
				curId: 0,
				activeClass: -1,
				indexArr: {},
				godid: '',
				hotmain: [],
				indicator: true, //是否显示指示点
				interval: 5000, //自动切换时间间隔
				duration: 400, //滑动动画时长
				autoplay: true, //是否自动切换
				circular: true, //是否采用衔接滑动
				classon: false, //判断模态框
				gghurl:false,
				cur: 0, //当前所在滑块的index
				page: 1,
				hide: true,
				classoninfo: "", //加载展示内容
				hasno: false, //判断有没有消息
				success: false,
				
			};
		},
		onReachBottom() {
			this.scroll();
		},
		components: {
			bottomNav,
			mixLoading
		},
		onShareAppMessage(res) {
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
			}
			return {
				title: 'ABCbook国际亲子阅读',
				path: '/pages/index/index'
			}
		},
		onPullDownRefresh: function() {
			this.load()
			setTimeout(function() {
				uni.stopPullDownRefresh(); //停止下拉刷新动画
			}, 1000);

		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			if (Object.scrollTop > 800) {
				this.hide = false;
			} else {
				this.hide = true;
			}
		},
		onReady() {
			// uni.setStorageSync('voivegodid','')
			console.log("onReady")
			// console.log(uni.getStorageSync('voivegodid'))
			// this.godid=uni.getStorageSync('voivegodid')

		},
		onUnload() {
			if (this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		},
		onShow() {
			console.log('onShow')
			// this.godid = uni.getStorageInfo('voivegodid')
			this.timer = setInterval(() => {
				this.godid = uni.getStorageSync('voivegodid')
				// console.log(this.godid)
			}, 500)
			// console.log(uni.getStorageInfo('voivegodid'))
			// this.load()
		},
		onUnload() {
			if (this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		},
		onLoad: function(options) {
			// uni.setStorageSync('voivegodid','')
			uni.setStorageSync('uid', options.u_id)
			this.load()
			this.$store.commit("change_page", 0)
		},
		methods: {
			upper: function(e) {
				console.log(e)
				uni.navigateTo({
					url:'/pages/famous/famous?id=104'
				})
			},
			expertper(e){
				uni.navigateTo({
					url:'/pages/expert/expert?id=147'
				})
			},
			
			
			gotoban(url) {
				uni.navigateTo({
					url: url
				})
			},


			// 关闭
			close() {
				this.success = false
			},
			// 去那一页
			goto(item, index) {
				if (uni.getStorageSync("token")) {
					uni.navigateTo({
						url: item.app_link
					})
					
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})

					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif

					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			// 页面初始化
			load() {
				var that = this;
				this.$api.quest('index', {}, (res) => {
					that.hotmain = res.data.data.goods_list
					that.indexArr = res.data.data
					this.loading = true;
				})
			},
			gotonew() {
				if (uni.getStorageSync("token")) {
					uni.navigateTo({
						url: '/pages/news/news'
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})

					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif

					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}

			},
			// 搜索
			gotoactivity: function(index, item) {
				this.curId = index;
				let ids = {}
				ids.class = item.cat_id
				uni.navigateTo({
					url: `/pages/search/agesearch?data=${JSON.stringify({
							ids,
						})}`
				})
			},
			// 搜索
			gotoage(id) {
				let ids = {}
				ids.age = id
				// console.log(index,"index",item,"item",item.active)
				uni.navigateTo({
					url: `/pages/search/agesearch?data=${JSON.stringify({
						ids,
					})}`
				})
			},
			// 返回顶部点击事件
			gotop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			// 下拉加载
			scroll() {
				const that = this;
				console.log(that.classon, "classon")
				that.classon = true;
				that.classoninfo = "正在努力加载..."
				this.loadingType = 1;
				this.$api.quest('nextpage', {
					page: that.page++
				}, (res) => {
					if (res.data == null) { //没有数据
						_self.loadingType = 2;
						that.classon = true;
						that.classoninfo = "我也是有底线的哦~"
						uni.hideNavigationBarLoading(); //关闭加载动画
						return;
					}
					that.hotmain.push(...res.data.data.goods_list)
					uni.hideNavigationBarLoading(); //关闭加载动画
					that.classon = false //判断模块框
					// console.log(that.hotmain,'hot',that.page,'page')
					uni.hideNavigationBarLoading(); //关闭加载动画
				})
			},
			// 加入书架
			addBook(e, id, num) {
				console.log(e,id,num)
				this.$api.addBook(e, id, num)
			},
			// 获取定位
			cityse() {
				uni.chooseLocation({
					success: function(res) {
						console.log('位置名称：' + res.name);
						console.log('详细地址：' + res.address);
						console.log('纬度：' + res.latitude);
						console.log('经度：' + res.longitude);
					}
				});

			}
		}
	}
</script>

<style lang="scss">
	
	@import '../../static/css/index.scss' ;
	.scroll-view_H{
	  width: 100%;
	  white-space: nowrap;
	}
	.scroll-view-item_H{
	  // width: 200px;
	  // height: 100px;
	  vertical-align: top;
	  display: inline-block;
	}
	.more{
		width: 72rpx !important;
		writing-mode: tb-rl;
		line-height: 72rpx;
		margin-right: 20rpx;
		font-size: 24rpx;
		color: #999;
		letter-spacing: 10rpx;
		border-radius: 10rpx;
		.yticon{
			margin-top: 30rpx;
			font-size: 14rpx;
		}
	}

	
</style>
