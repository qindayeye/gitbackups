<template>
	<view class="account">
		<view class="headerd">
			<view class="title">
				<navigator class="cell-icon yticon icon-zuo"  open-type="navigateBack"></navigator>
				<h4>押金</h4>
			</view>
			<view class="con">
				<view class="contitle">我的押金(元)</view>
				<view class="scclist">
					<view class="all">
						
						<text>全部</text>
						<text>￥{{count_deposit?count_deposit:'0.00'}}</text>
					</view>
					<view class="all">
						<text>未退</text>
						<text v-if="deposit_old>0">￥{{frozen_money}}</text>
						<text v-else>￥{{count_deposit_ing?count_deposit_ing:'0.00'}}</text>
					</view>
					<view class="all">
						<text>已退</text>
						<text>￥{{count_deposit_ok?count_deposit_ok:"0.00"}}</text>
					</view>
				</view>
				<!-- <h2>{{frozen_money}}</h2> -->
				<button type="primary" v-if="deposit_old>0" class="btn" :disabled="frozen" @click="frozenmoney()">退押金</button>
			</view>
		</view>	
		<view class="pint" v-if="deposit_old<0">
			支付分550以上可免押金，或交200元押金租书
		</view>
		<view class="accList">
			<view class="accinfo clear" v-for="(item,index) in list" @click="gotoaccdet(item)">
				<view class="fl left">
					<view class="infoti">订单号：{{item.order_sn}}</view>
					<view class="infotime">{{item.add_time}}({{item.deposit_type==1?'微信支付分支付':'微信支付'}})</view>
				</view>
				<view class="fr money">
					<text class="rederst" :class="item.order_status=='已完成'?'green':''">{{item.order_status}}</text>
				</view>
			</view>
		</view>
		<!-- 加载信息 -->
		<view :class="{'classon':classon}">{{classoninfo}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				frozen_money:"",
				list:[],
				frozen:false,
				page:1,
				classon:false, //判断模态框
				classoninfo:"" ,//加载展示内容
				count_deposit_ok:'',
				count_deposit_ing:'',
				count_deposit:'',
				deposit_old:''
			}
		},
		onLoad(option){
			this.$api.quest('user/deposit/list',{
				page: 1,
				size: 10,
				status:0,
				type: ""
			},(res)=>{
				console.log(res)
				if(res.data.code==0){
					this.frozen_money=res.data.data.frozen_money
					console.log(res.data.data.count)
					this.list=res.data.data.list
					this.count_deposit=res.data.data.count.deposit
					this.count_deposit_ing=res.data.data.count.deposit_ing
					this.count_deposit_ok=res.data.data.count.deposit_ok
					this.deposit_old=res.data.data.count.deposit_old
					// console.log(this.count_deposit,this.count_deposit_ing,this.count_deposit_ok)
				}
			})
			
			
			// this.$api.quest('user/order/list',{
			// 	page: 1,
			// 	size: 10,
			// 	status:0,
			// 	type: ""
			// },(res)=>{
			// 	if(res.data.code==0){
					
			// 		// this.frozen_money=res.data.data.frozen_money
			// 		this.list=res.data.data
			// 		// console.log(this.frozen_money)
			// 	}
			// })
		},
		onReachBottom(){
			this.scroll();
		},
		methods: {
			// 跳转详情页
			gotoaccdet(item){
				uni.navigateTo({
					url:`/pages/index/accountdetile?data=${JSON.stringify({
											list: item
										})}`
				})
			},
			frozenmoney(){
				this.$api.quest('user/refundFrozenMoney',{
					page:1
				},(res)=>{
					// console.log(res)
					if(res.data.data.code==0){
						this.$api.msg(res.data.data.data)
						this.frozen=true
					}else{
						this.$api.msg(res.data.data.data)
					}
				})
			},
			// 下拉刷新
			scroll(){
				const that=this;
				console.log(that.classon,"classon")
				that.classon=true;
				that.classoninfo="正在努力加载..."
				this.loadingType=1;
				this.$api.quest('user/deposit/list',{
					page:++that.page,
					size: 10,
					status:0,
					type: ""
				},(res)=>{
					if (res.data.data.length == 0) {  //没有数据
					    this.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
					    uni.hideNavigationBarLoading();//关闭加载动画
					    return;
					}
						that.list.push(...res.data.data.list) 
						  uni.hideNavigationBarLoading();//关闭加载动画
						 that.classon=false   //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading();//关闭加载动画
				})
			},
			
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/account.scss';
	.green{
		color: #1AAD19;
	}
	.classon {
		padding-top: 20rpx;
	}
	.contitle{
		font-size: 32rpx;
		// font-weight: bold;
		color: #fff;
		margin-bottom: 40rpx;
	}
	.scclist{
		display: flex;
		justify-content: space-around;
		align-items: center;
		.all{
			width: 33.33%;
			border-right: 1rpx solid #fff;
			&:last-child{
				border: none;
			}
			text{
				font-size: 28rpx !important;
				color: #fff;
			}
		}
	}
</style>
