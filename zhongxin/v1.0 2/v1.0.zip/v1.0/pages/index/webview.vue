<template>
	<view>
		<web-view src="https://mp.weixin.qq.com/s/NiTd0yqgybgN1KIzDZM-9Q"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		}
	}
</script>

<style>
</style>
