<template>
	<view v-if="loading" class="container">
		<view class="mp-search-box" :style="{height:(isIphoneX?'255rpx':'215rpx')}">
			<!-- 头部 -->
			
			<view class="head" :style="{paddingTop:(isIphoneX?'100rpx':'60rpx')}">
			
				<view class="inp">
					<text class="eosfont search">&#xe600;</text> <!-- 放大镜 -->
					<input type="text" placeholder="搜索你想要的商品" @click="gotoban('/pages/search/search')" />
				</view>
				
				<!-- godid -->
			</view>
			<!-- 导航 -->
			<view class="nav">
				<text :class="{active : index===curId}" v-for="(item,index) in indexArr.top_nav" :key="index" @click="gotoactivity(index,item)">{{item.cat_name}}</text>
			</view>
		</view>
		<!-- 头部轮播 -->
		<view class="carousel-section" :style="{top:(isIphoneX?'255rpx':'215rpx')}">
			
			<swiper class="swiper-box" :indicator-dots="indicator" :current="cur" :circular="circular" :autoplay="autoplay"
			 :interval="interval" :duration="duration">
			
				<block v-for="(item,index) in indexArr.banner" :key='index'>
					
					 <swiper-item  @click="gotoban(item.app_link,index)">
						 <image class="banner-img" :src="item.pic"  mode="widthFix"></image>
					 </swiper-item>
					
				</block>
				
			</swiper>
		</view>
		
		<!-- 分类 -->
		<view class="navlist" :style="{marginTop:(isIphoneX?'263rpx':'223rpx')}">
			<view class="list">
				<block v-for="(item,index) in indexArr.nav" :key='index'>
					<view @click="goto(item,index)" class="goto">
						<image :src="item.pic" mode="widthFix" lazy-load='true'></image>
						<text>{{item.ad_name}}</text>
					</view>
				</block>
			
			</view>
		</view>
		<!-- 百亿补贴 -->
		<view class="subsidy">
			<view class="pagetitle clear">
				<image class="fl" src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/iconp.png" mode=""></image>
				<view class="tit fl">
					<text class="tex1">品牌补贴</text>
					<text class="tex2">大牌正品  补贴优惠</text>
				</view>
				<!--<view class="fr">
					 <text class="tex1">全部</text> 
					<text class="more-icon yticon icon-you"></text>
				</view>-->
			</view>
			<view class="pagecon clear">
				<view class="logo fl">
					<image  :src="subsidies" mode="widthFix"></image>
				</view>
				<block v-for="(item,index) in bestgoods" :key='index'>
					<navigator :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
				<view class="conp fl">
					<image  :src="item.goods_thumb" mode=""></image>
					<view class="fc">{{item.goods_name}}</view>
					<view class="alone">
						<text>补贴价</text>
						<text>￥{{item.shop_price}}</text>
					</view>
				</view>
				 </navigator>
				 </block>
			</view>
		</view>
		
		<!-- #ifdef MP -->
		<button class="service" open-type="contact">
			<view class="bjse">
				<image src="https://www.abcbook2019.com/mobile/public/img/service2.png" mode=""></image>
			</view>
		</button>
		<!-- #endif -->
		<!-- 热门推荐 -->
		<view class="page pagehot">
		        <view class="hotmain">
		            <!-- <bookdetail ></bookdetail> -->
		         <block v-for="(item,index) in hotmain" :key='index'>
		                 <navigator :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
		                    <view class="hot_main_con">
		                         <image class="bookimg" :src="item.goods_thumb" mode=""></image>
		                        <view class="bookinfo">
		                             <text class="bookinfotitl">{{item.goods_name}}</text>
		                            <view class="bom_btn">
		                                <view class="label_btn">
		                                    <view class="label_btn1">
		                                        <image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/zan.png" mode=""></image>
		                                        <view class="">小编推荐</view>
		                                    </view>
		                                    <view class="label_btn2">急速退款</view>
		                                </view>
		                                <view class="label">
		                                    <text class="label_1">{{item.shop_price}}</text>
		                                    <text class="label_2">{{item.market_price}}</text>
		                                </view>
		                                <view class="bangdan">
		                                    入选牛排畅销榜
		                                    <image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/xiangyou.png" mode=""></image>
		                                </view>
		                            </view>
		                        </view>
		                    </view>
		                </navigator>
		            </block>
		        </view>
		    </view>

		<!-- dibu -->
		<view class="main-content">
			<footer>
				<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view>

		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		<!-- success -->
		<view class="message" v-if="success">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="con">
				<view class="fl">
					<image class="gift" src="https://www.abcbook2019.com/mobile/public/img/pop-up/giftCard.png" mode=""></image>
				</view>
				<view class="fr">
					<image class="free" src="https://www.abcbook2019.com/mobile/public/img/pop-up/FreeToBorrow.png" mode="" @click="gotoban('/pages/invitation/invitation')"></image>
					<image class="addvip" src="https://www.abcbook2019.com/mobile/public/img/pop-up/Invite.png" mode=""></image>
				</view>
			</view>
		</view>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "../navbar/navbar.vue";
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		data() {
			return {
				loading: false,
				curId: 0,
				activeClass: -1,
				indexArr: {},
				godid: '',
				isIphoneX:false,
				hotmain: [],
				bestgoods:[],
				indicator: true, //是否显示指示点
				interval: 5000, //自动切换时间间隔
				duration: 400, //滑动动画时长
				autoplay: true, //是否自动切换
				circular: true, //是否采用衔接滑动
				classon: false, //判断模态框
				gghurl:false,
				cur: 0, //当前所在滑块的index
				page: 1,
				hide: true,
				classoninfo: "", //加载展示内容
				hasno: false, //判断有没有消息
				success: false,
				subsidies:false
				
			};
		},
		onReachBottom() {
			this.scroll();
		},
		components: {
			bottomNav,
			mixLoading
		},
		onShareAppMessage(res) {
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
			}
			return {
				title: 'ABCbook国际亲子阅读',
				path: '/pages/index/index'
			}
		},
		onPullDownRefresh: function() {
			this.load()
			setTimeout(function() {
				uni.stopPullDownRefresh(); //停止下拉刷新动画
			}, 1000);

		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			if (Object.scrollTop > 800) {
				this.hide = false;
			} else {
				this.hide = true;
			}
		},
		onReady() {
			// uni.setStorageSync('voivegodid','')
			console.log("onReady")
			// console.log(uni.getStorageSync('voivegodid'))
			// this.godid=uni.getStorageSync('voivegodid')

		},
		onUnload() {
			if (this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		},
		onShow() {
			console.log('onShow')
			// this.godid = uni.getStorageInfo('voivegodid')
			this.timer = setInterval(() => {
				this.godid = uni.getStorageSync('voivegodid')
				// console.log(this.godid)
			}, 500)
			uni.getSystemInfo({
				success: res=>{
					// console.log('手机信息res'+res.model)
					let modelmes = res.model;
						if (modelmes.search('iPhone X') != -1) {
							// console.log('1111')
						this.isIphoneX = true
						}
					}
			})
		},
		onUnload() {
			if (this.timer) {
				clearInterval(this.timer);
				this.timer = null;
			}
		},
		onLoad: function(options) {
			// uni.setStorageSync('voivegodid','')
			uni.setStorageSync('uid', options.u_id)
			this.load()
			this.$store.commit("change_page", 0)
		},
		methods: {
			upper: function(e) {
				console.log(e)
				uni.navigateTo({
					url:'/pages/famous/famous?id=104'
				})
			},
			expertper(e){
				uni.navigateTo({
					url:'/pages/expert/expert?id=147'
				})
			},
			
			
			gotoban(url) {
				uni.navigateTo({
					url: url
				})
			},


			// 关闭
			close() {
				this.success = false
			},
			// 去那一页
			goto(item, index) {
				if (uni.getStorageSync("token")) {
					uni.navigateTo({
						url: item.app_link
					})
					
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})

					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif

					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			// 页面初始化
			load() {
				var that = this;
				this.$api.quest('index', {}, (res) => {
					that.hotmain = res.data.data.goods_list
					that.bestgoods = res.data.data.best_goods_list
					that.subsidies = res.data.data.subsidies[0].pic
					that.indexArr = res.data.data
					this.loading = true;
				})
			},
			gotonew() {
				if (uni.getStorageSync("token")) {
					uni.navigateTo({
						url: '/pages/news/news'
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})

					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif

					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}

			},
			// 搜索
			gotoactivity: function(index, item) {
				this.curId = index;
				let ids = {}
				ids.class = item.cat_id
				uni.navigateTo({
					url: `/pages/search/agesearch?data=${JSON.stringify({
							ids,
						})}`
				})
			},
			// 搜索
			gotoage(id) {
				let ids = {}
				ids.age = id
				// console.log(index,"index",item,"item",item.active)
				uni.navigateTo({
					url: `/pages/search/agesearch?data=${JSON.stringify({
						ids,
					})}`
				})
			},
			// 返回顶部点击事件
			gotop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			// 下拉加载
			scroll() {
				const that = this;
				console.log(that.classon, "classon")
				that.classon = true;
				that.classoninfo = "正在努力加载..."
				this.loadingType = 1;
				this.$api.quest('nextpage', {
					page: that.page++
				}, (res) => {
					if (res.data == null) { //没有数据
						_self.loadingType = 2;
						that.classon = true;
						that.classoninfo = "我也是有底线的哦~"
						uni.hideNavigationBarLoading(); //关闭加载动画
						return;
					}
					that.hotmain.push(...res.data.data.goods_list)
					uni.hideNavigationBarLoading(); //关闭加载动画
					that.classon = false //判断模块框
					// console.log(that.hotmain,'hot',that.page,'page')
					uni.hideNavigationBarLoading(); //关闭加载动画
				})
			},
			// 加入书架
			addBook(e, id, num) {
				console.log(e,id,num)
				this.$api.addBook(e, id, num)
			},
			// 获取定位
			cityse() {
				uni.chooseLocation({
					success: function(res) {
						console.log('位置名称：' + res.name);
						console.log('详细地址：' + res.address);
						console.log('纬度：' + res.latitude);
						console.log('经度：' + res.longitude);
					}
				});

			}
		}
	}
</script>

<style lang="scss">
		page{
			background: #f4f4f4;
		}
		.container{
			position: relative;
		}
		// 小程序头部兼容
			.mp-search-box{
				position: fixed;
				top: 0;
				width: 100%;
				height:215upx;
				background: #fff;
				z-index: 999;
				.head{
					// height: 88rpx;
					display: flex;
					justify-content: space-between;
					box-sizing: border-box;
					align-items: center;
					// padding: 0 22upx;
					padding-top:60rpx;
					.location{
						text{
							font-size: 26rpx;
							line-height: 88rpx;
							margin-left: 10rpx;
						}
					}
					.inp{
						display: flex;
						align-content: center;
						height: 66upx;
						width: 514rpx;
						background: #ededed;
						border-radius: 30upx;
						margin-left: 20rpx;
						justify-content: center;
						text{
							margin: 0 20upx 0 15upx;
						}
						.search{
							color: #333;
							font-size: 30upx;
							line-height: 66upx;
							margin-left: 25upx;
						}
						input{
							display:block;
							height: 100%;
							line-height: 60rpx;
							font-size:24upx;
							font-family:PingFangSC-Regular;
							font-weight:400;
							color:rgba(204,204,204,1);
						}
					}
				}
				.nav{
					display: flex;
					align-items: center;
					white-space: nowrap;
					line-height:80rpx;
					overflow-x: scroll;
					-webkit-overflow-scrolling: touch;
					white-space: nowrap;
					text{
						position: relative;
						display: inline-block;
						margin-left: 20rpx;
						color: #666;
						font-size: 30rpx;
					}
					.active{
						position: relative;
						color: #ee3937;
					}
					.active::before{
						display: block;
						content: "";
						position: absolute;
						width: 60rpx;
						height: 4rpx;
						bottom: 0;
						left: 50%;
						transform: translate(-50%,0%);
						background: #ee3937;
					}
				}
				.nav::-webkit-scrollbar {
					display:none
					}
			}
		// 头部轮播	
		.carousel-section{
			position: relative;
			top: 215rpx;
			left:50%;
			width: 736rpx;
			height: 286upx;
			transform: translate(-50%,0%);
			.swiper-box{
				height: 100%;
				
				.wx-swiper-dot{
					
					bottom: 6upx;
				    width:14upx; 
				    display: inline-flex;
					margin-left: 7upx;
				    height: 14upx;
					
					
				    justify-content:space-between;
				}
				
				image{
					width: 100%;
					height: 286upx;
					overflow: hidden;
				}
			}
			.swiper-box .wx-swiper-dot::before{
			    content: '';
			    flex-grow: 1;
				background: #fff;
			    border-radius: 50%;
			}
			.swiper-box .wx-swiper-dot-active::before{
			   background:#d92f27; 
			}
			
		
		}	
		.wx-swiper-dots{
		      position:relative;
		      left: unset!important;
		      right: 0;  
		}
		.wx-swiper-dots.wx-swiper-dots-horizontal{
		margin-bottom: -5rpx;
		}
		// 百亿补贴
		.subsidy{
			padding:20rpx;
			background: #fff;
			margin-bottom: 20rpx;
			.pagetitle{
				display: flex;
				align-items: center;
				height: 40rpx;
				justify-content: space-between;
				image{
					height: 40rpx;
					width: 40rpx;
					margin-right: 20rpx;
				}
				.tit{
					flex: 1;
					.tex1{
						font-size: 30rpx;
						font-weight: bold;
					}
					.tex2{
						font-size: 26rpx;
						color: #666;
						border-left: 1px solid #e6e6e6;
						padding-left: 20rpx;
						margin-left: 20rpx;
					}
				}
				.fr{
					font-size: 26rpx;
					color: #666;
					.tex1{
						margin-right: 15rpx;
					}
				}
			}
			.pagecon{
				margin-top: 20rpx;
				.logo{
					width: 300rpx;
					height: 229rpx;
					display: flex;
					image{
						width: 300rpx;
						display: block;
						margin: auto;
					}
				}
				
				.conp{
					position: relative;
					width:180rpx;
					height: 229rpx;
					margin-left: 20rpx;
					
					image{
						width:155rpx;
						height: 180rpx;
						display: block;
						margin: 0 auto;
						margin-bottom: 20rpx;
					}
					.fc{
						position: absolute;
						top: 155rpx;
						left: 0;
						width:100rpx;
						height: 27rpx;
						background: #d6a285;
						color: #fff;
						font-size: 20rpx;
						line-height: 26rpx;
						text-align: center;
						overflow:hidden;
					}
					.alone{
						font-size: 22rpx;
						color: #d44232;
						letter-spacing: 1rpx;
					}
				}
			}
		}
	// 分类
	.navlist{
		  height: 100%;
		  // width: 710upx;
		  margin: 0 auto;
		  margin-top:223rpx;
		  display: flex;
		  flex-wrap: wrap;
		  .list{
		   width: 100%;
		   margin-bottom:17rpx;
		   background: #fff;
		   border-radius: 10rpx;
		   padding-top: 20rpx;
		   .goto{
		    display: flex;
		    flex-direction: column;
		    align-items: center;
		    text-align: center;
		    display: inline-block;
		    width: calc(100%/5);
		    margin-bottom: 20rpx;
		   }
		   image{
		    width: 80upx;
		    height: 80upx;
		    margin-bottom: 5upx;
		    display: block;
		    margin: 0 auto;
		   }
		   text{
		    width: 100%;
		    font-size: 24upx;
		    margin-top:15upx;
		    color: #333;
		   }
		  }
		 }
		// 定制计划
		.customplanad{
			// position: absolute;
			// top: 130rpx;
			// left:50%;
			width: 734rpx;
			height: 202upx;
			// transform: translate(-50%,0%);
			text-align: center;
			margin: 0 auto;
			image{
				width: 734rpx;
				height:202rpx;
			}
			.ad-box{
				height: 100%;
			}
			.ad-box .wx-swiper-dot::before{
			    content: '';
			    flex-grow: 1;
				// background: rgba(255,255,255,.3 );
			    border-radius: 50%;
			}
			.ad-box .wx-swiper-dot-active::before{
			    background:#fff;  
			}
		}
		//帮助中心，库房视频
		.ad{
			height: 100%;
			margin-bottom:20upx;	
			width: 710upx;
			box-sizing: border-box;
			// padding: 0upx 20upx 20upx 20upx;
			margin:0 auto;
			margin-top: 8rpx;
			// padding-bottom: 10rpx;
			margin-bottom: 20rpx;
			display: flex;
			justify-content: space-between;
			.activity{
				// width: 100%;
				width: 344rpx;
				image{
					width: 344rpx;
					height:146rpx;
				}
			}
			}
		// page公用样式
		.page{
			.title{
				height: 88upx;
				background: #f5f5f5;
				line-height: 88rpx;
				box-sizing: border-box;
				padding-left: 20rpx;
				// padding-top: 10rpx;
				image{
					width: 22upx;
					height: 26upx;
					margin-right: 10rpx;
				}
				text{
					font-size:34rpx;
					font-weight:600;
					color:rgba(51,51,51,1);
					line-height:48rpx;
				}
				.fr{
					text{
						font-size: 30rpx;
						color: #666;
						font-weight:400;
					}
					
				}
			}
		}
		// 年龄分段
		.pageage{
			.agemain{
				box-sizing: border-box;
				padding: 0 20upx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 15rpx;
				.main{
					position: relative;
					image{
						display: block;
						width: 162upx;
						height: 88upx;
					}
					text{
						position: absolute;
						top: 0;
						left: 0;
						z-index: 2;
						width: 162upx;
						display: block;
						color: #fff;
						font-size: 34upx;
						text-align: center;
						line-height: 100upx;
					}
				}
			}
		}
		// 书单推荐
		.page_expert,.pagemaster{
			.page_expert_main{
				display: flex;
				align-items: center;
				// white-space: nowrap;
				line-height: 26rpx;
				flex-wrap: nowrap;
				// overflow-x: scroll;
				// -webkit-overflow-scrolling: touch;
				width: 100%;
				>text{
					position: relative;
					margin-left: 20rpx;
					color: #fff;
					font-size: 26rpx;
				}
				.active{
					position: relative;
				}
				.active:before{
					position: absolute;
					width: 10rpx;
					height: 4rpx;
					bottom: 0;
					left: 0;
					background: #fff;
				}
				&::-webkit-scrollbar {
					display:none
					}
			}
			.page_expert_main{
				display: flex;
				align-items: center;
				height: 289rpx;
				margin-bottom: 20rpx;
				.booklist{
					// display: flex;
					// flex-direction: column;
					// align-items: center;
					width: 212rpx;
					height: 289rpx;
					position: relative;
					text-align: center;
					background: #fff;
					margin-left: 20rpx;
					border-radius:10rpx;
					flex-shrink: 0;   //flex 导致子元素宽度无效
					box-sizing: border-box;
					padding: 20rpx 0;
					image{
						width: 118upx;
						height: 118upx;
						display: block;
						margin: 0  auto;
						margin-bottom: 20rpx;
					}
					.infopag{
						display: flex;
						align-items:center;
						height: 110rpx;
						flex-direction: column;
						justify-content: space-between;
						.experTitle{
							font-size: 22rpx;
							color: #666;
							overflow: hidden;
							text-overflow: ellipsis;
							-ms-text-overflow: ellipsis;
							white-space: nowrap;
						}
						.expertintro{
							font-size: 22rpx;
							color: #c3c3c3;
							overflow: hidden;
							text-overflow: ellipsis;
							-ms-text-overflow: ellipsis;
							white-space: nowrap;
						}
						button{
							display:block;
							width:128rpx;
							line-height: 42rpx;
							background: #fff;
							padding: 0;
							font-size: 20rpx;
							color: #fb8553;
							text-align: center;
							border: 2rpx solid #fb8553;
							border-radius:50rpx;
						}
					}
					.mastertitle{
						font-size: 26rpx;
					}
					.masterpic{
						border-radius: 50%;
						margin: 0 auto;
						margin-bottom: 20rpx;
					}
					
					
				}
				
			}
		}
		// 热门推荐
		.pagehot{
			background: #f5f5f5;
			.hotmain{
				box-sizing: border-box;
				//padding: 20upx;
				background: #fff;
				padding-top: 0;
				display: column;
				justify-content: space-between;
				flex-wrap: wrap;
				.hot_main_con {
					height: 350rpx;
					width: 100%;
					display: flex;
					justify-content: space-around;
					align-items: center;
					.bookimg {
						height: 300rpx;
						width: 300rpx;
					}
					.bookinfo {
						width: 400rpx;
						height: 300rpx;
						display: flex;
						justify-content: space-between;
						align-items: flex-start;
						flex-direction: column;
						.bookinfotitl {
							height: 100rpx;
							line-height: 50rpx;
							font-size: 28rpx;
							color: #666666;
							overflow: hidden;
							text-overflow: ellipsis;
							display: -webkit-box;
							-webkit-line-clamp: 2;
							-webkit-box-orient: vertical;
						}
						.bom_btn {
							//height: 160rpx;
							width: 100%;
							display: flex;
							justify-content: space-between;
							align-items: flex-start;
							flex-direction: column;
							.label_btn {
								height: 50rpx;
								margin-bottom: 20rpx;
								display: flex;
								justify-content: flex-start;
								align-items: center;
								.label_btn1 {
									padding: 8rpx 20rpx;
									height: 50rpx;
									line-height: 50rpx;
									background-color: #f2f1f4;
									color: #d44232;
									font-size: 25rpx;
									font-weight: 500;
									border-radius: 5rpx;
									margin-right: 10rpx;
									display: flex;
									justify-content: center;
									align-items: center;
				
									image {
										margin-right: 5rpx;
										height: 30rpx;
										width: 30rpx;
									}
								}
								.label_btn2 {
									height: 50rpx;
									line-height: 50rpx;
									padding: 0 10rpx;
									color: #d66633;
									background-color: #f9f0e4;
									font-size: 25rpx;
									font-weight: 500;
									border-radius: 5rpx;
								}
							}
							.label {
								height: 45rpx;
								margin-bottom: 20rpx;
								display: flex;
								justify-content: flex-start;
								align-items: flex-end;
								.label_1 {
									font-size: 35rpx;
									font-weight: 600;
									color: #d44232;
									margin-right: 20rpx;
								}
								.label_2 {
									font-size: 26rpx;
									color: #999999;
									font-weight: 500;
									text-decoration: line-through;
									margin-bottom: 2rpx;
								}
							}
							.bangdan {
								padding-left: 10rpx;
								height: 60rpx;
								line-height: 60rpx;
								width: 390rpx;
								font-size: 25rpx;
								color: #ad3929;
								background-color: #faf2ed;
								border-radius: 8rpx;
								display: flex;
								justify-content: space-between;
								align-items: center;
								image {
									height: 35rpx;
									width: 35rpx;
								}
							}
						}
					}
				}
			}
		}
		// 弹框
		.modal{
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			margin: auto;
			width: 200upx;
			height: 200upx;
			background: #333;
			border-radius: 20upx;
			opacity: .8;
		}
		.classon{
			font-size: 26rpx;
			color: rgba(153,153,153,1);
			text-align: center;
		}
		// 小火箭返回顶部
		.to-top{
			position: fixed;
			bottom:150rpx;
			right: 13rpx;
			width:84rpx;
			height:84rpx;
			border-radius: 50%;
			background: #fff;
			box-shadow:0rpx 2rpx 8rpx 0rpx rgba(255,130,75,0.3);
			border:2rpx solid rgba(255,205,120,1);
			image{
				width: 38rpx;
				height: 57rpx;
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%,-50%);
			}
		}
		.hide{
			display: none;
		}
		// @import '../../static/css/index.scss';
	
		.voimg {
			width: 40rpx;
			height: 40rpx;
			margin-left: 20rpx;
		}
	
		.service {
			position: fixed;
			top: 70%;
			right: 0;
			background-color: #FF824B;
			width: 76rpx;
			height: 76rpx;
			right: 0;
			z-index: 999;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			border-radius: 50rpx 0px 0px 50rpx;
	
			.bjse {
				position: absolute;
				top: 50%;
				left: 50%;
				width: 57rpx;
				height: 57rpx;
				border-radius: 50%;
				background: #fff;
				transform: translate(-50%, -50%);
	
				image {
					position: absolute;
					left: 50%;
					top: 50%;
					transform: translate(-50%, -50%);
					width: 38rpx;
					height: 38rpx;
					z-index: 99;
				}
			}
	
		}
	
		.head {
			position: relative;
		}
	
		.hasno {
			position: absolute;
			top: 20rpx;
			right: 20rpx;
			width: 20rpx;
			height: 20rpx;
			border-radius: 50%;
			background: red;
		}
	
		.message {
			position: fixed;
			height: 100vh;
			width: 100vw;
			top: 0;
			left: 0;
			background: rgba(0, 0, 0, .6);
	
			.close {
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				top: 25%;
				right: 50rpx;
			}
	
			.con {
				position: absolute;
				top: 30%;
				left: 50%;
				width: 670rpx;
				height: 442rpx;
				margin-left: -335rpx;
				border-radius: 24rpx;
				z-index: 999;
				display: flex;
				justify-content: space-between;
	
				.gift {
					width: 330rpx;
					height: 442rpx;
					margin-right: 10rpx;
				}
	
				.free,
				.addvip {
					width: 330rpx;
					height: 216rpx;
				}
			}
		}
	.scroll-view_H{
	  width: 100%;
	  white-space: nowrap;
	}
	.scroll-view-item_H{
	  // width: 200px;
	  // height: 100px;
	  vertical-align: top;
	  display: inline-block;
	}
	.more{
		width: 72rpx !important;
		writing-mode: tb-rl;
		line-height: 72rpx;
		margin-right: 20rpx;
		font-size: 24rpx;
		color: #999;
		letter-spacing: 10rpx;
		border-radius: 10rpx;
		.yticon{
			margin-top: 30rpx;
			font-size: 14rpx;
		}
	}

	
</style>
