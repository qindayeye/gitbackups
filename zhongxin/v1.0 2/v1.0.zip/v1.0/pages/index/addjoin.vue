<template>
	<view class="addjoin" v-if="loading">
		<!-- <listCell :title.default="msg"></listCell> -->
		<view class="banner">
			<!-- <image src="https://www.abcbook2019.com/mobile/public/img/jiaru.png" mode=""></image> -->
			<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/addjoinbanner.png" mode=""></image>
			<view class="exp">目前会员等级： <text>{{ranks_name}}</text></view>
		</view>
		<view class="vipcard">
			<!-- 新增年卡会员 -->
			<view class="limited" v-if="addjoin.new_card.length!=0">
				<view class="title_vard">
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
					<h4>新增年卡会员</h4>
					<view class="exp">每单最多可借 <text>10本</text> 租期 <text>30天</text></view>
				</view>
				<view class="icon_concard vipicon">
					<navigator :url="'../detail/detail?id='+item.goods_id" class="card" v-for="(item,index) in addjoin.new_card" :key='index'>
						<image class="vipimage" :src="item.goods_thumb" mode="widthFix"></image>
						<view class="cardinfo">
							<view class="infocon clear">
								<view class="tit  fl">{{item.goods_name}}</view>
								<view class="right fr">
									<view class="classfis">
										<text>{{item.goods_tag}}次</text>
										<text>借书次数</text>
									</view>
									<view class="classfis">
										<text>{{item.seller_note}}天</text>
										<text>借阅天数</text>
									</view>
								</view>
							</view>
							<view class="infohint">{{item.goods_brief}}</view>
							<view class="card_price">
								<view class="price fl">
									<text>{{item.shop_price*1}}</text>
									<text class="original" v-if="item.market_price>0">￥{{item.market_price*1}}</text>
								</view>
								<view class="btn fr" @click.stop="paycheckout(item.goods_id)">立即购买</view>
							</view>
						</view>
					</navigator>
				</view>
			</view>
			
			<!-- 不限次会员 -->
			<view class="limited">
				<view class="title_vard">
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
					<h4>不限次卡会员</h4>
					<view class="exp">每单最多可借 <text>10本</text> 租期 <text>30天</text></view>
				</view>
				<view class="icon_concard">
					<navigator :url="'../detail/detail?id='+item.goods_id" class="card" v-for="(item,index) in addjoin.not_num" :key='index'>
						<image :src="item.goods_thumb" mode="widthFix"></image>
						<view class="cardinfo">
							<view class="infocon clear">
								<view class="tit  fl">{{item.goods_name}}</view>
								<view class="right fr">
									<view class="classfis">
										<text>{{item.goods_tag}}次</text>
										<text>借书次数</text>
									</view>
									<view class="classfis">
										<text>{{item.seller_note}}天</text>
										<text>借阅天数</text>
									</view>
								</view>
							</view>
							<view class="card_price">
								<view class="price fl">
									<text>{{item.shop_price*1}}</text>
									<text class="original" v-if="item.market_price>0">￥{{item.market_price*1}}</text>
								</view>
								<view class="btn fr" @click.stop="paycheckout(item.goods_id)">立即购买</view>
							</view>
						</view>
					</navigator>
				</view>
			</view>
			<!-- 限次会员 -->
			<view class="limited">
				<view class="title_vard">
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
					<h4>限次卡会员</h4>
					<view class="exp">每单最多可借 <text>10本</text> 租期 <text>30天</text></view>
				</view>
				<view class="icon_concard">
					<navigator :url="'../detail/detail?id='+item.goods_id" class="card" v-for="(item,index) in addjoin.on_card" :key='index'>
					
						<image :src="item.goods_thumb" mode="widthFix"></image>
						<view class="cardinfo">
							<view class="infocon clear">
								<view class="tit  fl">{{item.goods_name}}</view>
								<view class="right fr">
									<view class="classfis">
										<text>{{item.goods_tag}}次</text>
										<text>借书次数</text>
									</view>
									<view class="classfis">
										<text>{{item.seller_note}}天</text>
										<text>借阅天数</text>
									</view>
								</view>
							</view>
							<view class="card_price">
								<view class="price fl">
									<text>{{item.shop_price*1}}</text>
									<text class="original" v-if="item.market_price>0">￥{{item.market_price*1}}</text>
								</view>
								<view class="btn fr"  @click.stop="paycheckout(item.goods_id)">立即购买</view>
							</view>
						</view>
					</navigator>
				</view>
			</view>
		</view>
		<view class="hint">
			<h5>温馨提示:</h5>
			<text v-for="(item,index) in hint" :key='index'>{{item}}</text>
		</view>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
		import listCell from '@/components/title-top';
		import mixLoading from '@/components/mix-loading/mix-loading.vue'
	    import {  
	        mapState 
	    } from 'vuex';  
		let startY = 0, moveY = 0, pageAtTop = true;
	    export default {
			components: {
				listCell,
				mixLoading
			},
			data(){
				return {
					msg:"加入会员",
					loading:false,
					addjoin:{},
					ranks_name:'普通会员',
					user_ranks:false,
					"hint":[
					      "1. 会员计划七天内未激活全额可退，超过七天需扣除20%的手续费；会员计划一旦激活，无法退款；",
					      "2. 购买的会员卡需在“我的-我的会员”点击激活，激活后立即生效，不激活则在购买之日起一年后自动生效；",
					      "3. 平台承诺往返京东物流包邮，以最快的速度送达您手中。"
					      ]
				}
			},
			onShow() {
					var that=this;
					this.$api.quest('goods/members',{
					},(res)=>{
						if(res.data.data.error==1){
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}else{
							// console.log(res)
							that.addjoin = res.data.data
							this.ranks_name=res.data.data.rank.ranks_name
							this.ranks_id=res.data.data.rank.ranks_id
							
							this.loading=true
						}
					})
				
			},
			onLoad: function(options) {},
			
	        computed: {
				
			},
	        methods: {
				 click() {
						this.$emit('title', "加入会员");
					},
				paycheckout(id){
					let goid=id
					// if(goid==4311 || goid==4312){
					// 	if(this.ranks_id==2 || this.ranks_id==3 ||  this.ranks_id==4){
					// 		this.$api.msg('您现在已经是免邮费超级会员了，暂不能享受畅读卡的权益哦!')
					// 	}else{
					// 		this.addme(goid)
					// 	}
					// }else if(this.ranks_id==6||this.ranks_id==7){
					// 	if(goid==4298 || goid==1859 ||goid==1858){
					// 		this.$api.msg('您现在已经是免邮费超级会员了，暂不能享受畅读卡的权益哦!')
					// 	}else{
					// 		this.addme(goid)
					// 	}
					// }else{
						
					// }
					this.addme(goid)
					
				},
				addme(goid){
					this.$api.quest('user/address/list', {}, (res) => {
						console.log(res, "res")
							this.$api.quest('cart/addmember',{
								id:goid,
								num:1,	
								uid:uni.getStorageSync("user_id"),
								attr_id:1,	
								act_id:30,
								rec_type:10,
								flow_type: 10,
								extension_code:"virtual_card",
								is_checked:1
							},(res)=>{
									console.log(res,'res')
									if(res.data.data.error){
										this.$store.commit("change_page", 4)
										// #ifdef H5
										// 判断微信内外
										var ua = window.navigator.userAgent.toLowerCase();
										console.log(ua)
										// console.log(ua.indexOf('micromessenger') != -1)
										// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
										if (ua.match(/MicroMessenger/i) == 'micromessenger') {
											// 微信内浏览器（公众号）
											console.log("公众号")
											uni.navigateTo({
												url: '/pages/public/login'
											})
										
										} else {
											uni.navigateTo({
												url: '/pages/public/registerSJ'
											})
										}
										// #endif
										
										// #ifdef MP
										uni.navigateTo({
											url: '/pages/public/login'
										})
										// #endif
									}else{
										if(res.data.code==0){
												uni.navigateTo({
													url:'/pages/flow/member?goid='+goid
												})
											
										}else{
											this.$api.msg(res.data.data)
										}
									}
							})
					})
				}
				
	        }  ,
		}
	</script>  

<style lang="scss" scoped>
	@import '../../static/css/addjoin.scss';
	@import '../../static/css/cardcon.scss';
	page{
		padding-bottom: 100rpx !important;
	}
	
</style>
