<template>
	<view>
		使用说明
		可能会跳转到帮助的页面
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
