<template>
	<view class="bjimg" v-if="loading">
		<!-- <image class="bg_img" src="https://www.abcbook2019.com/mobile/public/img/index/bjimg.png" mode="widthFix"></image> -->
		<!-- <image class="bg_img" src="../../static/upcon.png" mode=""></image> -->
		<view class="deposit_cont">
			<view class="order_dsc">
				<view class="order_dsc_header">
					<text class="header_z">ABCbook国际亲子阅读</text>
					<text class="header_y">{{shipping_name}}</text>
				</view>
				<view class="page_expert_main clear booksinfolist">
					<image v-for="(item,index) in goodsData" :src="item.goods_thumb" mode=""></image>
				</view>
				<!-- 地址 -->
				<navigator url="/pages/address/address?source=1" class="address-section">
					<view class="order-content">
						<image src="https://www.abcbook2019.com/mobile/public/img/user/position_order.png" mode=""></image>
						<view class="cen">
							<view class="top">
								<text class="name">{{addressData.consignee}}</text>
								<text class="mobile">{{addressData.mobile}}</text>
							</view>
							<text class="address">{{addressData.country}}{{addressData.city}}{{addressData.district}}{{addressData.address}}</text>
						</view>
						<text class="yticon icon-you"></text>
					</view>
				</navigator>
			</view>
			<view class="deposit_dsc">
				<view class="deposit_dsc_item">
					<image src="https://www.abcbook2019.com/mobile/public/img/index/deposit1.png" mode=""></image>
					<text>0-12岁儿童绘本，每次可借10本</text>
				</view>
				<view class="deposit_dsc_item">
					<image src="https://www.abcbook2019.com/mobile/public/img/index/deposit2.png" mode=""></image>
					<view class="rank" v-if="ranks==1">{{rent}}元/33天<text style="color:#FD2E32;">(普通会员)</text>,超过33天，1元/天</view>
					<view class="rank" v-else>{{rent?0:rent}}元/33天<text style="color:#FD2E32;">({{rankName?rankName:'普通会员'}})</text>，<text
						 v-if="ranks==5">剩余{{ranksnum}}次，</text> 超过33天，1元/天</view>
				</view>
				<view class="deposit_dsc_item">
					<image src="https://www.abcbook2019.com/mobile/public/img/index/deposit2.png" mode=""></image>
					<text>押金{{deposit}}元，微信支付分满550可免押金租借</text>
				</view>
				<view class="deposit_dsc_item">
					<image src="https://www.abcbook2019.com/mobile/public/img/index/deposit3.png" mode=""></image>
					<text>京东物流往返，送书上门，还书一键预约取件</text>
				</view>
			</view>
		</view>
		<view class="bot">
			<view class="arguments">
				<image class="fl" :src="deChecked?'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/selected.png':'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/select.png'"
				 mode="aspectFit" @click="check()"></image>
				<view class="con">
					点击即同意<text @click="poptrue(1)">《押金说明》</text><text @click="poptrue(2)">《委托扣款授权书》</text>
				</view>
			</view>
			<view class="forbtn">
				<button type="primary" class="btn" :disabled="substatl" @click="submit()">
					<text>免押金租书(推荐)</text>
					<!-- <text>(微信支付分550及以上有机会)</text> -->
				</button>
				<button type="primary" class="btn withdi" :disabled="topaysta" @click="topay()">交押金租借(可退)</button>
			</view>
		</view>

		<!-- 弹框 -->
		<view class="pop-up" v-if="popup">
			<view class="upcon">
				<view class="uptitle">
					{{value.title}}
				</view>
				<!-- <rich-text class="upopmain" :nodes="value.content"></rich-text> -->

				<view class="upopmain">
					<rich-text :nodes="value.content"></rich-text>
				</view>
				<!-- <image src="../../static/upcon.png" mode="widthFix"></image> -->
				<view class="upopinion">
					<text @click="opinion('n')">返回</text>
					<text class="main" @click="opinion('y')">同意</text>
				</view>
			</view>
		</view>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		data() {
			return {
				caid: "",
				shipping_name: '',
				flow_type: 0,
				addressData: {},
				deChecked: false,
				goodsData: {}, //商品列表 书
				res: {},
				rankName: "",
				loading: false,
				ranks: '',
				deposit: '',
				rent: '',
				substatl: false, //支付分免押金
				topaysta: false, //交押金支付
				popup: false,
				value: [],
				ranksnum: 0 //会员剩余体验次数
			}
		},
		components: {
			mixLoading
		},
		onShow() {
			this.loading = true
		},
		onLoad(option) {
			console.log(option, "option");
			// this.goid = option.goid ? option.goid : 4299
			// console.log(uni.getStorageSync("user_ranks"))
			this.ranks = uni.getStorageSync("user_ranks")
			this.rankName = uni.getStorageSync("rank_name")
			// console.log(this.rankName)
			this.type = option.type
			this.flow_type=option.type
			if (this.type == 'addre') {
				this.addressData = JSON.parse(option.addressData)
				console.log(this.addressData)
			}
			this.deposittype = uni.getStorageSync("deposittype")
			this.onloadgo()
		},
		methods: {
			check() {
				this.deChecked = !this.deChecked
			},
			// 法律条款
			poptrue(type) {
				this.$api.quest('index/userAuth', {}, (res) => {
					if (res.data.code == 0) {
						// console.log(res.data.data.article[0].list)
						let list = res.data.data.article[0].list
						this.value = list[type - 1]
					}
				})
				this.popup = true
			},
			// 法律条款同意不同意
			opinion() {
				this.deChecked = true
				this.popup = false
			},
			// 立即支付
			// deposit_type:1免押金
			topay() {
				this.disable = true
				let goodsId = []
				this.goodsData.forEach((item, index) => {
					goodsId.push(item.goods_id)
				})
				this.substatl = true;
				this.topaysta = true;
				this.$api.quest('flow/downpay', {
					consignee: this.addressData.address_id,
					shipping: 0,
					u_id: uni.getStorageSync("user_id"),
					uc_id: this.caid,
					flow_type: this.flow_type,
					team_id: 0,
					t_id: 0,
					goods_id: goodsId,
					deposit_type: 0
				}, (res) => {
					console.log(res)
					if (res.data.code == 0) {
						uni.setStorageSync('total_number', uni.getStorageSync("total_number") - this.goodsData.length + 1);
						this.payment = res.data.data.order_amount
						if (this.payment > 0) {
							uni.redirectTo({
								url: '/pages/money/pay?id=' + res.data.data.order_id + '&payok=0&payment=' + res.data.data.order_amount
							})
						} else {
							uni.redirectTo({
								url: '/pages/money/paySuccess?id=' + res.data.data.order_id + '&code=' + res.data.code +
									'&payok=0&payment=' + res.data.data.order_amount
							})
						}
					} else {
						this.disable = false
					}
				})



			},
			// 一进页面初始化
			onloadgo() {
				//商品数据
				if (uni.getStorageSync("user_ranks") > 1) {
					this.user_ranks = false
				} else {
					this.user_ranks = true
				}
				if (this.type == "parentchil") {
					this.flow_type = 11
					this.$api.quest('flow', {
						flow_type: this.flow_type,
						bs_id: 0,
						team_id: 0,
						t_id: 0,
						g_id: this.user_ranks? this.goid : 0,
					}, (res) => {
						if (res.data.code == 1) {
							uni.navigateTo({
								url: '/pages/bookrack/bookrack'
							})
							this.$api.msg(res.data.data.data)
						} else {
							this.nodata = true
							this.loading = true
							// console.log(res.data.data)
							this.deposit = res.data.data.deposit
							this.rent = res.data.data.rent
							this.goodsData = res.data.data.cart_goods_list.list[0].shop_list;
							this.addressData = this.type == 'addre' ? this.addressData : res.data.data.default_address
							// this.VScardarr = res.data.data.member_card_list
							// this.couponList = res.data.data.coupons_list
							// this.summoney = res.data.data.cart_goods_list.order_total //总金额
							this.shipping_name = res.data.data.cart_goods_list.list[0].shop_info[0].shipping_name
							this.ranks = res.data.data.user_ranks
							this.rankName = res.data.data.user_ranks_name
							this.ranksnum = res.data.data.free_number //剩余体验次数

							this.ordersn = res.data.data.order_sn
							let goodid = 0
							this.goodsData.forEach((item, index) => {
								if (item.is_real == 0) {
									// console.log(item.goods_id)
									goodid = item.goods_id
								}
							})
						}
					})
				} else {
					// console.log(this.ordersn,this.deposittype)
					this.$api.quest('flow', {
						flow_type: 0,
						bs_id: 0,
						team_id: 0,
						t_id: 0,
						g_id: this.user_ranks ? this.goid : 0,
					}, (res) => {
						console.log(res)
						if (res.data.code == 1) {
							uni.navigateTo({
								url: '/pages/order/order?states=0&index=0'
							})
							this.$api.msg(res.data.data.data)
						} else {
							this.nodata = true
							this.loading = true
							console.log(res.data.data)
							this.goodsData = res.data.data.cart_goods_list.list[0].shop_list;
							// this.VScardarr = res.data.data.member_card_list
							// this.couponList = res.data.data.coupons_list
							this.addressData = this.type == 'addre' ? this.addressData : res.data.data.default_address
							// this.summoney = res.data.data.cart_goods_list.order_total //总金额
							this.shipping_name = res.data.data.cart_goods_list.list[0].shop_info[0].shipping_name
							// this.coupon=0    //优惠金额
							this.deposit = res.data.data.deposit
							this.rent = res.data.data.rent
							this.payment = res.data.data.cart_goods_list.order_total_formated //实际付款
							this.ordersn = res.data.data.order_sn
							this.ranks = res.data.data.user_ranks
							this.rankName = res.data.data.user_ranks_name
							this.ranksnum = res.data.data.free_number //剩余体验次数
							let goodid = 0

							this.goodsData.forEach((item, index) => {
								if (item.is_real == 0) {
									// console.log(item.goods_id)
									goodid = item.goods_id
								}
							})
						}
					})
				}
			},
			// 提交订单 支付分
			submit() {
				if (this.deChecked) {

					this.disable = true
					let goodsId = []
					this.goodsData.forEach((item, index) => {
						goodsId.push(item.goods_id)
					})
					this.substatl = true;
					this.$api.quest('flow/downpay', {
						consignee: this.addressData.address_id,
						shipping: 0,
						u_id: uni.getStorageSync("user_id"),
						uc_id: this.caid,
						flow_type: this.flow_type,
						team_id: 0,
						t_id: 0,
						goods_id: goodsId,
						deposit_type: 1
					}, (res) => {
						console.log(res)
						if (res.data.code == 0) {
							this.orderid = res.data.data.order_id
							// console.log(this.orderid,'236')
							uni.setStorageSync('total_number', uni.getStorageSync("total_number") - this.goodsData.length + 1);
							// console.log('调用支付分')
							uni.setStorageSync('ordersn', res.data.data.order_sn)
							this.payscore() //调用支付分

						} else {
							this.$api.msg(res.data.data)
							// console.log('下单失败')
						}
					})
				} else {
					this.$api.msg('同意后才可以开通哦~')
				}
			},
			// 支付分
			payscore() {
				let lis = this;
				let goodsId = []
				lis.goodsData.forEach((item, index) => {
					goodsId.push(item.goods_id)
				})
				this.$api.quest('payscore/add', {
					order_sn: uni.getStorageSync("ordersn"),
					user_id: uni.getStorageSync("user_id"),
					book_num: lis.goodsData.length
				}, (res) => {
					let that = this;
					that.res = res
					if (res.data.data.code == 0) {
						this.anewtype = true;
						if (wx.openBusinessView) {
							wx.openBusinessView({
								businessType: 'wxpayScoreUse',
								extraData: {
									mch_id: res.data.data.mch_id,
									package: res.data.data.package,
									timestamp: res.data.data.timestamp,
									nonce_str: res.data.data.nonce_str,
									sign_type: res.data.data.sign_type,
									sign: res.data.data.sign_sh256
								},
								success(res) {
									console.log(res, '成功res')
									if (res.errMsg == 'openBusinessView:ok') {
										that.loading = false
										that.$api.quest('payscore/searchdb', {
											out_order_no: uni.getStorageSync("ordersn")
										}, (res) => {
											uni.navigateTo({
												url: '/pages/money/paySuccess?id=' + lis.orderid + '&payok=0&booknum=' + lis.goodsData.length
											})
										})
									} else {
										uni.navigateTo({
											url: `/pages/money/paySuccess?payok=1&goodid=${goodsId}&id=${lis.orderid}&flow_type=${lis.flow_type}&consignee=${lis.addressData.address_id}&booknum=${lis.goodsData.length}`
										})
									}
								},
								fail(faill) {
									that.loading = false
									console.log('失败')
									uni.navigateTo({
										url: `/pages/money/paySuccess?payok=1&goodid=${goodsId}&id=${lis.orderid}&flow_type=${lis.flow_type}&consignee=${lis.addressData.address_id}&booknum=${lis.goodsData.length}`
									})
								},
								complete(com) {
									that.loading = false
								}
							});
						} else {
							//引导用户升级微信版本
						}
					} else {
						console.log('嗯？？？')
					}

				})

			},
		}
	}
</script>

<style lang="scss">
	page {
		padding: 0;
		background: linear-gradient(top, rgba(80, 65, 255, 1), rgba(255, 95, 30, 0))
	}

	.bjimg {
		height: 100vh;
		width: 100vw;
		background: url('https://www.abcbook2019.com/mobile/public/img/index/depoistbjimg2.png') no-repeat center 38rpx,
			url('https://www.abcbook2019.com/mobile/public/img/index/depoistbjimg1.png') no-repeat center 129rpx;
		background-size: 446rpx, 750rpx;
	}

	.pop-up {
		width: 100vw;
		height: 100vh;
		background: rgba(0, 0, 0, .6);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.upcon {
			/* height: 500rpx; */
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: #fff;
			border-radius: 24rpx;
			text-align: center;
			padding: 20rpx;

			.uptitle {
				font-size: 36rpx;
				font-weight: bold;
				padding-bottom: 20rpx;
			}

			.upopmain {
				// padding: 20rpx 0;
				height: 1000rpx;
				text-align: left;
				overflow-y: auto;
				font-size: 24rpx;
				color: #666;
			}

			.upopinion {
				display: flex;
				width: 660rpx;
				margin: 0 auto;
				padding-top: 20rpx;
				// height: 148rpx;
				justify-content: space-around;
				align-items: center;

				text {
					width: 300rpx;
					line-height: 84rpx;
					border: 2rpx solid #666;
					border-radius: 44rpx;
					font-size: 32rpx;
					color: #666;
				}

				.main {
					color: #fff;
					line-height: 88rpx;
					border: none;
					background: linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				}
			}

		}
	}

	.bjimg {
		height: 100vh;
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		justify-content: flex-end;
	}

	.bg_img {
		position: fixed;
		top: 0;
		width: 100vw;
		height: 100vh;
		overflow: hidden;
		z-index: -1;
	}

	.address-section {
		margin: 0 30upx;
		background: #fff;
		position: relative;

		.order-content {
			display: flex;
			min-height: 133rpx;
			align-items: center;

			image {
				width: 36rpx;
				height: 44rpx;
				margin-right: 60rpx;
			}
		}

		.icon-shouhuodizhi {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 90upx;
			color: #888;
			font-size: 44upx;
		}

		.cen {
			display: flex;
			flex-direction: column;
			flex: 1;
			font-size: 28upx;
			color: $font-color-dark;
		}

		.name {
			font-size: 34upx;
			margin-right: 24upx;
		}

		.address {
			margin-top: 16upx;
			margin-right: 20upx;
			color: $font-color-light;
		}

		.icon-you {
			font-size: 32upx;
			color: $font-color-light;
		}

		.a-bg {
			position: absolute;
			left: 0;
			bottom: 0;
			display: block;
			width: 100%;
			height: 5upx;
		}
	}

	.deposit_cont {
		width: 710rpx;
		margin: 0 auto;
		z-index: 2;

	}

	.order_dsc {
		width: 710rpx;
		// height: 432rpx;
		background-color: #FFFFFF;
		border-radius: 10rpx;

		.order_dsc_header {
			height: 80rpx;
			display: flex;
			margin: 0 30rpx;
			justify-content: space-between;
			align-items: center;
			border-bottom: 1rpx dashed #D2D2D2;

			.header_z {
				height: 30rpx;
				font-size: 28rpx;
				font-weight: 400;
				color: rgba(51, 51, 51, 1);
				line-height: 30rpx;
			}

			.header_y {
				height: 44rpx;
				padding: 0 10rpx;
				background: rgba(255, 205, 120, 0.3);
				border-radius: 6rpx;
				font-size: 24rpx;
				font-weight: 400;
				color: rgba(255, 130, 75, 1);
				line-height: 44rpx;
				text-align: center;
			}
		}

		.order_dsc_IMG {
			height: 180rpx;
			border-bottom: 1rpx dashed #D2D2D2;

			image {
				margin: 20rpx;
				height: 144rpx;
				width: 144rpx;
			}
		}

		.order_dsc_adress {
			margin: 40rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.order_dsc_adress_cont {
				display: flex;
				justify-content: space-between;
				align-items: flex-start;
				flex-direction: column;
			}

			image {
				width: 36rpx;
				height: 44rpx;
			}
		}
	}

	.deposit_dsc {
		margin-top: 20rpx;
		width: 711rpx;
		background-color: #FFFFFF;
		border-radius: 10px;
		display: flex;
		justify-content: center;
		align-items: flex-start;
		flex-direction: column;
		box-sizing: border-box;
		padding: 20rpx 32rpx;

		.deposit_dsc_item {
			line-height: 40rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			border-radius: 10rpx;
			margin-bottom: 10rpx;

			&:last-child {
				margin-bottom: 0;
			}

			image {
				height: 44rpx;
				width: 44rpx;
			}

			text {
				color: #333;
				font-size: 24rpx;
				margin-left: 20rpx;
			}

			.rank {
				color: #333;
				font-size: 26rpx;
				margin-left: 20rpx;

				text {
					margin: 0;
				}
			}
		}
	}

	.arguments {
		width: 710rpx;
		margin: 30rpx 0 20rpx 0;
		height: 33rpx;
		text-align: center;
		line-height: 33rpx;
		font-size: 24rpx;
		color: #999999;
		z-index: -1;
		display: flex;
		align-items: center;
		justify-content: center;

		.con {
			text {
				color: #FF824B;
			}
		}

		image {
			width: 30rpx;
			height: 30rpx;
			margin-right: 20rpx;
		}
	}

	.booksinfolist {
		height: 206rpx;
		margin: 0 30rpx;
		overflow-x: scroll;
		white-space: nowrap;
		border-bottom: 1rpx dashed #e6e6e6;
		padding: 0;

		image {
			width: 144rpx;
			height: 144rpx;
			margin-right: 10rpx;
			margin-top: 30rpx;
		}

		&::-webkit-scrollbar {
			display: none
		}
	}

	.bot {
		width: 710rpx;
		margin: 0 auto;
	}

	.btn {
		padding: 0;
		margin-top: 20rpx;
		margin-bottom: 30rpx;
		width: 690rpx;
		height: 88rpx;
		background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
		box-shadow: 0rpx 4rpx 10rpx 0rpx rgba(255, 130, 75, 0.5);
		border-radius: 49rpx;
		z-index: 3;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-around;

		text {
			font-size: 32rpx;
			line-height: 0;

			&:last-child {
				font-size: 32rpx;
				color: #fff;
			}
		}
	}

	.withdi {
		background: #fff !important;
		border: 2rpx solid #FF824B;
		height: 686rpx;
		width: 690rpx;
		height: 88rpx;
		color: #FF824B !important;
		font-size: 32rpx;
	}
</style>
