<template>
	<view class="">
	</view>
</template>

<script>
	export default {
		data() {
			return {
				src: '',
				code:''
			}
		},
		onLoad(option) {
			var that = this
			console.log(option, 'option')
			// #ifdef H5
			let url =  window.location.href
			if (new RegExp(".*\\b" + 'code' + "\\b(\\s*=([^&]+)).*", "gi").test(url)) {
				that.code = RegExp.$2;
				window.location.href = 'https://www.abcbook2019.com/mobile/h5/#/pages/deposit/depositH5?deCode=' + that.code
				// uni.navigateTo({
				// 	url:'./depositH5?deCode=' + that.code
				// })		
			}else{
				// 微信内浏览器（公众号）
				console.log("公众号")
				that.$api.quest('user/getcode', {
					callback: "https://www.abcbook2019.com/mobile/h5/#/pages/deposit/H5code"
				}, (res) => {
					console.log(res, 'cobak')				
					window.location.href = res.data									
				})	
			}
			// #endif
		
		},

	}
</script>

<style>
</style>
