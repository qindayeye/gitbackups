<template>
		<view class="footer"  :class="{isIphoneX:isIphoneX}">
			<!-- <image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/dibulan.png" mode="widthFix"></image> -->
			<view :class="'footer_item ' + (item.size=='big'?'big_item':'')  " :style="'width:20%'"
			 v-for="(item,index) in footer_nav" :key="index"  @click="change_nav(index,item.url)">
				<image :src="index==now_index?item.select_icon:item.icon" mode=""></image>
				<view class="tex" :class="index==now_index?'active':''">{{item.name}}</view>
				<view class="num" v-if="index==3 && getgoodsnum>=1">
					{{getgoodsnum}}
				</view>
			</view>
		</view>
</template>

<script>
	export default {
		data() {
			return {
				goodsnum:0,
				is_real:false,
				isIphoneX:false,
			};
		},
		mounted() {
			// console.log('shkfbjh')
			
		},
		onReady() {
			// console.log(11111)
			uni.getSystemInfo({
				success: res=>{
					// console.log('手机信息res'+res.model)
					let modelmes = res.model;
						if (modelmes.search('iPhone X') != -1) {
							console.log('1111')
							this.isIphoneX = true
							console.log(this.isIphoneX)
						}
					}
			})
		},
		onShow() {
			console.log(0)
		},
		onUnload() {
			if(this.timer) {
				clearInterval(this.timer);  
				this.timer = null;  
			}  
		},
		watch:{},
		methods: {
			change_nav(index,url) {
				this.$store.commit("change_page", index)
				console.log(url)
				uni.reLaunch({
					url: url
				});
				// setInterval(()=>{
				// 	this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
				// 	this.goodsnum=uni.getStorageSync("total_number")
				// 	// console.log(this.goodsnum)
				// }, 500)
				// if (index == 0) {
					
				// } else if (index == 1) {
				// 	uni.reLaunch({
				// 		url: '/pages/help/help'
				// 	});
				// } else if (index == 2) {
				// 	uni.reLaunch({
				// 		url: '/pages/choiceBook/choiceBook'
				// 	});
				// } else if (index == 3) {
				// 	uni.reLaunch({
				// 		url: '/pages/bookrack/bookrack'
				// 	});
				// } else if (index == 4) {
				// 	uni.redirectTo({
				// 		url: '/pages/user/user'
				// 	});
					
				// }
			}
		},
		computed: {
			footer_nav() {
				return this.$store.state.footer_store.footer_nav
				
				console.log(this.$store.state.footer_store.footer_nav,"nav")
			},
			getgoodsnum(){
				this.timer=setInterval(()=>{
					this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
					this.goodsnum=uni.getStorageSync("total_number")
					// console.log(this.goodsnum)
				}, 500)
				return this.$store.state.footer_store.goodsnum
			},
			
			now_index() {
				return this.$store.state.footer_store.now_page_index;
			},
			// getgoodsnum(){
			// 	return this.$store.state.footer_store.num
			// 	console.log(this.$store.state.footer_store.num,"num")
			// }
		}
	}
</script>

<style lang="scss">
	.isIphoneX{
		
	}
	.tex{
		// background: red;
	}
	.footer{
		position: fixed;
		bottom:-38upx;
		left: 0;
		width: 100%;
		height: 156upx;
		background: #fff;
		z-index:9;
		justify-content: space-around;
		padding-top: 10rpx;
		>image{
			position: fixed;
			bottom: 25rpx;
			left: 0;
			width: 100%;
			z-index: -1;
		}
	}
	.footer_item {
		position: relative;
		float: left;
		text-align: center;
		font-size: 20upx;
		color: #999;

	}
	.footer_item image {
		width: 50upx;
		height: 50upx;
	}

	.footer_item.big_item {
		position: relative;
		width: 140upx;
		height: 140upx;
		border-radius: 50%;
		top: -17upx;
		z-index: 2;
	}
	.footer_item.big_item{
		margin-top: -2rpx;
	}
	.footer_item.big_item image {
		position: relative;
		width: 68upx;
		height: 68upx;
		border-radius:50%;

	}

	// .footer_item.big_item image:after {
	// 	position: absolute;
	// 	top: 50%;
	// 	left: 50%;
	// 	margin-left: -38upx;
	// 	margin-top: -32upx;
	// 	width: 80upx;
	// 	height:80upx;
	// 	content: "";
	// 	font-size: 24upx;
	// 	letter-spacing: 5upx;
	// 	color: #FFFFFF;
	// }

	.active {
		color: #FF6D43;
		border: none !important;
	} 
	.num{
		position: absolute;
		top: -5rpx;
		left: 80rpx;
		width: 30rpx;
		height: 30rpx;
		border-radius:50%;
		background:#FF6D43;
		color: #fff;
	}
</style>
