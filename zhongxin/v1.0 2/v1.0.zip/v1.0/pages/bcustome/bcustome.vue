<template>
	<view class="bcustome">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="imgp">
			<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/header.jpg" mode="widthFix"></image>
		</view>
		<view class="form-con">
			<view class="input">
				<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/mobile.png" mode="widthFix"></image>
				<input type="number" placeholder="请输入手机号码" maxlength="11" data-key="mobile" v-model="mobile" />
				<button class="send-code" @click="getVerify" :disabled='btnDisabled'>{{btnValue}}</button>
			</view>
			<view class="input">
				<image src="https://www.abcbook2019.com//mobile/public/img/bcustome/verify.png" mode="widthFix"></image>
				<input type="number" placeholder="请输入验证码" maxlength="6" data-key="mobileCode" v-model="mobileCode" />

			</view>
			<view class="input">
				<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/code.png" mode="widthFix"></image>
				<input type="text" placeholder="请输入兑换码" maxlength="11" data-key="activation" v-model="activation" />
			</view>
			<button type="primary" class="btn-sub fle" @click="exchange()">立即激活</button>
			<!-- <button type="primary" class="btn-sub" @click="gotoind()">平台首页</button> -->
		</view>
		<view class="hint">
			<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/shiyong.png" mode="widthFix"></image>
			<text v-for="(item,index) in hint">{{item}}</text>
		</view>
		<view class="message" v-if="success">
			<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/success.png" mode="widthFix"></image>
			<text class="tex">恭喜加入会员 快去选书吧</text>
			<button class="btn" type="primary" @click="gotoind()">去选书</button>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default {
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "兑换中心",
				success: false,
				mobile: "",
				btnValue: '获取验证码',
				btnDisabled: false,
				mobileCode: '', // 获取到的手机验证码
				activation: "",
				"hint": [
					"1. 多卡请前往会员中心绑定",
					"2. 输入电子密钥，并点击确定；",
					"3. 电子会员兑换后需要激活并在有效期内使用，过期作废；",
					"4. 严禁倒卖、转让，不可兑换现金，不可退款，请妥善保管；",
					"5. 如有任何疑问可联系客服，电话400-8508-556,微信：abcbookkf；",
					"6.最终解释权归ABCbook国际亲子阅读所有。"
				]
			}
		},
		methods: {
			gotoind() {
				this.$store.commit("change_page", 0)
				uni.redirectTo({
					url: '/pages/index/index'
				})
			},
			// 获取验证码
			getVerify() {
				console.log(12121212)
				let that = this;

				if (this.mobile) {
					var second = 60;

					let timer = setInterval(() => {
						second--
						that.btnValue = second + '秒';
						that.btnDisabled = true;
						if (second <= 0) {
							that.btnValue = '获取验证码';
							that.btnDisabled = false;
							clearInterval(timer);
						}
					}, 1000);
					const request = uni.request({
						url: 'https://www.abcbook2019.com/mobile/public/api/wx/sms/sendsms',
						data: {
							mobile: this.mobile
						},
						method: 'POST',
						success: (res) => {
							console.log(res)
							this.mobile_code = res.data.mobile_code
							if (res.data.code == 2) {
								this.$api.msg(res.data.msg)
							}
						}
					})
				} else {
					uni.showToast({
						title: '手机号不能为空！',
						icon: 'none',
						duration: 2000
					});
				}

			},
			exchange() {
				// console.log(this.mobile,this.mobileCode,this.activation)
				if (this.mobile_code == this.mobileCode ||this.mobile_code == 111111) {
					this.$api.quest('index/bcustome', {
						phone: this.mobile,
						code: this.mobileCode,
						activation: this.activation
					}, (res) => {

						if (res.data.code == 2) {

							this.$api.msg(res.data.data);
						} else if (res.data.code == 1) {
							this.success = true
						}
					})
				} else {
					this.$api.msg("验证码不正确");
				}

			},
		}
	}
</script>

<style lang="scss">
	page {
		background: #FFCD45;
	}

	.hint {
		box-sizing: border-box;
		width: 708rpx;
		padding: 30rpx;
		margin: 0 auto;
		background: #fff;
		border-radius: 10rpx;

		h5 {
			font-size: 26rpx;
			font-weight: 400;
			color: #666;
		}

		text {
			display: block;
			font-size: 24rpx;
			color: #999;
			line-height: 40rpx;
			text-align: justify;
			margin-bottom: 17rpx;
		}
	}

	.bcustome {
		.imgp {
			image {
				width: 750rpx;
			}
		}

		.form-con {
			image {
				width: 50rpx;
				height: 50rpx;
			}

			.input {
				position: relative;
				width: 650rpx;
				height: 88rpx;
				background: rgba(255, 255, 255, .4);
				// opacity:0.4;
				border-radius: 44rpx;
				margin: 0 auto;
				display: flex;
				align-items: center;
				margin-bottom: 30rpx;

				image {
					margin-left: 42rpx;
					margin-right: 38rpx;
				}

				input {
					font-size: 34rpx;
					color: #666;
				}

				.send-code {
					position: absolute;
					// width: 168rpx;
					line-height: 48rpx;
					right: 20rpx;
					top: 50%;
					margin-top: -24rpx;
					font-size: 22rpx;
					border-radius: 24rpx;
					background: rgba(255, 255, 255, .5);
					color: #999;
					border: none;
				}
			}

			.btn-sub {
				width: 650rpx;
				height: 88rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
				box-shadow: 0px 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
				border-radius: 49rpx;
				border: none;
			}

			.fle {
				margin-top: 50rpx;
				margin-bottom: 20rpx;
			}
		}
	}

	.hint {
		width: 710rpx;
		margin-top: 100rpx;

		image {
			display: block;
			width: 521rpx;
			height: 27rpx;
			margin: 20rpx auto;
		}
	}

	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		height: 465rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;

		image {
			width: 308rpx;
			height: 244rpx;
			margin-top: 30rpx;
		}

		.tex {
			display: block;
			font-size: 28rpx;
			color: #666;
			font-weight: 400;
		}

		.btn {
			width: 404rpx;
			height: 84rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 34rpx;
			color: #fff;
			margin-top: 30rpx;
		}
	}
</style>
