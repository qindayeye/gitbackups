<template>
	<view class="content">
		<image class="bjw" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/conver.png" mode="widthFix"></image>
		<image class="btn" @tap="shareEvn" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/btn.png" mode="widthFix"></image>
		
		<!-- 操作流程 -->
		<!-- <view class="page flow">
			<image class="title" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/titl1.png" mode="widthFix"></image>
			<image  class="flowimg" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/convertbgicon.png" mode="widthFix"></image>
		</view> -->
		<!-- 邀请记录 -->
		<view class="page invite">
			<image class="title" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/title2.png" mode="widthFix"></image>
			<view class="friends_con">
				<view class="friends friendt">
					<view class="friend fr1">等级</view>
					<view class="friend fr2">人数</view>
					<view class="friend fr3">已邀请好友</view>
				</view>
				<view class="friends" v-for="(item,index) in affdb" :key='index'>
					<view class="friend fr1">{{index}}</view>
					<view class="friend fr2">{{item.num}}</view>
					<view class="friend fr3 imagescr">
						<image v-for="(el,ind) in item.thumb" :key='ind' :src="el" mode=""></image>
						
					</view>
				</view>
			</view>
		</view>
		<!-- <button class="share-btn" @tap="shareEvn">分享</button> -->
		<!-- 分享弹窗-->
		<view class="share-pro" >
			<view class="share-pro-mask" v-if="deliveryFlag"></view>
			<view class="share-pro-dialog" :class="deliveryFlag?'open':'close'" >
				<view class="close-btn" @tap="closeShareEvn">
					<span class="font_family">&#xe6e6;</span>
				</view>
				<view class="share-pro-title">分享</view>
				<view class="share-pro-body">
					<view class="share-item">
						<button open-type="share">
							<view class="font_family share-icon">&#xe6fa;</view>
							<view >分享给好友</view>
						</button>
					</view>
					<view class="share-item" >
						<button type="primary" class="btn" @tap="createCanvasImageEvn">
							<view class="font_family share-icon">&#xe6f9;</view>
							<view >生成分享图片</view>
						</button>
					</view>
				</view>

			</view>
		</view>
		<!-- <hchPoster ref="hchPoster" :canvasFlag.sync="canvasFlag" @cancel="canvasCancel" :posterObj.sync="posterData"/> -->
		<view :hidden="false"><!-- 海报 要放外面放组件里面 会找不到 canvas-->
			<!-- <canvas class="canvas"  canvas-id="myCanvas" ></canvas> -->
			<wm-poster imgSrc="https://www.abcbook2019.com/mobile/public/img/QR_codebj.png" :QrSrc="imageName" Title="标题文本" PriceTxt="价格显示" OriginalTxt="划线价显示"></wm-poster>
		</view>
	</view>
</template>

<script>
	import wmPoster from "@/components/wm-poster/wm-poster.vue"
	// import hchPoster from '../../wxcomponents/hch-poster/hch-poster.vue'
	export default {
		components:{
			// hchPoster,
			wmPoster
		},
		data() {
			return {
				deliveryFlag: false,
				canvasFlag: true,
				imageName:'',
				urseName:'',
				posterData:{},
				// QrSrc:
				affdb:[],
				fold:true,
				loading:false,
				popup:false    //弹框
			}
		},
		onLoad(option) {
			this.affiliate()
			this.createCanvasImageEvn()
		},
		// 分享
		onShareAppMessage(res) {
			let uid=uni.getStorageSync("user_id")
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
			}
			return {
				title: 'ABCbook国际亲子阅读',
				path: '/pages/index/index?u_id='+uid
			}
		},
		methods: {
			affiliate(){
				this.$api.quest('user/affiliate',{
					
				},(res)=>{ 
					console.log(res)
					if(res.data.data.error==1){
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							// console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
							// #endif
						
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
					}else{
						if(res.data.code==0){
							this.affdb=res.data.data.affdb
							this.loading=true
						}
					}
				})
			},
			createCanvasImageEvn(){
				// this.canvasFlag=false;//显示canvas海报
					// console.log(res)
					let uid=uni.getStorageSync("user_id")
					this.$api.quest('share',{
						path:'/pages/index/index?u_id='+uid,
					},(res)=>{ 
						console.log(res)
						if(res.data.data.error==1){
							uni.navigateTo({
								url:'/pages/public/login'
							})
						}else{
							if(res.data.code==0){
								this.imageName=res.data.data.image_name
								this.urseName=res.data.data.name
								console.log(111)
							}
							// Object.assign(this.posterData,
							// {
							// 	url:'https://www.abcbook2019.com/mobile/public/img/QR_codebj.png',   //商品主图
							// 	title:"邀您加入ABCbook亲子阅读租书平台",       //标题
							// 	discountPrice:"好友   "+this.urseName,           //好友邀您
							// 	orignPrice:"识别二维码 享受新用户福利",        //原价
							// 	code:this.imageName,                          //小程序码
							// })
							// this.$forceUpdate();//强制渲染数据
							setTimeout(()=>{
								this.canvasFlag=false;//显示canvas海报
								this.deliveryFlag = false;//关闭分享弹窗
								// this.$refs.hchPoster.createCanvasImage();//调用子组件的方法
							},500)
						}
					})
					// code = res;
					
				
				// this.codeImg().then((res)=>{})
				// 以下是根据后端接口动态生成小程序码 end
			},
			
			// 分享弹窗
			shareEvn() {
				this.deliveryFlag = true;
			},
			// 关闭分享弹窗
			closeShareEvn() {
				this.deliveryFlag = false;
			},
			// 取消海报
			canvasCancel(val){
				this.canvasFlag=val;
			}
			
		}
	}
</script>

<style lang="scss">
	page{
		background: #FF922E;
	}
	.bjw{
		width: 750rpx;
	}
	.btn{
		position: relative;
		width: 734rpx;
		top: 50%;
		left: 50%;
		transform: translate(-50%,-50%);
	}
	.page{
		position: relative;
		width: 700rpx;
		height: 425rpx;
		background: #FFFAEE;
		border-radius: 10rpx;
		margin: 0 auto;
		border:5rpx solid #fff ;
		.title{
			position: absolute;
			left: 50%;
			transform: translate(-50%,-50%);
			width: 400rpx;
			height: 108rpx;
			
		}
		.flowimg{
			width: 676rpx;
			height: 353rpx;
			margin: 0 auto;
			display: block;
			margin-top: 58rpx;
		}
	}
	.invite{
		// margin-top:100rpx;
		height: auto;
		padding-bottom: 30rpx;
	}
	// 邀请记录
	.friends_con{
		margin-top: 67rpx;
		
		.friends{
			display: flex;
			height: 68rpx;
			align-items: center;
			border-bottom:1rpx solid #FFCAAC;
			text-align: center;
			font-size: 28rpx;
			color: #666;
			.friend{
				line-height: 68rpx;
				border-right: 1rpx solid #ffcaac;
				&:last-child{
					border: none;
				}
			}
			.fr1{
				width: 127rpx;
			}
			.fr2{
				width:113rpx;
			}
			.fr3{
				width: 440rpx;
			}
			&:last-child{
				border: none;
			}
		}
		.friendt{
			color:#FF824B;
			font-size: 28rpx;
		}
		.imagescr{
			text-align: left;
			overflow-x: auto;
			-webkit-overflow-scrolling: touch;
			white-space: nowrap;
			image{
				display:inline-block;
				vertical-align:middle;
				width: 50rpx;
				height: 50rpx;
				border-radius: 50%;
				margin:auto 10rpx;
			}
			&::-webkit-scrollbar{
				display: none;
			}
		}
	}
	// 弹框
	.popup{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.5);
		.popcon{
			position: absolute;
			height: 866rpx;
			width: 670rpx;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
			>image{
				display: block;
				width: 670rpx;
			}
			.userinfo{
				width: 670rpx;
				height: 226rpx;
				background: #fff;
				padding:40rpx 30rpx;
				border-radius: 0 0 24rpx 24rpx;
				.fl{
					height: 150rpx;
					.name{
						font-size: 30rpx;
						color: #333;
						margin-bottom: 20rpx;
					}
					.brief{
						font-size: 26rpx;
						color: #333;
					}
					.orange{
						font-size: 26rpx;
						font-weight: bold;
						color: #FF824B;
						margin-top: 10rpx;
					}
				}
				.fr{
					width: 150rpx;
					height: 150rpx;
				}
			}
		}
	}
	
	// .on{
	// 	height: 130rpx;
	// 	overflow: hidden;
	// }
	// .off{
	// 	height:auto;
	// }
	// .affiliate{
	
	// 	.QR_code{
	// 		position: relative;
	// 		top: -200rpx;
	// 		width:314rpx;
	// 		height:341rpx;
	// 		margin: 0 auto;
	// 		background:rgba(255,255,255,1);
	// 		border-radius:15px;
	// 		image{
	// 			position: absolute;
	// 			width: 290rpx;
	// 			height: 290rpx;
	// 			left: 50%;
	// 			top: 50%;
	// 			transform: translate(-50%,-50%);
	// 		}
	// 	}
	// 	.hint{
	// 		position: relative;
	// 		top: -170rpx;
	// 		color: #FF7B1B;
	// 		font-size: 38rpx;
	// 		font-weight:bold;
	// 		text-align: center;
	// 	}
	// 	.rule{
	// 		position: relative;
	// 		top: -100rpx;
	// 		.rul_title{
	// 			width: 690rpx;
	// 			height: 40rpx;
	// 			display: flex;
	// 			margin: 0 auto;
	// 			margin-bottom: 30rpx;
	// 			justify-content: space-around;
	// 			align-content: center;
	// 			.fll,.frr{
	// 				width: 150rpx;
	// 				height: 5rpx;
	// 				background:#DC6F1F;
	// 				margin-top: 20rpx;
	// 			}
	// 			.ttl{
	// 				font-size: 32rpx;
	// 				font-weight: bold;
	// 				color: #DC6F1F;
	// 			}
	// 		}
	// 		.rul_con{
	// 			width: 690rpx;
	// 			box-sizing: border-box;
	// 			padding: 48rpx;
	// 			background: #fff;
	// 			border-radius: 10rpx;
	// 			margin: 0 auto;
	// 			text{
	// 				display: block;
	// 				color: #666;
	// 				text-align: justify;
	// 				font-size: 24rpx;
	// 				line-height: 50rpx;
	// 			}
	// 		}
	// 	}
	// 	.friends{
	// 		margin-top:52rpx;
	// 	}
		
		
	// }
	/*每个页面公共css 放app.vue页面的 */
	 @font-face {
		font-family: 'font_family';  /* project id 1065286 */
		src: url('//at.alicdn.com/t/font_1065286_3bsye5aijur.eot');
		src: url('//at.alicdn.com/t/font_1065286_3bsye5aijur.eot?#iefix') format('embedded-opentype'),
		url('//at.alicdn.com/t/font_1065286_3bsye5aijur.woff2') format('woff2'),
		url('//at.alicdn.com/t/font_1065286_3bsye5aijur.woff') format('woff'),
		url('//at.alicdn.com/t/font_1065286_3bsye5aijur.ttf') format('truetype'),
		url('//at.alicdn.com/t/font_1065286_3bsye5aijur.svg#font_family') format('svg');
	  }
	  .font_family{
		font-family:"font_family" !important;
		font-size:16px;font-style:normal;
		-webkit-font-smoothing: antialiased;
		-webkit-text-stroke-width: 0.2px;
		-moz-osx-font-smoothing: grayscale;
	  }
	  /* 按钮去掉边框 */
	  button::after {
		border: none;
	  }
	  button{
		margin-left: 0;
		margin-right: 0;
		padding-left: 0;
		padding-right: 0;
		line-height: 1;
		color: #1c1c1c;
		font-size: 28rpx;
		background: none;
	  }
	  .button-hover {
		color:#1c1c1c;
		background:none;
	  }
	  /*每个页面公共css */
	.content {
		text-align: center;
		height: 100%;
	}
	.share-btn{
		padding: 30upx 60upx;
		// background-color:$uni-btn-color;
		// color: $uni-text-color-inverse;
	}
	.share-pro{
        display: flex;
        align-items: center;
        justify-content: flex-end;
        flex-direction: column;
		text-align: center;
        z-index: 5;
        line-height: 1;
        box-sizing: border-box;
        .share-pro-mask{
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.5);
        }
        .share-pro-dialog {
            width: 750rpx;
            height: 310rpx;
            overflow: hidden;
            background-color: #fff;
            border-radius: 24rpx 24rpx 0px 0px;
            position: relative;
            box-sizing: border-box;
            position: fixed;
            bottom: 0;
            .close-btn {
                padding: 20rpx 15rpx;
                position: absolute;
                top: 0rpx;
                right: 29rpx;
            }
            .share-pro-title {
                font-size: 28rpx;
                color: #1c1c1c;
                padding: 28rpx 41rpx;
                background-color: #f7f7f7;
            }

            .share-pro-body{
                display: flex;
				width: 750rpx;
                // flex-direction: row;
                justify-content:space-around;
                font-size: 28rpx;
	            color: #1c1c1c;
                .share-item{
                    display: flex;
					width: 50%;
					flex-direction: column;
                    justify-content: center;
                    justify-content:space-around;
                    .share-icon{
                        text-align:center;
                        font-size: 70rpx;
                        margin-top: 39rpx;
                        margin-bottom: 16rpx;
                        color: #42ae3c;
                    }
                    &:nth-child(2){
                        .share-icon{
                            color: #ff5f33;
                        }
                    }
					.btn{
						background: none;
						color: #1c1c1c;;
					}
                }
            }
        }

        /* 显示或关闭内容时动画 */

        .open {
            transition: all 0.3s ease-out;
			transform: translateY(0);
        }

        .close {
            transition: all 0.3s ease-out;
			transform: translateY(310rpx);
        }

    }
	 .canvas{
	    position: fixed !important;
	    top: 0 !important;
	    left: 0 !important;
	    display: block !important;
	    width: 100% !important;
	    height: 100% !important;
	    z-index: 10;
	}
	
</style>
