<template>
	<view class="expert">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="authorbanner">
			<image src="https://www.abcbook2019.com//mobile/public/img/recbooklist/parentBook.png" mode="aspectFill"></image>
			<view class="navList">
				<text  :class="{active : index===curId}" v-for="(item,index) in indexArr" :key="index" @click="Active(index,item)">{{item}}</text>
				
			</view>
		</view>
		
		<view class="books">
			<block v-for="(item,index) in books" :key='index'>
				<view class="Listbooks">
					<view class="listTop clear">
						<image class="fl" :src="item.touch_icon" mode="aspectFill"></image>
						<view class="fl book_con_info">
							<view class="infobook fl">
								<h4>{{item.cat_name}}</h4>
								<text>{{item.cat_alias_name}}</text>
							</view>
							<navigator class="fr btn" :url="'/pages/RecDetail/RecDetail?cat_id='+item.cat_id+'&is_show=1'">查看书单</navigator>
						</view>
					</view>
					<scroll-view class="page_expert_main clear booksinfolist scroll-view_H" 
					@scrolltolower="upper" 
					show-scrollbar 
					lower-threshold='30' 
					:data-cat=item.cat_id
					scroll-x="true" 
					scroll-left="120">
							<navigator class="everybook scroll-view-item_H" :url="'../detail/detail?id='+book.goods_id" v-for="(book,ind) in item.goods_list" :key='ind'>
								<image :src="book.goods_thumb" mode="aspectFill" lazy-load="true"></image>
								<view class="everyinfo">
									<text>{{book.goods_name}}</text>
									<image @click.stop="addBook(book,book.goods_id,book.goods_stock)" :src="book.cat_status==2 && book.goods_number>0?'https://www.abcbook2019.com//mobile/public/img/recbooklist/liang.png':'https://www.abcbook2019.com//mobile/public/img/recbooklist/hui.png'"
									 mode=""></image>
								</view>
							</navigator>
							<navigator class="booklist scroll-view-item_H more" :url="'/pages/RecDetail/RecDetail?cat_id='+item.cat_id+'&is_show=1'">
								查看更多<text class="more-icon yticon icon-you"></text>
							</navigator>
					</scroll-view>
				</view>
			</block>
		</view>
		<view :class="{'classon':classon}">{{classoninfo}}</view>
		<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
			<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
		</view>
		<goCar :carnum='goodsnum' ></goCar>
		<!-- dibu -->
		<!-- <view class="main-content">
			<footer>
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view> -->
	</view>
</template>

<script>
	import Vue from 'vue'

	import listCell from '@/components/title-top';

	import goCar from '@/components/car.vue';
	// import bottomNav from "../navbar/navbar.vue";
	import uniLoadMore from "../../components/uni-load-more/uni-load-more.vue";
	export default {
		data() {
			return {
				books:[],
				page:1,  // 上拉刷新页数
				classon:false, //判断模态框
				msg:"推荐书单",
				hide:true,
				cat_id:0,
				curId:0,
				indexArr:["全部","0-2岁","3-6岁","7-10岁","10岁以上"],
				item:'',
				classoninfo:"" ,
				goodsnum:0
			}
		},
		components: {
	
			listCell,
		
			goCar
			// bottomNav
		},
		onLoad: function(options) {
			let that = this;
			that.cat_id = options.id;
			// console.log(that.cat_id);
			this.$api.quest('index/getRecBooklist',{
				cat_id:that.cat_id,
				page:that.page,
				size:10
			}, (res) => {
				// console.log(res.data.data)
				that.books.push(...res.data.data) 
			})
			this.timer=setInterval(()=>{
				this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
				this.goodsnum=uni.getStorageSync("total_number")
			}, 500)
		},
		onUnload() {
			if(this.timer) {  
			        clearInterval(this.timer);  
			        this.timer = null;  
			    }  
		},
		onReachBottom(){
			this.scroll();
			
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
		 if(Object.scrollTop>800){
			 this.hide=false;
		 }else{
			 this.hide=true;
		 }
		},
		methods: {
			upper: function(e) {
				// console.log(e.currentTarget.dataset.cat)
				let catid =e.currentTarget.dataset.cat
				uni.navigateTo({
					url:'/pages/RecDetail/RecDetail?cat_id='+catid+'&is_show=1'
				})
			},
			gotop(){
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			Active(index,item){
				let that = this;
				this.curId = index;
				console.log(item)
				this.page=1
				if(item == '全部'){
					item = '';
				}
				that.item = item
				this.$api.quest('index/getRecBooklist',{cat_id:that.cat_id,page:that.page,type:that.item}, (res) => {
					console.log(res.data.data)
					that.books=res.data.data
				})
			},
			addBook(e, id, num) {
				this.$api.addBook(e, id, num)
			},
			// 下拉加载
			scroll(){
				const that=this;
				console.log(that.classon)
				that.classon=true;
				that.classoninfo="正在努力加载..."
				this.loadingType=1;
				const scrollrequest=this.$api.quest('index/getRecBooklist',{
					cat_id:that.cat_id,
					page:++that.page,
					type:that.item,
					},(res)=>{
					console.log(res)
					if (res.data.data.length == 0) {  //没有数据
					    this.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
					    uni.hideNavigationBarLoading();//关闭加载动画
					    return;
					}
						this.books.push(...res.data.data) 
						  uni.hideNavigationBarLoading();//关闭加载动画
						 this.classon=false   //判断模块框
						console.log(that.books,'hot',that.page,'page')
						uni.hideNavigationBarLoading();//关闭加载动画
				})
			}
		}
	}
</script>
<style lang='scss'>
	@import '../../static/css/expert.scss';
	page{
		background: #A5B9F7;
	}
	.scroll-view_H{
	  width: 100%;
	  white-space: nowrap;
	}
	.scroll-view-item_H{
	  vertical-align: top;
	  display: inline-block;
	}
	.more{
		width: 72rpx !important;
		writing-mode: tb-rl;
		height: 192rpx;
		line-height: 72rpx;
		margin-right: 20rpx;
		font-size: 24rpx;
		text-align: center;
		color: #999;
		letter-spacing: 10rpx;
		background:rgba(255,255,255,1);
		box-shadow:0rpx 2rpx 8rpx 0rpx rgba(0,0,0,0.1);
		border-radius: 10rpx;
		.yticon{
			margin-top: 10rpx;
			font-size: 20rpx;
		}
	}
</style>
