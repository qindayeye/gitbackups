<template>
	<view v-if="hasord" class="empty">
		<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
		<view class="empty-tips">
			<view>您有未完成的订单</view>
			<view>需要完成后才能继续下单哟~</view>
			<view class="navigator" @click="navToindx()">去逛逛</view>
		</view>
	</view>
	<view v-else class="content">
		<view class="row b-b">
			<text class="tit">联系人</text>
			<input class="input" type="text" v-model="addressData.consignee" placeholder="收货人姓名" placeholder-class="placeholder" />
		</view>
		<view class="row b-b">
			<text class="tit">手机号</text>
			<input class="input" type="number" v-model="addressData.mobile" placeholder="收货人手机号码" placeholder-class="placeholder" />
		</view>
		<view class="row b-b">
			<text class="tit">地址</text>
			<input class="input" type="text" v-model="pickerText" disabled=true placeholder="请选择地址" @click="showMulLinkageThreePicker"/>
		</view>
		<view class="row b-b"> 
			<text class="tit">详细地址</text>
			<input class="input" type="text" v-model="addressData.address" placeholder="楼号、门牌" placeholder-class="placeholder" />
		</view>
		
		<view class="row default-row">
			<text class="tit">设为默认</text>
			<switch :checked="addressData.default" color="#fd8a54" @change="switchChange" />
		</view>
		<button class="add-btn" @click="confirm">提交</button>
		
		
		<mpvue-city-picker :themeColor="themeColor" ref="mpvueCityPicker" :provinceData="provinceDataList" :pickerValueDefault="cityPickerValueDefault"
		 @onCancel="onCancel" @onConfirm="onConfirm"></mpvue-city-picker>
		 
		 
		
	</view>
</template>

<script>
	import mpvueCityPicker from '@/components/mpvue-citypicker/mpvueCityPicker.vue'
	export default {
		data() {
			return {
				addressData: {},
				hasord:false,
				cityPickerValueDefault: [0, 0, 0],
				themeColor: '#007AFF',
				provinceDataList:[],
				pickerText: '',
				pickerValueDefault: [0],
				pickerValueArray:[],
				provinceCode:null,
				cityCode:null,
				districtCode:null,
				default:0,
				source:0
			}
		},
	 components:{
			mpvueCityPicker
		},
		onLoad(option){
			console.log(option,'addressM')
			this.source=option.source
			let title = '新增收货地址';
			if(option.type==='edit'){
				title = '编辑收货地址'
				this.addressData = JSON.parse(option.data)
				console.log(this.addressData,"add")
				this.pickerText=this.addressData.country+""+this.addressData.city+this.addressData.district
				this.provinceCode=this.addressData.province_id
				this.cityCode=this.addressData.city_id
				this.districtCode=this.addressData.district_id,
				this.default = this.addressData.default
			}
			this.manageType = option.type;
			uni.setNavigationBarTitle({
				title
			})
		},
		methods: {
			navToindx(){
				uni.navigateBack()
				// uni.navigateTo({
				// 	url:'/pages/index/index'
				// })
			},
				showMulLinkageThreePicker() {
					this.$refs.mpvueCityPicker.show()
				},
				onConfirm(e) {
					let pickerText = JSON.stringify(e)
					this.pickerText=e.label
					console.log(this.pickerText)
					this.provinceCode=e.cityCode.province
					this.cityCode=e.cityCode.city
					this.districtCode=e.cityCode.area
				},
				
			
			switchChange(e){
				console.log(e);
				this.default=this.default?0:1
				console.log(this.default)
				if(this.manageType==='edit'){
					this.$api.quest('user/address/default',{
						id:this.addressData.id,
						is_default:this.default?1:0
					},(res)=>{
						console.log(res)
					})
				}else{
					
				}
			},
			//提交
			confirm(){
				let data = this.addressData;
				if(!data.consignee){
					this.$api.msg('请填写收货人姓名');
					return;
				}
				if(!/(^1[3|4|5|7|8][0-9]{9}$)/.test(data.mobile)){
					this.$api.msg('请输入正确的手机号码');
					return;
				}
				if(!data.address){
					this.$api.msg('请填写详细地址');
					return;
				}
				
				if(this.manageType==='edit'){
					this.$api.quest('user/address/update',{
						consignee: this.addressData.consignee,
						province: this.provinceCode,
						district:this.addressData.district,
						mobile: this.addressData.mobile,
						address: this.addressData.address,
						city: this.cityCode,
						district: this.districtCode,
						id:this.addressData.id,
						default:this.default
					},(res)=>{
						if(res.data.code==0){
							console.log(res,'res',this.source)
							if(this.manageType==='noaddress'){
								uni.navigateTo({
									url: `/pages/deposit/deposit`
								})
							}else if(this.manageType==='shopgood'){
								uni.navigateTo({
									url: `pages/flow/shopgoods`
								})
							}else{
								if(this.source==1){
									console.log('source')
									uni.navigateTo({
										url: `/pages/deposit/deposit?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else if(this.source==2){
									uni.navigateTo({
										url: `/pages/flow/shopgoods?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else if(this.source==3){
									uni.navigateTo({
										url: `/pages/appoint/appoint?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else{
									uni.navigateTo({
										url:'/pages/address/address'
									})
								}
							}
							
						}else{
							this.$api.msg("提交失败")
						}
					})
				}else{
					// 新增地址
					this.$api.quest('user/address/add',{
						consignee: this.addressData.consignee,
						province: this.provinceCode,
						district:this.addressData.district,
						mobile: this.addressData.mobile,
						address: this.addressData.address,
						city: this.cityCode,
						district: this.districtCode,
						is_default:1
					},(res)=>{
						console.log(res)
						if(res.data.data.error==true){
							console.log(res,'res',this.source)
							if(this.manageType==='noaddress'){
									this.$api.quest('flow/checkuserorder', {}, (res) =>{
										console.log(res)
										if(res.data.code==1){
											this.hasord=true
											// this.$api.msg(res.data.data.data)
										}else{
											uni.navigateTo({
												url: `/pages/deposit/deposit`
											})
										}
									})
							}else if(this.manageType==='shopgood'){
								uni.navigateTo({
									url: `/pages/flow/shopgoods`
								})
								// this.$api.quest('flow/checkuserorder', {}, (res) =>{
								// 	console.log(res)
								// 	if(res.data.code==1){
								// 		this.hasord=true
								// 		// this.$api.msg(res.data.data.data)
								// 	}else{
										
								// 	}
								// })
							}else{
								if(this.source==1){
									console.log('source')
									uni.navigateTo({
										url: `/pages/deposit/deposit?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else if(this.source==2){
									uni.navigateTo({
										url: `/pages/flow/shopgoods?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else if(this.source==3){
									uni.navigateTo({
										url: `/pages/appoint/appoint?type=addre&addressData=${JSON.stringify(res.data.data.address)}`
									})
								}else{
									uni.navigateTo({
										url:'/pages/address/address'
									})
								}
							}
							
						}else{
							this.$api.msg("修改失败")
						}
					})
				}
				
				
			},
		},
		
		onBackPress() {
		  if (this.$refs.mpvueCityPicker.showPicker) {
		  	this.$refs.mpvueCityPicker.pickerCancel();
		    return true;
		  }
		},
		onUnload() {
			if (this.$refs.mpvueCityPicker.showPicker) {
				this.$refs.mpvueCityPicker.pickerCancel()
			}
		}
	}
</script>

<style lang="scss">
	page{
		background:#fff;
		padding-top: 16upx;
	}
	.address{
		display:flex;
		justify-content: flex-start;
		
	}
	.row{
		display: flex;
		align-items: center;
		position: relative;
		padding:0 30upx;
		height: 110upx;
		background: #fff;
		
		.tit{
			flex-shrink: 0;
			width: 120upx;
			font-size: 30upx;
			color: $font-color-dark;
		}
		.input{
			flex: 1;
			font-size: 30upx;
			color: $font-color-dark;
		}
		.icon-shouhuodizhi{
			font-size: 36upx;
			color: $font-color-light;
		}
	}
	.default-row{
		margin-top: 16upx;
		.tit{
			flex: 1;
		}
		switch{
			transform: translateX(16upx) scale(.9);
		}
	}
	.add-btn{
		display: flex;
		align-items: center;
		justify-content: center;
		width: 690upx;
		height: 80upx;
		margin: 60upx auto;
		font-size: $font-lg;
		color: #fff;
		background-color: #FA6C3A;
		border-radius: 10upx;
		// box-shadow: 1px 2px 5px rgba(219, 63, 96, 0.4);
	}
</style>
