<script>
	/**
	 * vuex管理登陆状态，具体可以参考官方登陆模板示例
	 */
	import {
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				num: 0,
			}
		},
		methods: {
			...mapMutations(['login'])
		},
		onLoad() {
			console.log('onload app')
		},
		// onLaunch: function() {

		// 	let userInfo = uni.getStorageSync('userInfo') || '';
		// 	this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
		// 	if (userInfo.id) {
		// 		//更新登陆状态
		// 		uni.getStorage({
		// 			key: 'userInfo',
		// 			success: (res) => {
		// 				this.login(res.data);
		// 			}
		// 		});
		// 	}
		// },

		onShow: function() {
			// console.log('App Show')
		},
		onHide: function() {
			// console.log('App Hide')
		},
		onUnload() {
			uni.setStorageSync('voivegodid','')
		}
	}
</script>

<style lang='scss'>
	@import './common/icon.css';
	@import './common/yticon.css';
	@import './common/abc.css';
	page{
		-webkit-overflow-scrolling: touch;
	}

	/* #ifdef H5 */
	* {
		-webkit-user-select: auto !important;
		-khtml-user-select: auto !important;
		-moz-user-select: auto !important;
		-ms-user-select: auto !important;
		-o-user-select: auto !important;
		user-select: auto !important;
	}

	/* #endif */

	page {
		box-sizing: border-box;
		padding-bottom: 200upx;
		background: #F5F5F5;
	}

	view,
	scroll-view,
	swiper,
	swiper-item,
	cover-view,
	cover-image,
	icon,
	text,
	rich-text,
	progress,
	button,
	checkbox,
	form,
	input,
	label,
	radio,
	slider,
	switch,
	textarea,
	navigator,
	audio,
	camera,
	image,
	video {
		box-sizing: border-box;
	}

	.hot_main_con {
		position: relative;
	}

	.topleftcorner {
		position: absolute;
		top: 0;
		left: 0;
		width: 84rpx;
		height: 36rpx;
		background: linear-gradient(135deg, rgba(255, 165, 127, 1) 0%, rgba(255, 82, 82, 1) 100%);
		border-radius: 10rpx 0 20rpx 0;
		color: #fff;
		font-size: 20rpx;
		text-align: center;
		line-height: 36rpx;
	}

	.navigator-hover {
		background: transparent;
		opacity: 1;
	}

	.fl {
		float: left;
	}

	.fr {
		float: right;
	}

	.clear:after {
		content: "";
		display: block;
		clear: both;
	}

	.classon {
		font-size: 26rpx;
		color: rgba(153, 153, 153, 1);
		text-align: center;
	}

	button::after {
		border: none;
	}

	/* // 小火箭返回顶部 */
	.to-top {
		position: fixed;
		bottom: 150rpx;
		right: 13rpx;
		width: 84rpx;
		height: 84rpx;
		border-radius: 50%;
		background: #fff;
		box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.3);
		border: 2rpx solid rgba(255, 205, 120, 1);

		image {
			width: 38rpx;
			height: 57rpx;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
	}

	.empty {
		image {
			width: 287rpx;
			height: 181rpx;
		}

		.empty-tips {
			text {
				display: block;
			}
		}
	}

	.empty {
		position: fixed;
		left: 0;
		top: 0rpx;
		width: 100%;
		height: 100vh;
		padding-bottom: 100upx;
		display: flex;
		justify-content: center;
		flex-direction: column;
		align-items: center;
		background: #fff;

		image {
			width: 287rpx;
			height: 181rpx;
			margin-bottom: 30upx;
		}

		.empty-tips {
			text-align: center;
			font-size: 24rpx;
			line-height: 33rpx;
			color: #999;

			.navigator {
				color: $uni-color-primary;
				width: 146rpx;
				line-height: 52rpx;
				background: rgba(255, 255, 255, 1);
				border-radius: 26rpx;
				border: 1rpx solid rgba(250, 110, 60, 1);
				margin: 0 auto;
				margin-top: 14rpx;
			}
		}
	}

	.hide {
		display: none;
	}

	*,
	*:after,
	*:before {
		-webkit-box-sizing: border-box;
		-moz-box-sizing: border-box;
		box-sizing: border-box;
		-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
		-webkit-touch-callout: none;
		-webkit-user-drag: none;
		-ms-touch-action: none;
		/* #ifdef H5 */
		-webkit-user-select: auto;
		-ms-user-select: auto;
		-moz-user-select: auto;
		/* #endif */
		/* #ifdef MP */
		-webkit-user-select: none;
		-ms-user-select: none;
		-moz-user-select: none;
		/* #endif */
	}

	uni-page-head .uni-page-head,
	.uni-placeholder {
		display: none;
	}

	.uni-scroll-view::-webkit-scrollbar {
		/* 隐藏滚动条，但依旧具备可以滚动的功能 */
		display: none
	}

	scroll-view::-webkit-scrollbar {
		/* 隐藏滚动条，但依旧具备可以滚动的功能 */
		display: none
	}

	/* 骨架屏替代方案 */
	.Skeleton {
		background: #f3f3f3;
		padding: 20upx 0;
		border-radius: 8upx;
	}

	/* 图片载入替代方案 */
	.image-wrapper {
		font-size: 0;
		background: #f3f3f3;
		border-radius: 4px;

		image {
			width: 100%;
			height: 100%;
			transition: .6s;
			opacity: 0;

			&.loaded {
				opacity: 1;
			}
		}
	}

	/* .clamp {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		display: block;
	}

	.common-hover {
		background: #f5f5f5;
	}
 */
	/*边框*/
	/* .b-b:after,
	.b-t:after {
		position: absolute;
		z-index: 3;
		left: 0;
		right: 0;
		height: 0;
		content: '';
		transform: scaleY(.5);
		border-bottom: 1px solid $border-color-base;
	}

	.b-b:after {
		bottom: 0;
	}

	.b-t:after {
		top: 0;
	}
 */
	/* button样式改写 */
	/* uni-button,
	button {
		height: 80upx;
		line-height: 80upx;
		font-size: $font-lg + 2upx;
		font-weight: normal;

		&.no-border:before,
		&.no-border:after {
			border: 0;
		}
	}

	uni-button[type=default],
	button[type=default] {
		color: $font-color-dark;
	}
 */
	/* input 样式 */
	/* .input-placeholder {
		color: #999999;
	} */

	/* .placeholder {
		color: #999999;
	} */
</style>
