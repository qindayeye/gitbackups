/* 用户 */
const userInfo = {}
/* 首页轮播图 */
const carouselList = []
/* 商品列表 */
const goodsList = []

/* 购物车 */
const cartList = [];
//详情展示页面
const detailData = {}
const shareList = [{
		type: 1,
		icon: '/static/temp/share_wechat.png',
		text: '微信好友'
	},
	{
		type: 2,
		icon: '/static/temp/share_moment.png',
		text: '朋友圈'
	},
	{
		type: 3,
		icon: '/static/temp/share_qq.png',
		text: 'QQ好友'
	},
	{
		type: 4,
		icon: '/static/temp/share_qqzone.png',
		text: 'QQ空间'
	}
]
const lazyLoadList = []

const orderList = [{},
	{},
	{},
	{},
	{},
	{}

]
const cateList = []

export default {
	carouselList,
	cartList,
	detailData,
	lazyLoadList,
	userInfo,
	shareList,
	goodsList,
	orderList,
	cateList
}
