

export default {
	state:{
		footer_nav:[
			{
				name:'首页', 
				name_code:'home',
				icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/shouh.png',
				select_icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/shouy.png',
				size:'small',
				url:'/pages/index/index'
			},
			{
				name:'分类',
				name_code:'my',
				icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/zhaoh.png',
				select_icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/zhaoyy.png',
				size:'small',
				url:'/pages/classify/classify'
			},
			{
				name:'搜索',
				name_code:'my',
				icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiaruhuiyuanyy.png',
				select_icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiaruhuiyuanyy.png',
				size:'small',
				url:'/pages/index/index'
			},
			{
				name:'购物车',
				name_code:'publish',
				icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiarushujian.png',
				select_icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiay.png',
				size:'small',
				url:'/pages/bookrack/bookrack'
			},
		
			{
				name:'我的',
				name_code:'my',
				icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/woh.png',
				select_icon:'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/woy.png',
				size:'small',
				url:'/pages/user/user'
			}
			
		],
		now_page_index:0,
		goodsnum:uni.getStorageSync("total_number")
	},
	mutations:{
		change_page(state,index){
			state.now_page_index = index;
			// console.log(state.now_page_index,index)
			// console.log()
		},
		getgoodsnum(state,con){
			state.goodsnum=uni.getStorageSync("total_number")
			// console.log(state.goodsnum,'state.goodsnum')
		}
	},
	actions:{
		copeFun:function(context,mData){
			// context.commit('getgoodsnum',mData)
			console.log("store")
		},
	}
}