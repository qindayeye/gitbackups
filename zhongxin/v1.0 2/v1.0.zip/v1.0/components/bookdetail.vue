<template>
	<view>
		<block v-for="(item,index) in hotmain">
			<navigator :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
				<view class="hot_main_con">
					<image class="bookimg" :src="item.goods_thumb" mode=""></image>
					<view class="bookinfo">
						<text>{{item.goods_name}}</text>
						<view class="label">
							<text v-if="item.age">{{item.age}}</text>
							<text v-if="item.cat_name">{{item.cat_name}}</text>
						</view>
						<image @click.stop="addBook(item.goods_id,item.goods_stock)" :src="item.cat_status==1?'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiarushujiy.png':'https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/jiah.png'" mode=""></image>
					</view>
					<text class="topleftcorner" v-if="item.video_url">含视频</text>
					<text class="topleftcorner" v-else-if="item.audio_url">含音频</text>
				</view>
			</navigator>
		</block>
	</view>
</template>

<script >
	import uniLoadMore from "../../components/uni-load-more/uni-load-more.vue"
	export default{
		// props:{
		// 	 hotmain: {
  //               type: Array,
  //               // default: 'default'
  //           }
		// },
		data(){
			return{
				hotmian:[],
					page: 0
			}
		},
		onReachBottom(){
			this.scroll();
			
		},
		onLoad: function(options) {
			this.$api.quest('mobile/public/api/wx/index',{},(res)=>{
				this.hotmain = res.data.data.goods_list
				this.bannermain = res.data.data.banner
				this.navlist = res.data.data.navlist
				this.activity = res.data.data.activity
			})
		},
		components: {
			
			uniLoadMore
		},
		methods:{
			scroll(){
				const that=this;
				console.log(that.classon)
				that.classon=true;
				this.loadingType=1;
				const scrollrequest=this.$api.quest('mobile/public/api/wx/nextpage',{page:that.page++},(res)=>{
					console.log(res)
					if (res.data == null) {  //没有数据
					    _self.loadingType = 2;
					    uni.hideNavigationBarLoading();//关闭加载动画
					    return;
					}
						this.hotmain.push(...res.data.data.goods_list) 
						  uni.hideNavigationBarLoading();//关闭加载动画
						 this.classon=false   //判断模块框
						console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading();//关闭加载动画
				})
			},
			// 加入书架
			addBook(e,id,num){
				this.$api.addBook(e,id,num)
			},
		}
	}
</script>

<style>
</style>
