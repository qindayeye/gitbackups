<template>
	<view>
		<view :class="{dingbukong:vioc}">

		</view>
		<view :class="[vioc?'videodb':'title']">
			<navigator v-if="H5back" class="cell-icon yticon icon-zuo" @click="H5Goback()"></navigator>
			<navigator v-else class="cell-icon yticon icon-zuo" open-type="navigateBack"></navigator>
			
			<h4>{{title}}</h4>
			<!-- 空标签  占位符 -->
			<view class=""></view>
			<!-- <image v-if="godid" src="../static/voiceing.gif" @click="gotodetail()" mode=""></image> -->
			<!-- <image src="../static/voiceing.gif" @click="gotodetail()" mode=""></image> -->
			<!-- <text class="eosfont" v-else-if="vioc" style="color: #FFFFFF;">&#xe60e;</text>
			<text class="eosfont" v-else @click="gotonews()">&#xe60e;</text>
			<text class="hasno" v-if="hasno"></text> -->
		</view>
		<!-- 空标签  占位符 -->
		<view class="Kong">

		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				hasno: false,
				godid: '',
				typeList: {
					left: 'icon-zuo',
					right: 'icon-you',
					up: 'icon-shang',
					down: 'icon-xia'
				},
			}
		},
		onLoad() {
			console.log('shkfbjh')
			this.$api.quest('user/hasNoReadMessage', {}, (res) => {
				// console.log(res.data)
				if (res.data.data == 1) {
					this.hasno = true
				}
			})
		},
		props: {
			H5back:{
				type:String,
				default: ''
			},
			vioc: {
				type: String,
				default: ''
			},
			icon: {
				type: String,
				default: ''
			},
			title: {
				type: String,
				default: '标题'
			},
			tips: {
				type: String,
				default: ''
			},
			navigateType: {
				type: String,
				default: 'right'
			},
			border: {
				type: String,
				default: 'b-b'
			},
			hoverClass: {
				type: String,
				default: 'cell-hover'
			},
			iconColor: {
				type: String,
				default: '#333'
			}
		},
		onReady() {
			console.log("onti")
			// console.log(uni.getStorageSync('voivegodid'))
			// this.godid=uni.getStorageSync('voivegodid')
			this.timer= setInterval(() => {
				this.godid = uni.getStorageSync('voivegodid')
				// console.log(this.godid)
			}, 500)
		},
		onUnload() {
			 if(this.timer) {  
			        clearInterval(this.timer);  
			        this.timer = null;  
			    }  
		},
		onShow() {
			console.log('shoew')
			this.godid = uni.getStorageInfo('voivegodid')
		},
		methods: {
			H5Goback(){
				uni.navigateBack({
					delta:4
				})
			},
			gotonews() {
				if (uni.getStorageSync("token")) {
					uni.navigateTo({
						url: '/pages/news/news'
					})
				} else {
					uni.redirectTo({
						url: '/pages/public/login'
					});
				}
			},
			gotodetail(id) {
				// 进入播放详情
				// uni.redirectTo({
				// 	url: '/pages/voice/voicedetail?id=' + this.godid
				// });
				// 进入播放列表
				uni.navigateTo({
					url:'/pages/voice/PlayList'
				})
			},
			eventClick() {
				this.$emit('eventClick');
			}
		},
	}
</script>
<style lang="scss">
	.Kong {
		width: 100%;
		height: 88rpx;
	}

	/* #ifdef MP */
	.dingbukong {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 88rpx;
		background: #fff;
		z-index: 19;
	}
	/* #endif */
	.videodb {
		width: 100%;
		position: fixed;
		/* #ifdef MP */
		top: 88rpx;
		/* #endif */
		/* #ifdef H5 */
		top: 0;
		/* #endif */
		left: 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 88rpx;
		/* box-shadow:0rpx -1rpx 0rpx 0rpx rgba(153,153,153,1); */
		padding: 0 20rpx;
		background: #fff;
		z-index: 20;

		image {
			width: 40rpx;
			height: 40rpx;
		}
	}

	.title {
		width: 100%;
		position: fixed;
		top: 0;
		left: 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 88rpx;
		/* box-shadow:0rpx -1rpx 0rpx 0rpx rgba(153,153,153,1); */
		padding: 0 20rpx;
		background: #fff;
		z-index: 20;

		image {
			width: 40rpx;
			height: 40rpx;
		}
	}

	.yticon {
		font-size: 34rpx;
		color: #333;
		font-weight: 600;
	}


	.eosfont {
		color: #666;
		font-weight: 600;
	}

	.hasno {
		position: absolute;
		top: 20rpx;
		right: 15rpx;
		width: 20rpx;
		height: 20rpx;
		border-radius: 50%;
		background: red;
	}
</style>
