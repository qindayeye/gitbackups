// #ifdef H5
let H5wxjs = require('jweixin-module')
export default H5wxjs
// #endif