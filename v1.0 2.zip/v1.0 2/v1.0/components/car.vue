<template>
	<view class="gocar" @click="gotoCar()">
		<view v-if="carnum!=0 " class="carnum">{{carnum}}</view>
		 <!-- #ifdef MP -->
		<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/carbook.png" mode="widthFix"></image>
		<!-- #endif -->
		<!-- #ifdef H5 -->
		<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/carbook.png" mode="widthFix"></image>
		<!-- #endif -->
	</view>
</template>

<script>
	export default{
		props:['carnum'],
		data(){
			return{
				getgoodsnum:uni.getStorageSync("total_number")
			}
		},
		
		watch: {            
			username: function(newVal,oldVal){               
				console.log(newVal,oldVal)                         
				},
		},
		created() {
			this.getgoodsnum = this.carnum
		},
		methods:{
			gotoCar(){
				if(uni.getStorageSync("token")){
					uni.reLaunch({
						url: '/pages/bookrack/bookrack'
					});
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					// #ifdef MP
					uni.navigateTo({
						url:'/pages/public/login'
					})
					// #endif
				}
			}
		}
	}
</script>

<style lang="scss">
	.gocar{
		position: fixed;
		bottom:250rpx;
		right: 13rpx;
		width:84rpx;
		height:84rpx;
		border-radius: 50%;
		background: #fff;
		box-shadow:0rpx 2rpx 8rpx 0rpx rgba(255,130,75,0.3);
		border:2rpx solid rgba(255,205,120,1);
		.carnum{
			position: absolute;
			top: 8rpx;
			left: 40rpx;
			color: #fff;
			border-radius:50%;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
			min-width: 34rpx;
			-webkit-box-sizing: border-box;
			box-sizing: border-box;
			padding: 0 10rpx;
			height: 34rpx;
			border-radius: 16rpx;
			font-size: 22rpx;
			color: #fff;
			text-align: center;
			z-index: 9;

		}
		image{
			width: 42rpx;
			height: 42rpx;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%,-50%);
		}
	}
</style>
