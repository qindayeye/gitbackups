export default {
	state: {
		Playlist: [],
		music_index: 0//  正在播放的index
	},
	mutations: {
		addPlaylist(state, music) {
			state.Playlist.push(music)
			console.log("添加成功")
		},
		subPlaylist(state, index) {
			state.Playlist.splice(index, 1)
			//如果删除的音频是在正在播放的音频之前的
			if (state.music_index >index) {
				state.music_index--
			}
			console.log('删除成功')
		},
		emptyPlaylist(state) { // 清空播放列表
			state.Playlist = []
			state.music_index = 0
			console.log('清空列表成功')			
		},
		setMusicIndex(state,index){// 设置当前正在播放的音乐
			state.music_index = index
		},
		addMusicIndex(state){
			state.music_index++
		},
		
	},
	actions: {
		// copeFun:function(context,mData){
		// 	// context.commit('getgoodsnum',mData)
		// 	console.log("store")
	}
}
