<template>
	<view class="container">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="fle list-cell b-b m-t clear" v-for="(item,index) in messlist" hover-class="cell-hover" :hover-stay-time="50"
		 @click="gotomess(item.cat_id)">
			<image class="portrait fl" :src="image[index]"></image>
			<text class="cell-tit fl clefr ">{{item.cat_name}}</text>
			<text class="hasno fl" v-if="item.hasno"></text>
			<text class="cell-more yticon icon-you fr"></text>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	import Vue from 'vue'
	import {
		mapMutations
	} from 'vuex';
	export default {
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "消息",
				messlist: [],
				image: [
					"https://www.abcbook2019.com/mobile/public/img/index/icon-item001.png",
					"https://www.abcbook2019.com/mobile/public/img/index/icon-item005.png",
					"https://www.abcbook2019.com/mobile/public/img/index/icon-item004.png"
				]
			};
		},
		onLoad(option) {
			this.$api.quest('user/messageCat', {}, (res) => {
				this.messlist = res.data.data
				this.messlist.forEach(el => {
					this.$api.quest('user/hasNoReadMessage', {
						type: el.cat_id
					}, (res) => {
						console.log(res.data)
						if (res.data.data == 1) {
							Vue.set(el, 'hasno', true);
							console.log(el)
						}
					})
				})
				this.messlist = res.data.data
				console.log(this.messlist)
			})


		},
		methods: {
			gotomess(id) {
				this.$api.quest('user/message', {
					type: id,
					page: 1
				}, (res) => {
					// console.log(res)
					if (res.data.code == 0) {
						uni.navigateTo({
							url: `/pages/notice/notice?data=${JSON.stringify({
							 mess: res.data.data,
							 type:id
							})}`
						})
					} else {
						this.$api.msg("请求失败")
					}

					// this.messlist=res.data.data
				})
			},
		}
	}
</script>

<style lang='scss'>
	page {
		background: $page-color-base;
	}

	.portrait {
		width: 60rpx;
		height: 60rpx;
		border: 50%;
	}

	.fle {
		display: block !important;

	}

	.hasno {
		width: 20rpx;
		height: 20rpx;
		border-radius: 50%;
		background: red;
	}

	.clefr {
		margin: 0;
		margin-left: 50rpx;
		line-height: 60rpx;
	}

	.list-cell {
		display: flex;
		align-items: baseline;
		padding: 20upx $page-row-spacing;
		line-height: 60upx;
		position: relative;
		background: #fff;
		justify-content: center;

		&.log-out-btn {
			margin-top: 40upx;

			.cell-tit {
				color: $uni-color-primary;
				text-align: center;
				margin-right: 0;
			}
		}

		&.cell-hover {
			background: #fafafa;
		}

		&.b-b:after {
			left: 30upx;
		}

		&.m-t {
			margin-top: 16upx;
		}

		.cell-more {
			align-self: baseline;
			font-size: $font-lg;
			color: $font-color-light;
			margin-left: 10upx;
		}

		.cell-tit {
			flex: 1;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: $font-base;
			color: $font-color-light;
		}

		switch {
			transform: translateX(16upx) scale(.84);
		}
	}
</style>
