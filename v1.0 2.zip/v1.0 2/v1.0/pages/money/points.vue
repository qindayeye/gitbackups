<template>
	<view>4</view>
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		onLoad() {
			uni.request({
				url:'https://www.abcbook2019.com/mobile/public/api/wx/demo/search',
				data:{},
				method: "POST",
				header: {
					'Content-Type': 'application/json',
					'X-ECTouch-Authorization':uni.getStorageSync("token")
				},
				success: function(res) {
					console.log(res)
					console.log(res.data.data.mch_id)
					console.log(res.data.data.package)
					console.log(res.data.data.timestamp)
					console.log(res.data.data.nonce_str)
					console.log(res.data.data.sign_type)
					console.log(res.data.data.timestamp)
					console.log(wx.openBusinessView)
					if (wx.openBusinessView) {
						console.log(111)
					  wx.openBusinessView({
					    businessType: 'wxpayScoreUse',
					    extraData: {
					      // mch_id: res.data.data.mch_id,
					      // package: res.data.data.package,
					      // timestamp:res.data.data.time,
					      // nonce_str: res.data.data.nonce_str,
					      // sign_type: res.data.data.sign_type,
					      // sign:res.data.data.sign,
						  mch_id: res.data.data.mch_id,
						  package: res.data.data.package,
						  timestamp:res.data.data.timestamp,
						  nonce_str: res.data.data.nonce_str,
						  sign_type: res.data.data.sign_type,
						  sign:res.data.data.sign_sh256
					    },
					    success(src) {
					      //dosomething
						    console.log(res)
					    },
					    fail(faill) {
					      //dosomething
						   console.log(faill)
					    },
					    complete() {
					      //dosomething
					    }
					  });
					} else {
					  //引导用户升级微信版本
					}
				}
			})
		},
		methods:{
			
		}
	}
</script>

<style>
</style>
