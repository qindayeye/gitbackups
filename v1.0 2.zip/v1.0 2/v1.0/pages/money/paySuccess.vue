<template>
	<view class="content" v-if="loading">
		<image :src="payok?'https://www.abcbook2019.com/mobile/public/payresult/img/paySuccess.png':'https://www.abcbook2019.com/mobile/public/payresult/img/PayFailed.png'"
		 mode=""></image>
		<text class="tit" v-if="payok">下单成功</text>
		<text class="tit" v-else>{{error}}</text>
		<view class="number" v-if="payok&&!card">
			<text>收到绘本请检查  如有破损请尽快联系客服</text>
			<text>以免造成额外损失</text>
		</view>
		<!-- <text class="number" v-if="!payok">{{errhint}}</text> -->
		<!-- 书是 true   卡是false -->
		<view class="btn-group" v-if="card">
			<!-- 买的卡 -->
			<view @click="lookmenu" class="mix-btn hollow">查看订单</view>

			<view @click="govip" class="mix-btn " v-if="payok">激活会员</view>
			<!-- 买卡不用支付分 -->
			<view @click="opinion('n')" class="mix-btn" v-else>重新下单</view>
		</view>

		<view class="btn-group" v-else>
			<!-- 买的书 -->
			<view @click="lookmenu" class="mix-btn hollow">查看订单</view>

			<view @click="gohome" class="mix-btn" v-if="payok">返回首页</view>
			<!-- 不用支付分 -->
			<view @click="opinion('n')" class="mix-btn" v-else-if="ruid>0">重新下单</view>
			<!-- 用支付分 -->
			<view @click="reorder" class="mix-btn" v-else>重新下单</view>
		</view>
		<!-- #ifdef H5 -->
		<goHome></goHome>
		<!-- #endif -->
		
		<view class="pop-up" v-if="popup">

			<view class="upcon">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
				<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/upcon.png" mode="widthFix"></image>
				<view class="upopinion">
					<text @click="opinion('n')">先不用</text>
					<text class="main" @click="opinion('y')">免押金租书</text>
				</view>
			</view>
		</view>
		<view class="H5mengB" v-if="H5Loding">
			<view class="H5mengB1">
				<view class="H5Loding">
					正在查询支付结果···
				</view>
			</view>
		</view>
	</view>

	<mixLoading v-else></mixLoading>

</template>

<script>
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	import goHome from '@/components/home.vue';
	export default {
		data() {
			return {
				popup: false,
				loading: false,
				payok: false,
				id: "",
				payment: "",
				adactive: false, //返回首页，
				nunt: 0, // 回调请求次数
				H5data: {}, // h5支付返回结果
				error: '下单失败',
				errhint: '糟糕！网络出现故障',
				card: null,
				ruid: null,
				H5Loding: false,
				deCode: '',
				booknum: ''
			}
		},
		components: {
			mixLoading,
			goHome
		},
		// #ifdef MP
		onLoad(option) {
			console.log(option)

			this.goodid = []
			this.id = option.id;
			this.payment = option.payment
			this.card = option.isreal == '0' ? true : false //0 卡 1 书
			this.ruid = option.ruid
			console.log(this.card, 'this.card')
			console.log(this.ruid)
			if (option.payok == 0) {
				this.loading = true;
				this.payok = true
			} else if (option.payok == 1) {
				this.payok = false
				this.loading = true;
				this.booknum = option.booknum
				this.consignee = option.consignee
				this.flow_type = option.flow_type
				this.goodid.push(option.goodid * 1)
			}

		},
		// #endif
		// #ifdef H5
		onLoad(option) {
			this.loading = true;
			console.log(option)
			// 判断微信内外
			var ua = window.navigator.userAgent.toLowerCase();
			console.log(ua)
			// console.log(ua.indexOf('micromessenger') != -1)
			// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
			if (ua.match(/MicroMessenger/i) == 'micromessenger') {
				// 微信内浏览器（公众号）
				console.log(option, "公众号")
				this.deCode = option.deCode
				console.log(option)
				this.goodid = []
				this.id = option.id;
				this.payment = option.payment
				this.card = option.isreal == '0' ? true : false //0 卡 1 书

				if (option.payok == 0) {
					this.loading = true;
					this.payok = true
				} else if (option.payok == 1) {
					this.payok = false
					this.loading = true;
					this.booknum = option.booknum
					this.consignee = option.consignee
					this.flow_type = option.flow_type
					this.goodid.push(option.goodid * 1)
					// this.$api.quest('flow/cancelorder',{
					// 	order_id:option.id
					// },(res)=>{
					// 	console.log(res)
					// 	if(res.data.code==0){
					// 		this.loading=true;
					// 		this.adactive=true
					// 	}
					// })
				}
			} else {
				// 浏览器	
				console.log(option, "浏览器")
				// this.id = option.id //测试
				this.id = option.order_id; // 正式
				this.card = option.is_real == '0' ? true : false //0 卡 1 书
				this.H5callbackasync()
			}
		},
		// #endif
		methods: {
			// #ifdef H5
			// 查看H5支付成功结果
			H5callbackasync() {
				this.H5Loding = true // 显示查询loding
				let that = this
				let int = setInterval(() => {
					that.nunt++
					console.log(that.nunt)
					// 查看H5支付回调
					this.$api.quest('payment/checkstatus', {
						id: this.id,
					}, (res) => {
						console.log(res, "h5支付回调查询详情")
						console.log(res.data.code)
						if (res.data.code == 0) {
							// 成功
							clearInterval(int) // 清除循环
							console.log("成功")
							that.H5Loding = false // loding消失
							that.payok = true
						} else {
							if (that.nunt > 8) {
								// 失败
								clearInterval(int) // 清除循环
								console.log("失败")
								that.H5Loding = false // loding消失
								that.payok = false
								// this.$api.quest('flow/cancelorder', {
								// 	order_id: that.id
								// }, (res) => {
								// 	console.log(res, "...")
								// 	if (res.data.code == 0) {
								// 		this.adactive = true
								// 	}
								// })
							}
						}
					})
				}, 1000)
			},
			// #endif
			// 弹框
			close() {
				console.log('关闭弹框')
				this.popup = false;
			},
			// 查看订单
			lookmenu() {
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + this.id + '&deCode=' + this.deCode
					// url:'/pages/order/order?states=0&index=0'
				})
			},
			// 支付分弹框
			opinion(type) {
				this.$api.quest('flow/againorder', {
					order_id: this.id,
					type: type == 'y' ? 1 : 0
				}, (res) => {
					this.payment=res.data.amount
					if (res.data.code == 0) {
						uni.setStorageSync('ordersn', res.data.error)
					}
					if (type == 'y') {


						// console.log('调用支付分')
						this.gopay()
						this.deposittype = 1
					} else {
						this.payAgain()
						this.deposittype = 0

					}
				})

			},
			// 重新支付
			reorder() {
				// #ifdef MP
				this.popup = true
				// #endif				
				// #ifdef H5				
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					this.popup = true
				} else {
					this.payAgain()
				}
				// #endif
			},
			// 重新支付
			payAgain() {
				// againorder:重新支付状态
				// deposit_type: 支付分支付状态  1支付分  0 不是支付分
				// 正常微信支付
				console.log(this.payment)
				if(this.payment==0){
					uni.navigateTo({ 
						url: '/pages/money/paySuccess?id=' + this.id + '&payok=0&payment=' + this.payment
					})
				}else{
					uni.navigateTo({
						url: '/pages/money/pay?id=' + this.id + '&payment=' + this.payment,
						// #ifdef H5
						success: (res) => {
							if (res.errMsg == 'navigateTo:ok') {
								window.location.reload(true);
							}
						}
						// #endif
					})
				}
				// this.$api.quest('flow/againorder',{
				// 	order_id:this.id,
				// 	type:0
				// },(res)=>{
				// 	if(res.data.code==0){
				// 		// this.payment=options.payment
				// 		uni.navigateTo({
				// 			url:'/pages/money/pay?id='+this.id +'&payment='+this.payment
				// 		})
				// 	}
				// })
			},
			// 返回首页
			gohome() {
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
			// #ifdef H5
			compareVersion(v1, v2) {
				v1 = v1.split('.')
				v2 = v2.split('.')
				const len = Math.max(v1.length, v2.length)
				while (v1.length < len) {
					v1.push('0')
				}
				while (v2.length < len) {
					v2.push('0')
				}
				for (let i = 0; i < len; i++) {
					const num1 = parseInt(v1[i])
					const num2 = parseInt(v2[i])
					if (num1 > num2) {
						return 1
					} else if (num1 < num2) {
						return -1
					}
				}
				return 0
			},
			// #endif	

			// 重新支付
			gopay() {
				// #ifdef MP
				this.error = '处理中...'
				this.errhint = '正在处理请稍后..'
				console.log(this.booknum)
				this.$api.quest('payscore/add', {
					order_sn: uni.getStorageSync("ordersn"),
					user_id: uni.getStorageSync("user_id"),
					book_num: this.booknum
				}, (res) => {
					let that = this;
					console.log(res)
					if (res.data.data.code == 1) {
						// this.$api.msg(res.data.data.msg)
						that.$api.quest('payscore/changesn', {
							order_id: that.id
						}, (res) => {
							console.log(res)
							uni.setStorageSync('ordersn', res.data.data)
							console.log(res)
							if (res.data.code == 0) {
								this.gopay()
							}
						})
					} else {
						this.anewtype = true;

						if (wx.openBusinessView) {
							// console.log(uni.getStorageSync("ordersn"))
							wx.openBusinessView({
								businessType: 'wxpayScoreUse',
								extraData: {
									mch_id: res.data.data.mch_id,
									package: res.data.data.package,
									timestamp: res.data.data.timestamp,
									nonce_str: res.data.data.nonce_str,
									sign_type: res.data.data.sign_type,
									sign: res.data.data.sign_sh256
								},
								success(res) {
									// setTimeout(function() {
									that.$api.quest('payscore/searchdb', {
										out_order_no: uni.getStorageSync("ordersn")
									}, (res) => {

										uni.navigateTo({
											url: '/pages/money/paySuccess?id=' + that.id + '&payok=0&payment=' + that.payment
										})
										// if(res.data.data.msg_id){
										// 	uni.navigateTo({
										// 		url: '/pages/money/paySuccess?id=' + that.id+ '&payok=0&payment='+that.payment
										// 	})
										// }else{
										// 	uni.navigateTo({
										// 		url: '/pages/money/paySuccess?id=' + that.id+'&payok=1&payment='+that.payment
										// 	})
										// }
									})
									// }, 2000);
								},
								fail(faill) {
									uni.navigateTo({
										url: '/pages/money/paySuccess?id=' + that.id + '&payok=1&payment=' + that.payment
									})
								},
								complete(com) {
									console.log(com)
								}
							});
						} else {
							//引导用户升级微信版本
						}
					}

				})
				// #endif
				// #ifdef H5
				let lis = this
				lis.$api.quest('payment/getticketsign', {
					code: lis.deCode,
					url: decodeURIComponent(window.location.href.split('#')[0])
				}, (reda) => {
					console.log(reda.data.data, 'eee')
					lis.cketsign = reda.data.data.sign
					// alert(lis.cketsign)
					let wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i);
					console.log(wechatInfo);
					let wechatVersion = wechatInfo[1];
					if (lis.compareVersion(wechatVersion, "7.0.5") >= 0) {
						console.log("www");
						// alert("www");
						H5wxjs.config({
							// debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
							appId: reda.data.data.appid, // 必填，公众号的唯一标识wxbdbc05d9a09741f7
							timestamp: reda.data.data.timestamp, // 必填，生成签名的时间戳
							nonceStr: reda.data.data.nonceStr, // 必填，生成签名的随机串
							signature: reda.data.data.sign, // 必填，签名
							jsApiList: ["openBusinessView"] // 必填，需要使用的JS接口列表
						});
						H5wxjs.ready(function() {
							// config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
							H5wxjs.checkJsApi({
								jsApiList: [
									"openBusinessView",
								], // 需要检测的JS接口列表
								success: function(data) {
									console.log(data, "rrr");
									// 以键值对的形式返回，可用的api值true，不可用为false
									// 如：{"checkResult":{"openBusinessView":true},"errMsg":"checkJsApi:ok"}
									if (data.checkResult.openBusinessView) {
										// alert("ddd");
										console.log("ddd");
										// alert(JSON.stringify(res.data.data));
										lis.$api.quest('payscore/add_h5', {
											order_sn: uni.getStorageSync("ordersn"),
											user_id: uni.getStorageSync("user_id"),
											book_num: this.booknum
										}, (res) => {
											console.log(res.data.data, 'add_h5');
											let that = this;
											if (res.data.data.code == 0) {
												lis.anewtype = true;
												H5wxjs.invoke(
													"openBusinessView", {
														businessType: "wxpayScoreUse",
														queryString: "mch_id=" + res.data.data.mch_id + "&package=" + res.data.data.package +
															"&timestamp=" + res.data.data.timestamp + "&nonce_str=" + res.data.data.nonce_str +
															"&sign_type=" + res.data.data.sign_type + "&sign=" + res.data.data.sign_sh256
													},
													function(res) {
														console.log(res, "l");
														// alert(JSON.stringify(res), '450');
														// 从微信侧小程序返回时会执行这个回调函数
														if (parseInt(res.err_code) == 0) {
															// alert("fff");
															setTimeout(function() {
																lis.$api.quest('payscore/searchdb', {
																	out_order_no: uni.getStorageSync("ordersn")
																}, (res) => {
																	// alert(JSON.stringify(res), '458');
																	if (res.data.data.msg_id) {
																		uni.navigateTo({
																			url: '/pages/money/paySuccess?id=' + lis.orderid + '&payok=0&booknum=' + lis.goodsDat
																				.length
																		})
																	}
																})
															}, 2000);
															// 返回成功
														} else {
															// alert("ggg");
															uni.navigateTo({
																url: `/pages/money/paySuccess?payok=1&goodid=${goodsId}&id=${lis.orderid}&flow_type=${lis.flow_type}&consignee=${lis.addressData.address_id}&booknum=${lis.goodsData.length}`
															})
															// 返回失败
														}
													}
												);

											} else {

												// this.$api.msg(res.data.data.msg)
												lis.$api.quest('payscore/changesn', {
													order_id: lis.itemclick.order_id
												}, (res) => {
													// console.log(res)
													uni.setStorageSync('ordersn', res.data.data)
													// console.log(res)
													if (res.data.code == 0) {
														this.gopay()
													}
												})

											}
										})

									}
								}
							});
						});
					} else {
						// 提示用户升级微信客户端版本
						console.log("vvv");
						// alert("vvv");
						window.location.href =
							"https://support.weixin.qq.com/cgi-bin/readtemplate?t=page/common_page__upgrade&text=text005&btn_text=btn_text_0";
					}
				})

				// #endif
			},
			// 激活会员
			govip() {
				uni.navigateTo({
					url: '/pages/members/members'
				})
			}
		}
	}
</script>

<style lang='scss'>
	.number{
		text{
			display: block;
			text-align: center;
			font-size: 28rpx;
			color: #999;
		}
	}
	.H5mengB {
		z-index: 200;
		height: 100%;
		width: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-color: #FFFFFF;

		.H5mengB1 {
			z-index: 300;
			height: 100%;
			width: 100%;
			position: fixed;
			top: 0;
			left: 0;
			background-color: rgba(0, 0, 0, 0.5);

			.H5Loding {
				text-align: center;
				line-height: 200rpx;
				font-size: 32rpx;
				margin: 400rpx auto;
				height: 200rpx;
				width: 300rpx;
				background-color: #FFFFFF;
				border-radius: 10rpx;
			}
		}
	}

	.pop-up {
		width: 100vw;
		height: 100vh;
		background: rgba(0, 0, 0, .6);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.upcon {
			/* height: 500rpx; */
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: #fff;
			border-radius: 24rpx;
			text-align: center;

			image {
				width: 660rpx;
				height: 752rpx;
			}

			.close {
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				top: 20rpx;
				right: 25rpx;
				z-index: 9;
			}

			.upopinion {
				display: flex;
				width: 660rpx;
				margin: 0 auto;
				height: 148rpx;
				justify-content: space-around;
				align-items: center;

				text {
					width: 300rpx;
					line-height: 84rpx;
					border: 2rpx solid #666;
					border-radius: 44rpx;
					font-size: 32rpx;
					color: #666;
				}

				.main {
					color: #fff;
					line-height: 88rpx;
					border: none;
					background: linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				}
			}

		}
	}

	.content {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;

		>image {
			width: 222rpx;
			height: 183rpx;
			margin-bottom: 60rpx;
			margin-top: 137rpx;
		}

		.tit {
			font-size: 34upx;
			color: #333;
			font-weight: bold;
		}

		.number {
			font-size: 30rpx;
			color: #999;
			font-weight: 400;
			margin-top: 25rpx;
		}
	}


	.btn-group {
		width: 750rpx;
		display: flex;
		justify-content: space-around;
		padding-top: 100upx;
	}

	.mix-btn {
		margin-top: 200upx;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 343rpx;
		height: 88upx;
		font-size: 32rpx;
		color: #fff;
		background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
		box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
		border-radius: 49rpx;

		&.hollow {
			background: #fff;
			color: #FF824B;
			border: 1px solid #FF824B;
			box-shadow: none
		}
	}
</style>
