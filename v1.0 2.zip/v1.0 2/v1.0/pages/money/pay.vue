<template>
	<view class="app">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg" H5back='true'></listCell>
		<!-- #endif -->
		<view class="pay">
			<view class="price-box">
				<text>需要支付</text>
				<text class="price">{{payment}}</text>
				<text>ABCbook国际亲子阅读</text>
			</view>
			<view class="pay-type-list">
				<view class="type-item b-b" @click="changePayType(1)">
					<!-- <text class="icon yticon icon-weixinzhifu"></text> -->
					<view class="con">
						<text class="tit">微信支付</text>
						<text>推荐使用微信支付</text>
					</view>
					<label class="radio">
						<radio value="" color="#F68545" :checked='payType == 1'/>
						</radio>
					</label>
				</view>
			</view>
		</view>
		<text class="mix-btn" @click="confirm">确认支付</text>
		<!-- 返回首页 -->
		<!-- #ifdef H5 -->
		<goHome></goHome>
		<!-- #endif -->
		
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	import goHome from '@/components/home.vue';
	export default {
		components: {
			goHome,
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "支付",
				payType: 1,
				orderInfo: {},
				payment: 0,
				id: '',
				is_real:'',
				ordersn: ''
			};
		},
		computed: {

		},
		onLoad(options) {
			// console.log(options)
			this.id = options.id
			this.ordersn = options.ordersn
			this.$api.quest('user/order/detail', {
				id: options.id
			}, (res) => {
				if (res.data.code == 0) {
					// res.data.data.goods_amount
					this.payment = parseFloat(res.data.data.goods_amount) + parseFloat(res.data.data.shipping_fee)
					uni.setStorageSync('ordersn', res.data.data.order_sn)
				}
			})
		},
		methods: {
			//选择支付方式
			changePayType(type) {
				this.payType = type;
			},
			//确认支付
			// #ifdef MP
			confirm() { 
				// console.log(uni.getStorageSync("ordersn"))
				this.$api.quest('payment/pay', {
					id: this.id,
					open_id: uni.getStorageSync("openid"),
					code: "order.pay",
					order_sn: uni.getStorageSync("ordersn"),
				}, (res) => {
					console.log(res)
					if (res.data.code == 0) {
						// uni.setStorageSync('deposittype',0)
						this.payment = res.data.data.order_amount
						this.is_real = res.data.data.wxpay.is_real
						this.ruid=res.data.data.wxpay.ru_id
						console.log(this.is_real)
						this.$api.wePay(
							"abcbook国际亲子阅读",
							res.data.data.wxpay.timestamp,
							res.data.data.wxpay.nonce_str,
							res.data.data.wxpay.packages,
							"MD5",
							res.data.data.wxpay.sign,
							res => {
								console.log(JSON.parse(res))
								uni.setStorageSync('ordersn', '')
								uni.navigateTo({
									url:'/pages/money/paySuccess?payok=0&id='+this.id+'&ruid='+this.ruid+'&isreal='+this.is_real
								})

							}, fail => {
								console.log(fail)
								uni.navigateTo({
									url:'/pages/money/paySuccess?payok=1&id='+this.id+'&ruid='+this.ruid+'&isreal='+this.is_real+'&payment='+this.payment
															
								})
							})
					}
				})
				// /**
				//  * 微信小程序支付,仅支持微信支付(后续可能集成网页支付宝支付web-view)
				//  *
				//  * @param : provider(String) ->付款商家
				//  * @param : timeStamp(String) ->时间戳(当前支付时间)
				//  * @param : nonceStr(String) ->支付密匙
				//  * @param : packages(String) ->支付id
				//  * @param : signType(String) ->加密方式(默认MD5)
				//  * @param : paySign(String)
				//  *
				//  *
				//  *
				//  * 小程序支付调用

				// uni.redirectTo({
				// 	url: '/pages/money/paySuccess'
				// })
			},
			// #endif
			// #ifdef H5
			confirm: async function() {
				let that = this
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					// alert('公众号')
					that.$api.quest('payment/gzhpay', {
						id: that.id,
						// open_id: "oM9p81HiT8r71of12Vj_uT8S_Nnk",
						open_id: uni.getStorageSync("openid"),
						code: "order.pay"
					}, (res) => {
						console.log(res, "公众号")
						let gzhCS = res.data.data
						that.is_real =gzhCS.is_real				
						WeixinJSBridge.invoke(
							'getBrandWCPayRequest', {
								debug: true,
								"appId": gzhCS.appId, //公众号名称，由商户传入
								"timeStamp": gzhCS.timeStamp.trim(), //时间戳，自1970年以来的秒数 // trim去掉空格
								"nonceStr": gzhCS.nonceStr, //随机串
								"package": gzhCS.package,
								"signType": gzhCS.signType, //微信签名方式：
								"paySign": gzhCS.paySign, //微信签名
								jsApiList: [
									'chooseWXPay'
								]
							},
							function(res) {
								console.log(res, "公众号支付回调")
								// 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
								if (res.err_msg == "get_brand_wcpay_request:ok") {
									// 支付成功
									console.log("公众号支付成功")
									console.log(that.id, "idid")
									uni.navigateTo({
										url:'/pages/money/paySuccess?payok=0&id='+that.id+'&isreal='+this.is_real
									})
								} else {
									// 支付失败
									console.log("公众号支付失败")
									console.log(that.id, "idid")
									uni.navigateTo({
										url: '/pages/money/paySuccess?payok=1&id=' + that.id + '&payment=' + that.payment+'&isreal='+this.is_real
									})
								}
							}
						);
					})
					return true;
				} else {
					// 微信外浏览器
					console.log("浏览器")
					that.$api.quest('payment/browserpay', {
						id: that.id,
						code: "order.pay"
					}, (res) => {
						console.log(res, "H5支付")
						window.location.href = res.data.data
					})
				}
			}
			// #endif
		}
	}
</script>

<style lang='scss'>
	.pay {
		width: 710rpx;
		background: #fff;
		box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(0, 0, 0, 0.1);
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		overflow: hidden;
	}

	.app {
		width: 100%;
	}

	.price-box {
		background-color: #fff;
		height: 265upx;
		width: 630rpx;
		margin: 0 auto;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		font-size: 28upx;
		color: #909399;
		box-sizing: border-box;
		border-bottom: 1px dashed #e6e6e6;

		.price {
			font-size: 50upx;
			color: #303133;
			margin-top: 12upx;
		}
	}

	.pay-type-list {
		margin-top: 20upx;
		background-color: #fff;
		padding-left: 60upx;

		.type-item {
			height: 120upx;
			padding: 20upx 0;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding-right: 60upx;
			font-size: 30upx;
			position: relative;
		}

		.icon {
			width: 100upx;
			font-size: 52upx;
		}

		.icon-erjiye-yucunkuan {
			color: #fe8e2e;
		}

		.icon-weixinzhifu {
			color: #36cb59;
		}

		.icon-alipay {
			color: #01aaef;
		}

		.tit {
			font-size: $font-lg;
			color: $font-color-dark;
			margin-bottom: 4upx;
		}

		.con {
			flex: 1;
			display: flex;
			flex-direction: column;
			font-size: $font-sm;
			color: $font-color-light;
		}
	}

	.mix-btn {
		position: fixed;
		bottom: 0;
		left: 50%;
		width: 710rpx;
		line-height: 88rpx;
		background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
		box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
		border-radius: 49rpx;
		font-size: 32rpx;
		color: #fff;
		text-align: center;
		margin-left: -355rpx;
		margin-bottom: 25rpx;

	}
</style>
