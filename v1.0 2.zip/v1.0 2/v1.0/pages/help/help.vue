<template>
	<view>
		<view class="main-content" >
			<view class="navlist">
				<!-- <text  :class="{active : index===curId}" v-for="(item,index) in indexArr.top_nav" :key="index" @click="gotoactivity(index,item)">{{item.cat_name}}</text> -->
				<view class="tex"  :class="{active:ind==curId}" v-for="(nav,ind) in list" :key="ind"  @click="navlist(nav,ind)" >{{nav[0].cat_name}}</view>
			</view>
			<view class="readbg">
				<view class="use" v-for="(value,index) of conlist" :key='index'  @click="chide(value,index)">
					<h3>
					Q {{value.title}}
					</h3>
					<view class="conne" :class="value.hide?'':'hide'">
						<rich-text :nodes="value.content"></rich-text>
					</view>
				</view>
				
			</view>
			<footer>
				
				<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
				<bottom-nav class=""   ref="bottomNav" ></bottom-nav>
			</footer>
		</view>
	</view>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "@/pages/navbar/navbar.vue";
	export default {
		data(){
			return{
				curId:'borrow',
				list:[],
				conlist:[],
				// hide:ture
			}
		},
		onLoad: function(options) {
			var that=this
			this.$api.quest('index/getHelp',{},(res)=>{
				// console.log(res)
				this.list=res.data.data
				this.conlist=res.data.data.borrow[0].list
			})
		},
		methods:{
			chide(e,index){
				console.log(e)
				
				this.hide=false
				console.log(index)
				if(e.hide){
				    Vue.set(e,'hide',false);//为item添加不存在的属性，需要使用vue提供的Vue.set( object, key, value )方法。 
				}else{
				    Vue.set(e,'hide',true);
				}
			},
			navlist(item,index){
				this.curId = index;
				console.log(item,index)
				this.conlist=item[0].list
				console.log(this.conlist)
			}
		},
		components: {
			bottomNav
		}
	}
</script>

<style lang="scss">
	page{
		padding: 0;
		background: #FFFAF1;
	}
	.navlist{
		display: flex;
		width: 750rpx;
		justify-content: space-around;
		flex-wrap: wrap;
		background: #fff;
		border-bottom: 1rpx solid #e6e6e6;
		.tex{
			width:26%;
			line-height:60rpx;
			margin: 15rpx;
			background: #e6e6e6;
			color:#666;
			border: 2rpx solid #e6e6e6;
			font-size: 28rpx;
			text-align: center;
		}
		.active{
			background: #fff1e7;
			color: #fb7414;
			border: 2rpx solid #fb7414;
		}
	}
	.readbg{
		.use{
			padding: 20rpx;
			background: #fff;
			h3{
				color: #999;
				font-size:34rpx;
				line-height: 60rpx;
				border-bottom: 1rpx solid #e6e6e6;
			}
			.conne{
				padding-top: 30rpx;
				font-size:26rpx;
				color: #666;
			}
		}
	}
</style>
