<template>
	<!-- 拼团秒杀下单 -->
	<view class="container">
		<view class="carousel">
			<image :src="list.goods_img[0]" class="loaded" mode=""></image>
			<!-- <view class="actEndTime">{{countDownList}}</view> -->
		</view>

		<view class="introduce-section">
			<text class="bttitle">{{list.goods_info.goods_name}}</text>
			<view class="price">￥{{list.goods_info.market_price}}</view>
			<view class="YJ">
				市场价
				<text>￥1597</text>
			</view>
		</view>
		<view class="introduce-section ">
			<text class="title">拼团介绍</text>
			<view class="infocon">
				<view class="confl">
					<text class="num">{{list.goods_info.team_desc}}</text>
				</view>
			</view>
		</view>
		<view class="introduce-section ">
			<view class="xian">

			</view>
			<text class="title">拼团规则</text>
			<view class="groupd">
				<view class="confl">
					<text class="num">1</text>
					<text>选择商品</text>
				</view>
				<view class="confl">
					<text class="num">2</text>
					<text>开团/参团</text>
				</view>
				<view class="confl">
					<text class="num">3</text>
					<text>邀请好友</text>
				</view>
				<view class="confl">
					<text class="num">4</text>
					<text>人满成团</text>
				</view>

			</view>
			<image class="imgla" @click="btn()" :src="teaminfo?'https://www.abcbook2019.com//mobile/public/img/recbooklist/jiantou_buttom.png':'https://www.abcbook2019.com//mobile/public/img/recbooklist/jiantou_top.png'"
			 mode="widthFix"></image>
		</view>
		<view class="teaminfo" v-if="teaminfo">
			<text>1.开团：在商城内选择喜欢的商品，点击“去开团”，付款成功后即为开团成功；</text>
			<text>2.参团：进入朋友分享的页面，点击“立即参团”，付款后即为参团成功，若多人同时支付，按先支付成功的用户获得参团资格，参团订单未支付不计入参团数量，团过期未支付订单失效，但参团人信息也会显示在团里面；</text>
			<text>3.成团：在开团或参团之后,可以点击“分享出去”，在有效时间凑齐成团人数即拼团成功；</text>
			<text>4.组团失败：在有效时间内未凑齐人数，即为组团失败，此时商城会将原款分别退回；</text>
		</view>
		<view class="introduce-section ">
			<text class="title">不想开团,和以下小伙伴一起拼了</text>
			<swiper :class="[displayMultipleItems==2 ? 'swiper' : 'swiper1']" :display-multiple-items="displayMultipleItems" vertical=true circular=true autoplay=true
			 :interval="interval" :duration="duration">
				<swiper-item class="groupInfo" v-for="(item,index) in teamlog">
					<view class="groupInfo_item">
						<image :src="item.user_picture" mode=""></image>
						<view class="usercon">
							<text>{{item.user_name}}</text>
							<text class="end">剩余{{item.end_time}}结束</text>
						</view>
						<text>还差{{item.surplus}}人成团</text>
						<button type="primary" @click.stop="itpaycheckout(item.goods_id,item.team_id)">去参团</button>
					</view>
				</swiper-item>
			</swiper>
		</view>
		<view class="detail-desc">
			<view class="d-header">
				<text>图文详情</text>
			</view>
			<rich-text :nodes="desc|formatRichText " class="imgdetail"></rich-text>
		</view>

		<!-- <uni-evaluate :list-data="listev" :rate="reted"/> -->
		<!-- 底部操作菜单 -->
		<view class="page-bottom">
			<view class="btnf bun1" @click.stop="itpaycheckout(list.goods_info.goods_id,0)">
				<text>{{list.goods_info.team_num}}人团</text>
				<text>{{list.goods_info.team_price}}</text>
			</view>
			<!-- <button  type="primary" v-else  class="btnf ghui" >{{list.goods_info.team_num}}人团</button> -->
		</view>

	</view>
</template>

<script>
	import share from '@/components/share';
	import uniEvaluate from '@/components/xiujun-evaluate/uni-evaluate.vue';

	export default {
		components: {
			share,
			uniEvaluate
		},
		data() {
			return {
				list: {},
				hotmain: [],
				is_collect: false,
				desc: ``,
				goods_id: 0,
				// countDownList: '00天00时00分00秒',
				// actEndTime: '2020-01-08 23:17:00',
				finished: true,
				teaminfo: true, //显示拼团规则详细信息
				indicatorDots: true,
				autoplay: true,
				interval: 2000,
				duration: 500,
				teamlog: [],
				tid: 0,
				displayMultipleItems: 1,

			};
		},
		// onShow() {
		// 	this.$nextTick(() => {
		// 		this.countDown();
		// 	})
		// },
		onLoad(option) {
			// console.log(option.id, 'opt')

			var that = this;
			var id = option.id;

			this.$api.quest('team/goodsDetail', {
				team_id: 0,
				goods_id: 4301
			}, (res) => {
				console.log(res, "22")
				that.list = res.data.data
				console.log(that.list)
				that.goods_id = that.list.goods_id
				that.is_collect = that.list.is_collect ? true : false
				if (that.list.team_log.length > 1) {
					that.displayMultipleItems = 2
				}
				if (that.list.team_log.length > 0) {
					that.teamlog = that.list.team_log.map(item => {
						// 隐藏昵称
						let reg = /(.*)(.)$/;
						item.user_name = item.user_name.replace(reg, function(a, b, c) {
							return "**" + c;
						});
						item.end_time = that.teamLogDown(item.end_time)
						return item
					})
				}

				if (that.list.goods_info.goods_desc.indexOf('style="float:none;"') > 0) {

					var str = that.list.goods_info.goods_desc.replace('style="float:none;"', '')
					var reg = new RegExp('style="float:none;"', "gi");
					var a = str.replace(reg, "");
					console.log(a, 'desc')
					that.desc = a.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				} else {
					that.desc = that.list.goods_info.goods_desc.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				}

				// if(res.data.data.presale.status==0 || res.data.data.presale.status==2){
				// 	this.finished=true
				// }else{
				// 	this.finished=false
				// }
				// this.finished=res.data.data.presale.is_finished
				// this.actEndTime=res.data.data.presale.end_time
				// console.log(that.list, that.desc, res.data.data.root_path)


			})

		},

		methods: {
			btn() {
				this.teaminfo = !this.teaminfo
			},
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			// 每个团到期的时间
			teamLogDown(itTime) {

				// 获取当前时间，同时得到活动结束时间数组
				let newTime = parseInt(+new Date() / 1000);
				// console.log(newTime)
				// 对结束时间进行处理渲染到页面
				let endTime = new Date(itTime).getTime();
				// console.log(endTime,"end")
				let obj = null;
				// 如果活动未结束，对时间进行处理
				if (endTime - newTime > 0) {
					let time = endTime - newTime;
					// 获取天、时、分、秒
					let day = parseInt(time / (60 * 60 * 24));
					let hou = parseInt(time % (60 * 60 * 24) / 3600);
					let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
					let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
					obj = {
						day: this.timeFormat(day),
						hou: this.timeFormat(hou),
						min: this.timeFormat(min),
						sec: this.timeFormat(sec)
					};
				} else { // 活动已结束，全部设置为'00'
					obj = {
						day: '00',
						hou: '00',
						min: '00',
						sec: '00'
					};
					this.finished = true
					clearInterval(interval);
				}
				return obj.hou + ':' + obj.min + ':' + obj.sec;

			},
			// 活动剩余时间
			// countDown(ittime) {
			// 	var interval = setInterval(() => {
			// 		// 获取当前时间，同时得到活动结束时间数组
			// 		let newTime = new Date().getTime();
			// 		// let newTime = parseInt(+new Date() / 1000);
			// 		// 对结束时间进行处理渲染到页面
			// 		let endTime = new Date(this.actEndTime).getTime();
			// 		let obj = null;
			// 		// 如果活动未结束，对时间进行处理
			// 		if (endTime - newTime > 0) {
			// 			let time = (endTime - newTime) / 1000;
			// 			// 获取天、时、分、秒
			// 			let day = parseInt(time / (60 * 60 * 24));
			// 			let hou = parseInt(time % (60 * 60 * 24) / 3600);
			// 			let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
			// 			let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
			// 			obj = {
			// 				day: this.timeFormat(day),
			// 				hou: this.timeFormat(hou),
			// 				min: this.timeFormat(min),
			// 				sec: this.timeFormat(sec)
			// 			};
			// 		} else { // 活动已结束，全部设置为'00'
			// 			obj = {
			// 				day: '00',
			// 				hou: '00',
			// 				min: '00',
			// 				sec: '00'
			// 			};
			// 			this.finished = true
			// 			clearInterval(interval);
			// 		}
			// 		this.countDownList = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
			// 	}, 1000);
			// },

			itpaycheckout(id, team_id) {
				let that = this
				let goid = id
				if (uni.getStorageSync("token")) {
					this.$api.quest('flow/checkteam', {
						t_id: that.list.goods_info.id,
					}, (res) => {
						console.log(res, "eee")
						if (res.data.code == 0) {
							// 没参加过了
							that.paycheckout(id, team_id)
						} else {
							console.log("参加过了")
							uni.showToast({
								title: res.data.data,
								icon: 'none',
								duration: 2000
							});
						}
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}

			},
			paycheckout(id, team_id) {
				let that = this
				let goid = id
				this.$api.quest('team/teamBuy', {
					goods_id: id,
					team_id: team_id,
					t_id: that.list.goods_info.id,
					num: 1,
					uid: uni.getStorageSync("user_id"),
					attr_id: 1,
					act_id: 0,
					rec_type: 6,
					extension_code: "team_buy",
					is_checked: 1
				}, (res) => {
					console.log(res, "eee")
					if (res.data.code == 0) {
						uni.navigateTo({
							url: '/pages/flow/groupmember?goid=' + goid + '&t_id=' + that.list.goods_info.id + '&team_id=' + team_id
						})
					} else if (res.data.data.error) {
						this.$store.commit("change_page", 4)
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif
						
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						})
						// #endif
					}
				})

			},
			addBook() {
				if (uni.getStorageSync("token")) {
					const that = this;
					console.log(that.goods_id)
					this.$api.quest('cart/add', {
						id: that.goods_id,
						num: 1,
						uid: uni.getStorageSync("user_id"),
						attr_id: 1,
						rec_type: 0,
						is_checked: 1,
						act_id: 0
					}, (res) => {
						console.log(res, 'res')
						if (res.data.code == 0) {
							uni.showToast({
								title: "加入成功",
								icon: 'none',
								duration: 2000
							});
							uni.setStorageSync('total_number', res.data.data.total_number);
						}
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			//分享
			// share(){
			// 	this.$refs.share.toggleMask();	
			// },
			//收藏
			toFavorite(id) {
				if (uni.getStorageSync("token")) {
					this.$api.quest('user/collect/add', {
						id: id,
						uid: uni.getStorageSync("user_id")
					}, (res) => {
						if (res.data.data == 1) {
							this.is_collect = !this.is_collect;
						}

					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			}
		},
		filters: {
			/**
			 * 处理富文本里的图片宽度自适应
			 * 1.去掉img标签里的style、width、height属性
			 * 2.img标签添加style属性：max-width:100%;height:auto
			 * 3.修改所有style里的width属性为max-width:100%
			 * 4.去掉<br/>标签
			 * @param html
			 * @returns {void|string|*}
			 */
			formatRichText(html) { //控制小程序中图片大小
				let newContent = html.replace(/<img[^>]*>/gi, function(match, capture) {
					match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
					match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
					match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
					return match;
				});
				newContent = newContent.replace(/style="[^"]+"/gi, function(match, capture) {
					match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi, 'max-width:100%;');
					return match;
				});
				newContent = newContent.replace(/<br[^>]*\/>/gi, '');
				newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:10rpx"');
				return newContent;
			}
		}
	}
</script>

<style lang='scss' scoped>
	/* @import '../../static/css/public.scss'; */
	/* @import '../../../static/public.scss'; */
	page {
		padding: 0;
		margin: 0;
	}

	.swiper {
		height: 160rpx;
	}
	.swiper1{
		height: 80rpx;
	}
	.groupInfo {
		

		.groupInfo_item {
			border: 1rpx solid #FF824B;
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 690rpx;
			height: 80rpx;
			/* border: 1rpx solid #FF824B; */
			border-radius: 44rpx;

			/* margin-top: 20rpx; */
			.usercon {
				display: flex;
				flex-direction: column;


				.end {
					color: #666;
					font-size: 28rpx;
				}
			}

			image {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}

			button {
				padding: 0;
				margin: 0;
				line-height: 80rpx;
				font-size: 28rpx;
				width: 150rpx;
				border-radius: 0 44rpx 44rpx 0;
				background: #FF824B;
			}
		}

	}

	.imgla {
		position: relative;
		display: block;
		/* top: 0; */
		/* top: 50%; */
		left: 50%;
		width: 20rpx;
		margin-top: 50rpx;
		transform: translate(-50%, -50%);
	}

	.teaminfo {
		background: #faf9f0;
		box-sizing: border-box;
		padding: 20rpx;

		text {
			color: #666;
			font-size: 26rpx;
			display: block;
			line-height: 30rpx;
			margin-bottom: 10rpx;
		}
	}

	.groupd {
		width: 650rpx;
		display: flex;
		justify-content: space-between;
		margin: 0 auto;

		.confl {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: space-between;
			color: #666;
			font-size: 24rpx;

			.num {

				display: block;
				width: 35rpx;
				height: 35rpx;
				/* line-height: 35rpx; */
				text-align: center;
				/* line-height: 40rpx; */
				border-radius: 50%;
				margin-bottom: 20rpx;
				border: 1rpx solid #666;
				z-index: 999;
				background-color: #ffffff;
			}

		}

	}

	.actEndTime {
		background: rgba(0, 0, 0, .4);
		padding: 20rpx 40rpx;
		color: #fff;
		font-size: 28rpx;
		position: absolute;
		border-radius: 40rpx;
		position: absolute;
		bottom: 20rpx;
		left: 20rpx;
	}

	.container {
		width: 100%;
		display: flex;
		flex-direction: column;
		margin-bottom: 60upx;
	}

	.carousel {
		width: 100%;
		height: auto;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: relative;
	}

	/* 标题简介 */
	.introduce-section {
		background: #fff;
		padding: 30upx 30upx;
		border-bottom: 3rpx solid #e6e6e6;

		position: relative;

		.bttitle {
			font-size: 30rpx;
		}

		.YJ {
			color: gray;
			font-size: 30rpx;

			text {
				text-decoration: line-through;
				margin-left: 10rpx;

			}
		}

		.xian {
			background-color: grey;
			height: 1rpx;
			width: 580rpx;
			position: absolute;
			top: 104rpx;
			left: 85rpx;

		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			height: 60upx;
			line-height: 60upx;
		}

		.infocon {
			.confl {
				.ti {
					background: #FF824B;
					padding: 0 10rpx;
					color: #fff;
					line-height: 34rpx;
					font-size: 26rpx;
					border-radius: 20rpx;
					margin-left: 20rpx;
				}

				.num {
					color: #666;
					line-height: 34rpx;
					font-size: 26rpx;

				}
			}
		}

		.price-box {
			display: flex;
			align-items: baseline;
			height: 64upx;
			padding: 10upx 0;
			font-size: 26upx;
			color: $uni-color-primary;
		}

		.price {
			font-size: 42rpx;
			color: #FF824B;
			margin-top: 20rpx;
		}

		.m-price {
			margin: 0 12upx;
			color: $font-color-light;
			text-decoration: line-through;
		}

		.coupon-tip {
			align-items: center;
			padding: 4upx 10upx;
			background: $uni-color-primary;
			font-size: $font-sm;
			color: #fff;
			border-radius: 6upx;
			line-height: 1;
			transform: translateY(-4upx);
		}

		.bot-row {
			display: flex;
			align-items: center;
			height: 50upx;
			font-size: $font-sm;
			color: $font-color-light;

			text {
				flex: 1;
			}
		}
	}

	/* 分享 */
	.share-section {
		display: flex;
		align-items: center;
		color: $font-color-base;
		background: linear-gradient(left, #fdf5f6, #fbebf6);
		padding: 12upx 30upx;

		.share-icon {
			display: flex;
			align-items: center;
			width: 70upx;
			height: 30upx;
			line-height: 1;
			border: 1px solid $uni-color-primary;
			border-radius: 4upx;
			position: relative;
			overflow: hidden;
			font-size: 22upx;
			color: $uni-color-primary;

			&:after {
				content: '';
				width: 50upx;
				height: 50upx;
				border-radius: 50%;
				left: -20upx;
				top: -12upx;
				position: absolute;
				background: $uni-color-primary;
			}
		}

		.icon-xingxing {
			position: relative;
			z-index: 1;
			font-size: 24upx;
			margin-left: 2upx;
			margin-right: 10upx;
			color: #fff;
			line-height: 1;
		}

		.tit {
			font-size: $font-base;
			margin-left: 10upx;
		}

		.icon-bangzhu1 {
			padding: 10upx;
			font-size: 30upx;
			line-height: 1;
		}

		.share-btn {
			flex: 1;
			text-align: right;
			font-size: $font-sm;
			color: $uni-color-primary;
		}

		.icon-you {
			font-size: $font-sm;
			margin-left: 4upx;
			color: $uni-color-primary;
		}
	}

	.c-list {
		font-size: $font-sm + 2upx;
		color: $font-color-base;
		background: #fff;

		.c-row {
			display: flex;
			align-items: center;
			padding: 20upx 30upx;
			position: relative;
		}

		.tit {
			width: 140upx;
		}

		.con {
			flex: 1;
			color: $font-color-dark;

			.selected-text {
				margin-right: 10upx;
			}
		}

		.bz-list {
			height: 40upx;
			font-size: $font-sm+2upx;
			color: $font-color-dark;

			text {
				display: inline-block;
				margin-right: 30upx;
			}
		}

		.con-list {
			flex: 1;
			display: flex;
			flex-direction: column;
			color: $font-color-dark;
			line-height: 40upx;
		}

		.red {
			color: $uni-color-primary;
		}
	}

	/* 评价 */
	.eva-section {
		display: flex;
		flex-direction: column;
		padding: 20upx 30upx;
		background: #fff;
		margin-top: 16upx;

		.e-header {
			display: flex;
			align-items: center;
			height: 70upx;
			font-size: $font-sm + 2upx;
			color: $font-color-light;

			.tit {
				font-size: $font-base + 2upx;
				color: $font-color-dark;
				margin-right: 4upx;
			}

			.tip {
				flex: 1;
				text-align: right;
			}

			.icon-you {
				margin-left: 10upx;
			}
		}
	}

	.eva-box {
		display: flex;
		padding: 20upx 0;

		.portrait {
			flex-shrink: 0;
			width: 80upx;
			height: 80upx;
			border-radius: 100px;
		}

		.right {
			flex: 1;
			display: flex;
			flex-direction: column;
			font-size: $font-base;
			color: $font-color-base;
			padding-left: 26upx;

			.con {
				font-size: $font-base;
				color: $font-color-dark;
				padding: 20upx 0;
			}

			.bot {
				display: flex;
				justify-content: space-between;
				font-size: $font-sm;
				color: $font-color-light;
			}
		}
	}

	/*  详情 */

	.detail-desc {
		width: 100%;
		background: #fff;

		/* padding: 20upx 30upx; */
		img {
			width: 100%;
		}

		.imgdetail {
			width: 100%;
			text: 22upx;
			font-size: 30upx;
			line-height: 50upx;

		}

		.d-header {
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 80upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			position: relative;

			text {
				padding: 0 20upx;
				background: #fff;
				position: relative;
				z-index: 1;
			}

			&:after {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translateX(-50%);
				width: 300upx;
				height: 0;
				content: '';
				border-bottom: 1px solid #ccc;
			}
		}
	}

	/* 底部操作菜单 */
	.page-bottom {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 95;
		display: flex;
		justify-content: space-around;
		align-items: center;
		width: 100%;
		height: 100upx;
		/* background: rgba(255, 255, 255, .9); */
		box-shadow: 0 0 20upx 0 rgba(0, 0, 0, .5);
		/* border-radius: 16upx; */


		.btnf {
			height: 100upx;
			background: #FF824B;
			width: 100%;
			line-height: 100rpx;
			color: #fff;
			font-size: 32rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			/* flex-direction: column; */

			text {
				font-size: 40rpx;
				line-height: 50rpx;
			}
		}

		.ghui {
			background: #e6e6e6;
			color: #FF824B;
			font-weight: bold;
		}

		.p-b-btn {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: $font-sm;
			color: $font-color-base;
			width: 96upx;
			height: 80upx;

			.yticon {
				font-size: 40upx;
				line-height: 48upx;
				color: $font-color-light;
			}

			&.active,
			&.active .yticon {
				color: $uni-color-primary;
			}

			.icon-fenxiang2 {
				font-size: 42upx;
				transform: translateY(-2upx);
			}

			.icon-shoucang {
				font-size: 46upx;
			}
		}

		.action-btn-group {
			/* display: flex; */
			height: 76upx;
			border-radius: 100px;
			overflow: hidden;
			box-shadow: 0 20upx 40upx -16upx #fd8a54;
			box-shadow: 1px 2px 5px rgba(219, 63, 96, 0.4);
			/* background: linear-gradient(to right, #ffac30, #fd8a54, #F56C6C); */
			margin-left: 20upx;
			position: relative;

			.action-btn {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 95vw;
				height: 100%;
				font-size: $font-base;
				padding: 0;
				border-radius: 0;
				background: #FD2E32;
			}
		}
	}
</style>
