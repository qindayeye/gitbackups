<template>
	<view class="evaluate">
		<view class="evinfotitl">
			<image class="imag" :src="commentList.goods_info.goods_thumb" mode="widthFix"></image>
			<text>{{commentList.goods_info.goods_name}}</text>
		</view>
		<view class="evcon">
			<view class="example">
				<text>评价</text>
				<view class="example-body">
					<uni-rate :value="5" :margin="5" />
				</view>
			</view>
			<view class="textex">
				<textarea placeholder-style="color:#666" maxlength="100" @input="descInput" v-model="desc" placeholder="图书质量如何？精不精彩？快写下你的评价,分享给大家吧!(0-100字)" />
				<text class="jinum">{{100-remnant}}</text>
			</view>
			<view class="imgcon">
				<view class="titleimg">
					图片信息
				</view>
				<view class="imageinfo">
					<view class="imagecon">
						<view class="imacc" v-for="(item,index) in iamgearr">
							<image :src="item.pic" mode="widthFix"></image>
							<text @click.stop="delCommentImg(item.img_id,index)">x</text>
						</view>
						 <!-- <progress :percent="percent" stroke-width="10"></progress> -->
					</view>
					<view class="inpfil" @click="upload" v-if="offimg">
						<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/add.png" mode=""></image>
						<text >上传图片</text>
						<!-- <input type="file" value="" class="file"/> -->
					</view>
				</view>
			</view>
		</view>
		
		<button class="btn" @click="prima()">提交评论</button>
	</view>
</template>

<script>
	import uniRate from '@/components/uni-rate/uni-rate.vue'
	export default{
		data(){
			return {
				commentList:[],
				textval:"",
				remnant:"",
				 percent:0,
				  loading:false,
				  disabled:false,
				  iamgearr:[],
				  desc:"",
				  offimg:true
			}
		},
		onLoad(option) {
			this.$api.quest('user/order/addCommentDetail',{
				rec_id:option.rec
			},(res)=>{ 
				// this.commentList=res.data.data
				
				if(res.data.code==0){
					this.commentList=res.data.data
					this.commentList.img.forEach(item=>{
							this.iamgearr.push(item)
					})
					
				}
				console.log(this.commentList)
			})
		},
		components:{
			uniRate
		},
		watch:{
			iamgearr(newimg){
				console.log(this.imagearr,"111",newimg)
			}
		},
		methods:{
			upload : function(){
			  let  _self = this;
			   uni.chooseImage({
			    count: 1,
			    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album'], //从相册选择
			    success:(res)=> {
			     const tempFilePaths = res.tempFilePaths;
			     const uploadTask = uni.uploadFile({
			      url : 'https://www.abcbook2019.com/mobile/public/api/wx/user/order/addCommentImg',
			      filePath: tempFilePaths[0],
			      name: 'file',
				   header: {
					'Content-Type': 'application/json',
					'X-ECTouch-Authorization':uni.getStorageSync("token")
				   },
			      formData: {
					goods_id:_self.commentList.goods_id,
					order_id:_self.commentList.order_id,
					rec_id:_self.commentList.rec_id
			      },
			      success: (res)=> {
					  let pagess=JSON.parse(res.data)
					  let lastimg=pagess.data.pop()
					  // console.log(,"pop")
					  _self.iamgearr=pagess.data
					  this.iamgearr.push(lastimg)
						if(_self.iamgearr.length>=4){
							this.offimg=false
						}else{
							this.offimg=true
						}
					  }
			     });
			 
			     uploadTask.onProgressUpdate(function (res) {
			      _self.percent = res.progress;
			     });
			    },
			    error : function(e){
			     console.log(e);
			    }
			   });
			  },
			 descInput(e){
				this.remnant = e.detail.value.length
			 },
			 prima(){
				 console.log(this.remnant.goods_id,this.remnant.order_id,this.remnant.rec_id)
				 if(this.desc){
					 this.$api.quest('user/order/addComment',{
					 	goods_id:this.commentList.goods_id,
						order_id:this.commentList.order_id,
						rec_id:this.commentList.rec_id*1,
						content:this.desc,
						impression:"",
						desc_rank:0,
						service_rank:0,
						delivery_rank:0,
						sender_rank:0
					 },(res)=>{ 
					 	console.log(res)
						if(res.data.data==true){
							uni.navigateTo({
								url:'/pages/user/user'
							})
						}
					 })
				 }else{
					 this.$api.msg("评价内容不能为空哦~")
				 }
				 
			 },
			 delCommentImg(id,index){
				 console.log(index)
				 this.$api.quest('user/order/delCommentImg',{
				 	id:id
				 },(res)=>{ 
				 	console.log(res.data)
					
					if(res.data.data==1){
						this.iamgearr.splice(index,1)
					}else{
						this.$api.msg("删除失败")
					}
					console.log(this.iamgearr)
				 })
			 }
		}
	}
</script>

<style lang="scss">
	page {
		display: flex;
		flex-direction: column;
		box-sizing: border-box;
		background-color: #efeff4
	}
	
	view {
		font-size: 28upx;
		line-height: inherit
	}

	.evinfotitl{
		height: 200rpx;
		display: flex;
		box-sizing: border-box;
		padding: 0 20rpx;
		align-items: center;
		background: #fff;
		margin-bottom:20rpx;
		.imag{
			width: 150rpx;
			margin-right: 20rpx;
		}
		text{
			font-size: 28rpx;
			color: #666;
		}
	}
	.imagecon{
		display: flex;
		height: 160rpx;
		align-items: center;
		.imacc{
			position: relative;
			margin-right: 15rpx;
		}
		image{
			width: 120rpx !important;
			height: 120rpx !important;
		}
		text{
			position: absolute;
			top: 0;
			right: 0;
		}
	}
	.evcon{
		box-sizing: border-box;
		background: #fff;
		.example{
			display: flex;
			height: 80rpx;
			align-items: center;
			margin: 0;
			padding-left: 20rpx;
			border-bottom: 1rpx solid #e6e6e6;
		}
		.textex{
			position: relative;
			border-bottom: 1rpx solid #e6e6e6;
			textarea{
				width: 100vw;
				padding: 20rpx;
			}
			.jinum{
				position: absolute;
				bottom: 0;
				right: 20rpx;
				color: #666;
			}
		}
	}
	.imageinfo{
		width: 100vw;
		height: 300rpx;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		.inpfil{
			width: 150rpx;
			height: 150rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			flex-direction: column;
			border-radius: 10px;
			border: 2rpx dashed #e6e6e6;
			image{
				width: 60rpx;
				height: 60rpx;
				margin-bottom: 10rpx;
				opacity: .6;
			}
			text{
				color: #666;
				font-size: 28rpx;
				z-index: 99;
			}
		}
		image{
			width: 100%;
			height: 100%;
		}
	}
	.example-title {
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 32upx;
		color: #464e52;
		padding: 30upx 30upx 30upx 50upx;
		margin-top: 20upx;
		position: relative;
		background-color: #fdfdfd;
		border-bottom: 1px #f5f5f5 solid
	}
	
	.example-title__after {
		position: relative;
		color: #031e3c
	}
	
	.example-title:after {
		content: '';
		position: absolute;
		left: 30upx;
		margin: auto;
		top: 0;
		bottom: 0;
		width: 6upx;
		height: 32upx;
		background-color: #ccc
	}
	.imgcon{
		padding: 20rpx;
	}
	.example .example-title {
		margin: 40upx 0
	}
	
	// .example-body {
	// 	padding: 30upx;
	// 	background: #fff
	// }
	
	.example-info {
		padding: 30upx;
		color: #3b4144;
		background: #fff
	}
	.btn{
		position: fixed;
		width: 90%;
		left: 50%;
		margin-left: -45%;
		bottom: 20rpx;
		color: #fff;
		background:#fd8a54 !important;
	}
</style>
