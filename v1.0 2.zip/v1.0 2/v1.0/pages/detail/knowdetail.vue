<template>
	<view class="container">
		<view class="banner">
			<swiper class="carousel"  :current="cur" :circular="circular" :autoplay="autoplay"
			 :interval="interval" :duration="duration" :vertical="vertical"  @change="bindchange">
				<block v-for="(item,index) in imgs" :key='index'>
					<swiper-item style="width: 100%;">
						<image class="loaded" v-if="list.is_real==0" mode="widthFix" :src="item"></image>
						<image class="loaded" v-else-if="detailA.user_id>0" :style="{height:'80%',width:'80%'}" mode="widthFix" :src="item"
						 @load="imageLoad"></image>
						<image class="loaded" v-else :style="{height:imgheights[cur]+'rpx',width:'370rpx'}" mode="widthFix" :src="item"
						 @load="imageLoad"></image>
					</swiper-item>
				</block>
			</swiper>
			<view class="current">
				{{cur+1}}/{{imgs.length}}
			</view>
		</view>
		<view class="introduce-section">
			<view class="shop"  v-if="detailA.user_id">
				<!-- 价格 -->
				<view class="price">
					<text>{{list.goods_price}}</text><text v-if="list.market_price>0">￥{{list.market_price}}</text>
				</view>
				<!-- 商城标签 -->
				<view class="shoplabel">
					<text class="label1" v-if="list.goods_discount">{{list.goods_discount}}折</text>
					<text class="label2" v-else-if="list.warn_num">{{list.warn_num}}</text>
					<text class="label2" v-else-if="categoryArr[0].cat_name">{{categoryArr[0].cat_name}}</text>
					<!-- <text class="label2">{{categoryArr[0].cat_name}}</text> -->
					<text class="label2" v-if="categoryArr[1]">{{categoryArr[1].cat_name}}</text>
					<!-- <text class="label2" v-for="(item,index) in categoryArr" :key='index'>{{item.cat_name}}</text> -->
				</view>
			</view>			
			<!-- 标题 -->
			<text class="title">{{list.goods_name}}</text>			
			<!-- 书籍标签 -->
			<view class="label" v-if="list.author">
				<text v-for="(item,index) in categoryArr" :key='index'>{{item.cat_name}}</text>
			</view>
			<!-- 商品简介 -->
			<text class="brief">{{list.goods_brief}}</text>
			<view class="information" >
				<view class="tt" v-if="list.author"><text>作  者：</text><text>{{list.author}}</text></view>
				<view class="tt" v-if="list.publisher"><text>出版社：</text><text>{{list.publisher}}</text></view>
			</view>
		</view>
	<!-- 	<view class="detail-desc">
			<view class="d-header">
				<text>图文详情</text> 
			</view>
			<rich-text :nodes="desc|formatRichText " class="imgdetail"></rich-text>
		</view> -->
		<view class="knowdetail-desc">
			<!-- 导航 -->
			<view class="nav" :class="{ navTop: navTop === true }">
				<text :class="{ active: isShowcatalog === 1 }" @click="selectCatalog(1)">详情</text>
				<text :class="{ active: isShowcatalog === 2 }" @click="selectCatalog(2)">目录</text>
			</view>
			<view class="imgtextdetail">
				<rich-text v-if="isShowcatalog === 1"  :nodes="desc|formatRichText " class="imgdetail"></rich-text>
			</view>		
			<view v-if="isShowcatalog === 2" class="catalog">
				<view class="knowledgelsit" v-for="(item,index) in knowcatalog" :key='index'>
					<view class="list_item" @click="gotoKnw">
						<view v-if="item.video_url" class="list_item_category">
							视频
						</view>
						<view v-if="item.audio_url" class="list_item_category">
							音频
						</view>
						<view :class="[item.goods_name.length>25?'list_item_title2':'list_item_title1']">
								{{item.goods_name}}					
						</view>
						<!-- 没权限听 -->
						<image  v-if="index>2" src='http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/notplay.png' mode=""></image>				
						<image v-else @click.stop="PlayIt(index)" :src="isplay==index&&isVideo?'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/knowpused.png':'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/knowplay.png'" mode=""></image>
					</view>
				</view>
				<view class="catalog_bottom">已经是全部课程</view>
			</view>
		</view>
		<!-- 补白 -->
		<view class="filler"></view>
		<!-- <uni-evaluate :list-data="listev" :rate="reted"/> -->
		<!-- 底部操作菜单 -->
		<view class="page-bottom" :class="{isIphoneX:isIphoneX}" v-if="detailA.user_id">
			<!-- #ifdef MP -->
			<button class="p-b-btn" open-type="contact">
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="p-b-btn" @click="CoKF()">	
				<!-- #endif -->
					<image src="https://www.abcbook2019.com/mobile/public/img/service.png" mode=""></image>
					<text>联系客服</text>
				</button>				
				<view class="action-group">
					<!-- 买商品 -->
					<button v-if="detailA.user_id" type="primary" class=" action-btn no-border add-cart-btn"
					 @click.stop="shopgoods(list.goods_id,detailA.user_id)">立即购买</button>
					<!-- 买卡 -->
					<button v-else-if="list.is_real==0" type="primary" class="action-btn no-border add-cart-btn" @click.stop="paycheckout(list.goods_id)">立即购买</button>
					<!-- 买书 -->
					<button v-else type="primary" class="hbtn" :class="addbtn=='加入书架'?'action-btn no-border add-cart-btn':'hbtn'"
					 @click='addBook()'>{{addbtn}}</button>
				</view>
		</view>
		<!-- 底部操作菜单 -->
		<view class="page-bottom" :class="{isIphoneX:isIphoneX}" v-else>
			   <!-- #ifdef MP -->
			   <button class="p-b-btn" open-type="contact">
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="p-b-btn" @click="CoKF()">		
				<!-- #endif -->
					<image src="https://www.abcbook2019.com/mobile/public/img/service.png" mode=""></image>
					<text>联系客服</text>
				</button>				
				<view class="p-b-btn" @click="toFavorite(list.goods_id)">
					<image :src="is_collect?'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/collect-j.png':'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/collect-h2.png'" mode=""></image>
					<text>收藏</text>
				</view>
				<view class="action-btn-group" >
					<!-- 买商品 -->
					<button v-if="detailA.user_id" type="primary" class=" action-btn no-border add-cart-btn"
					 @click.stop="shopgoods(list.goods_id,detailA.user_id)">立即购买</button>
					<!-- 买卡 -->
					<button v-else-if="list.is_real==0" type="primary" class=" action-btn no-border add-cart-btn" @click.stop="paycheckout(list.goods_id)">立即购买</button>
					<!-- 买书 -->
					<button v-else type="primary" class="hbtn" :class="addbtn=='加入书架'?'action-btn no-border add-cart-btn':'hbtn'"
					 @click='addBook()'>{{addbtn}}</button>
				</view>			
		</view>
		<view class="Kft" v-if='kFW'>
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<image class="ewm" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/kefu.png" mode=""></image>
		</view>
		<view class="knowOrder">
			<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/shoplist.png"></image>
		</view>
	</view>
</template>

<script>
	let bgAudioMannager = ''
	import Vue from 'vue'
	import share from '@/components/share';
	import uniEvaluate from '@/components/xiujun-evaluate/uni-evaluate.vue';
	export default {
		components: {
			share,
			uniEvaluate
			
		},
		data() {
			return {
				kFW: false,
				list: {},
				hotmain: [],
				imgs: [],
				detailA: [],
				is_collect: false,
				desc: ``,
				goods_id: 0,
				addbtn: '加入书架',
				cur: 0, //当前所在滑块的index
				page: 1,
				hide: true,
				classoninfo: "", //加载展示内容
				hasno: false, //判断有没有消息
				success: false,
				//所有图片的高度  
				imgheights: ['0'],
				categoryArr:[],
				//图片宽度 
				imgwidth: 750,
				isIphoneX:false,
				indicatorDots: true, //是否显示指示点
				interval: 5000, //自动切换时间间隔
				duration: 400, //滑动动画时长
				autoplay: true, //是否自动切换
				circular: true, //是否采用衔接滑动
				classon: false, //判断模态框
				vertical: false,
				isShowcatalog:1,
				isplay:-1, // 当前播放的index
				isVideo:false, // 当前有播放中的音频
				knowcatalog:[
					{video_url:'https://ktoss.oss-cn-beijing.aliyuncs.com/sound/2.mp4',
					goods_name:"Sheep in a Shop  小羊在商店 英文原版",
					goods_thumb:"http://public.abcbook2019.com/upload/20190612/19000140.jpg"
					},
					{audio_url:'https://ktoss.oss-cn-beijing.aliyuncs.com/sound/54.mp3',
					goods_name:"Henny Penny 母鸡潘妮 英文原版",	
					goods_thumb:"http://public.abcbook2019.com/upload/20190612/19021667.jpg"
					},
					{video_url:'https://ktoss.oss-cn-beijing.aliyuncs.com/sound/74.mp4',
					goods_name:"Does a Kangaroo Have a Mother， Too?袋鼠也有妈妈吗？ 英文原版",
					goods_thumb:"http://public.abcbook2019.com/upload/20190612/19009019.jpg"
					},
					{audio_url:'https://ktoss.oss-cn-beijing.aliyuncs.com/sound/8.mp3',
					goods_name:"The Very Hungry Caterpillar's Buggy Book  好饿的毛毛虫 英文原版",
					goods_thumb:"http://public.abcbook2019.com/upload/20190612/19028469.jpg"
					},
					{audio_url:'https://ktoss.oss-cn-beijing.aliyuncs.com/sound/8.mp3',
					goods_name:"Silly Sally Board Book 倒着走的女孩 英文原版",		
					goods_thumb: "http://public.abcbook2019.com/upload/20190612/19021588.jpg"
					}
				],
				navTop:false,
				// #ifdef H5
				topnum :385,
				// #endif
				// #ifdef MP
				topnum:410
				// #endif
			};
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			// console.log(Object.scrollTop)
			if (Object.scrollTop > this.topnum) {
				this.navTop = true;
			} else {
				this.navTop = false;
			}
		},
		// 分享
		onShareAppMessage(res) {
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
			}
			return {
				title: 'ABCbook国际亲子阅读',
				path: '/pages/detail/detail?id=' + id
			}
		},
		async onLoad(option) {
			console.log(this.knowcatalog[1].goods_name.length)
			// console.log(option.id,'opt')
			var that = this;
			var id = option.id;
			this.$api.quest('goods/detail', {
				id: id
			}, (res) => {
				that.list = res.data.data.goods_info
				that.imgs = res.data.data.goods_img
				that.detailA = res.data.data.detail ? res.data.data.detail : [],
				that.categoryArr=that.list.category
				// console.log(that.categoryArr)
				// that.sellershopinfo=res.data.data.detail.sellershopinfo
				// console.log(that.imgs)
				that.goods_id = that.list.goods_id
				that.is_collect = that.list.is_collect ? true : false
				that.addbtn = that.list.cat_status == 1 ? '已加入书架' : that.list.goods_number == 0 ? '暂无库存' : '加入书架'
				// console.log(that.addbtn)
				if (that.list.goods_desc.indexOf('style="float:none;"') > 0) {
					var str = that.list.goods_desc.replace('style="float:none;"', '')
					var reg = new RegExp('style="float:none;"', "gi");
					var a = str.replace(reg, "");
					// console.log(a, 'desc')
					that.desc = a.replace(/(<br\s*\/?>)+/gi, "<br>")
					that.desc = that.desc.replace(/(<h3\s*\/?>)+/gi, "<h3 style='display:none'>")
					that.desc = that.desc.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				} else {
					that.desc = that.list.goods_desc.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				}
				// console.log(that.list,that.desc,res.data.data.root_path)
			})
		},
		onShow() {
			uni.getSystemInfo({
				success: res=>{
					console.log(res)
					let modelmes = res.model;
						if (modelmes.search('iPhone X') != -1) {
							// console.log('1111')
						this.isIphoneX = true
						}
					}
			})
		},
		methods: {
				PlayIt(index){
					if(this.knowcatalog[index].video_url){	// 如果视频存在
					   if(bgAudioMannager){// 如果有音频正在播放
							console.log('结束了')
							bgAudioMannager .stop()
							bgAudioMannager =''
							this.isplay = -1
						}
						uni.navigateTo({
								url:'../voice/knowledgeVideo?video_url='+this.knowcatalog[index].video_url
						})			
					}else{ //当前要播放的是音频
						if(index==this.isplay){ // 如果点击的是正在播放的
							if(this.isVideo){// 播放中
								bgAudioMannager.pause()
								this.isVideo=false
							}else{ // 暂停中
								bgAudioMannager.play()
								this.isVideo=true
							}
							
						}else{ //当前没有音频正在播放
							bgAudioMannager = uni.getBackgroundAudioManager();
							bgAudioMannager.title = this.knowcatalog[index].goods_name;
							bgAudioMannager.singer = '二大爷';
							bgAudioMannager.coverImgUrl = this.knowcatalog[index].goods_thumb;
							bgAudioMannager.src = this.knowcatalog[index].audio_url;
							this.isplay  = index
							this.isVideo = true
							// bgAudioMannager.play()
							bgAudioMannager.onEnded(()=>{
								console.log('结束了')
								bgAudioMannager .stop()
								bgAudioMannager =''
								this.isplay = -1
								this.isVideo = false
								
							})
						}
						
					}				
				},
			PlayAudio(){// 播放音频的方法
				bgAudioMannager = uni.getBackgroundAudioManager();
				bgAudioMannager.title = this.knowcatalog[index].goods_name;
				bgAudioMannager.singer = '二大爷';
				bgAudioMannager.coverImgUrl = this.knowcatalog[index].goods_thumb;
				bgAudioMannager.src = this.knowcatalog[index].src;
				// bgAudioMannager.play()
				bgAudioMannager.onEnded(()=>{
					console.log('结束了')
					if(index <this.knowcatalog.length-1){
						this.PlayIt(index+1)				
					}else{
						this.PlayIt(0)	
					}
				})
				bgAudioMannager.onNext(()=>{
					console.log('下一曲')
					if(index <this.knowcatalog.length-1){
						this.PlayIt(index+1)				
					}else{
						this.PlayIt(0)	
					}
				})
			},
			gotoKnw(){
				console.log('nidaddd')
				// uni.navigateTo({
				// 	url:'../voice/knowledgeVideo'
				// })
			},
			selectCatalog(index){
				this.isShowcatalog = index
			},
			CoKF() {
				// console.log('客服开')
				this.kFW = true
			},
			close() {
				// console.log('客服开')
				this.kFW = false
			},
			imageLoad(e) {
				var imgwidth = e.detail.width,
					imgheight = e.detail.height,
					//宽高比  
					ratio = imgwidth / imgheight;
				// console.log(imgwidth, imgheight)
				//计算的高度值  
				var viewHeight = 476 / ratio;
				var imgheight = viewHeight;
				var imgheights = this.imgheights;
				//把每一张图片的对应的高度记录到数组里  
				this.imgheights[this.cur] = imgheight
			},
			bindchange(e) {
				this.cur=e.detail.current
			},
			gohome() {
				this.$store.commit("change_page", 0)
				uni.reLaunch({
					url: `/pages/index/index`
				})
			},
			bookshelf() {
				uni.reLaunch({
					url: `/pages/bookrack/bookrack`
				})
			},
			// 买商品
			shopgoods(goodsid, ruid) {
				this.$api.quest('user/address/list', {}, (res) => {
					// console.log(res, "res")
					this.$api.quest('cart/addshopgoods', {
						id: goodsid,
						num: 1,
						ru_id: ruid,
						rec_type: 10,
						is_checked: 1,
						act_id: 0
					}, (res) => {
						uni.setStorageSync('goid', goodsid);
						uni.setStorageSync('ruid', ruid);
						// console.log(res,'res')
						if (res.data.code == 0) {
							uni.navigateTo({
								url: '/pages/flow/shopgoods?goid=' + goodsid + '&ruid=' + ruid
							})
						} else if (res.data.data.error) {
							this.$store.commit("change_page", 4)
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}
					})
				})

			},
			// 买卡
			paycheckout(id) {
				let goid = id
				this.$api.quest('user/address/list', {}, (res) => {
					// console.log(res, "res")
					this.$api.quest('cart/addmember', {
						id: id,
						num: 1,
						uid: uni.getStorageSync("user_id"),
						attr_id: 1,
						act_id: 30,
						rec_type: 10,
						flow_type: 10,
						extension_code: "virtual_card",
						is_checked: 1
					}, (res) => {
						if (res.data.code == 0) {
							uni.navigateTo({
								url: '/pages/flow/member?goid=' + goid
							})
						} else if (res.data.data.error) {
							this.$store.commit("change_page", 4)
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}
					})
				})
			},
			addBook() {
				this.$api.quest('cart/add', {
					id: this.goods_id,
					num: 1,
					uid: uni.getStorageSync("user_id"),
					attr_id: 1,
					rec_type: 0,
					is_checked: 1,
					act_id: 0
				}, (res) => {
					if (res.data.data.error == 1) {
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif
						
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						})
						// #endif
					} else {
						if (res.data.code == 0) {
							// uni.showToast({
							// 	title:'加入成功',
							// 	icon: 'none',
							// 	duration: 2000
							// });
							this.addbtn = res.data.data.cat_status == 1 ? '已加入书架' : res.data.data.real_number == 0 ? '暂无库存' : '加入书架'
							console.log(this.addbtn)
							uni.setStorageSync('total_number', res.data.data.total_number);
						} else {
							this.$api.msg(res.data.data)
						}
					}
				})

			},
			//分享
			// share(){
			// 	this.$refs.share.toggleMask();	
			// },
			//收藏
			toFavorite(id) {
				if (uni.getStorageSync("token")) {
					this.$api.quest('user/collect/add', {
						id: id,
						uid: uni.getStorageSync("user_id")
					}, (res) => {
						if (res.data.data == 1) {
							this.is_collect = !this.is_collect;
						}

					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},

		},
		filters: {
			/**
			 * 处理富文本里的图片宽度自适应
			 * 1.去掉img标签里的style、width、height属性
			 * 2.img标签添加style属性：max-width:100%;height:auto
			 * 3.修改所有style里的width属性为max-width:100%
			 * 4.去掉<br/>标签
			 * @param html
			 * @returns {void|string|*}
			 */
			formatRichText(html) { //控制小程序中图片大小
				let newContent = html.replace(/<img[^>]*>/gi, function(match, capture) {
					match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
					match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
					match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
					return match;
				});
				newContent = newContent.replace(/style="[^"]+"/gi, function(match, capture) {
					match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi, 'max-width:100%;');
					return match;
				});
				newContent = newContent.replace(/<br[^>]*\/>/gi, '');
				newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:10rpx"');
				return newContent;
			}
		}


	}
</script>

<style lang='scss' scoped>
	/* @import '../../static/css/public.scss'; */
	/* @import '../../../static/public.scss'; */
	/* 灰色按钮 */
	css {
		position: relative;
	}
	.banner{
		position: relative;
	}
	.current{
		position: absolute;
		right: 20rpx;
		bottom: 20rpx;
		width:94rpx;
		/* height:42rpx; */
		background:rgba(0,0,0,0.25);
		border-radius:30rpx;
		font-size: 30rpx;
		color: #fff;
		line-height: 50rpx;
		text-align: center;
	}
	.isIphoneX{
		height: 118rpx !important;
		padding-bottom: 25rpx;
	}

	.hbtn {
		width: 329rpx;
		line-height: 98rpx;
		border-radius: 0;
		background: #e6e6e6;
		color: #fff;
	}
	.container {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		margin-bottom: -110upx;
		.filler{
			height: 100rpx;
			width: 100%;
			background-color: #FFFFFF;		
		}
	}
	.carousel {
		position: relative;
		width: 100%;
		height: 476rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		background: #fff;

		image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: block;
			width: 750rpx;
			margin: 0 auto;
		}
	}

	/* 标题简介 */
	.introduce-section {
		background: #fff;
		padding: 30upx 30upx;
		box-shadow: 0rpx -2rpx 8rpx 0rpx rgba(0, 0, 0, 0.1);
		margin-bottom: 20rpx;
		.shop{
			display: flex;
			align-items: center;
			/* 价格 */
			.price{
				margin-bottom: 14rpx;
				>text:first-child{
					color: #E02020;
					font-size: 46rpx;
					font-weight: 600;
					&::before{
						display: inline-block;
						content: '￥';
						color: #E02020;
						font-size: 32rpx;
					}
				}
				>text:nth-child(2){
					color: #999;
					font-size: 28rpx;
					margin-left: 20rpx;
					text-decoration: line-through;
				}
			}
			/* 商城标签 */
			.shoplabel{
				margin-left: 20rpx;
				>text{
					display: inline-block;
					font-size: 22upx;
					padding:5rpx 15rpx;
					border-radius: 22rpx;
				}
				.label1 {
					background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
					color: #fff;
				}
				
				.label2 {
					background:rgba(255,230,220,1);
					color: #FF824B;
					margin-left: 10rpx;
				}
			}
			
		}
		
		/* 标题 */
		.title {
			font-size: 30upx;
			color: $font-color-dark;
			/* line-height: 30upx; */
			width: 690rpx;
			display: block;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
			color: #333;
			font-weight: bold;

		}
		/* 标签 */
		.label{
			margin-top: 10rpx;
			text{
				display: inline-block;
				background::rgba(255,130,75,0.2);
				color:#FF824B;
				font-size: 24rpx;
				padding: 0 15rpx;
				line-height: 40rpx;
				margin-right: 10rpx;
				margin-bottom: 10rpx;
				border-radius:4rpx;
				&:first-child{
					
					background:rgba(255,205,120,0.2);
					color:#FFA24B;
				}
			}
			
		}
		/* 作者,出版社 */
		.information{
			line-height: 40rpx;
			color: #666;
			font-size: 26rpx;
			margin-top: 20rpx;
			/* font-weight: 900; */
			.tt{
				text:first-child{
					word-spacing: 19rpx;
					font-size: 28rpx;
				}
				
			}
			text{
				font-weight: normal;
			}
		}
		.brief {
			width: 690rpx;
			font-size: 24rpx;
			color: #999;
			line-height: 36rpx;
			margin-top: 10rpx;
			display: -webkit-box;
			overflow: hidden;
			-webkit-box-orient: vertical;
			text-overflow: ellipsis;
			-webkit-line-clamp: 2;
		}

		.price {
			font-size: $font-lg + 2upx;
		}
	}

	/*  详情 */

	.detail-desc {
		width: 100%;
		background: #fff;
		padding: 20upx 30upx;

		img {
			width: 100%;
		}

		.imgdetail {
			width: 100%;
			text: 22upx;
			font-size: 30upx;
			line-height: 50upx;
			text-align: justify;
			color: #666;
			text-indent: 62rpx;
		}

		.d-header {
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 80upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			position: relative;

			text {
				padding: 0 20upx;
				background: #fff;
				position: relative;
				z-index: 1;
			}

			&:after {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translateX(-50%);
				width: 300upx;
				height: 0;
				content: '';
				border-bottom: 1px solid #ccc;
			}
		}
	}
.knowdetail-desc{
	width: 100%;
	background: #fff;
	.navTop {
		z-index: 9998;
		position: fixed;
		top: 0;
		left: 0;
		border-top: 1rpx solid #999999;
	}
	.imgtextdetail{
		margin-left: 20rpx;
		margin-right: 20rpx;
		.imgdetail {		
			width: 100%;
			text: 22upx;
			font-size: 30upx;
			line-height: 50upx;
			text-align: justify;
			color: #666;
			text-indent: 62rpx;
		}
	}
	
	.nav {
		display: flex;
		align-items: center;
		white-space: nowrap;
		justify-content: space-around;
		line-height: 36rpx;
		overflow-x: scroll;
		-webkit-overflow-scrolling: touch;
		white-space: nowrap;
		width: 750rpx;
		height: 88rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.06), 0px -1px 0px 0px rgba(230, 230, 230, 1);
	
		text {
			position: relative;
			display: inline-block;
			// margin-left: 50rpx;
			color: #666;
			font-size: 30rpx;
			line-height: 50rpx;
		}
	
		.active {
			color: #ff824b;
			position: relative;
			font-size: 36rpx;
			font-weight: bold;
		}
	
		.active::before {
			display: block;
			content: '';
			position: absolute;
			width: 26rpx;
			height: 8rpx;
			bottom: -12rpx;
			left: 50%;
			transform: translate(-50%, 0%);
			background: #ff824b;
			border-radius: 4rpx;
		}
	}
	
	.nav::-webkit-scrollbar {
		display: none;
	}
	
	.catalog{
		.list_item{
			width: 100%;
			height: 130rpx;
			/* border-top: #C0C0C0 solid 1rpx; */
			border-bottom: rgba(230,230,230,1) solid 1rpx;
			display: flex;
			justify-content: space-around;
			align-items: center;
			.list_item_category{
				width: 70rpx;
				height:32rpx;
				font-size :22rpx;
				font-family :PingFangSC-Regular,PingFang SC;
				font-weight: 400;
				color: rgba(153,153,153,1);
				text-align :center;
				line-height :32rpx;
				border: #8F8F94 1rpx solid;
			}
			.list_item_title1{
				width: 494rpx;
				height: 80rpx;
				font-size :30rpx;
				font-family: PingFangSC-Medium,PingFang SC;
				font-weight: 900;
				color: #333333;
				line-height :80rpx ;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
			}
			.list_item_title2{
				width: 494rpx;
				height: 80rpx;
				font-size :30rpx;
				font-family: PingFangSC-Medium,PingFang SC;
				font-weight: 900;
				color: #333333;
				line-height :40rpx ;
				overflow: hidden;
				display: -webkit-box;
				-webkit-box-orient: vertical;
				text-overflow: ellipsis;
				-webkit-line-clamp: 2;
			}
			
			image{
				width :56rpx;
				height: 56rpx;
			}
		}
		.catalog_bottom{
			width:100%rpx;
			height:70rpx;
			font-size:24rpx;
			font-family:PingFangSC-Regular,PingFang SC;
			font-weight:400;
			color:rgba(153,153,153,1);
			line-height:70rpx;
			text-align:center;
		}
	}
}



	/* 底部操作菜单 */
	.page-bottom {
		position: fixed;
		left: 0;
		bottom: 0upx;
		z-index: 95;
		display: flex;
		justify-content: space-around;
		align-items: center;
		width: 750upx;
		height: 99upx;
		background: #FFFFFF;
		box-shadow: 0 0 20upx 0 rgba(0, 0, 0, .3);
		/* border-radius: 16upx; */

		.service {
			height: 100upx;
			/* width: 96upx; */
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			background:#FFFFFF;
			margin-top: 15rpx;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-bottom: -5rpx;
			}

			text {
				font-size: 22rpx;
				font-family: PingFangSC-Light, PingFang SC;
				font-weight: 300;
				color: #FEA364;
			}
		}

		.p-b-btn {
			background: #FFFFFF;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: $font-sm;
			color: $font-color-base;
			width: 180upx;
			height: 80upx;
			margin-right: auto;
			line-height: normal;

			image {
				width: 38rpx;
				height: 38rpx;
			}

			.yticon {
				font-size: 40upx;
				line-height: 40upx;
				color: $font-color-light;
			}

			&.active,
			&.active .yticon {
				color: $uni-color-primary;
			}
		}

		.action-btn-group {
			width: 329rpx;
			height: 98rpx;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);

			.action-btn {
				width: 329rpx;
				line-height: 98rpx;
				color: #fff;
				font-size: 30rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			}
		}

		.action-group {
			width: 427rpx;
			height: 74rpx;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			border-radius: 49rpx;
			margin-right: 20rpx;

			.action-btn {
				width: 427rpx;
				line-height: 74rpx;
				color: #fff;
				font-size: 30rpx;
				border-radius: 49rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			}
		}
	}

	.Kft {
		position: fixed;
		top: 0;
		left: 0;
		height: 100%;
		width: 100%;
		z-index: 998;
		background: rgba(0, 0, 0, 0.6);

		.ewm {
			height: 855rpx;
			width: 670rpx;
			position: fixed;
			top: 360rpx;
			right: 40rpx;
		}

		.close {
			width: 58rpx;
			height: 58rpx;
			position: fixed;
			top: 279rpx;
			right: 20rpx;
		}
	}
	.knowOrder{
		z-index: 99;
		height: 84rpx;
		width: 84rpx;
		border-radius: 50%;
		background: #fff;
		box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.3);
		border: 2rpx solid rgba(255, 205, 120, 1);
		position: fixed;
		bottom: 344rpx;
		right: 14rpx;		
		image {
			height: 50rpx;
			width: 47rpx;
			position: absolute;
			top: 12rpx;
			left: 18.5rpx;
		}
	}
</style>
