<template>
	<view class="container">
		<view class="banner">
			<swiper class="carousel" :style="{height:'750rpx'}" :current="cur" :circular="circular" :autoplay="autoplay"
			 :interval="interval" :duration="duration" :vertical="vertical"  @change="bindchange">
				 <block v-if="list.goods_video">
				 	<swiper-item class="viedoF" style="width: 100%;"  >
				 		<video class="theviedo" :src="list.goods_video"></video>
				 	</swiper-item>
				 </block>
				 <block v-if="imgs.length==0">
					<swiper-item style="width: 100%;"  >
						<image class="loaded" :src="goods_thumb" mode="aspectFit"></image>
					</swiper-item>
				 </block>
				<block v-for="(item,index) in imgs" :key='index' v-else>
					<swiper-item style="width: 100%;" >
						<!-- <image class="loaded" v-if="list.is_real==0" mode="widthFix" :src="item"></image>
						<image class="loaded" v-else-if="detailA.user_id>0" :style="{height:'80%',width:'80%'}" mode="widthFix" :src="item"
						 @load="imageLoad"></image> -->
						<image class="loaded" :style="{height:'750rpx'}"  mode="widthFix" :src="item"
						 @load="imageLoad"></image>
					</swiper-item>
				</block>
				
			</swiper>
			<view class="current">
				{{cur+1}}/{{getcur}}
			</view>
		</view>
		

		<view class="introduce-section">
			<view class="shop"  v-if="detailA.goods_price">
				<!-- 价格 -->
				<view class="price">
					<text>{{list.goods_price}}</text><text v-if="list.market_price>0">￥{{list.market_price}}</text>
				</view>
				<!-- 商城标签 -->
				<view class="shoplabel">					
					<text class="label1" v-if="list.goods_discount">{{list.goods_discount}}折</text>
					<text class="label2" v-else-if="list.warn_num">{{list.warn_num}}</text>
					<text class="label2" v-else-if="categoryArr[0]">{{categoryArr[0].cat_name}}</text>
					<!-- <text class="label2">{{categoryArr[0].cat_name}}</text> -->
					<text class="label2" v-if="categoryArr[1]">{{categoryArr[1].cat_name}}</text>
					<!-- <text class="label2" v-for="(item,index) in categoryArr" :key='index'>{{item.cat_name}}</text> -->
				</view>
			</view>
			
			<!-- 标题 -->
			<view class="clear tit">
				<text  class="title fl"  style="width: 620rpx;">
					<text class="tag"  v-if="list.goods_lx=='JD'">京东</text>
					<text class="tag"  v-else>自营</text>
					<text>{{list.goods_name}}</text>
				</text>
				<button class="yticon icon-fenxiang2 fr" style="width: 50rpx;overflow: visible;background: #FFFFFF;" :class="{active: is_collect}" open-type="share"></button>
			</view>
			<view class="shuliang">
				<view class="sales">
					销量：{{list.sales}}
				</view>
				<view class="stock">
					库存：{{list.stock}}
				</view>
			</view>
			
		</view>
		
		<!-- 促销：下单立减 -->
		<view class="addnum" v-if="list.creduce > 0">
			<view class="younum">
				<view class="younum-Z clear">
					<text class="fl">优惠</text>
					<image class="yhq fl" src="http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/yhq.png" mode="widthFix"></image>
					
				</view>
				<view class="fr">
					<text class="lq">下单立减 {{list.creduce}}元</text>
				</view>
			</view>
		</view>
		
			<view class="addnum" v-if="detArr.coupont.length!==0">
				<view class="younum">
					<view class="younum-Z clear">
						<text class="fl">领券</text>
						<image class="yhq fl" src="http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/yhq.png" mode="widthFix"></image>
						
					</view>
					<view class="fr">
						<text class="lq"> 领取优惠券</text>
						<image
							@click="showquan()"
							class="younum-Y"
							:src="[quanShow == true ? 'http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/shang.png' : 'http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/xiala.png']"
							mode=""
						></image>
					</view>
				</view>
				
			</view>
			<view class="Lquan" v-if="quanShow">
				<view class="LqItem" v-for="(item,index) in coupont" :key="index">    
				      <view class="lqz">
				      	<view class="lqzTop">
				      		<view class="lqzz">
				      			{{item.pick}}
				      		</view>
							<view class="lqzY">
				      			<view class="lqzYtop">
				      				{{item.cou_name}}
				      			</view>
								<view class="lqzYbottom">
				      				{{item.cou_title}}
				      			</view>
				      		</view>
				      	</view>
						<view class="lqzbottom">
				      		{{item.cou_start_time}}至{{item.cou_end_time}}
				      	</view>
				      </view>   
				     <view class="max-right tb-lr-center active" data-index="" v-if="item.pick==2">已领取券</view>
				     <view @click="printCoupont" class="ljLIngqu" data-index="" v-else>立即领取</view>   
				</view>
			</view>
			<view class="addnum">
				<view class="younum">
					<view class="younum-Z">已选{{ num }}个</view>
					<image
						@click="showNum()"
						class="younum-Y"
						:src="[numShow == true ? 'http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/shang.png' : 'http://ktoss.oss-cn-beijing.aliyuncs.com/jdcs/xiala.png']"
						mode=""
					></image>
				</view>
				<view class="jiajian" v-if="numShow">
					数量
					<view @click="setNum(1)" :class="[num>1?'cate_title':'bgHS']" style="margin-left: 30rpx;border-bottom-left-radius: 10rpx;border-top-left-radius: 10rpx;">-</view>
					<input type="number" @input="setNumY" style="width: 100rpx; margin-left: -3rpx" class="cate_title" :value="num"></input>
					<view @click="setNum(2)" class="cate_title" style="margin-left: -1rpx;  border-bottom-right-radius: 10rpx;border-top-right-radius: 10rpx;">+</view>
				</view>
			</view>
			<view class="addnum" v-if="detArr.detail!=undefined">
				<view class="younum">
					<view class="younum-Z">评价</view>
					<view class="younum-Z">共0条评价</view>		
				</view>
				<view class="pl">		
					<view class="pl-Z">共0条评价</view>
					<view class="pl-Z">查看更多</view>		
				</view>
			</view>
		<view class="youlike">
			<view class="liketitle">
				猜你喜欢
			</view>
			<scroll-view scroll-x="true" class="likelist scroll-view_H">
				<view class="scroll-view-item_H" v-for="(item,index) in likelist" :key='index' @click="gotodetail(item.goods_id)">
					<view class="likeitem">
						<image :src="item.goods_img" mode=""></image>
						<view class="likename">
							{{item.goods_name}}
						</view>
						<view class="jiaqian">
							￥{{item.cfull}}
						</view>
					</view>
					
				</view>
			</scroll-view>
		</view>
			<!-- 导航 -->
			<view class="nav" :class="{ navTop: navTop === true }">
				<text :class="{ active: isShowcatalog === 1 }" @click="selectCatalog(1)">商品描述</text>
				<text :class="{ active: isShowcatalog === 2 }" @click="selectCatalog(2)">规格参数</text>
			</view>
		<view class="detail-desc" v-if="isShowcatalog === 1">
			<rich-text :nodes="desc|formatRichText " class="imgdetail"></rich-text>
		</view>
		<view v-if="isShowcatalog === 2" class="catalog">
			<image src="../../static/no_content.png" mode="widthFix"></image>
			<view class="catalogtext">
				亲，此处暂无规格参数
			</view>
		</view>
		<!-- <uni-evaluate :list-data="listev" :rate="reted"/> -->
		
		<!-- 底部操作菜单 -->
		<view class="page-bottom" v-if="list.stock==0">
			<view class="bottomKc">
				库存不足
			</view>
			
		</view>
		<view class="page-bottom" v-else>
		  <view @click='gohome' open-type="switchTab" class="p-b-btn">
		   <text class="yticon icon-xiatubiao--copy"></text>
		   <text>首页</text>
		  </view>
		  <view @click='bookshelf' open-type="switchTab" class="p-b-btn">
			   <text class="yticon icon-gouwuche"></text>
			   <text>购物车</text>
			   <text class="goodnum">{{goosnum}}</text>
		  </view>
		 <!-- <view class="p-b-btn" :class="{active: is_collect}" @click="toFavorite(list.goods_id)">
		   <text class="yticon icon-shoucang" :class="{active: is_collect}" @click="toFavorite(list.goods_id)"></text>
		   <text>收藏</text>
		  </view> -->
		  
		  <view class="action-btn-group">
		   <!-- 买商品 -->
		   <!-- <button type="primary" class=" action-btn no-border add-cart-btn" @click.stop="shopgoods(list.goods_id,detailA.user_id)">立即购买</button> -->
		   <!-- 买卡 -->
		   <button type="primary" class=" action-btn no-border add-cart-btn" @click.stop="paycheckout(list.goods_id)">立即购买</button>
		   <!-- 买书 -->
		   <button  type="primary" class=" action-btn no-border add-cart-btn" @click='addBook()'>加入购物车</button>
		  </view>
		 </view>
		<view class="Kft" v-if='kFW'>
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<image class="ewm" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/kefu.png" mode=""></image>
		</view>
	</view>
</template>

<script>
	import share from '@/components/share';
	import uniEvaluate from '@/components/xiujun-evaluate/uni-evaluate.vue';
	export default {
		components: {
			share,
			uniEvaluate
		},
		data() {
			return {
				kFW: false,
				list: {},
				coupont:[],
				hotmain: [],
				id:'',
				imgs: [],
				detailA: [],
				is_collect: false,
				num: 1,
				numShow: true,
				quanShow:false,
				goods_thumb:"",
				goosnum:'',    //书架有多少本书
				desc: ``,
				goods_id: 0,
				addbtn: '加入书架',
				cur: 0, //当前所在滑块的index
				page: 1,
				hide: true,
				classoninfo: "", //加载展示内容
				hasno: false, //判断有没有消息
				success: false,
				//所有图片的高度  
				imgheights: ['0'],
				categoryArr:[],
				detArr:[],
				//图片宽度 
				imgwidth: 750,
				isIphoneX:false,
				indicatorDots: true, //是否显示指示点
				interval: 5000, //自动切换时间间隔
				duration: 400, //滑动动画时长
				autoplay: false, //是否自动切换
				circular: true, //是否采用衔接滑动
				classon: false, //判断模态框
				vertical: false,
				isShowcatalog:1,
				likelist:[]
			};
		},
		// 分享
		onShareAppMessage(res) {
			if (res.from === 'button') { // 来自页面内分享按钮
				console.log(res.target)
			}
			return {
				title: 'ABCbook国际亲子阅读',
				path: '/pages/detail/detail?id=' + this.id
			}
		},
		async onLoad(option) {
			// console.log(option.id,'opt')
			var that = this;
			that.id = option.id
			var id = option.id;
			this.$api.quest('goods/detail', {
				id: id
			}, (res) => {
				// console.log(res)
				that.detArr = res.data.data
				that.likelist =res.data.data.recommend
				that.list = res.data.data.goods_info
				that.imgs = res.data.data.goods_img
				that.goods_thumb=that.list.goods_thumb
				that.coupont=res.data.data.coupont
				that.goosnum=res.data.data.cart_number
				that.detailA = res.data.data.goods_info ? res.data.data.goods_info : [],
				that.categoryArr=that.list.category
				// console.log(that.categoryArr)
				// that.sellershopinfo=res.data.data.detail.sellershopinfo
				// console.log(that.imgs)
				that.goods_id = that.list.goods_id
				that.is_collect = that.list.is_collect ? true : false
				that.addbtn = that.list.cat_status == 1 ? '已加入书架' : that.list.goods_number == 0 ? '暂无库存' : '加入书架'
				console.log(that.addbtn)
				if (that.list.goods_desc.indexOf('style="float:none;"') > 0) {
					var str = that.list.goods_desc.replace('style="float:none;"', '')
					var reg = new RegExp('style="float:none;"', "gi");
					var a = str.replace(reg, "");
					console.log(a, 'desc')
					that.desc = a.replace(/(<br\s*\/?>)+/gi, "<br>")
					that.desc = that.desc.replace(/(<h3\s*\/?>)+/gi, "<h3 style='display:none'>")
					that.desc = that.desc.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				} else {
					that.desc = that.list.goods_desc.replace(/<img/gi,
						'<img style="float:left !important;width:100%;padding:0;height:auto;display:block"')
				}
				console.log(that.desc)
				// console.log(that.list,that.desc,res.data.data.root_path)
			})
		},
		onShow() {
			uni.getSystemInfo({
				success: res=>{
					// console.log('手机信息res'+res.model)
					let modelmes = res.model;
						if (modelmes.search('iPhone X') != -1) {
							// console.log('1111')
						this.isIphoneX = true
						}
					}
			})
		},
		computed:{
			getcur(){
				if(this.imgs.length==0){// 没有图片列表
					if(this.list.goods_video){
						return 2
					}else{
						return 1
					}				
				}else{
					if(this.list.goods_video){
						return this.imgs.length+1
					}else{
						return this.imgs.length
				}
			}
			}
		},
		methods: {
			printCoupont(){ // 领取优惠券
				console.log('领取优惠券咯')
			},
			gotodetail(id){
				uni.navigateTo({
					url:"/pages/detail/detail?id="+id
				})
			},
			selectCatalog(index){
				this.isShowcatalog = index
			},
				showNum() {
					this.numShow = !this.numShow;
				},
				showquan() {
					this.quanShow = !this.quanShow;
				},
				setNum(i){
					if(i==1&&this.num>1){
						this.num--
					}
					if(i==2){
						this.num++
					}
				},
				setNumY(event){
					 let value = event.target.value;
					if(value>1){
						this.num = value
					}else{
						this.num = 1
					}
				},
			
			CoKF() {
				// console.log('客服开')
				this.kFW = true
			},
			close() {
				// console.log('客服开')
				this.kFW = false
			},
			imageLoad(e) {
				var imgwidth = e.detail.width,
					imgheight = e.detail.height,
					//宽高比  
					ratio = imgwidth / imgheight;
				// console.log(imgwidth, imgheight)
				//计算的高度值  
				var viewHeight = 476 / ratio;
				var imgheight = viewHeight;
				var imgheights = this.imgheights;
				//把每一张图片的对应的高度记录到数组里  
				this.imgheights[this.cur] = imgheight
			},
			bindchange(e) {
				this.cur=e.detail.current
			},
			gohome() {
				this.$store.commit("change_page", 0)
				uni.reLaunch({
					url: `/pages/index/index`
				})
			},
			bookshelf() {
				uni.reLaunch({
					url: `/pages/bookrack/bookrack`
				})
			},
			// 买商品
			shopgoods(goodsid, ruid) {
				this.$api.quest('user/address/list', {}, (res) => {
					// console.log(res, "res")
					this.$api.quest('cart/addshopgoods', {
						id: goodsid,
						num: 1,
						ru_id: ruid,
						rec_type: 10,
						is_checked: 1,
						act_id: 0
					}, (res) => {
						uni.setStorageSync('goid', goodsid);
						uni.setStorageSync('ruid', ruid);
						// console.log(res,'res')
						if (res.data.code == 0) {
							uni.navigateTo({
								url: '/pages/flow/shopgoods?goid=' + goodsid + '&ruid=' + ruid
							})
						} else if (res.data.data.error) {
							this.$store.commit("change_page", 4)
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}
					})
				})

			},
			// 买卡
			paycheckout(id) {
				let goid = id
				this.$api.quest('user/address/list', {}, (res) => {
					// console.log(res, "res")
					this.$api.quest('cart/addmember', {
						id: id,
						num: 1,
						uid: uni.getStorageSync("user_id"),
						attr_id: 1,
						act_id: 30,
						rec_type: 10,
						flow_type: 10,
						extension_code: "virtual_card",
						is_checked: 1
					}, (res) => {
						if (res.data.code == 0) {
							uni.navigateTo({
								url: '/pages/flow/member?goid=' + goid
							})
						} else if (res.data.data.error) {
							this.$store.commit("change_page", 4)
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
							
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
							
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
						}
					})
				})
			},
			addBook() {
				var iq = [];
				this.$api.quest('cart/add', {
					id: this.goods_id,
					num: 1,
					uid: uni.getStorageSync("user_id"),
					attr_id: JSON.stringify(iq),
					rec_type: 0,
					is_checked: 1,
					act_id: 0
				}, (res) => {
					if (res.data.data.error == 1) {
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif
						
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						})
						// #endif
					} else {
						if (res.data.code == 0) {
							// uni.showToast({
							// 	title:'加入成功',
							// 	icon: 'none',
							// 	duration: 2000
							// });
							this.addbtn = res.data.data.cat_status == 1 ? '已加入书架' : res.data.data.real_number == 0 ? '暂无库存' : '加入书架'
							console.log(this.addbtn)
							this.goosnum=res.data.data.total_number
							uni.setStorageSync('total_number', res.data.data.total_number);
						} else {
							this.$api.msg(res.data.data)
						}
					}
				})

			},
			//分享
			// share(){
			// 	this.$refs.share.toggleMask();	
			// },
			//收藏
			toFavorite(id) {
				if (uni.getStorageSync("token")) {
					this.$api.quest('user/collect/add', {
						id: id,
						uid: uni.getStorageSync("user_id")
					}, (res) => {
						if (res.data.data == 1) {
							this.is_collect = !this.is_collect;
						}

					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},

		},
		filters: {
			/**
			 * 处理富文本里的图片宽度自适应
			 * 1.去掉img标签里的style、width、height属性
			 * 2.img标签添加style属性：max-width:100%;height:auto
			 * 3.修改所有style里的width属性为max-width:100%
			 * 4.去掉<br/>标签
			 * @param html
			 * @returns {void|string|*}
			 */
			formatRichText(html) { //控制小程序中图片大小
				let newContent = html.replace(/<img[^>]*>/gi, function(match, capture) {
					match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
					match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
					match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
					return match;
				});
				newContent = newContent.replace(/style="[^"]+"/gi, function(match, capture) {
					match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi, 'max-width:100%;');
					return match;
				});
				newContent = newContent.replace(/<br[^>]*\/>/gi, '');
				newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:10rpx"');
				return newContent;
			}
		}


	}
</script>

<style lang='scss' scoped>
	/* @import '../../static/css/public.scss'; */
	/* @import '../../../static/public.scss'; */
	/* 灰色按钮 */
	page{
		padding: 0;
	}
	css {
		position: relative;
	}
	.bottomKc{
		width: 100%;
		height: 99rpx;
		background-color: #C8C8CD;
		color: #fff;
		text-align: center;
		line-height: 99rpx;
	}
	.bgHS{
		background-color: #f7f7f7;
		height: 70rpx;
		border: 1rpx solid #CCCCCC;
		color: #ccc;
		width: 70rpx;
		font-weight: 600;
		font-size: 30rpx;
		text-align: center;
		line-height: 70rpx;
	}
	.viedoF{
		display: flex;
		justify-content: center;
		align-items: center;
		.theviedo{
			width: 750rpx;
			margin: auto 0;
		}
	}
	
	.scroll-view_H{
	  width: 100%;
	  white-space: nowrap;
	}
	.scroll-view-item_H{
	  // width: 200px;
	  // height: 100px;
	  vertical-align: top;
	  display: inline-block;
	}
	.Lquan{
		margin-top: -10rpx;
		margin-bottom: 25rpx;
		.LqItem{
			background-color: #FFFFFF;
			border-radius: 10rpx;
			margin: 10rpx;
			padding-left: 20rpx;
			height: 150rpx;
			/* width: 100%; */
			display: flex;
			justify-content: space-between;
			align-items: center;
			
			.lqz{
				display: flex;
				justify-content: space-around;
				align-items: flex-start;
				flex-direction: column;
				.lqzTop{
					display: flex;
					justify-content: flex-start;
					align-items: center;
					.lqzz{
						color: #74d2d4;
						font-size: 52rpx;
						font-weight: 700;
						padding-left: 15rpx;
						position: relative;

					}
					.lqzz::after{
						content: "￥";
						color: #74d2d4;
						font-size: 26rpx;
						position: absolute;
						left: -5rpx;
						top: 5rpx;
						color: #74d2d4;
					}
					.lqzY{
						margin-left: 15rpx;
						display: flex;
						justify-content: space-around;
						align-items: flex-start;
						flex-direction: column;
						font-size: 24rpx;
						.lqzYtop{
							color: #74d2d4;
						}
					}
				}
				.lqzbottom{
					margin-top: 4rpx;
					font-size: 24rpx;
					color: #777;
				}
			}
			.ljLIngqu{
				height: 100%;
				width: 106rpx;
				font-size: 26rpx;
				background-color: #74d2d4;
				color: #FFFFFF;
				padding: 42rpx 25rpx;
				border-top-right-radius: 10rpx;
				border-bottom-right-radius: 10rpx;
				position: relative;
			}		
		}
	}
	.addnum {
		margin-bottom: 20rpx;
		background: #fff;
		.younum {
			height: 80rpx;
			padding: 0 30rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			.younum-Z{
				display: flex;
				justify-content: flex-start;
				align-items: center;
				font-size: 30rpx;
				line-height: 80rpx;
				.yhq{
					height: 50rpx;
					width: 50rpx;
					margin: 0 10rpx;
				}
			}
			.fr{
				display: flex;
				align-items: center;
				.lq{
					font-size: 26rpx;
					color: #E02020;
					margin-right: 15rpx;
				}
			}
			
			
			.younum-Y {
				height: 30rpx;
				width: 30rpx;
			}
		}
		.jiajian {
			border-top: 1rpx solid #CCCCCC;
			padding: 0 30rpx;
			height: 100rpx;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			font-size: 34rpx;
			color: #CCCCCC;
	
			.cate_title {
				height: 70rpx;
				border: 1rpx solid #CCCCCC;
				background-color: #ffffff;
				color: #333333;
				width: 70rpx;
				font-weight: 600;
				font-size: 30rpx;
				text-align: center;
				line-height: 70rpx;
			}
		}
		.pl{
			height: 80rpx;
			padding: 0 30rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			.pl-Z{
				font-size: 30rpx;
				text-align: center;
				line-height: 70rpx;
				color: #CCCCCC;
			}
		}
	}
	.banner{
		position: relative;
	}
	.current{
		position: absolute;
		right: 20rpx;
		bottom: 20rpx;
		width:94rpx;
		/* height:42rpx; */
		background:rgba(0,0,0,0.25);
		border-radius:30rpx;
		font-size: 30rpx;
		color: #fff;
		line-height: 50rpx;
		text-align: center;
	}
	.isIphoneX{
		height: 118rpx !important;
		padding-bottom: 25rpx;
	}

	.hbtn {
		width: 329rpx;
		line-height: 98rpx;
		border-radius: 0;
		background: #e6e6e6;
		color: #fff;
	}

	.container {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		margin-bottom: 60upx;
	}

	.carousel {
		position: relative;
		width: 100%;
		height: 750rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		background: #fff;

		image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			display: block;
			width: 750rpx;
			margin: 0 auto;
		}
	}

	/* 标题简介 */
	.introduce-section {
		background: #fff;
		padding: 30upx 30upx;
		box-shadow: 0rpx -2rpx 8rpx 0rpx rgba(0, 0, 0, 0.1);
		margin-bottom: 20rpx;
		.shop{
			display: flex;
			align-items: center;
			/* 价格 */
			.price{
				margin-bottom: 14rpx;
				>text:first-child{
					color: #E02020;
					font-size: 46rpx;
					font-weight: 600;
					&::before{
						display: inline-block;
						content: '￥';
						color: #E02020;
						font-size: 32rpx;
					}
				}
				>text:nth-child(2){
					color: #999;
					font-size: 28rpx;
					margin-left: 20rpx;
					text-decoration: line-through;
				}
			}
			/* 商城标签 */
			.shoplabel{
				margin-left: 20rpx;
				>text{
					display: inline-block;
					font-size: 22upx;
					padding:5rpx 15rpx;
					border-radius: 22rpx;
				}
				.label1 {
					background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
					color: #fff;
				}
				
				.label2 {
					background:rgba(255,230,220,1);
					color: #FF824B;
					margin-left: 10rpx;
				}
			}
			
		}
		.tag{
			width: 60upx;
			height: 35upx;
			border-radius: 8upx;
			background-color: #e02e24;
			color: #fff;
			display: inline-block;
			line-height: 35upx;
			font-size: 24upx;
			text-align: center;
			position: relative;
			margin-right: 20upx;
		}
		
		/* 标题 */
		.tit{
			.yticon {
				font-size: 40upx;
				line-height: 40upx;
				color: $font-color-light;
				&.active,
				&.active .yticon {
					color: $uni-color-primary;
				}
			}
			
			
		}
		.title {
			font-size: 28upx;
			color: $font-color-dark;
			/* line-height: 30upx; */
			width: 650rpx;
			display: block;
			overflow: hidden;
			text-overflow: ellipsis;
/* 			white-space: nowrap;
 */			color: #333;

		}
		
		/* 标签 */
		.label{
			margin-top: 10rpx;
			text{
				display: inline-block;
				background::rgba(255,130,75,0.2);
				color:#FF824B;
				font-size: 24rpx;
				padding: 0 15rpx;
				line-height: 40rpx;
				margin-right: 10rpx;
				margin-bottom: 10rpx;
				border-radius:4rpx;
				&:first-child{
					
					background:rgba(255,205,120,0.2);
					color:#FFA24B;
				}
			}
			
		}
		/* 作者,出版社 */
		.information{
			line-height: 40rpx;
			color: #666;
			font-size: 26rpx;
			margin-top: 20rpx;
			/* font-weight: 900; */
			.tt{
				text:first-child{
					word-spacing: 19rpx;
					font-size: 28rpx;
				}
				
			}
			text{
				font-weight: normal;
			}
		}
		.brief {
			width: 690rpx;
			font-size: 24rpx;
			color: #999;
			line-height: 36rpx;
			margin-top: 10rpx;
			display: -webkit-box;
			overflow: hidden;
			-webkit-box-orient: vertical;
			text-overflow: ellipsis;
			-webkit-line-clamp: 2;
		}

		.price {
			font-size: $font-lg + 2upx;
		}
	}

	/*  详情 */

	.detail-desc {
		width: 100%;
		background: #fff;
		/* padding: 20upx 30upx; */

		img {
			width: 100%;
		}

		.imgdetail {
			width: 100%;
			text: 22upx;
			font-size: 30upx;
			line-height: 50upx;
			text-align: justify;
			color: #666;
			text-indent: 62rpx;
		}

		.d-header {
			width: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 80upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			position: relative;

			text {
				padding: 0 20upx;
				background: #fff;
				position: relative;
				z-index: 1;
			}

			&:after {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translateX(-50%);
				width: 300upx;
				height: 0;
				content: '';
				border-bottom: 1px solid #ccc;
			}
		}
	}

	/* 底部操作菜单 */
	.page-bottom {
		position: fixed;
		left: 0;
		bottom: 0upx;
		z-index: 95;
		display: flex;
		/* justify-content: space-around; */
		align-items: center;
		width: 750upx;
		height: 99upx;
		background: #FFFFFF;
		box-shadow: 0 0 20upx 0 rgba(0, 0, 0, .3);
		/* border-radius: 16upx; */

		

		.p-b-btn {
			position: relative;
			background: #FFFFFF;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: $font-sm;
			color: $font-color-base;
			width: 120upx;
			height: 80upx;
			/* margin-right: auto; */
			line-height: normal;

			image {
				width: 38rpx;
				height: 38rpx;
			}
			.goodnum{
				position: absolute;
				top: 0;
				right: 20rpx;
				line-height:30rpx;
				width: 30rpx;
				text-align: center;
				background: #FD2E32;
				color: #fff;
				font-size: 22rpx;
				border-radius: 50rpx;
			}
			
		}

		.action-btn-group {
			flex: 1;
			display: flex;
			justify-content: space-between;
			width: 329rpx;
			height: 98rpx;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);

			.action-btn {
				width: 329rpx;
				line-height: 98rpx;
				color: #fff;
				font-size: 30rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			}
		}

		.action-group {
			width: 427rpx;
			height: 74rpx;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			border-radius: 49rpx;
			margin-right: 20rpx;

			.action-btn {
				width: 427rpx;
				line-height: 74rpx;
				color: #fff;
				font-size: 30rpx;
				border-radius: 49rpx;
				background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			}
		}
	}

	.Kft {
		position: fixed;
		top: 0;
		left: 0;
		height: 100%;
		width: 100%;
		z-index: 998;
		background: rgba(0, 0, 0, 0.6);

		.ewm {
			height: 855rpx;
			width: 670rpx;
			position: fixed;
			top: 360rpx;
			right: 40rpx;
		}

		.close {
			width: 58rpx;
			height: 58rpx;
			position: fixed;
			top: 279rpx;
			right: 20rpx;
		}
	}
	.nav {
		display: flex;
		align-items: center;
		white-space: nowrap;
		justify-content: space-around;
		line-height: 36rpx;
		overflow-x: scroll;
		-webkit-overflow-scrolling: touch;
		white-space: nowrap;
		width: 750rpx;
		height: 88rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.06), 0px -1px 0px 0px rgba(230, 230, 230, 1);
	
		text {
			position: relative;
			display: inline-block;
			// margin-left: 50rpx;
			color: #666;
			font-size: 30rpx;
			line-height: 50rpx;
		}
	
		.active {
			color: #ff824b;
			position: relative;
			font-size: 36rpx;
			font-weight: bold;
		}
	
		.active::before {
			display: block;
			content: '';
			position: absolute;
			width: 26rpx;
			height: 8rpx;
			bottom: -12rpx;
			left: 50%;
			transform: translate(-50%, 0%);
			background: #ff824b;
			border-radius: 4rpx;
		}
	}
	.catalog{
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		image{
			margin-top: 200rpx;
			width: 200rpx;
		}
		.catalogtext{
			text-align: center;
			font-size: 30rpx;
			color: #999;
			margin-top: 10rpx;

		}
	}
	.youlike{
		background-color: #FFFFFF;
		
		.liketitle{
			line-height: 80rpx;
			height: 80rpx;
			padding: 0 20rpx;
			color: #808080;
			font-size: 26rpx;
			position: relative;
		
		}
		.liketitle::after{
			content: "";
			position: absolute;
			left: 15rpx;
			bottom: 0;
			right: 0;
			height: 1px;
			border-bottom: 1px solid #E5E5E5;
			color: #E5E5E5;
			transform-origin: 0 100%;
			transform: scaleY(0.5);
		}
		.likelist{
			margin-top: 15rpx;
			height: 300rpx;
			width: 750rpx;
			.likeitem{
				margin-left: 20rpx;
				height: 100%;
				width: 180rpx;
				display: flex;
				justify-content: space-around;
				align-items: flex-start;
				flex-direction: column;
				image{
					height: 180rpx;
					width: 180rpx;
					border: 1rpx solid #E5E5E5;
				}
				.likename{
					width: 100%;
					font-size: 26rpx;
					overflow: hidden;
				}
				.jiaqian{
					font-size: 30rpx;
					color: #ff495e!important;

				}
			}
		}
	}
	.shuliang{
		height: 60rpx;
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		color: #888;
		font-size: 28rpx;	
	}
</style>
