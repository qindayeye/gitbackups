<template>
	<view class="twelve">
		<image v-for="(item,index) in gtoimg"  :class="'double'+(index+1)" :src="item" mode="widthFix" @click="gotodeti('double'+(index+1))"></image>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				srcImg:[],
				actEndTime:'2019-12-12 00:00:00',
				finished:true,
				gtoimg:[]
			}
		},
		mounted(){
			
		},
		onLoad() {
			for(var i=1;i<=26;i++){
				this.srcImg.push(`https://www.abcbook2019.com/mobile/public/img/twelve/double-${i}.jpg`)
			}
			// console.log(this.$refs)
			var timestamp = Date.parse(new Date())/1000;//获取当前时间
		},
		mounted() {
			this.countDown()
		},
		methods:{
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			countDown(it) {
				var interval = setInterval(() => {
					// 获取当前时间，同时得到活动结束时间数组
					let newTime = new Date().getTime();
					// 对结束时间进行处理渲染到页面
					let endTime = new Date(this.actEndTime).getTime();
					let obj = null;
					// 如果活动未结束，对时间进行处理
					if (endTime - newTime > 0) {
						let time = (endTime - newTime) / 1000;
						// 获取天、时、分、秒
						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
					} else { // 活动已结束，全部设置为'00'
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00' ,
							
						};
						
						this.finished=false
						
						this.srcImg[2]='https://www.abcbook2019.com//mobile/public/img/twelve/double-27.jpg'
						this.srcImg[8]='https://www.abcbook2019.com//mobile/public/img/twelve/double_9.jpg'
						this.srcImg[14]='https://www.abcbook2019.com//mobile/public/img/twelve/double_15.jpg'
						this.srcImg[20]='https://www.abcbook2019.com//mobile/public/img/twelve/double_21.jpg'
						this.srcImg[24]='https://www.abcbook2019.com//mobile/public/img/twelve/double_25.jpg'
						console.log(this.srcImg)
						this.gtoimg=this.srcImg
						
						clearInterval(interval);
						// this.onLoad()
					}
					// console.log(obj)
					// this.countDownList = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
				}, 1000);
			},
			gotodet(cla){
				console.log(cla)
				if(uni.getStorageSync("token")){
						if(cla=='double9'){
							// console.log('1499')
							uni.navigateTo({
								url:'/pages/detail/double?id=1859'
							})
						}else if(cla=='double15'){
							// console.log('699')
							uni.navigateTo({
								url:'/pages/detail/double?id=4301'
							})
						}else if(cla=='double21'){
							// console.log('499')
							uni.navigateTo({
								url:'/pages/detail/double?id=1858'
							})
						}else if(cla=='double25'){
							// console.log('299')
							uni.navigateTo({
								url:'/pages/detail/double?id=4300'
							})
						}
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
				
			},
			gotodeti(cla){
				if(uni.getStorageSync("token")){
						if(cla=='double9'){
							console.log('1499')
							uni.navigateTo({
								url:'/pages/detail/detail?id=1859'
							})
						}else if(cla=='double15'){
							console.log('699')
							uni.navigateTo({
								url:'/pages/detail/datail?id=4301'
							})
						}else if(cla=='double21'){
							console.log('499')
							uni.redirectTo({
								url:'/pages/detail/datail?id=1858'
							})
						}else if(cla=='double25'){
							console.log('299')
							uni.redirectTo({
								url:'/pages/detail/datail?id=4300'
							})
						}
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			}
		}
	}
</script>

<style lang="scss">
	.service{
		padding: 0;
		border-radius:0 ;
	}
	page{
		padding: 0;
		margin: 0;
	}
	.twelve{
		image{
			width: 100vw;
			display: block;
			margin-top: -1rpx;
		}
	}
</style>
