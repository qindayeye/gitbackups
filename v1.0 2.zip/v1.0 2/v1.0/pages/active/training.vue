<template>
	<view class="training">
		<image v-for="(item,index) in training" :class="'training'+(index+1)" :src="item" mode="widthFix" @click="gotodet('training'+(index+1))"></image>


		<!-- 弹框 -->
		<view class="popout" v-if="success">
			<view class="message">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="widthFix"
				 @click.stop="close()"></image>
				<view class="box">
					<text class="tex">{{tex}}</text>
					<text class="tex">{{tex2}}</text>
					<view class="btn">
						<button class="btn" v-if="gopay" type="primary" @click="gotopay()">去支付</button>
						<button class="btn" v-else type="primary" @click="gotoind()">去选书</button>
					</view>
				</view>
			</view>
		</view>
	</view>


</template>

<script>
	// import Vue from 'vue'
	export default {
		data() {
			return {
				training: [],
				actEndTime: '2019-12-12 00:00:00',
				finished: true,
				gtoimg: [],
				success: false,
				froms: '',
				referer: '',
				type: '',
				tex: '你已经购买过了',
				tex2: '快去选书吧~',
				gopay: false
				// customer:'WXPYQ010'
			}
		},
		onLoad(option) {
			// #ifdef H5
			// 判断微信内外
			var ua = window.navigator.userAgent.toLowerCase();
			console.log(ua)
			// console.log(ua.indexOf('micromessenger') != -1)
			// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
			if (ua.match(/MicroMessenger/i) == 'micromessenger') {
				// 微信内浏览器（公众号）
				console.log("公众号")
				this.froms = 'touch'
				this.referer = 'touch'
				this.type = 3

			} else {
				console.log("H5")
				this.froms = 'IE'
				this.referer = 'IE'
				this.type = 2
			}
			// #endif

			for (var i = 1; i <= 10; i++) {
				this.training.push(`https://www.abcbook2019.com/mobile/public/img/training/training${i}.jpg`)
			}
		},
		methods: {

			gotopay() {
				uni.navigateTo({
					url: '/pages/order/order?states=500&index=1'
				})
			},

			gotodet(cla) {
				// console.log(cla)
				if (uni.getStorageSync('token')) {
					if (cla == 'training5') {
						// this.id=4399
						// console.log('12次卡')
						this.confirm(4301)
					}
					if (cla == 'training9') {
						// this.id=4399
						// console.log('年卡')
						this.confirm(1859)
					}
					if (cla == 'training2' || cla == 'training3' || cla == 'training4') {
						// 12次卡进详情页
						console.log(cla)
						uni.navigateTo({
							url: '/pages/detail/detail?id=4301'
						})
					}
					if (cla == 'training6' || cla == 'training7' || cla == 'training8') {
						// 年卡进详情页
						uni.navigateTo({
							url: '/pages/detail/detail?id=1859'
						})
					}
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.setStorageSync('HDurl', window.location.href)
						uni.navigateTo({
							url: '/pages/public/login'
						})
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif				
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					});
					// #endif
				}
			},
			onShareAppMessage(res) {
				if (res.from === 'button') { // 来自页面内分享按钮
					console.log(res.target)
				}
				return {
					title: '亲子读书日-训练营',
					path: '/pages/active/training'
				}
			},
			close() {
				this.success = false
			},
			gotoind() {
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
			confirm(id) {
				this.$api.quest('flow/trainingflow', {
					id: id, //goodsid
					rec_type: 84,
					type: this.type,
					froms: this.froms,
					referer: this.referer,
					open_id: uni.getStorageSync("openid"), //openid
				}, (res) => {
					console.log(res)
					if (res.data.data.error == 1) {
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.setStorageSync('HDurl', window.location.href)
							uni.navigateTo({
								url: '/pages/public/login'
							})
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif							
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						});
						// #endif
					} else {
						if (res.data.code == 0) {
							// #ifdef MP
							this.id = res.data.data.wxpay.order_id ? res.data.data.wxpay.order_id : ''
							this.payment = res.data.data.wxpay.goods_price ? res.data.data.wxpay.goods_price : ''
							this.$api.wePay(
								"abcbook国际亲子阅读",
								res.data.data.wxpay.timestamp,
								res.data.data.wxpay.nonce_str,
								res.data.data.wxpay.packages,
								"MD5",
								res.data.data.wxpay.sign,
								res => {
									console.log(JSON.parse(res))
									uni.navigateTo({
										url: '/pages/money/paySuccess?payok=0&id=' + this.id
									})

								}, fail => {
									console.log(fail)
									uni.navigateTo({
										url: '/pages/money/paySuccess?payok=1&id=' + this.id + '&payment=' + this.payment
									})
								})
							// #endif						
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								this.id = res.data.data.msg.order_id
								let gzhCS = res.data.data.msg
								WeixinJSBridge.invoke(
									'getBrandWCPayRequest', {
										debug: true,
										"appId": gzhCS.appId, //公众号名称，由商户传入
										"timeStamp": gzhCS.timeStamp.trim(), //时间戳，自1970年以来的秒数 // trim去掉空格
										"nonceStr": gzhCS.nonceStr, //随机串
										"package": gzhCS.package,
										"signType": gzhCS.signType, //微信签名方式：
										"paySign": gzhCS.paySign, //微信签名
										jsApiList: [
											'chooseWXPay'
										]
									},
									function(res) {
										console.log(res, "公众号支付回调")
										// 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
										if (res.err_msg == "get_brand_wcpay_request:ok") {
											// 支付成功
											console.log("公众号支付成功")
											console.log(that.id, "idid")
											uni.navigateTo({
												url: '/pages/money/paySuccess?payok=0&id=' + that.id
											})
										} else {
											// 支付失败
											console.log("公众号支付失败")
											console.log(that.id, "idid")
											uni.navigateTo({
												url: '/pages/money/paySuccess?payok=1&id=' + that.id
											})
										}
									}
								);
							} else {
								console.log("H5")
								window.location.href = res.data.data.msg
							}
							// #endif							
						} else if (res.data.code == 10) {
							// 让弹框显示
							// this.$api.msg(res.data.data)
							this.tex = '您有未支付的订单'
							this.tex2 = '快去支付吧~'
							this.gopay = true //去支付按钮
							this.success = true

						} else {
							this.success = true
						}
					}

				})
			},
		}
	}
</script>

<style lang="scss">
	page {
		padding: 0;
		margin: 0;
	}

	.popout {
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0, 0, 0, .6);
	}

	.close {
		position: absolute;
		top: -70rpx;
		right: 0;
		width: 30rpx;
	}

	.message {
		position: fixed;
		top: 40%;
		left: 50%;
		width: 600rpx;
		// height: 465rpx;
		padding: 50rpx 0;
		transform: translate(-50%, -50%);
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;

		.box {
			// height: 488rpx;

			.tex {
				display: block;
				text-align: center;
				font-size: 36rpx;
				margin-bottom: 15rpx;
				color: #666;
				font-weight: 400;
				letter-spacing: 5rpx;

			}

			.btn {
				width: 300rpx;
				line-height: 80rpx;
				background: #FF824B;
				border-radius: 42rpx;
				font-weight: 900;
				font-size: 34rpx;
				color: #fff;
				margin: 0 auto;
				margin-top: 40rpx;
			}
		}

	}

	.service {
		padding: 0;
		border-radius: 0;
	}

	.training {
		>image {
			width: 100vw;
			display: block;
			/* #ifdef MP */
			margin-top: -1rpx;
			/* #endif */
		}
	}
</style>
