<template>
	<view class="twelve">
		<image v-for="(item,index) in christmas"  :class="'christmas'+(index+1)" :src="item" mode="widthFix" @click="gotodet(index)"></image>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				christmas:[],
				actEndTime:'2019-12-12 00:00:00',
				finished:true,
				gtoimg:[],
				success:false,
				customer:'WXPYQ010'
			}
		},
		onLoad(option) {
			for(var i=1;i<=8;i++){
				this.christmas.push(`https://www.abcbook2019.com/mobile/public/img/team/team_${i}.jpg`)
			}			
		},	
		methods:{
			gotodet(cla){
				// console.log(cla)
				if(uni.getStorageSync("token")){
						if(cla=='3'){
							uni.navigateTo({
								url:"../detail/groupdetail"
							})
						}						
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}				
			}
		}
	}
</script>

<style lang="scss">
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	page{
		padding: 0;
		margin: 0;
	}
	.twelve{
		>image{
			width: 100vw;
			display: block;
			/* #ifdef MP */ 
			margin-top: -1rpx;
			/* #endif */
		}
	}
</style>
