<template>
	<view class="twelve">
		<image v-for="(item,index) in oncead" :key='index' :class="'double'+(index+1)" :src="item" mode="widthFix" @click="gotodet('double'+(index+1))"></image>
		<view class="buon">
			<text class="experience" @click="confirm(4299)">19.9借绘本</text>
			<text @click="gotourl('/pages/index/addjoin')">加入会员</text>
		</view>
		<!-- 弹框 -->
		<view class="popout" v-if="success">
			<view class="message">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="widthFix" @click.stop="close()"></image>
				<text class="tex">您已经购买过了 快去选书吧</text>
				<view class="btn">
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				oncead:[],
				success:false,
			}
		},
		onLoad(option) {
			uni.setStorageSync('uid', option.u_id)
			for(var i=1;i<=16;i++){
				this.oncead.push(`http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/newpople/newpeople${i}.png`)
			}
		},
		mounted() {
			
		},
		methods:{
			gotourl(url){
				uni.navigateTo({
					url:url
				})
			},
			gotodet(cla){
				if(uni.getStorageSync('token')){
					if(cla=='double3' || cla=='double6'){
						// this.id=4399
						this.confirm(1859)
					}
					
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			close(){
				this.success=false
			},
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			confirm(id) {
				this.$api.quest('flow/sdflow',{
					id: id,   //goodsid
					rec_type:85,
					open_id: uni.getStorageSync("openid"),           //openid
				},(res)=>{
					console.log(res)
					
					if(res.data.code==0){
						this.id=res.data.data.wxpay.order_id?res.data.data.wxpay.order_id:''
						this.payment=res.data.data.wxpay.goods_price?res.data.data.wxpay.goods_price:''
						this.ruid=res.data.data.wxpay.ru_id
						this.is_real=res.data.data.wxpay.is_real
						this.$api.wePay(
						"abcbook国际亲子阅读", 
						res.data.data.wxpay.timestamp, 
						res.data.data.wxpay.nonce_str, 
						res.data.data.wxpay.packages, 
						"MD5", 
						res.data.data.wxpay.sign,
						res=>{
							console.log(JSON.parse(res))
							uni.navigateTo({
								url:'/pages/money/paySuccess?payok=0&id='+this.id+'ruid='+this.ruid+'&isreal='+this.is_real,
								// payok=0&id='+this.id+'&
							})
							
						},fail=>{
							console.log(fail)
							
							uni.navigateTo({
								url:'/pages/money/paySuccess?payok=1&id='+this.id+'&payment='+this.payment
							})
							
						})
					}else{
						// 让弹框显示
						this.success=true
						// this.$api.msg(res.data.data)
					}
				})
			},
		}
	}
</script>

<style lang="scss">
	page{
		padding: 0;
		margin: 0;
		padding-bottom: 118rpx;
	}
	.buon{
		position: fixed;
		display: flex;
		width: 100vw;
		bottom: 0;
		height:118rpx;
		justify-content:space-around;
		// background: url('http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/newpople/newpeople_bj.png');
		text{
			width: 343rpx;
			height: 88rpx;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
			box-shadow:0rpx 4rpx 8rpx 0rpx rgba(255,130,75,0.5);
			border-radius:49rpx;
			color: #fff;
			font-size: 32rpx;
			text-align: center;
			line-height: 88rpx;
		}
		.experience{
			background: #fff;
			border: 1rpx solid #FF824B;
			color: #FF824B;
		}
	}
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	.twelve{
		background: url('http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/newpople/newpeople_bj.png');
		>image{
			width: 100vw;
			display: block;
			/*#ifdef MP*/
			margin-top: -1rpx;
			/*#endif*/
		}
	}
	.double16{
		width: 726rpx;
		margin: 0 auto;
	}
	.floor_di{
		height: 98rpx;
		width: 100%;
		background: #fff;
		position: fixed;
		align-items: center;
		bottom: 0;
		display: flex;
		.price{
			flex: 1;
			// text-align: center;
			margin-left:40rpx ;
			color: #333;
			font-size: 32rpx;
			.num{
				color: #E02020;
				font-size: 32rpx;
				font-weight: bold;
			}
			.original{
				position: relative;
				color: #666;
				font-size: 28rpx;
				margin-left: 20rpx;
				&:before{
					position: absolute;
					display: inline-block;
					content: "———";
					
				}
			}
		}
		.button{
			align-self: flex-end;
			line-height: 98rpx;
			align-items: center;
			width:296rpx;
			font-size: 32rpx;
			color: #fff;
			text-align: center;
			background: linear-gradient(135deg,rgba(255,96,96,1) 0%,rgba(255,45,45,1) 100%);
		}
	}
</style>
