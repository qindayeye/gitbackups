<template>
	<view class="twelve">
		<image v-for="(item,index) in oncead" :key='index' :class="'double'+(index+1)" :src="item" mode="widthFix" @click="gotodet('double'+(index+1))"></image>
		
		<!-- 弹框 -->
		<view class="popout" v-if="success">
			<view class="message">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="widthFix" @click.stop="close()"></image>
				<text class="tex">您已经购买过了 快去选书吧</text>
				<view class="btn">
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import Vue from 'vue'
	export default{
		data(){
			return{
				oncead:[],
				success:false,
			}
		},
		onLoad(option) {
			for(var i=1;i<=6;i++){
				this.oncead.push(`http://ktoss.oss-cn-beijing.aliyuncs.com/nymph0308/nymph_${i}.png`)
			}
		},
		mounted() {
			
		},
		methods:{
			gotodet(cla){
				if(uni.getStorageSync('token')){
					if(cla=='double3' || cla=='double6'){
						// this.id=4399
						this.confirm(1859)
					}
					
				}else{
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}
			},
			onShareAppMessage(res) {
			if (res.from === 'button') {// 来自页面内分享按钮
			  console.log(res.target)
			}
			return {
			  title: '解放妈妈 —— “包”你满意',
			  path: '/pages/active/nymph'
			}
		  },
			close(){
				this.success=false
			},
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			confirm(id) {
				let goodid=[]
				goodid.push(id)
				this.$api.quest('cart/addmember',{
					id:id,
					num:1,	
					uid:uni.getStorageSync("user_id"),
					attr_id:1,	
					act_id:30,
					rec_type:10,
					flow_type: 10,
					extension_code:"virtual_card",
					is_checked:1
				},(res)=>{
						console.log(res,'res')
						if(res.data.code==0){
							uni.navigateTo({
								url:'/pages/flow/member?goid='+id
							})
						}else if(res.data.data.error){
							this.$store.commit("change_page", 4)
							
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif
						
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						})
						// #endif
						}
				})
			},
		}
	}
</script>

<style lang="scss">
	page{
		padding: 0;
		margin: 0;
	}
	.popout{
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		left: 0;
		background: rgba(0,0,0,.6);
	}
	.close{
		position: absolute;
		top: -70rpx;
		right: 0;
		width:30rpx;
	}
	.message {
		position: fixed;
		top: 30%;
		left: 50%;
		width: 488rpx;
		// height: 465rpx;
		padding: 30rpx;
		margin-left: -244rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		z-index: 999;
		text-align: center;
	
		.tex {
			display: block;
			font-size: 30rpx;
			color: #666;
			font-weight: 400;
		}
	
		.btn {
			width: 200rpx;
			line-height: 70rpx;
			background: #FF824B;
			border-radius: 42rpx;
			font-size: 30rpx;
			color: #fff;
			margin: 0 auto;
			margin-top: 30rpx;
		}
	}
	.service{
		padding: 0;
		border-radius:0 ;
	}
	.twelve{
		>image{
			width: 100vw;
			
			display: block;
			/*#ifdef MP*/
			margin-top: -1rpx;
			/*#endif*/
		}
	}
	.floor_di{
		height: 98rpx;
		width: 100%;
		background: #fff;
		position: fixed;
		align-items: center;
		bottom: 0;
		display: flex;
		.price{
			flex: 1;
			// text-align: center;
			margin-left:40rpx ;
			color: #333;
			font-size: 32rpx;
			.num{
				color: #E02020;
				font-size: 32rpx;
				font-weight: bold;
			}
			.original{
				position: relative;
				color: #666;
				font-size: 28rpx;
				margin-left: 20rpx;
				&:before{
					position: absolute;
					display: inline-block;
					content: "———";
					
				}
			}
		}
		.button{
			align-self: flex-end;
			line-height: 98rpx;
			align-items: center;
			width:296rpx;
			font-size: 32rpx;
			color: #fff;
			text-align: center;
			background: linear-gradient(135deg,rgba(255,96,96,1) 0%,rgba(255,45,45,1) 100%);
		}
	}
</style>
