<template>
	<view class="searchbox">
		<view class="searchtop">
			<view class="center">
				<view><text class="eosfont search">&#xe600;</text> <!-- 放大镜 -->
				</view>
				<input type="text" placeholder="图书搜索" :value="booksearchlist" @input="fuzzysearch" />
			</view>
			<view class="right" @click="clicksearch">搜索</view>
		</view>
		<view class="hotsearch" v-if="searchlist.length!=0">
			<view class="hotcont">
				<view class="contItl">搜索历史</view>
				<text class="abcbook deletesearch" @click="deletesearch">&#xe62f;</text>
			</view>
		
			<view>
				<block v-for="(item,index) in searchlist" :key="index">
					<view class="searchboxit" @click="gotoagesearch(item)">{{item}}</view>
				</block>
			</view>
		</view>
		<view class="nowsearch">
			<view class="nowcont">
				<view class="contItl">热门搜索</view>
			</view>
			<view>
				<block v-for="(item,index) in nowlist" :key="index">
					<view class="searchboxit" @click="gotoagesearch(item)">{{item}}</view>
				</block>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				booksearchlist: "",
				searchlist:[],
				nowlist: []
			}
		},
		onLoad() {
			this.$api.quest('goods/hotKey', {}, (res) => {
				console.log(res.data)
				if (res.data.code == 0) {
					this.nowlist = res.data.data
				}
			})
			if(uni.getStorageSync("searchlist")){
				this.searchlist=uni.getStorageSync("searchlist")
			}
			

		},
		methods: {
			//点击搜索
			clicksearch() {
				if (this.booksearchlist.trim()) {    //搜索不为空
					console.log(this.searchlist)

					this.searchlist.push(this.booksearchlist.trim())
					uni.setStorageSync("searchlist",this.searchlist)
				}
				
				uni.navigateTo({
					url: '/pages/search/searchone?name=' + this.booksearchlist
				})
				this.booksearchlist = ""
			},
			fuzzysearch(e) {
				this.booksearchlist = e.detail.value.trim()
			},
			gotoagesearch(name) {
				uni.navigateTo({
					url: '/pages/search/searchone?name=' + name
				})
			},
			//删除最近查询
			deletesearch() {
				this.searchlist = []
				uni.setStorageSync("searchlist",this.searchlist)
			},
			//回退
			goback() {
				uni.navigateBack({
					delta: 1,
				});
			},

		}
	}
</script>

<style lang="scss">
	page {
		background: #fff;
	}

	.search {
		color: #333;
		font-size: 30upx;
		line-height: 55upx;
	}

	.deletesearch {
		font-size: 32rpx;
		padding: 0;
		margin: 0;
	}

	.searchbox {
		width: 100%;
		display: flex;
		flex-direction: column;

		.searchtop {
			width: 100%;
			display: flex;
			justify-content: space-around;
			height: 88upx;
			padding-top: 10upx;
			align-item: center;
			border-bottom: 1px solid #CCCCCC;

			.left {
				width: 8%;
				height: 60upx;
				line-height: 60upx;
				padding-left: 20upx;
			}

			.center {
				width: 640rpx;
				height: 60upx;
				display: flex;
				align-items: center;
				background: #F0F0F0;
				border-radius: 50upx;

				// border: 1rpx solid #666;
				input {
					font-size: 30upx;
					color: #CCCCCC;
					padding-left: 20upx;
				}

				view {
					margin-left: 20upx;
				}

			}

			.right {
				width: 8%;
				height: 60upx;
				font-size: 28upx;
				line-height: 60upx;
				text-align: center;
				color: #666;
			}

		}

		.hotsearch {
			color: #A3A3A3;
			font-size: 36upx;
			margin-top: 25upx;

			.hotcont {
				width: 100%;
				align-items: center;
				display: flex;
				justify-content: space-between;
				padding: 0 20upx;
				.contItl{
					font-size: 32rpx;
				}
			}

			.searchboxit {
				min-width: 170upx;
				text-align: center;
				line-height: 60upx;
				box-sizing: border-box;
				padding: 0 30rpx;
				font-size: 28upx;
				float: left;
				color: black;
				background: #f5f5f5;
				margin: 11upx;
				border-radius: 29upx;
				font-size: 26upx;
				color: #666;
			}


		}

		.nowsearch {
			margin-top: 30upx;
			color: #A3A3A3;
			font-size: 36upx;

			.nowcont {
				width: 100%;
				display: flex;
				justify-content: space-between;
				padding: 0 20upx;
				.contItl{
					font-size: 32rpx;
				}
			}

			.searchboxit {
				min-width: 170upx;
				text-align: center;
				line-height: 60upx;
				box-sizing: border-box;
				padding: 0 30rpx;
				font-size: 28upx;
				float: left;
				color: black;
				background: #f5f5f5;
				margin: 11upx;
				border-radius: 29upx;
				font-size: 26upx;
				color: #666;
			}

		}
	}
</style>
