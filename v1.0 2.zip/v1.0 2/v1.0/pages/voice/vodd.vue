<template>
	<view>
	       <camera device-position="back" flash="off" @error="error" style="width: 100%; height: 300px;" frame-size="large" ></camera>
	        <button type="primary" @click="takePhoto">拍照</button>
	        <view>预览</view>
	        <image mode="widthFix" :src="src"></image>
			<!-- 
			<camera device-position="back" flash="off" binderror="error" frame-size="large" class="mycamera">
			  </camera>
			  <canvas canvas-id="mycanvas" class="mycanvas"> </canvas> -->
	    </view>
</template>

<script>
	export default{
		data(){
			return{
				src:''
			}
		},
		mounted() {
			
			const context = wx.createCameraContext()
			const listener = context.onCameraFrame((frame) => {
							 // console.log(frame)
			  console.log(frame.data instanceof ArrayBuffer, frame.width, frame.height)
			  
			  // if (nCounter == 0) {
			  //         wx.canvasPutImageData({
			  //           canvasId:'mycanvas',
			  //           x: 0,
			  //           y: 0,
			  //           width: frame.width,
			  //           heihgt: frame.heihgt,
			  //           data:new Uint8ClampedArray(frame.data),
			  //           success(res) {
			  //             console.log('OK')
			  //           },
			  //           fail(res) {
			  //             console.log('FAIL')
			  //           }
			  //         })
			  //       }
			        // nCounter++
			        // if (nCounter >= 10) {
			        //   nCounter = 0
			        // }
			})
			
			
			listener.start()
			console.log(listener)
		},
		methods: {
         takePhoto() {
			 
			 // uni.scanCode({
				//  onlyFromCamera: true,
			 //     success: function (res) {
			 //         console.log('条码类型：' + res.scanType);
			 //         console.log('条码内容：' + res.result);
			 //     }
			 // });
			
			 
			 
     //        const ctx = uni.createCameraContext();
     //        ctx.takePhoto({
     //            quality: 'high',
     //            success: (res) => {
					// console.log(res)
     //                this.src = res.tempImagePath
					//   uni.getFileSystemManager().readFile({
					//     filePath: this.src,
					//     encoding: 'base64',	
					//     success: (res) => {	
					//       let avatarBase64 = res.data
					//       console.log(avatarBase64)
					//       uni.hideLoading()	
					//     }
												
					//   })
     //            }
     //        });
        },
        error(e) {
            console.log(e.detail);
        }
    }}
				
				// uni.createCameraContext()
				// console.log(12121)
				// uni.createCameraContext().takePhoto({
							
				//    quality: 'high',
							
				//    success: (res) => {
				// 	   console.log(res)
							
				//      let tempImagePath = res.tempImagePath
							
				     
							
				   //   uni.getFileSystemManager().readFile({
							
				   //     filePath: tempImagePath,
							
				   //     encoding: 'base64',
							
				   //     success: (res) => {
							
				   //       let avatarBase64 = res.data
							
				   //       console.log(avatarBase64)
							
				   //       uni.hideLoading()
							
				   //     }
							
				   //   })
							
				   // }
							
				 // })
</script>

<style>
</style>
