<template>
	<view class="voicedetail">
		<listCell :title.default="msg" vioc="true"></listCell>
		<view class="pagehot" v-if="hotmain.length">
			<view class="hotmain">
				<block v-for="(item, index) in hotmain" :key="index">
					<navigator class="block" :url="'../voice/voicedetail?id=' + item.goods_id" open-type="navigate">
						<view class="hot_main_con">
							<image class="bookimg" :src="item.goods_thumb" mode=""></image>
							<view class="bookinfo">
								<text>{{ item.goods_name }}</text>
								<view class="label">
									<text v-if="item.cat_name_t">{{ item.cat_name_t }}</text>
									<text v-if="item.cat_name">{{ item.cat_name }}</text>
								</view>
								<!-- 添加到播放列表 -->
								<image @click.stop="addPlayList(item)" src="https://www.abcbook2019.com/mobile/public/img/new/jrsj.png" mode=""></image>
							</view>
							<!-- <text class="topleftcorner" v-if="item.video_url">含视频</text> -->
							<!-- <text class="topleftcorner" v-else-if="item.audio_url">含音频</text> -->
						</view>
						<image
							@click.stop="pauseIt(item.goods_id)"
							v-if="voivegodid == item.goods_id"
							class="shade"
							src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pause2.png"
							mode="widthFix"
						></image>
						<view class="shade" v-else @click.stop="palyIt(item.goods_id)">
							<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/triangle.png" mode="widthFix"></image>
						</view>
					</navigator>
				</block>
			</view>
		</view>
		<button class="palyall" v-if="playState == 0" type="primary" @click="judge()" :disabled="disabled">播放全部音频</button>
		<button class="palyall" v-if="playState == 1" type="primary" @click="judge()" :disabled="disabled">暂停</button>
		<button class="palyall" v-if="playState == 2" type="primary" @click="judge()" :disabled="disabled">继续</button>
		<view class="message" v-if="nojoin">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="hopop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/addjoin.png" mode=""></image>
				<view class="poptitle">{{ poptitle }}</view>
				<view class="subhead">{{ subhead }}</view>
				<button type="primary" class="addjoin" v-if="ctivate" @click="addactivate()">立即激活</button>
				<button type="primary" class="addjoin" v-else @click="addjoin()">立即加入</button>
			</view>
		</view>

		<view class="flocon" v-if="classon">{{ classoninfo }}</view>

		<view id="scrollToTop" class="to-top" :class="{ hide: hide }" @click="gotop"><image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image></view>

		<goCar :carnum="goodsnum"></goCar>
		<!-- 测试用 -->
		<PlayList @updateVoivefodid="updateVoivefodid" ref="PlayList" v-if="isshowPlayList"></PlayList>
	</view>
</template>

<script>
let innerAudioContext = '';
import Vue from 'vue';
import goCar from '@/components/car.vue';
import listCell from '@/components/title-top';
import PlayList from './PlayList.vue';
export default {
	data() {
		return {
			msg: '',
			poptitle: '加入会员畅听无阻',
			subhead: '加入会员即可享受专业1对1书单推荐',
			ctivate: false,
			nojoin: false, //加入会员弹框
			hotmain: [],
			type: 0,
			page: 1,
			hide: true,
			classon: false, //判断模态框
			classoninfo: '正在努力加载...', //加载展示内容
			audioPlaySrc: 0, //当前播放的歌曲index
			audioWay: 0, //播放方式 0顺序播放 1随机播放 2单曲循环
			playState: 0, //播放状态
			disabled: false,
			voivegodid: -1, // 当前播放的音频
			indicator: true, //是否显示指示点
			interval: 5000, //自动切换时间间隔
			duration: 400, //滑动动画时长
			autoplay: true, //是否自动切换
			circular: true, //是否采用衔接滑动
			infolist: {
				type: 'voicelist',
				listid: '',
				listplays: ''
			},
			goodsnum: '',
			isshowPlayList: false
		};
	},
	components: {
		listCell,
		goCar,
		PlayList
	},
	mounted: function() {
		this.audioPlaySrc = 0;
		// this.audioInit()
	},
	onReachBottom() {
		this.scroll();
	},
	// 实时获取滚动的值，到一定位置显示返回顶部
	onPageScroll: function(Object) {
		if (Object.scrollTop > 800) {
			this.hide = false;
		} else {
			this.hide = true;
		}
		if (this.classoninfo == '我也是有底线的哦~') {
			this.classon = false;
		}
	},
	onShow() {
		this.queryPlayList();
		if (Vue.prototype.$innerAudioContext && !Vue.prototype.$innerAudioContext.paused) {
			// 如果有正在播放的音乐
			this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
			this.playState = 1;
			this.$refs.PlayList.isPlayState = true;
		} else {
			this.voivegodid = -1;
			this.playState = 0;
			if (this.isshowPlayList) {
				this.$refs.PlayList.isPlayState = false;
			}
		}
		// this.innerAudioContext = uni.createInnerAudioContext();
		// console.log(Vue.prototype.$innerAudioContext, this.catid);
		// if (uni.getStorageSync('innerAudioContext').indexid == this.catid) {
		// 	this.playState = uni.getStorageSync('innerAudioContext').indexplayState;
		// } else if (uni.getStorageSync('innerAudioContext').listid == this.catid) {
		// 	this.playState = uni.getStorageSync('innerAudioContext').listplays;
		// } else {
		// 	this.playState = 0;
		// 	this.infolist.catid = this.catid;
		// 	this.infolist.listplays = this.playState;
		// 	console.log(this.infolist);
		// }
	},
	onLoad: function(options) {
		this.queryPlayList();
		if (Vue.prototype.$innerAudioContext && !Vue.prototype.$innerAudioContext.paused) {
			// 如果有正在播放的音乐
			this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
			this.playState = 1;
		} else {
			this.playState = 0;
		}
		console.log(options, 'options');
		this.msg = options.cat_name;
		this.catid = options.cat_id;

		this.$api.quest(
			'goods/getpicturebook',
			{
				page: 1,
				cate: options.cat_id,
				type: 2,
				size: 30
			},
			res => {
				console.log(res);
				this.hotmain = res.data.data;
			}
		);
		this.timer = setInterval(() => {
			this.$store.commit('getgoodsnum', uni.getStorageSync('total_number'));
			this.goodsnum = uni.getStorageSync('total_number');
		}, 500);
	},
	methods: {
		// 查询播放列表是否为空
		queryPlayList(isPlay) {
			if (this.$store.state.music.Playlist.length > 0) {
				this.isshowPlayList = true;

				setTimeout(() => {
					this.$refs.PlayList.updateList();
				}, 500);
				if (isPlay) {
					setTimeout(() => {
						//必须子组件完全渲染处理完成后才能调
						// console.log(this.playState,'ddddd')
						this.$refs.PlayList.Play();
						this.playState = 1;
						this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
					}, 500);
				}
			} else {
				this.isshowPlayList = false;
			}
		},
		updateVoivefodid(isId) {
			// 更新当前正在播放的音频的id
			if (isId !== -1) {
				this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
			} else {
				this.voivegodid = isId;
				this.playState = 0;
			}
		},
		// 加入播放列表
		addPlayList(item) {
			if (item.audio_url) {
				this.$store.commit('addPlaylist', item);
				uni.showToast({
					title: '添加成功',
					icon: 'none',
					duration: 200
				});
				this.queryPlayList(false);
				console.log(this.$store.state.music.Playlist);
			} else {
				uni.showToast({
					title: '此绘本无音频',
					icon: 'none',
					duration: 2000
				});
			}
		},
		// 暂停这一首
		pauseIt() {
			this.playState = 0;
			this.voivegodid = -1;
			// Vue.prototype.$innerAudioContext.destroy();
			Vue.prototype.$innerAudioContext.pause();
		},
		//播放这一首
		palyIt(id) {
			uni.navigateTo({
				url: './voicedetail?id=' + id + '&isPay=true'
			});
		},
		// 返回顶部
		gotop() {
			uni.pageScrollTo({
				scrollTop: 0,
				duration: 300
			});
		},
		// 下拉加载
		scroll() {
			const that = this;
			that.classon = true;
			this.loadingType = 1;
			this.$api.quest(
				'goods/getpicturebook',
				{
					page: ++that.page,
					cate: this.catid,
					type: 2,
					size: 30
				},
				res => {
					// console.log(res,'1')
					// console.log(res.data.data)
					if (res.data.data.length == 0) {
						//没有数据
						this.loadingType = 2;
						that.classon = true;
						that.classoninfo = '我也是有底线的哦~';
						uni.hideNavigationBarLoading(); //关闭加载动画
					} else {
						that.hotmain.push(...res.data.data);
						// console.log(that.orderList,"w")
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false; //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
						// this.loading = true
					}
				}
			);
		},
		judge() {
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				this.playAll();
			} else if (uni.getStorageSync('no_apply') !== 0) {
				// 判断有没有待激活的卡
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活会员 激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
		},
		// 播放全部
		playAll() {
			if (this.playState == 2) {
				// 当前有音频正在暂停中
				Vue.prototype.$innerAudioContext.play();
				this.$refs.PlayList.isPlayState = true; // 不经过播放列表来控制 播放列表中的播放状态需要同步
				this.voivegodid = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id;
				this.playState = 1;
			} else if (this.playState == 1) {
				// 正在播放
				Vue.prototype.$innerAudioContext.pause(); // 如何暂停  销不销毁掉？？？？？？
				this.$refs.PlayList.isPlayState = true;
				this.playState = 2;
				this.voivegodid = -1;
			} else {
				// 无音频 开始播放全部
				this.hotmain.forEach((item, index) => {
					if (item.audio_url) {
						this.$store.commit('addPlaylist', item);
					}
				});
				this.queryPlayList(true);
			}
		},
		// 关闭弹框
		close() {
			console.log('关闭弹框');
			this.nojoin = false;
		},
		// 跳转加入会员
		addjoin() {
			this.nojoin = true;
			uni.navigateTo({
				url: '/pages/index/addjoin'
			});
		}
	}
};
</script>

<style lang="scss">
@import '../../static/css/index.scss';

.bookinfo > text {
	margin-bottom: 5rpx !important;
}

.pagehot {
	/* #ifdef MP  */
	margin-top: 108rpx;
	/* #endif */
	/* #ifdef H5  */
	margin-top: 20rpx;
	/* #endif */
}

// 不是会员加入会员
.message {
	width: 100vw;
	height: 100vh;
	position: fixed;
	top: 0;
	left: 0;
	background: rgba(0, 0, 0, 0.5);
	z-index: 9;

	.close {
		position: absolute;
		width: 30rpx;
		height: 30rpx;
		top: 25%;
		right: 50rpx;
	}

	.hopop {
		width: 488rpx;
		height: 628rpx;
		background: #fff;
		position: absolute;
		top: 30%;
		left: 50%;
		margin-left: -244rpx;
		border-radius: 24rpx;
		z-index: 4;
		text-align: center;

		image {
			width: 378rpx;
			height: 318rpx;
			margin: 35rpx auto 20rpx auto;
		}

		> .poptitle {
			font-size: 34rpx;
			color: #ff824b;
			letter-spacing: 1rpx;
			margin-bottom: 10rpx;
		}

		.subhead {
			font-size: 26rpx;
			color: #666;
			margin-bottom: 47rpx;
		}

		.addjoin {
			padding: 0;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			width: 408rpx;
			line-height: 88rpx;
			border-radius: 49rpx;
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			font-size: 32rpx;
			color: #fff;
		}
	}
}

.palyall {
	position: fixed;
	bottom: 0;
	background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
	width: 750rpx;
	line-height: 98rpx;
	border-radius: 0;
	font-size: 32rpx;
	color: #fff;
}

.flocon {
	position: fixed;
	bottom: 120rpx;
	left: 50%;
	transform: translate(-50%, 0);
	font-size: 26rpx;
	color: #999999;
	text-align: center;
}

.block {
	position: relative;

	.hot_main_con {
		.topleftcorner {
			position: absolute;
			top: 0;
			left: 0;
			width: 84rpx;
			height: 36rpx;
			background: -webkit-linear-gradient(315deg, #ffa57f 0%, #ff5252 100%);
			background: linear-gradient(135deg, #ffa57f 0%, #ff5252 100%);
			border-radius: 10rpx 0 20rpx 0;
			color: #fff;
			font-size: 20rpx;
			text-align: center;
			line-height: 36rpx;
		}
	}

	.shade {
		position: absolute;
		top: 40%;
		left: 50%;
		transform: translate(-50%, -50%);
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
		background: rgba(0, 0, 0, 0.5);

		image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			width: 50rpx;
		}
	}
}
</style>
