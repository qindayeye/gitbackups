<template>
	<view class="container">
		<view class="carousel"><image :src="list.goods_thumb" class="loaded" mode=""></image></view>
		<!-- 视频 -->
		<view class="tvideo" v-if="list.video_url">
			<video
				id="Tvideo"
				:src="list.video_url"
				style="width: 750rpx"
				@play="videoPlay()"
				@pause="videoPause()"
				:show-center-play-btn="false"
				:show-fullscreen-btn="true"
				:show-play-btn="true"
				:custom-cache="false"
				direction="90"
			></video>

			<!-- show-fullscreen-btn   是否全屏 -->
			<!-- show-play-btn   是否显示视频底部控制栏的播放按钮 -->
			<!-- show-center-play-btn 是否显示视频中间的播放按钮 -->
		</view>
		<!-- 视频上层的蒙版 -->
		<view class="masking" v-if="playTV" @click="cli()"></view>
		<!-- 如果有视频,进度条消失 -->
		<view class="lineBar" v-if="!list.video_url">
			<view class="time star">{{ nowmiaoForc }}</view>
			<slider class="line" :value="nowmiao" min="0" :max="allmiao" @change="sliderChange" block-color="#FEA364" block-size="11" activeColor="#FEA364" />
			<view class="time end">{{ allmiaoForc }}</view>
		</view>

		<!-- <view class="introduce-section">
			<text class="title">{{list.goods_name}}</text>
			<text class="brief">{{list.goods_brief}}</text>
		</view> -->
		<view class="introduce-section">
			<text class="title">{{ list.goods_name }}</text>
			<view class="label">
				<text v-for="(item, index) in categoryArr" :key="index">{{ item.cat_name }}</text>
			</view>
			<!-- 商品简介 -->
			<text class="brief">{{ list.goods_brief }}</text>

			<view class="information">
				<view class="tt" v-if="list.author">
					<text>作 者：</text>
					<text>{{ list.author }}</text>
				</view>
				<view class="tt" v-if="list.publisher">
					<text>出版社：</text>
					<text>{{ list.publisher }}</text>
				</view>
			</view>
		</view>

		<!-- 点击暂停开始 -->
		<view @click="play" class="play" v-if="!list.video_url">
			<image v-if="!playState" class="iconbtn play" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/play1.png"></image>
			<image v-if="playState" class="iconbtn play" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pause2.png"></image>
		</view>

		<view class="detail-desc"><rich-text :nodes="desc | formatRichText" class="imgdetail"></rich-text></view>

		<!-- <uni-evaluate :list-data="listev" :rate="reted"/> -->
		<!-- 底部操作菜单 -->
		<view class="page-bottom" :class="{ isIphoneX: isIphoneX }">
			<!-- #ifdef MP -->
			<button class="service" open-type="contact">
				<image src="https://www.abcbook2019.com/mobile/public/img/service.png" mode=""></image>
				<text>联系客服</text>
			</button>
			<!-- #endif -->
			<!-- #ifdef H5 -->
			<view @click="bookshelf" open-type="switchTab" class="p-b-btn">
				<text class="yticon icon-gouwuche"></text>
				<text>书架</text>
			</view>
			<!-- #endif -->
			<view class="p-b-btn" @click="toFavorite(list.goods_id)">
				<image
					:src="is_collect ? 'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/collect-j.png' : 'http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/collect-h2.png'"
					mode=""
				></image>
				<text>收藏</text>
			</view>
			<view class="action-btn-group">
				<button :class="addbtn == '加入书架' ? 'action-btn no-border add-cart-btn' : 'hbtn'" @click="addBook()">{{ addbtn }}</button>
			</view>
		</view>
		<view class="message" v-if="nojoin">
			<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
			<view class="hopop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/addjoin.png" mode=""></image>
				<view class="poptitle">{{ poptitle }}</view>
				<view class="subhead">{{ subhead }}</view>
				<button type="primary" class="addjoin" v-if="ctivate" @click="addactivate()">立即激活</button>
				<button type="primary" class="addjoin" v-else @click="addjoin()">立即加入</button>
			</view>
		</view>
	</view>
</template>

<script>
let innerAudioContext = '';
import Vue from 'vue';
import share from '@/components/share';
import uniEvaluate from '@/components/xiujun-evaluate/uni-evaluate.vue';
export default {
	components: {
		share,
		uniEvaluate
	},
	data() {
		return {
			controls: false,
			poptitle: '加入会员畅听无阻',
			subhead: '加入会员即可享受专业1对1书单推荐',
			ctivate: false,
			isIphoneX: false,
			screenWidth: 750,
			nojoin: false, //加入会员弹框
			nowmiao: 0, //当前时间
			allmiao: 0, //全部时间
			lineBarWid: 520, //进度条的宽度跟css一只
			playState: 0, //播放状态
			list: {},
			hotmain: [],
			is_collect: false,
			addbtn: '加入书架',
			categoryArr: [],
			desc: ``,
			goods_id: 0,
			playTV: false
		};
	},
	onReady: function(res) {
		// 创建视频
		this.videoContext = uni.createVideoContext('Tvideo');
	},
	// 分享
	onShareAppMessage(res) {
		if (res.from === 'button') {
			// 来自页面内分享按钮
			// console.log(res.target);
		}
		return {
			title: 'ABCbook国际亲子阅读',

			path: '/pages/detail/detail?id=' + id
		};
	},
	onShow() {
		uni.getSystemInfo({
			success: res => {
				// console.log('手机信息res' + res.model);
				let modelmes = res.model;
				if (modelmes.search('iPhone X') != -1) {
					// console.log('1111');
					this.isIphoneX = true;
				}
			}
		});
	},
	onLoad(option) {
		if (Vue.prototype.$innerAudioContext) {
			if (this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id == option.id) {
				innerAudioContext = Vue.prototype.$innerAudioContext;
				innerAudioContext.obeyMuteSwitch = false;
				this.playState = 1;
				Vue.prototype.$innerAudioContext.onEnded(() => {
					// this.nextPlay()
					this.playState = 0;
					this.nowmiao = 0;
					uni.setStorageSync('voivegodid', 0);
					console.log('结束额');
					// innerAudioContext.destroy(); // 不能销毁  继续走播放列表中的方法
					// innerAudioContext = '';
					// delete Vue.prototype.$innerAudioContext
				});
				innerAudioContext.onTimeUpdate(e => {
					this.nowmiao = Math.floor(innerAudioContext.currentTime);
				});
				this.allmiao = Math.floor(innerAudioContext.duration);
			}
		}
		var that = this;
		var id = option.id;
		this.$api.quest(
			'goods/detail',
			{
				id: id
			},
			res => {
				this.list = res.data.data.goods_info;
				// console.log(that.list, 'list')
				this.goods_id = this.list.goods_id;
				that.addbtn = that.list.cat_status == 1 ? '已加入书架' : that.list.goods_number == 0 ? '暂无库存' : '加入书架';
				that.playTV = that.list.video_url ? true : false;

				that.categoryArr = that.list.category;
				that.is_collect = that.list.is_collect ? true : false;
				if (that.list.goods_desc.indexOf('style="float:none;"') > 0) {
					var str = that.list.goods_desc.replace('style="float:none;"', '');
					var reg = new RegExp('style="float:none;"', 'gi');
					var a = str.replace(reg, '');
					// console.log(a, 'desc');
					that.desc = a.replace(/<img/gi, '<img style="float:left !important;width:100%;padding:0;height:auto;display:block"');
				} else {
					that.desc = that.list.goods_desc.replace(/<img/gi, '<img style="float:left !important;width:100%;padding:0;height:auto;display:block"');
				}
				if (option.isPay) {
					that.play();
				}
			}
		);
	},
	mounted: function() {
		this.audioPlaySrc = 0;
	},
	computed: {
		width: function() {
			return 'width:' + (this.nowmiao / this.allmiao) * this.lineBarWid + 'upx';
		},
		playWidth: function() {
			return 'transform:translate3d(' + (this.nowmiao / this.allmiao) * this.lineBarWid + 'upx,0,0);';
		},
		nowmiaoForc: function() {
			return this.$pubFuc.secondFormact(this.nowmiao);
			console.log(this.nowmiao);
		},
		allmiaoForc: function() {
			return this.$pubFuc.secondFormact(this.allmiao);
		}
		// bgStyle:function (){
		// 	// return 'background-image:url('+this.audioList[this.audioPlaySrc].img+')'
		// }
	},
	created() {
		this.screenWidth = uni.getSystemInfoSync().windowWidth;
	},
	methods: {
		// 音频加入播放列表
		addPlayList() {
			if (this.list.audio_url) {
				this.$store.commit('addPlaylist', this.list);
				this.$store.commit('setMusicIndex',this.$store.state.music.Playlist.length-1)
				console.log(this.$store.state.music.Playlist);
				console.log(this.$store.state.music.music_index)
			} else {
				uni.showToast({
					title: '此绘本无音频',
					icon: 'none',
					duration: 2000
				});
			}
		},
		TvPaly() {
			// 监听视频播放
			this.playTV = false;
		},
		// 点击遮罩弹加入会员  判断是否是会员 如果是会员 执行播放，不是会员弹加入会员
		cli() {
			if (uni.getStorageSync('user_ranks') > 1) {
				this.play();
			} else {
				this.nojoin = true;
			}
		},
		videoPlay() {
			// 监听播放
			this.playState = 1;

			this.playTV = false;
			console.log('播放');
			if (Vue.prototype.$innerAudioContext) {
				Vue.prototype.$innerAudioContext.destroy();
				uni.setStorageSync('innerAudioContext', {});
				// uni.clearStorageSync()
			}
		},
		videoPause() {
			// 监听暂停
			this.playState = 0;
			// console.log('暂停');
		},
		playFunc() {
			this.playState = 1;
		},
		pauseFunc() {
			this.playState = 0;
		},
		audioInit() {
			// console.log(this.list);
			if (Vue.prototype.$innerAudioContext) {// 如果有音频在放？（不确定，稍后改）
			console.log(this.$store.state.music.Playlist,this.$store.state.music.music_index)
			let playMusicId = this.$store.state.music.Playlist[this.$store.state.music.music_index].goods_id
				// console.log(uni.getStorageSync('voivegodid'), this.goods_id, '对比');
				if (playMusicId == this.goods_id) {
					// console.log('当前有播放id==googsid');
					if (this.playState) {
						//暂停
						uni.setStorageSync('voivegodid', '');
						this.playState = 0;
						Vue.prototype.$innerAudioContext.pause();
					} else {
						//播放
						uni.setStorageSync('voivegodid', this.goods_id);
						this.playState = 1;
						Vue.prototype.$innerAudioContext.play();
					}
				} else {
					// console.log('有音频但不一样 先清空 在播放');
					Vue.prototype.$innerAudioContext.destroy();
					uni.setStorageSync('voivegodid', '');
					// Vue.prototype.$innerAudioContext?:''
					this.createInner();
				}
			} else {
				console.log('当前没有播放音频，需要新建');
				this.createInner();				
			}
		},
		sliderChange(e) {
			this.nowmiao = e.detail.value;
			innerAudioContext.seek(this.nowmiao);
		},
		createInner() {
			let src = this.list.audio_url;
			uni.setStorageSync('voivegodid', this.list.goods_id);
			innerAudioContext = uni.createInnerAudioContext();
			innerAudioContext.obeyMuteSwitch = false;
			Vue.prototype.$innerAudioContext = innerAudioContext;
			innerAudioContext.src = src;
			innerAudioContext.play();
			this.addPlayList();
			this.playState = 1;
			innerAudioContext.onTimeUpdate(e => {
				this.nowmiao = Math.floor(innerAudioContext.currentTime);
			});
			let dura = setInterval(() => {
				// console.log(innerAudioContext.duration, ';;;');
				this.allmiao = Math.floor(innerAudioContext.duration);
				// console.log(this.allmiao);
				if (this.allmiao) {
					clearInterval(dura);
				}
				uni.setStorageSync('nowmiao', this.nowmiao);
			}, 1000);
			innerAudioContext.onEnded(() => {
				// this.nextPlay()
				this.playState = 0;
				this.nowmiao = 0;
				uni.setStorageSync('voivegodid', '');
				console.log('结束额');
				innerAudioContext.destroy();
				innerAudioContext = '';
				delete Vue.prototype.$innerAudioContext;
			});
		},
		// 关闭弹框
		close() {
			console.log('关闭弹框');
			this.nojoin = false;
		},
		// 跳转加入会员
		addjoin() {
			this.nojoin = true;
			uni.navigateTo({
				url: '/pages/index/addjoin'
			});
		},
		play() {
			// 播放之前判断是不是会员
			console.log(uni.getStorageSync('user_ranks'), 'e');
			if (uni.getStorageSync('user_ranks') > 1) {
				console.log('点击play');
				if (this.list.video_url) {
					// 如果视频存在
					if (Vue.prototype.$innerAudioContext) {
						// 如果啊有音乐正在播放
						Vue.prototype.$innerAudioContext.destroy();
						delete Vue.prototype.$innerAudioContext;
						innerAudioContext = '';
						uni.removeStorageSync('innerAudioContext');
						uni.setStorageSync('voivegodid', '');
						this.playState = 0;
					} else {
						if (this.playState) {
							//暂停
							console.log('点击暂停');
							this.videoContext.pause();
						} else {
							//播放
							console.log('播放');
							this.videoContext.play();
						}
					}
				} else if (this.list.audio_url) {
					this.audioInit();
				}
			} else if (uni.getStorageSync('no_apply') !== 0) {
				// 判断有没有待激活的卡
				this.ctivate = true;
				this.poptitle = '激活会员畅听无阻';
				this.subhead = '您有待激活会员 激活后即可开启有声绘本';
				this.nojoin = true;
			} else {
				this.nojoin = true;
			}
		},

		collectFunc() {
			this.collect = !this.collect;
		},

		gohome() {
			this.$store.commit('change_page', 0);
			uni.reLaunch({
				url: `/pages/index/index`
			});
		},
		bookshelf() {
			uni.reLaunch({
				url: `/pages/bookrack/bookrack`
			});
		},
		paycheckout(id) {
			let goid = id;
			this.$api.quest('user/address/list', {}, res => {
				console.log(res, 'res');
				this.$api.quest(
					'cart/addmember',
					{
						id: id,
						num: 1,
						uid: uni.getStorageSync('user_id'),
						attr_id: 1,
						act_id: 30,
						rec_type: 10,
						flow_type: 10,
						extension_code: 'virtual_card',
						is_checked: 1
					},
					res => {
						// console.log(res, 'res');
						if (res.data.code == 0) {
							uni.navigateTo({
								url: '/pages/flow/member?goid=' + goid
							});
						} else if (res.data.data.error) {
							this.$store.commit('change_page', 4);
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua);
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log('公众号');
								uni.navigateTo({
									url: '/pages/public/login'
								});
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								});
							}
							// #endif

							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							});
							// #endif
						}
					}
				);
			});
		},
		addBook() {
			this.$api.quest(
				'cart/add',
				{
					id: this.goods_id,
					num: 1,
					uid: uni.getStorageSync('user_id'),
					attr_id: 1,
					rec_type: 0,
					is_checked: 1,
					act_id: 0
				},
				res => {
					console.log(res, 'res');
					if (res.data.data.error == 1) {
						// #ifdef MP
						uni.redirectTo({
							url: '/pages/public/login'
						});
						// #endif

						// #ifdef H5
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						});
						// #endif
					} else {
						if (res.data.code == 0) {
							uni.showToast({
								title: '加入成功',
								icon: 'none',
								duration: 2000
							});
							this.addbtn = res.data.data.cat_status == 1 ? '已加入书架' : res.data.data.real_number == 0 ? '暂无库存' : '加入书架';
							uni.setStorageSync('total_number', res.data.data.total_number);
						} else {
							uni.showToast({
								title: res.data.data,
								icon: 'none',
								duration: 2000
							});
						}
					}
				}
			);
		},
		//分享
		// share(){
		// 	this.$refs.share.toggleMask();
		// },
		//收藏
		toFavorite(id) {
			if (uni.getStorageSync('token')) {
				this.$api.quest(
					'user/collect/add',
					{
						id: id,
						uid: uni.getStorageSync('user_id')
					},
					res => {
						if (res.data.data == 1) {
							this.is_collect = !this.is_collect;
						}
					}
				);
			} else {
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua);
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log('公众号');
					uni.navigateTo({
						url: '/pages/public/login'
					});
				} else {
					uni.navigateTo({
						url: '/pages/public/registerSJ'
					});
				}
				// #endif

				// #ifdef MP
				uni.navigateTo({
					url: '/pages/public/login'
				});
				// #endif
			}
		}
	},
	filters: {
		/**
		 * 处理富文本里的图片宽度自适应
		 * 1.去掉img标签里的style、width、height属性
		 * 2.img标签添加style属性：max-width:100%;height:auto
		 * 3.修改所有style里的width属性为max-width:100%
		 * 4.去掉<br/>标签
		 * @param html
		 * @returns {void|string|*}
		 */
		formatRichText(html) {
			//控制小程序中图片大小
			let newContent = html.replace(/<img[^>]*>/gi, function(match, capture) {
				match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
				match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
				match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
				return match;
			});
			newContent = newContent.replace(/style="[^"]+"/gi, function(match, capture) {
				match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi, 'max-width:100%;');
				return match;
			});
			newContent = newContent.replace(/<br[^>]*\/>/gi, '');
			newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:10rpx"');
			return newContent;
		}
	}
};
</script>

<style lang="scss" scoped>
/* @import '../../static/css/public.scss'; */
/* @import '../../../static/public.scss'; */
.isIphoneX{
		height: 118rpx !important;
		padding-bottom: 20rpx;
	}
	.hbtn {
		// width: 329rpx;
		line-height: 98rpx;
		border-radius: 0;
		background: #e6e6e6;
		color: #fff;
	}
/*不是会员加入会员*/
.message {
	width: 100vw;
	height: 100vh;
	position: fixed;
	top: 0;
	left: 0;
	background: rgba(0, 0, 0, .5);
	z-index: 9999;

	.close {
		position: absolute;
		width: 30rpx;
		height: 30rpx;
		top: 25%;
		right: 50rpx;
	}

	.hopop {
		width: 488rpx;
		height: 628rpx;
		background: #fff;
		position: absolute;
		top: 30%;
		left: 50%;
		margin-left: -244rpx;
		border-radius: 24rpx;
		z-index: 4;
		text-align: center;

		image {
			width: 378rpx;
			height: 318rpx;
			margin: 35rpx auto 20rpx auto;
		}

		>.poptitle {
			font-size: 34rpx;
			color: #FF824B;
			letter-spacing: 1rpx;
			margin-bottom: 10rpx;
			font-weight:bold;
		}

		.subhead {
			font-size: 26rpx;
			color: #666;
			margin-bottom: 35rpx;
		}

		.addjoin {
			padding: 0;
			background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
			width: 408rpx;
			line-height: 100rpx;
			border-radius: 49rpx;
			box-shadow: 0rpx 4rpx 8rpx 0rpx rgba(255, 130, 75, 0.5);
			font-size: 32rpx;
			color: #fff;
			margin-bottom: 35rpx;
		}
	}
}

.play {
	z-index: 9999;
	position: fixed;
	right: 20rpx;
	top: 330rpx;

	image {
		width: 80rpx;
		height: 80rpx;
	}
}

.tvideo {
	background-color: #fff;
	z-index: 999;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 500rpx;
	display: flex;
	justify-content: center;
	align-items: center;
}

.masking {
	z-index: 9998;
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 500rpx;
	/* border: red solid 1rpx; */
}

.lineBar {
	display: flex;
	padding: 20upx;
	justify-content: space-between;
	background: #fff;

	.time{
		font-size:24rpx;
		font-family:PingFangSC-Medium,PingFang SC;
		font-weight:500;
		color:rgba(51,51,51,1);
	}
	.line {
		margin: 0;
		width: 520upx;
	}
}

.container {
	width: 100%;
	display: flex;
	flex-direction: column;
	margin-bottom: 60upx;
}

.carousel {
	width: 100%;
	height: 500rpx;
	display: flex;
	flex-direction: column;
	align-items: center;

}

/* 标题简介 */
.introduce-section {
	background: #fff;
	padding: 30upx 30upx;
	box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(0, 0, 0, 0.1);
	margin-bottom: 20rpx;
	/* 价格 */
	.price{
		margin-bottom: 14rpx;
		text:first-child{
			color: #E02020;
			font-size: 46rpx;
			font-weight: 600;
			&::before{
				display: inline-block;
				content: '￥';
				color: #E02020;
				font-size: 32rpx;
			}
		}
		text:nth-child(2){
			color: #999;
			font-size: 28rpx;
			margin-left: 20rpx;
			text-decoration: line-through;
			&::before{
				display: inline-block;
				content: '￥';
				color: #999;
				font-size: 20rpx;
			}
		}
	}
	/* 标题 */
	.title {
		font-size: 30upx;
		color: $font-color-dark;
		line-height: 30upx;
		width: 690rpx;
		display: block;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		color: #333;
		font-weight: bold;

	}
	/* 标签 */
	.label{
		margin-top: 10rpx;
		text{
			display: inline-block;
			background::rgba(255,130,75,0.2);
			color:#FF824B;
			font-size: 24rpx;
			padding: 0 15rpx;
			line-height: 28rpx;
			margin-right: 10rpx;
			margin-bottom: 20rpx;
			border-radius:4rpx;
			&:first-child{

				background:rgba(255,205,120,0.2);
				color:#FFA24B;
			}
		}

	}
	/* 作者,出版社 */
	.information{
		line-height: 40rpx;
		color: #666;
		font-size: 26rpx;
		margin-top: 20rpx;
		/* font-weight: 900; */
		.tt{
			text:first-child{
				word-spacing: 19rpx;
				font-size: 28rpx;
			}

		}
		text{
			font-weight: normal;
		}
	}
	.brief {
		width: 690rpx;
		font-size: 24rpx;
		color: #999;
		line-height: 36rpx;
		display: -webkit-box;
		overflow: hidden;
		-webkit-box-orient: vertical;
		text-overflow: ellipsis;
		-webkit-line-clamp: 2;
	}

	.price-box {
		display: flex;
		align-items: baseline;
		height: 64upx;
		padding: 10upx 0;
		font-size: 26upx;
		color: $uni-color-primary;
	}

	.price {
		font-size: $font-lg + 2upx;
	}

	.m-price {
		margin: 0 12upx;
		color: $font-color-light;
		text-decoration: line-through;
	}

	.coupon-tip {
		align-items: center;
		padding: 4upx 10upx;
		background: $uni-color-primary;
		font-size: $font-sm;
		color: #fff;
		border-radius: 6upx;
		line-height: 1;
		transform: translateY(-4upx);
	}

	.bot-row {
		display: flex;
		align-items: center;
		height: 50upx;
		font-size: $font-sm;
		color: $font-color-light;

		text {
			flex: 1;
		}
	}
}


/* 分享 */
.share-section {
	display: flex;
	align-items: center;
	color: $font-color-base;
	background: linear-gradient(left, #fdf5f6, #fbebf6);
	padding: 12upx 30upx;

	.share-icon {
		display: flex;
		align-items: center;
		width: 70upx;
		height: 30upx;
		line-height: 1;
		border: 1px solid $uni-color-primary;
		border-radius: 4upx;
		position: relative;
		overflow: hidden;
		font-size: 22upx;
		color: $uni-color-primary;

		&:after {
			content: '';
			width: 50upx;
			height: 50upx;
			border-radius: 50%;
			left: -20upx;
			top: -12upx;
			position: absolute;
			background: $uni-color-primary;
		}
	}

	.icon-xingxing {
		position: relative;
		z-index: 1;
		font-size: 24upx;
		margin-left: 2upx;
		margin-right: 10upx;
		color: #fff;
		line-height: 1;
	}

	.tit {
		font-size: $font-base;
		margin-left: 10upx;
	}

	.icon-bangzhu1 {
		padding: 10upx;
		font-size: 30upx;
		line-height: 1;
	}

	.share-btn {
		flex: 1;
		text-align: right;
		font-size: $font-sm;
		color: $uni-color-primary;
	}

	.icon-you {
		font-size: $font-sm;
		margin-left: 4upx;
		color: $uni-color-primary;
	}
}

.c-list {
	font-size: $font-sm + 2upx;
	color: $font-color-base;
	background: #fff;

	.c-row {
		display: flex;
		align-items: center;
		padding: 20upx 30upx;
		position: relative;
	}

	.tit {
		width: 140upx;
	}

	.con {
		flex: 1;
		color: $font-color-dark;

		.selected-text {
			margin-right: 10upx;
		}
	}

	.bz-list {
		height: 40upx;
		font-size: $font-sm+2upx;
		color: $font-color-dark;

		text {
			display: inline-block;
			margin-right: 30upx;
		}
	}

	.con-list {
		flex: 1;
		display: flex;
		flex-direction: column;
		color: $font-color-dark;
		line-height: 40upx;
	}

	.red {
		color: $uni-color-primary;
	}
}

/* 评价 */
.eva-section {
	display: flex;
	flex-direction: column;
	padding: 20upx 30upx;
	background: #fff;
	margin-top: 16upx;

	.e-header {
		display: flex;
		align-items: center;
		height: 70upx;
		font-size: $font-sm + 2upx;
		color: $font-color-light;

		.tit {
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			margin-right: 4upx;
		}

		.tip {
			flex: 1;
			text-align: right;
		}

		.icon-you {
			margin-left: 10upx;
		}
	}
}

.eva-box {
	display: flex;
	padding: 20upx 0;

	.portrait {
		flex-shrink: 0;
		width: 80upx;
		height: 80upx;
		border-radius: 100px;
	}

	.right {
		flex: 1;
		display: flex;
		flex-direction: column;
		font-size: $font-base;
		color: $font-color-base;
		padding-left: 26upx;

		.con {
			font-size: $font-base;
			color: $font-color-dark;
			padding: 20upx 0;
		}

		.bot {
			display: flex;
			justify-content: space-between;
			font-size: $font-sm;
			color: $font-color-light;
		}
	}
}

/*  详情 */

.detail-desc {
	width: 100%;
	background: #fff;
	padding: 20upx 30upx;

	img {
		width: 100%;
	}

	.imgdetail {
		width: 100%;
		text: 22upx;
		font-size: 30upx;
		line-height: 50upx;

	}

	.d-header {
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		height: 80upx;
		font-size: $font-base + 2upx;
		color: $font-color-dark;
		position: relative;

		text {
			padding: 0 20upx;
			background: #fff;
			position: relative;
			z-index: 1;
		}

		&:after {
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translateX(-50%);
			width: 300upx;
			height: 0;
			content: '';
			border-bottom: 1px solid #ccc;
		}
	}
}

/* 底部操作菜单 */
.page-bottom {
	position: fixed;
	left: 0;
	bottom: 0upx;
	z-index: 95;
	display: flex;
	justify-content: space-around;
	align-items: center;
	width: 750upx;
	height: 99upx;
	background: #FFFFFF;
	box-shadow: 0 0 20upx 0 rgba(0, 0, 0, .5);
	/* border-radius: 16upx; */

	.service{
		height: 100upx;
		/* width: 96upx; */
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background: #FFFFFF;
		margin-top: 15rpx;
		image{
			width: 40rpx;
			height: 40rpx;
			margin-bottom: -5rpx;
		}
		text{
			font-size:22rpx;
			font-weight:300;
			color:#999;
		}
	}

	.p-b-btn {
		background: #FFFFFF;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		font-size: $font-sm;
		color: $font-color-base;
		width: 180upx;
		height: 80upx;
		margin-right: 8rpx;
		image{
			width: 38rpx;
			height: 38rpx;
		}
		.yticon {
			font-size: 40upx;
			line-height: 40upx;
			color: $font-color-light;
		}

		&.active,
		&.active .yticon {
			color: $uni-color-primary;
		}

		.icon-fenxiang2 {
			font-size: 42upx;
			transform: translateY(-2upx);
		}

		.icon-shoucang {
			font-size: 46upx;
		}
	}

	.action-btn-group {
	/* #ifdef MP */
		width:329rpx;
		/* #endif */
		/* #ifdef H5 */
		width:369rpx;
		/* #endif */
		background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);

		.action-btn{
				/* #ifdef MP */
			width:329rpx;
			/* #endif */
			/* #ifdef H5 */
			width:369rpx;
			/* #endif */
			color: #fff;
			font-size: 30rpx;
			line-height: 100rpx;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		}
	}
}
</style>
