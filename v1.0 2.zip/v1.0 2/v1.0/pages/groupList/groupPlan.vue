<template>
	<view class="">
		<view class="grou_header" v-if="groupdata.team_info.status==0">
			<image :src="groupdata.team_info.user_picture" mode=""></image>
			<view class="grou_header_dsc">
				<text>开团成功啦！</text>
				<text style="color: gray; font-size: 30rpx;">只差1位小伙伴参团，快点邀请好友参团</text>
			</view>
		</view> 
		<view class="grou_header" v-if="groupdata.team_info.status==1">
			<image :src="groupdata.team_info.user_picture" mode=""></image>
			<view class="grou_header_dsc">
				<text>拼团成功啦！</text>
				<text style="color: gray; font-size: 30rpx;">继续去拼团吧。</text>
			</view>
		</view>
		<view class="grou_header" v-if="groupdata.team_info.status==2">
			<image :src="groupdata.team_info.user_picture" mode=""></image>
			<view class="grou_header_dsc">
				<text>拼团失败啦！</text>
				<text style="color: gray; font-size: 30rpx;">该拼团已过期，继续去开团吧</text>
			</view>
		</view>
		<view class="goods-item-dsc" @click="Gotodetail()">
			<image :src="groupdata.team_info.goods_thumb" mode=""></image>
			<view class="goods-dsc">
				<text>{{groupdata.team_info.goods_name}}</text>
				<text style="color: gray; font-size: 30rpx;">2人团<text style="color: red; font-size: 40rpx;">{{groupdata.team_info.team_price}}</text></text>
			</view>
		</view>
		<view class="" style="background-color: #FFFFFF;margin-top: 20rpx;">
			<view class="TimeStatus" v-if="groupdata.team_info.status==0">
				剩余{{countDownList}}结束
			</view>
			<view class="TimeStatus" v-if="groupdata.team_info.status==1">
				拼团成功
			</view>
			<view class="TimeStatus" v-if="groupdata.team_info.status==2">
				拼团失败
			</view>
			<view class="grou_header">
				<view class="gou_img" v-for="img in groupdata.teamUser" :key="img.user_id">
					<image :src="img.user_picture" mode="">

					</image>
					<text class="tesm_Z" v-if="img.team_parent_id">团长</text>
				</view>
				<view class="sanD" @click="goToTeamList(team_id)">
					···
				</view>

			</view>
			<view class="barZ">
				<view class="bar">
					<text v-if="groupdata.team_info.status==0">50%</text>
					<text v-if="groupdata.team_info.status==1">100%</text>
					<text v-if="groupdata.team_info.status==2">0%</text>
				</view>
				<view class="bar_item" style="width: 50%;" v-if="groupdata.team_info.status==0">

				</view>
				<view class="bar_item" style="width: 100%;" v-if="groupdata.team_info.status==1">

				</view>
			</view>

			<!-- 拼团规则 -->
			<view class="introduce-section ">
				<view class="xian">

				</view>
				<view class="TimeStatus title">
					拼团规则
				</view>
				<view class="groupd">
					<view class="confl">
						<text class="num">1</text>
						<text>选择商品</text>
					</view>
					<view class="confl">
						<text class="num">2</text>
						<text>开团/参团</text>
					</view>
					<view class="confl">
						<text class="num">3</text>
						<text>邀请好友</text>
					</view>
					<view class="confl">
						<text class="num">4</text>
						<text>人满成团</text>
					</view>

				</view>
				<image class="imgla" @click="btn()" :src="teaminfo?'https://www.abcbook2019.com//mobile/public/img/recbooklist/jiantou_buttom.png':'https://www.abcbook2019.com//mobile/public/img/recbooklist/jiantou_top.png'"
				 mode="widthFix"></image>
			</view>
			<view class="teaminfo" v-if="teaminfo">
				<text>1.开团：在商城内选择喜欢的商品，点击“去开团”，付款成功后即为开团成功；</text>
				<text>2.参团：进入朋友分享的页面，点击“立即参团”，付款后即为参团成功，若多人同时支付，按先支付成功的用户获得参团资格，参团订单未支付不计入参团数量，团过期未支付订单失效，但参团人信息也会显示在团里面；</text>
				<text>3.成团：在开团或参团之后,可以点击“分享出去”，在有效时间凑齐成团人数即拼团成功；</text>
				<text>4.组团失败：在有效时间内未凑齐人数，即为组团失败，此时商城会将原款分别退回；</text>
			</view>
			<view class="footer_btn">
				<!-- <view class="footer_btn_left">
					更多拼团
				</view> -->
				<template v-if="groupdata.team_info.status==2||groupdata.team_info.status==1">
					<view class="footer_btn_right" @click="Gotodetail()">
						去开团
						<text>{{groupdata.team_info.team_price}}</text>
					</view>
				</template>
				<view v-else-if="Muser_id !== Tuser_id" class="footer_btn_right" @click.stop="itpaycheckout(groupdata.team_info.goods_id,groupdata.team_info.team_id)" >
					去参团
					<text>{{groupdata.team_info.team_price}}</text>
				</view>
				<template v-else>
					<view class="footer_btn_right" v-if="groupdata.team_info.status==0">
						<button style="background-color: #FF824B; height: 88rpx;" open-type="share">邀请好友参团</button>
					</view>
				</template>

			</view>
		</view>
		
	</view>

</template>

<script>
	export default {
		data() {
			return {
				team_id: "",
				Tuser_id: "", // 团长id
				Muser_id: '', // 我的id
				type: 0,
				list:{},
				teaminfo: false, //显示拼团规则详细信息
				groupdata: {},
				teamUser: [],
				countDownList: '00时00分00秒',
				actEndTime: '2019-12-08 23:17:00',
			}
		},
		onLoad: function(option) {
			if (uni.getStorageSync("token")) {
				this.Muser_id = +uni.getStorageSync("user_id")
				console.log(+this.Muser_id,"我的id")
				this.team_id = option.id
				this.Tuser_id = +option.user_id
				console.log(+this.Tuser_id,"团长id")
				console.log(+this.Tuser_id == +this.Muser_id)
				this.gotoTeamWait(option.id)
				this.getGoods()
			} else {
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					uni.navigateTo({
						url: '/pages/public/login'
					})
				
				} else {
					uni.navigateTo({
						url: '/pages/public/registerSJ'
					})
				}
				// #endif
				
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/public/login'
				})
				// #endif
			}

		},
		onShow() {
			this.$nextTick(() => {
				this.countDown();
			})
		},
		methods: {
			
			getGoods(){
				let that = this
				this.$api.quest('team/goodsDetail', {
					team_id: 0,
					goods_id: 4301
				}, (res) => {
					console.log(res, "22")
					that.list = res.data.data
					console.log(that.list)
					that.goods_id = that.list.goods_id
				})
			},
			// 检测有没正在进行中的拼团
			itpaycheckout(id, team_id) {
				let that = this
				let goid = id
				if (uni.getStorageSync("token")) {
					this.$api.quest('flow/checkteam', {
						t_id: that.list.goods_info.id,
					}, (res) => {
						console.log(res, "eee")
						if (res.data.code == 0) {
							// 没参加过了
							that.paycheckout(id, team_id)
						} else {
							console.log("参加过了")
							uni.showToast({
								title: res.data.data,
								icon: 'none',
								duration: 2000
							});
						}
					})
				} else {
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
					
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
					
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
				}

			},
			paycheckout(id, team_id) {
				let that = this
				let goid = id
				this.$api.quest('team/teamBuy', {
					goods_id: id,
					team_id: team_id,
					t_id: that.list.goods_info.id,
					num: 1,
					uid: uni.getStorageSync("user_id"),
					attr_id: 1,
					act_id: 0,
					rec_type: 6,
					extension_code: "team_buy",
					is_checked: 1
				}, (res) => {
					console.log(res, "eee")
					if (res.data.code == 0) {
						uni.navigateTo({
							url: '/pages/flow/groupmember?goid=' + goid + '&t_id=' + that.list.goods_info.id + '&team_id=' + team_id
						})
					} else if (res.data.data.error) {
						this.$store.commit("change_page", 4)
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua)
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log("公众号")
							uni.navigateTo({
								url: '/pages/public/login'
							})
						
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							})
						}
						// #endif
						
						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						})
						// #endif
					}
				})
			},
			// 进入团队列表
			goToTeamList(id) {
				uni.navigateTo({
					url: "./teamList?id=" + id
				})
			},
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			countDown(it) {
				var interval = setInterval(() => {
					// 获取当前时间，同时得到活动结束时间数组
					let newTime = parseInt(+new Date() / 1000);
					// console.log(newTime)
					// 对结束时间进行处理渲染到页面
					let endTime = new Date(this.actEndTime).getTime();
					// console.log(endTime,"end")
					let obj = null;
					// 如果活动未结束，对时间进行处理
					if (endTime - newTime > 0) {
						let time = endTime - newTime;
						// 获取天、时、分、秒
						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
					} else { // 活动已结束，全部设置为'00'
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00'
						};
						this.finished = true
						clearInterval(interval);
					}
					this.countDownList = obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
				}, 1000);
			},
			btn() {
				this.teaminfo = !this.teaminfo
			},
			// 查看进度
			gotoTeamWait(id) {
				this.$api.quest('team/teamWait', {
					team_id: id
				}, (res) => {
					console.log(res, "ww")
					this.groupdata = res.data.data
					this.actEndTime = res.data.data.team_info.end_time
					// this.loading = true
				});
			},
			// 进入详情页
			Gotodetail() {
				uni.navigateTo({
					url: "../detail/groupdetail"
				})
			},

		}
	}
</script>

<style lang="scss" scoped>
	.grou_header {
		height: 200rpx;
		width: 100%;
		display: flex;
		justify-content: flex-start;
		align-items: center;

		image {
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
			margin-left: 20rpx;

		}

		.grou_header_dsc {
			margin-left: 20rpx;
			height: 80%;
			display: flex;
			justify-content: center;
			align-items: flex-start;
			flex-direction: column;
		}
	}

	.sanD {
		width: 120rpx;
		height: 120rpx;
		border: 1rpx solid #e6e6e6;
		border-radius: 50%;
		margin-left: 20rpx;
		text-align: center;
		line-height: 120rpx;
		font-size: 50rpx;
	}

	.gou_img {
		position: relative;
	}

	.tesm_Z {
		background-color: pink;
		height: 40rpx;
		width: 80rpx;
		font-size: 28rpx;
		border: 1rpx solid #FFFFFF;
		border-radius: 25rpx;
		text-align: center;
		line-height: 40rpx;
		position: absolute;
		right: -15rpx;
		top: 0;
	}

	.goods-item-dsc {
		background-color: #FFFFFF;
		height: 200rpx;
		width: 100%;
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.goods-dsc {
			margin-left: 20rpx;
			display: flex;
			justify-content: space-around;
			align-items: flex-start;
			flex-direction: column;
		}

		image {
			width: 180rpx;
			height: 180rpx;
			margin-left: 20rpx;
		}
	}

	.TimeStatus {
		text-align: center;
		height: 80rpx;
		width: 100%;
		line-height: 80rpx;
	}

	// 进度条
	.barZ {
		position: relative;
		height: 20rpx;
		margin: 20rpx;
		border: 1rpx solid pink;
		border-radius: 2rpx;

		.bar {
			position: absolute;
			top: 0;
			left: 0;
			height: 20rpx;
			width: 100%;
			text-align: center;
			line-height: 20rpx;
			font-size: 20rpx;
			z-index: 998;

			text {
				text-align: center;
				line-height: 20rpx;
				font-size: 20rpx;
				z-index: 999;
			}

		}

		.bar_item {
			height: 20rpx;
			background-color: #FF824B;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 997;
		}
	}

	/* 标题简介 */
	.introduce-section {
		background: #fff;
		padding: 30upx 30upx;
		border-bottom: 3rpx solid #e6e6e6;
		position: relative;

		.xian {
			background-color: grey;
			height: 1rpx;
			width: 580rpx;
			position: absolute;
			top: 194rpx;
			left: 85rpx;
		}

		.groupd {
			width: 650rpx;
			display: flex;
			justify-content: space-between;
			margin: 0 auto;

			.confl {
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: space-between;
				color: #666;
				font-size: 24rpx;

				.num {
					display: block;
					width: 35rpx;
					height: 35rpx;
					/* line-height: 35rpx; */
					text-align: center;
					/* line-height: 40rpx; */
					border-radius: 50%;
					margin-bottom: 20rpx;
					border: 1rpx solid #666;
					z-index: 999;
					background-color: #ffffff;
				}
			}
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			height: 150upx;
			line-height: 150upx;
		}
	}

	.imgla {
		position: relative;
		display: block;
		/* top: 0; */
		/* top: 50%; */
		left: 50%;
		width: 20rpx;
		margin-top: 50rpx;
		transform: translate(-50%, -50%);
	}

	.teaminfo {
		background: #faf9f0;
		box-sizing: border-box;
		padding: 20rpx;

		text {
			color: #666;
			font-size: 26rpx;
			display: block;
			line-height: 30rpx;
			margin-bottom: 10rpx;
		}
	}

	.footer_btn {
		height: 88rpx;
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 99;

		.footer_btn_left {
			background-color: pink;
			width: 50%;
			height: 88rpx;
			line-height: 88rpx;
			text-align: center;
			color: #FFFFFF;
		}

		.footer_btn_right {
			background-color: #FF824B;
			width: 100%;
			height: 88rpx;
			line-height: 44rpx;
			text-align: center;
			color: #FFFFFF;
			display: flex;
			justify-content: center;
			align-items: center;
			// flex-direction: column;
		}
	}
</style>
