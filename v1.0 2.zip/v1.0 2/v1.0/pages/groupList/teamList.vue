<template>
	<view class="">
		<view class="team" v-for="item in teamList" :key="item.user_id">
			<image :src="item.user_picture" mode=""></image>
			<view class="team_item">
				<view class="team_name">
					{{item.user_name}}
				</view> 
				<view class="team_dsc">
					<text v-if="item.team_parent_id">开团时间</text>
					<text v-else>参团时间</text>
					<text>{{item.add_time}}</text>
				</view>
			</view>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				teamList: []
			}

		},
		onLoad: function(option) {
			let that = this
			this.$api.quest('team/teamWait', {
				team_id: option.id
			}, (res) => {
				console.log(res, "ww")
				this.teamList = res.data.data.teamUser.map(item => {
					// 把时间戳改为时间
					let reg = /(.*)(.)$/;
					item.add_time = that.timestampToTime(item.add_time)
					item.user_name = item.user_name.replace(reg, function(a, b, c) {
						return "**"+ c;
					});
					return item
				})

				// this.loading = true
			});
		},
		methods: {

			timestampToTime(timestamp) {
				var date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
				var Y = date.getFullYear() + '-';
				var M = ((date.getMonth() + 1) < 10) ? ('0' + (date.getMonth() + 1) + '-') : ((date.getMonth() + 1) + '.');
				var D = (date.getDate() < 10) ? ('0' + date.getDate() + ' ') : (date.getDate() + ' ');
				var h = (date.getHours() < 10) ? ('0' + date.getHours() + ':') : (date.getHours() + ':');
				var m = (date.getMinutes() < 10) ? ('0' + date.getMinutes() + ':') : (date.getMinutes() + ':');
				var s = (date.getSeconds() < 10) ? ('0' + date.getSeconds()) : (date.getSeconds());
				return Y + M + D + h + m + s;
			}
		}

	}
</script>

<style lang="scss" scoped>
	.team {
		border-top: 1rpx solid #CCCCCC;
		height: 150rpx;
		width: 100%;
		background-color: #FFFFFF;
		display: flex;
		justify-content: flex-start;
		align-items: center;

		image {
			margin-left: 20rpx;
			height: 100rpx;
			width: 100rpx;
			border-radius: 50%;
		}

		.team_item {
			margin-left: 20rpx;
			display: flex;
			justify-content: center;
			align-items: flex-start;
			flex-direction: column;

			.team_name {
				font-size: 33rpx;
			}

			.team_dsc {
				display: flex;
				justify-content: flex-start;
				align-items: center;

				text {
					font-size: 28rpx;
					color: gray;
					margin-right: 10rpx;
				}
			}
		}
	}
</style>
