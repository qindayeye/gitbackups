<template>
	<view class="content">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg" H5back='true'></listCell>
		<!-- #endif -->
		<view class="navbar">
			<text v-for="(item, index) in navList" :class="{active:tabCurrentIndex==index}" :key="index" class="nav-item" @click="tabClick(index,item.states)">
				{{item.text}}
			</text>
		</view>

		<!-- <empty v-if="orderList.length === 0"></empty> -->
		<view class="tablist" v-if="loading">
			<!-- 激活会员弹框 -->
			<view class="popup" v-if="success">
				<view class="message">
					<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/success.png" mode="widthFix"></image>
					<view class="textit">恭喜成为{{rankName}}</view>
					<view class="tex">快去首页选书吧 每次可借阅10本哦</view>
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
				
			</view>
			<!-- 空白页 -->
			<view v-if="orderList.length === 0" class="empty" style="position:fixed;top:80rpx;height:100vh;overflow: hidden;">
				<image src="https://www.abcbook2019.com/mobile/public/img/icon/boxs.png" mode="aspectFit"></image>
				<view class="empty-tips">
					<view>订单什么也没有</view>
					<view>快去寻找自己喜欢的绘本吧~</view>
					<view class="navigator" @click="navToindx()">去逛逛</view>
				</view>
			</view>
			<!-- 订单列表 -->

			<view v-else v-for="(item,index) in orderList" :key="index" class="order-item" @click="gotoordetil(item.order_id)">
				<view class="i-top b-b" v-if="tabCurrentIndex!=7">
					<text class="time">编号:{{item.order_sn}}</text>
					<text class="state" v-if="item.detail_status==7" :style="{'color':'#666666'}">{{item.order_status}}</text>

					<text class="state" v-else-if="item.detail_status==6" :style="{'color':'#46A02D'}">{{item.order_status}}</text>
					<text class="state" v-else>{{item.order_status}}</text>

				</view>
				<view class="con" v-if="tabCurrentIndex!=7">
					<scroll-view v-if="item.hyk === 0" class="goods-box fl" scroll-x>
						<view v-for="(goodsItem, goodsIndex) in item.goods" :key="goodsIndex" class="goods-item">
							<image class="goods-img" :src="goodsItem.goods_thumb" mode="aspectFill"></image>
						</view>
					</scroll-view>
					<view v-if="item.hyk === 1" class="goods-box-single fl" v-for="(goodsItem, goodsIndex) in item.goods" :key="goodsIndex">
						<image class="goods-img" :src="goodsItem.goods_thumb" mode="aspectFill"></image>
						<view class="right">
							<text class="title clamp">{{goodsItem.goods_name}}</text>
						</view>
					</view>

					<view class="price-box fr" v-if="item.hyk === 0">
						共
						<text class="num">{{item.total_number}}</text>
						本
						<!-- <text class="price">143.7</text> -->
					</view>
					<view class="price-box" v-else>
						查看详情<text class="more-icon yticon icon-you"></text>
					</view>
				</view>
				<view class="evaluale" v-else>
					<view class="imageg">
						<image :src="item.goods_thumb"></image>
					</view>
					<text>{{item.goods_name}}</text>
				</view>
				<!-- 根据订单状态判断显示按钮 待付款-->
				<view class="action-box b-t" v-if="item.detail_status == 1">
					<button class="action-btn" @click.stop="cancelOrder(item,index)">取消订单</button>
					<button class="action-btn recom" type="primary" v-if="(item.goods_amount>0 || item.deposit_type==1) && (item.hyk === 1 || item.ru_id>0)"
					 @click.stop="nopayscore(item)">立即支付</button>
					<button class="action-btn recom" v-else-if="item.goods_amount>0 || item.deposit_type==1" @click.stop="gotopay(item)">立即支付</button>
					<!-- <button class="action-btn recom" v-else @click.stop="navToindx()">返回首页</button> -->
					<!-- #ifdef H5 -->
					<button class="action-btn recom" v-else @click.stop="navToindx()">返回首页</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn recom" v-else open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
				</view>
				<!-- 根据订单状态判断显示按钮 待收货 -->
				<view class="action-box b-t" v-if="item.detail_status == 2">
					<!-- <button class="action-btn" open-type="contact" @click.stop="">联系客服</button> -->
					<button class="action-btn" @click.stop="cancelOrder(item,index)">取消订单</button>
					<button class="action-btn">查看物流</button>
				</view>
				<!-- 根据订单状态判断显示按钮 待归还-->
				<view class="action-box b-t" v-if="item.detail_status == 3">
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<button class="action-btn">查看物流</button>
				</view>
				<!-- 根据订单状态判断显示按钮 待评价-->
				<view class="action-box b-t" v-if="item.detail_status == 4">
					<!-- #ifdef H5 -->
					<button class="action-btn" type="primary" v-if="item.user_ranks==5" @click.stop="delayReturn(item)">延期还书</button>
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn" type="primary" v-if="item.user_ranks==5" @click.stop="delayReturn(item)">延期还书</button>
					<button class="action-btn" v-else open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<button class="action-btn recom" v-if="item.ru_id == 0" @click.stop="yoreturn(item.rec_id,item.order_id)">预约还书</button>
					<button class="action-btn recom" v-else @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- 根据订单状态判断显示按钮 已完成-->
				<view class="action-box b-t" v-if="item.detail_status == 5">
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<button class="action-btn recom" @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- 根据订单状态判断显示按钮 已关闭-->
				<view class="action-box b-t" v-if="item.detail_status == 6">
					<view class="" v-if="item.hyk==1" style="display: flex;">
						<view class="" v-if="item.member_status!==88" style="display: flex;">
							<button v-if="item.pay_id > 0 && item.money_paid>0 && item.rec_type!==6 && item.rec_type!==84" class="action-btn" @click.stop="refund(item.order_id)">申请退款</button>
							<button v-else class="action-btn" @click.stop="navToindx()">前去选书</button>
							<button class="action-btn recom" @click.stop="gotomem(item.order_id)">立即激活</button>
						</view>
						<view class="" v-else style="display: flex;">
							<button class="action-btn" @click.stop="navToindx()">前去选书</button>
							<button class="action-btn">已激活</button>
						</view>
					</view>
					<view class="" v-else style="display: flex;">
						<!-- #ifdef H5 -->
						<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
						<!-- #endif -->
						<!-- #ifdef MP -->
						<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
						<!-- #endif -->
						<button class="action-btn" @click.stop="navToindx()">重新选书</button>
					</view>
				</view>

				<view class="action-box b-t" v-if="item.detail_status == 7">
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<button class="action-btn" @click.stop="navToindx()">重新选书</button>
				</view>
				<view class="action-box b-t" v-if="item.detail_status == 8">
					<!-- #ifdef H5 -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
					<!-- #endif -->
					<!-- #ifdef MP -->
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<!-- #endif -->
					<button class="action-btn" @click.stop="navToindx()">再去逛逛</button>
				</view>
				<!-- <view class="action-box b-t" v-if="item.detail_status == 101">
					<button class="action-btn" open-type="contact" @click.stop="">联系客服</button>
					<button class="action-btn" @click.stop="navdeti(item.order_id)">前去支付</button>
				</view> -->
				<view class="action-box b-t" v-if="tabCurrentIndex == 7">
					<button class="action-btn recom" @click.stop="navToevlu(item.rec_id)">评价晒单</button>
				</view>


			</view>
			<view class="flocon" v-if="classon">{{classoninfo}}</view>

			<view id="scrollToTop" class="to-top" :class="{'hide':hide}" @click="gotop">
				<image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image>
			</view>
			<!-- #ifdef H5 -->
			<goHome></goHome>
			<!-- #endif -->
			

			<!-- 弹框 -->
			<view class="pop-up" v-if="popup">

				<view class="upcon">
					<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/upcon.png" mode="widthFix"></image>
					<view class="upopinion">
						<text @click="opinion('n')">先不用</text>
						<text class="main" @click="opinion('y')">免押金租书</text>
					</view>
				</view>
			</view>
			<!-- 延期还书弹框 -->
			<view class="pop-up delayup" v-if="delayup">
				<view class="upcon">
					<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
					
					<view class="conpage">
						<view class="titletop">温馨提示</view>
						<view class="conmain">选择延期还书后将扣除您一次借阅次数</view>
					</view>
					<view class="upopinion">
						<text @click.stop="close()">先不用</text>
						<text class="lasttext"  @click.stop="delay()">延期还书</text>
					</view>
				</view>
			</view>
		</view>
		
		<mixLoading v-else></mixLoading>
	</view>
</template>

<script>
	// #ifdef H5
	import H5wxjs from "../../common/jwx.js";
	import listCell from '@/components/title-top';


	// #endif
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	import bottomNav from "../navbar/navbar.vue";
	import goHome from '@/components/home.vue';
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	export default {
		components: {
			bottomNav,
			uniLoadMore,
			
			goHome,
			mixLoading,
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "我的订单",
				optst: 0,
				popup: false,
				loading: false,
				delayup:false,   //延期弹框
				page: 1,
				type: '',
				classon: false, //判断模态框
				tabCurrentIndex: 0,
				orderList: [],
				itemclick: {},
				success:false,   //激活成功弹框
				rankName:'',
				hide: true,
				deCode: '',
				classoninfo: "正在努力加载...", //加载展示内容
				navList: [{
						states: 0,
						text: '全部',
					},
					{
						states: 500,
						text: '待付款',
						loadingType: 'more'
					},
					{
						states: 502,
						text: '待发货',
						loadingType: 'more'
					},
					{
						states: 512,
						text: '待收货',
						loadingType: 'more'
					},
					{
						states: 522,
						text: '待归还',
						loadingType: 'more'
					},
					{
						states: 992,
						text: '还书中',
						loadingType: 'more'
					},
					{
						states: 10102,
						text: '已完成',
						loadingType: 'more'
					},
					// {
					// 	states: 5,
					// 	text: '我的预售',
					// 	loadingType: 'more'
					// },
					{
						states: "",
						text: '待评价',
						loadingType: 'more'
					}
				],
			};
		},

		onLoad(options) {
			this.optst = options.states;
			this.type = options.type
			this.loadindex=options.index
			// #ifdef H5
			this.loadData(options.index)

			// 判断微信内外
			var ua = window.navigator.userAgent.toLowerCase();
			console.log(ua)
			// console.log(ua.indexOf('micromessenger') != -1)
			// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
			if (ua.match(/MicroMessenger/i) == 'micromessenger') {
				// 微信内浏览器（公众号）
				console.log("公众号")
				console.log(options)
				this.deCode = options.deCode
			}
			// #endif
			// #ifdef MP
			if (options.index == 7) {
				this.tabCurrentIndex = 7
				this.commentList()
			} else {
				this.loadData(options.index)
				this.tabCurrentIndex = options.index
			}
			// #endif

		},
		onShow() {
			// this.loadData()
		},
		onReachBottom() {
			this.scroll();
		},
		onPullDownRefresh: function() {
			if (this.tabCurrentIndex == 7) {
				this.commentList()
			} else {
				this.loadData()
			}
			setTimeout(function() {
				uni.stopPullDownRefresh(); //停止下拉刷新动画
			}, 1000);

		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			if (Object.scrollTop > 400) {
				this.hide = false;
			} else {
				this.hide = true;
			}
			if (this.classoninfo == "我也是有底线的哦~") {
				this.classon = false
			}
		},
		methods: {
			// 弹框
			close() {
				this.popup = false;
				this.delayup=false;   //延期体验弹框
			},
			delay(){
				console.log(this.itemclick)
				this.$api.quest('user/delayReturn',{
					order_id:this.itemclick.order_id
				},(res)=>{
					if(res.data.code==0){
						this.delayup=false;  
						this.$api.msg(res.data.data)
					}else{
						this.delayup=false;
						this.$api.msg(res.data.data)
					}
					console.log(res.data)
				})
			},
			// 申请退卡
			refund(id,index){
				this.$api.quest('user/refund',{
					order_id:id
				},(res)=>{
					console.log(res.data.data)
					if(res.data.code==0){
						this.$api.msg("退卡成功")
						// this.dataArr.splice(index,1)
						this.scroll()
					}else{
						this.$api.msg("退卡失败，请联系客服")
					}
				})
				this.loadData(this.loadindex)
			},
			// 延期还书
			delayReturn(item){
				this.delayup=true
				this.itemclick=item
				
			},
			// 判断是否是支付分
			opinion(type) {
				this.$api.quest('flow/againorder', {
					order_id: this.itemclick.order_id,
					type: type == 'y' ? 1 : 0
				}, (res) => {
					if (res.data.code == 0) {
						// 将ordersn改变 并存储
						uni.setStorageSync('ordersn', res.data.error)
						if (type == 'y') {
							this.gopay()
							this.popup = false
							this.deposittype = 1
						} else {
							this.nopayscore(this.itemclick)
						}
					}else{
						this.$api.msg(res.data.data)
					}
					
				})
			},
			// 微信支付  没有使用支付分
			nopayscore(itemclick) {
				if(itemclick.goods_amount==0){
					uni.navigateTo({
						url: '/pages/money/paySuccess?id=' + itemclick.order_id + '&payok=0'
					})
				}else{
					uni.navigateTo({
						url: '/pages/money/pay?id=' + itemclick.order_id + '&payment=' + itemclick.goods_amount,
						// #ifdef H5
						success: (res) => {
							if (res.errMsg == 'navigateTo:ok') {
								window.location.reload(true);
							}
						}
						// #endif
					})
				}
				// if(this.itemclick.extension_code=='presale'){
				// 	uni.navigateTo({
				// 		url:'/pages/money/pay?id='+this.itemclick.order_id+'&payment='+this.itemclick.order_amount
				// 	})
				// }else{

				// }

			},
			gotopay(payli) {
				//#ifdef MP
				this.popup = true
				this.itemclick = payli
				// #endif
				// #ifdef H5				
				// 判断微信内外
				this.itemclick = payli
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					this.popup = true
				} else {
					this.nopayscore(payli.order_id)
				}

				// #endif

				// uni.navigateTo({
				// 	url: '/pages/money/pay?id=' + payli.order_id + '&payment=' + payli.goods_amount
				// })
			},
			commentList() {
				this.$api.quest('user/order/commentList', {
					page: 1,
				}, (res) => {
					console.log(res)
					this.orderList = res.data.data
					this.loading = true
				})
			},
			// 立即激活
			gotomem(id) {
				// uni.navigateTo({
				// 	url: '/pages/members/members'
				// })
				this.$api.quest('user/activity',{
					order_id:id
				},(res)=>{
					console.log(res)
					if(res.data.code==0){
						// this.$api.msg("激活成功")
						this.dataArr.splice(index,1)
						this.rankName=res.data.data.ranks_name
						this.success=true
					}else{
						this.$api.msg(res.data.data)
					}
				})
				
				this.loadData(this.loadindex)
				
			},
			navToevlu(id) {
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/detail/evaluate?rec=' + id
				})
				// #endif
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id + '&deCode=' + this.deCode
					})
				} else {
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id
					})
				}
				// #endif
			},
			//获取订单列表
			loadData(index, states) {

				this.tabCurrentIndex = index
				// this.$api.quest('user/order/list', {
				// 		page: 1,
				// 		size: 10,
				// 		status: this.optst,
				// 		type:this.type?this.type:''
				// 	}, (res) => {
				// 		this.orderList = res.data.data
				// 		this.loading = true
				// 	})
				if (this.tabCurrentIndex == 7) {
					this.commentList()
				} else {
					this.$api.quest('user/order/list', {
						page: 1,
						size: 10,
						status: this.optst,
						type: ""
					}, (res) => {
						this.orderList = res.data.data
						this.loading = true
					})
				}

			},
			// 预约还书跳转
			yoreturn(rec, order) {
				this.$api.quest('user/checkReturn', {
					rec_id: rec
				}, (res) => {
					console.log(res)
					if (res.data.code == 1) {
						uni.navigateTo({
							url: '/pages/appoint/appoint?rec=' + rec + '&order=' + order
						})
					} else {
						this.$api.msg(res.data.data)
					}
				})
			},
			navdeti(id) {
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + id
				})
				// #endif
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id + '&deCode=' + this.deCode
					})
				} else {
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id
					})
				}
				// #endif
			},
			gotoordetil(id) {
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/order/createOrder?id=' + id
				})
				// #endif
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id + '&deCode=' + this.deCode
					})
				} else {
					uni.navigateTo({
						url: '/pages/order/createOrder?id=' + id
					})
				}
				// #endif
			},
			navToindx() {
				uni.navigateBack()
				// this.$store.commit("change_page", 0)
				// uni.navigateTo({
				// 	url: '/pages/index/index'
				// })
			},
			// 下拉加载
			scroll() {
				if (this.tabCurrentIndex == 7) {
					const that = this;
					that.classon = true;
					this.loadingType = 1;
					this.$api.quest('user/order/commentList', {
						page: ++that.page,
					}, (res) => {
						// console.log(res.data.data)
						if (res.data.data.length == 0) { //没有数据
							this.loadingType = 2;
							that.classon = true;
							that.classoninfo = "我也是有底线的哦~"
							uni.hideNavigationBarLoading(); //关闭加载动画
							return;
						}
						that.orderList.push(...res.data.data)
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
					})
				} else {
					const that = this;
					that.classon = true;
					this.loadingType = 1;
					this.$api.quest('user/order/list', {
						page: ++that.page,
						size: 10,
						status: this.optst,
						type: ""
					}, (res) => {
						// console.log(res.data.data)
						if (res.data.data.length == 0) { //没有数据
							this.loadingType = 2;
							that.classon = true;
							this.loading = true
							that.classoninfo = "我也是有底线的哦~"
							uni.hideNavigationBarLoading(); //关闭加载动画
							return;
						}
						that.orderList.push(...res.data.data)
						uni.hideNavigationBarLoading(); //关闭加载动画
						that.classon = false //判断模块框
						// console.log(that.hotmain,'hot',that.page,'page')
						uni.hideNavigationBarLoading(); //关闭加载动画
					})
				}

			},
			//顶部tab点击
			tabClick(index, states) {
				this.tabCurrentIndex = index;
				this.optst = states
				this.page = 1

				if (this.optst == 5) {
					this.type = "presale"
				} else {
					this.type = ""
				}
				// this.loadData(index, states);
				if (index == 7) {
					this.commentList()
				} else {
					this.loadData(index, states);
				}
			},
			//删除订单
			deleteOrder(item, index) {
				this.$api.quest('user/order/del', {
					id: item.order_id
				}, (res) => {
					console.log(res)
					this.orderList.splice(index, 1);
					// uni.hideLoading();
				})
			},
			//取消订单
			cancelOrder(item, index) {
				this.$api.quest('user/order/cancel', {
					id: item.order_id
				}, (res) => {
					console.log(res)
					if (res.data.code == 1) {
						this.$api.msg(res.data.data)
						// this.orderList.splice(index, 1);
					} else {
						this.$api.msg(res.data.data)
					}
				})
				this.loadData(this.loadindex)
			},
			// 返回顶部
			gotop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			// #ifdef H5
			compareVersion(v1, v2) {
				v1 = v1.split('.')
				v2 = v2.split('.')
				const len = Math.max(v1.length, v2.length)
				while (v1.length < len) {
					v1.push('0')
				}
				while (v2.length < len) {
					v2.push('0')
				}
				for (let i = 0; i < len; i++) {
					const num1 = parseInt(v1[i])
					const num2 = parseInt(v2[i])
					if (num1 > num2) {
						return 1
					} else if (num1 < num2) {
						return -1
					}
				}
				return 0
			},
			// #endif	
			gopay() {
				// #ifdef MP
				// alert('支付分支付接口')
				console.log(uni.getStorageSync("ordersn"), 'ordersn')
				this.$api.quest('payscore/add', {
					order_sn: uni.getStorageSync("ordersn"),
					user_id: uni.getStorageSync("user_id"),
					book_num: this.itemclick.total_number
				}, (res) => {
					let that = this;
					console.log(res)
					if (res.data.data.code == 1) {
						// this.$api.msg(res.data.data.msg)
						that.$api.quest('payscore/changesn', {
							order_id: that.itemclick.order_id
						}, (res) => {
							// console.log(res)
							uni.setStorageSync('ordersn', res.data.data)
							// console.log(res)
							if (res.data.code == 0) {
								this.gopay()
							}
						})
					} else {
						this.anewtype = true;

						if (wx.openBusinessView) {
							wx.openBusinessView({
								businessType: 'wxpayScoreUse',
								extraData: {
									mch_id: res.data.data.mch_id,
									package: res.data.data.package,
									timestamp: res.data.data.timestamp,
									nonce_str: res.data.data.nonce_str,
									sign_type: res.data.data.sign_type,
									sign: res.data.data.sign_sh256
								},
								success(res) {
									if (res.errMsg == 'openBusinessView:ok') {
										that.loading = false
										that.$api.quest('payscore/searchdb', {
											out_order_no: uni.getStorageSync("ordersn")
										}, (res) => {
											uni.navigateTo({
												url: '/pages/money/paySuccess?id=' + that.itemclick.order_id + '&payok=0'
											})
										})
									} else {
										uni.navigateTo({
											url: '/pages/money/paySuccess?id=' + that.itemclick.order_id + '&payok=1&payment=' + that.itemclick.order_amount
										})
									}
								},
								fail(faill) {
									uni.navigateTo({
										url: '/pages/money/paySuccess?id=' + that.itemclick.order_id + '&payok=1&payment=' + that.itemclick.order_amount
									})
								},
								complete(com) {
									console.log(com)
								}
							});
						} else {
							//引导用户升级微信版本
						}
					}

				})
				// #endif
				// #ifdef H5
				let lis = this
				lis.$api.quest('payment/getticketsign', {
					code: lis.deCode,
					url: decodeURIComponent(window.location.href.split('#')[0])
				}, (reda) => {
					console.log(reda.data.data, 'eee')
					lis.cketsign = reda.data.data.sign
					// alert(lis.cketsign)
					let wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i);
					console.log(wechatInfo);
					let wechatVersion = wechatInfo[1];
					if (lis.compareVersion(wechatVersion, "7.0.5") >= 0) {
						console.log("www");
						// alert("www");
						H5wxjs.config({
							// debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
							appId: reda.data.data.appid, // 必填，公众号的唯一标识wxbdbc05d9a09741f7
							timestamp: reda.data.data.timestamp, // 必填，生成签名的时间戳
							nonceStr: reda.data.data.nonceStr, // 必填，生成签名的随机串
							signature: reda.data.data.sign, // 必填，签名
							jsApiList: ["openBusinessView"] // 必填，需要使用的JS接口列表
						});
						H5wxjs.ready(function() {
							// config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
							H5wxjs.checkJsApi({
								jsApiList: [
									"openBusinessView",
								], // 需要检测的JS接口列表
								success: function(data) {
									console.log(data, "rrr");
									// 以键值对的形式返回，可用的api值true，不可用为false
									// 如：{"checkResult":{"openBusinessView":true},"errMsg":"checkJsApi:ok"}
									if (data.checkResult.openBusinessView) {
										// alert("ddd");
										console.log("ddd");
										console.log(lis, 'ss');
										// alert(JSON.stringify(res.data.data));
										lis.$api.quest('payscore/add_h5', {
											order_sn: uni.getStorageSync("ordersn"),
											user_id: uni.getStorageSync("user_id"),
											book_num: lis.itemclick.total_number
										}, (res) => {
											console.log(res.data.data, 'add_h5');
											let that = this;
											if (res.data.data.code == 0) {
												lis.anewtype = true;
												H5wxjs.invoke(
													"openBusinessView", {
														businessType: "wxpayScoreUse",
														queryString: "mch_id=" + res.data.data.mch_id + "&package=" + res.data.data.package +
															"&timestamp=" + res.data.data.timestamp + "&nonce_str=" + res.data.data.nonce_str +
															"&sign_type=" + res.data.data.sign_type + "&sign=" + res.data.data.sign_sh256
													},
													function(res) {
														console.log(res, "l");
														// alert(JSON.stringify(res), '450');
														// 从微信侧小程序返回时会执行这个回调函数
														if (parseInt(res.err_code) == 0) {
															// alert("fff");
															window.location.href = 'https://www.abcbook2019.com/mobile/h5/#/pages/money/paySuccess?id=' +
																lis.itemclick.order_id + '&payok=0&payment=' + lis.itemclick.order_amount
															// setTimeout(function() {
															// 	lis.$api.quest('payscore/searchdb', {
															// 		out_order_no: uni.getStorageSync("ordersn")
															// 	}, (res) => {
															// 		// alert(JSON.stringify(res), '458');
															// 		if (res.data.data.msg_id) {
															// 			uni.navigateTo({
															// 				url:'/pages/money/paySuccess?id=' + lis.itemclick.order_id + '&payok=0&payment=' + lis.itemclick.order_amount
															// 			})
															// 		}
															// 	})
															// }, 2000);
															// 返回成功
														} else {
															window.location.href = 'https://www.abcbook2019.com/mobile/h5/#/pages/money/paySuccess?id=' +
																lis.itemclick.order_id + '&payok=1&payment=' + lis.itemclick.order_amount
															// alert("ggg");

															// uni.navigateTo({
															// 	url: '/pages/money/paySuccess?id=' + lis.itemclick.order_id + '&payok=1&payment=' + lis.itemclick.order_amount
															// })
															// 返回失败
														}
													}
												);

											} else {

												// this.$api.msg(res.data.data.msg)
												lis.$api.quest('payscore/changesn', {
													order_id: lis.itemclick.order_id
												}, (res) => {
													// console.log(res)
													uni.setStorageSync('ordersn', res.data.data)
													// console.log(res)
													if (res.data.code == 0) {
														this.gopay()
													}
												})

											}
										})

									}
								}
							});
						});
					} else {
						// 提示用户升级微信客户端版本
						console.log("vvv");
						// alert("vvv");
						window.location.href =
							"https://support.weixin.qq.com/cgi-bin/readtemplate?t=page/common_page__upgrade&text=text005&btn_text=btn_text_0";
					}
				})

				// #endif

			},


			//订单状态文字和颜色
			orderStateExp(state) {
				let stateTip = '',
					stateTipColor = '#fd8a54';
				switch (+state) {
					case 1:
						stateTip = '待付款';
						break;
					case 2:
						stateTip = '待发货';
						break;
					case 9:
						stateTip = '订单已关闭';
						stateTipColor = '#909399';
						break;

						//更多自定义
				}
				return {
					stateTip,
					stateTipColor
				};
			}
		},
	}
</script>

<style lang="scss" scoped>
	.delayup{
		.upopinion{
			border-top: 1rpx solid #e6e6e6;
			text{
				// width: 200rpx !important;
				// line-height: 60rpx !important;
			}
			.lasttext{
				background:linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				color: #fff !important;
				border: none !important;
			}
		}
	}
	// 激活会员
	.popup{
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		background: rgba(0,0,0,.5);
		z-index: 999;
		.message{
			position: absolute;
			top: 30%;
			left: 50%;
			transform: translate(-50%);
			width:488rpx;
			height:366rpx;
			background:rgba(255,255,255,1);
			border-radius:24rpx;
			text-align:center;
			image{
				position: absolute;
				top: -75rpx;
				left:50%;
				transform: translate(-50%);
				width: 306rpx;
				height: 225rpx;
			}
			.textit{
				color:#FF824B;
				font-size: 34rpx;
				margin-top:139rpx;
				margin-bottom: 10rpx;
			}
			.tex{
				font-size: 26rpx;
				color: #666;
			}
			.btn{
				width:408rpx;
				line-height:88rpx;
				color: #fff;
				font-size: 32rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0rpx 4rpx 8rpx 0rpx rgba(255,130,75,0.5);
				border-radius:49rpx;
				margin-top: 30rpx;
			}
			
		}
	}
	
	
	.pop-up {
		width: 100vw;
		height: 100vh;
		background: rgba(0, 0, 0, .6);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;
		.conpage{
			.titletop{
				margin: 50rpx 0 30rpx 0;
				font-size: 42rpx;
				color: #333;
			}
			.conmain{
				font-size: 28rpx;
				color: #666;
				margin-bottom: 20rpx;
			}
		}
		.upcon {
			/* height: 500rpx; */
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: #fff;
			border-radius: 24rpx;
			text-align: center;

			image {
				width: 660rpx;
				height: 752rpx;
			}

			.close {
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				top: 20rpx;
				right: 25rpx;
				z-index: 9;
			}

			.upopinion {
				display: flex;
				width: 660rpx;
				margin: 0 auto;
				height: 148rpx;
				justify-content: space-around;
				align-items: center;

				text {
					width: 300rpx;
					line-height: 84rpx;
					border: 2rpx solid #666;
					border-radius: 44rpx;
					font-size: 32rpx;
					color: #666;
				}

				.main {
					color: #fff;
					line-height: 88rpx;
					border: none;
					background: linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				}
			}

		}
	}

	page,
	.content {
		background: $page-color-base;
		height: 100%;
	}

	.empty {
		position: static;
	}

	.swiper-box {
		height: calc(100% - 40px);
	}

	.list-scroll-content {
		height: 100%;
	}

	.navbar {
		position: fixed;
		/* #ifdef MP */
		top: 0;
		/* #endif */
		/* #ifdef H5 */
		top: 88rpx;
		/* #endif */
		width: 750rpx;
		line-height: 88rpx;
		background: #fff;
		overflow-x: scroll;
		-webkit-overflow-scrolling: touch;
		white-space: nowrap;
		z-index: 99;
		box-shadow: 0px 2rpx 8rpx 0px rgba(0, 0, 0, 0.1), 0px -1rpx 0px 0px rgba(230, 230, 230, 1);

		text {
			position: relative;
			display: inline-block;
			margin-left: 50rpx;
			color: #666;
			font-size: 30rpx;
			line-height: 50rpx;
		}

		.active {
			color: #FF824B;
			position: relative;
			font-size: 36rpx;
			font-weight: bold;
		}

		.active::before {
			display: block;
			content: "";
			position: absolute;
			width: 26rpx;
			height: 8rpx;
			bottom: -12rpx;
			left: 50%;
			transform: translate(-50%, 0%);
			background: #FF824B;
			border-radius: 4rpx;
		}

		// .nav-item {
		// 	display: inline-block;
		// 	width: 150rpx;
		// 	line-height: 88rpx;
		// 	font-size: 15px;
		// 	text-align: center;
		// 	color: $font-color-dark;
		// 	position: relative;

		// 	&.current {
		// 		color: $base-color;

		// 		&:after {
		// 			content: '';
		// 			position: absolute;
		// 			left: 50%;
		// 			bottom: 0;
		// 			transform: translateX(-50%);
		// 			width: 44px;
		// 			height: 0;
		// 			border-bottom: 2px solid $base-color;
		// 		}
		// 	}
		// }

		&::-webkit-scrollbar {
			display: none
		}
	}

	.tablist {
		padding-top: 88rpx;
		padding-bottom: 200rpx;
	}

	.flocon {
		position: fixed;
		bottom: 120rpx;
		left: 50%;
		transform: translate(-50%, 0);
		font-size: 26rpx;
		color: #999999;
		text-align: center;

	}

	.uni-swiper-item {
		height: auto;
	}

	.action-box {
		display: flex;
	}

	.order-item {
		display: flex;
		flex-direction: column;
		width: 710rpx;
		// height: 389rpx;
		margin: 0 auto;
		// padding-left: 30upx;
		background: #fff;
		margin-top: 16upx;
		box-sizing: border-box;
		padding: 0 20rpx;
		box-shadow: 0px 2rpx 8rpx 0px rgba(0, 0, 0, 0.1);
		border-radius: 10rpx;

		.i-top {
			display: flex;
			align-items: center;
			width: 670rpx;
			height: 80upx;
			font-size: $font-base;
			color: $font-color-dark;
			border-bottom: 1rpx dashed #e6e6e6;
			position: relative;

			.time {
				flex: 1;
			}

			.state {
				color: $base-color;
			}

			.del-btn {
				padding: 10upx 0 10upx 36upx;
				font-size: $font-lg;
				color: $font-color-light;
				position: relative;

				&:after {
					content: '';
					width: 0;
					height: 30upx;
					border-left: 1px solid $border-color-dark;
					position: absolute;
					left: 20upx;
					top: 50%;
					transform: translateY(-50%);
				}
			}


		}

		.con {
			display: flex;
			height: 200rpx;
			align-items: center;
			justify-content: space-between;
		}

		/* 多条商品 */
		.goods-box {
			width: 520rpx;
			height: 160upx;
			padding: 20upx 0;
			white-space: nowrap;

			.goods-item {
				width: 120upx;
				height: 120upx;
				display: inline-block;
				margin-right: 24upx;
			}

			.goods-img {
				display: block;
				width: 100%;
				height: 100%;
			}
		}

		/* 单条商品 */
		.goods-box-single {
			display: flex;
			padding: 20upx 0;

			.goods-img {
				display: block;
				width: 120upx;
				height: 120upx;
			}

			.right {
				flex: 1;
				display: flex;
				flex-direction: column;
				height: 120upx;
				align-items: center;
				justify-content: center;
				// padding: 0 30upx 0 24upx;
				overflow: hidden;

				.title {
					font-size: $font-base + 2upx;
					color: $font-color-dark;
					align-items: center;
				}

				.attr-box {
					font-size: $font-sm + 2upx;
					color: $font-color-light;
					padding: 10upx 12upx;
				}

				.price {
					font-size: $font-base + 2upx;
					color: $font-color-dark;

					&:before {
						content: '￥';
						font-size: $font-sm;
						margin: 0 2upx 0 8upx;
					}
				}
			}
		}

		.price-box {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 160rpx;
			font-size: $font-sm + 2upx;
			color: $font-color-light;

			.num {
				margin: 0 8upx;
				color: $font-color-dark;
			}

			.price {
				font-size: $font-lg;
				color: $font-color-dark;

				&:before {
					content: '￥';
					font-size: $font-sm;
					margin: 0 2upx 0 8upx;
				}
			}
		}

		.action-box {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			height: 100upx;
			position: relative;
			border-top: 1rpx dashed #e6e6e6;
		}

		.action-btn {
			width: 160upx;
			// height: 60upx;
			margin: 0;
			margin-left: 24upx;
			padding: 0;
			text-align: center;
			line-height: 60upx;
			font-size: $font-sm + 2upx;
			color: $font-color-dark;
			background: #fff;
			border-radius: 100px;
			border: 1rpx solid #999;

			&:after {
				border-radius: 100px;
			}

			&.recom {
				background: #fff9f9;
				color: $base-color;
				border: 1rpx solid #FF824B;

				&:after {
					border-color: #f7bcc8;
				}
			}
		}
	}


	/* load-more */
	.uni-load-more {
		display: flex;
		flex-direction: row;
		height: 80upx;
		align-items: center;
		justify-content: center
	}

	.uni-load-more__text {
		font-size: 28upx;
		color: #999
	}

	.uni-load-more__img {
		height: 24px;
		width: 24px;
		margin-right: 10px
	}

	.uni-load-more__img>view {
		position: absolute
	}

	.uni-load-more__img>view view {
		width: 6px;
		height: 2px;
		border-top-left-radius: 1px;
		border-bottom-left-radius: 1px;
		background: #999;
		position: absolute;
		opacity: .2;
		transform-origin: 50%;
		animation: load 1.56s ease infinite
	}

	.uni-load-more__img>view view:nth-child(1) {
		transform: rotate(90deg);
		top: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(2) {
		transform: rotate(180deg);
		top: 11px;
		right: 0
	}

	.uni-load-more__img>view view:nth-child(3) {
		transform: rotate(270deg);
		bottom: 2px;
		left: 9px
	}

	.uni-load-more__img>view view:nth-child(4) {
		top: 11px;
		left: 0
	}

	.load1,
	.load2,
	.load3 {
		height: 24px;
		width: 24px
	}

	.load2 {
		transform: rotate(30deg)
	}

	.load3 {
		transform: rotate(60deg)
	}

	.load1 view:nth-child(1) {
		animation-delay: 0s
	}

	.load2 view:nth-child(1) {
		animation-delay: .13s
	}

	.load3 view:nth-child(1) {
		animation-delay: .26s
	}

	.load1 view:nth-child(2) {
		animation-delay: .39s
	}

	.load2 view:nth-child(2) {
		animation-delay: .52s
	}

	.load3 view:nth-child(2) {
		animation-delay: .65s
	}

	.load1 view:nth-child(3) {
		animation-delay: .78s
	}

	.load2 view:nth-child(3) {
		animation-delay: .91s
	}

	.load3 view:nth-child(3) {
		animation-delay: 1.04s
	}

	.load1 view:nth-child(4) {
		animation-delay: 1.17s
	}

	.load2 view:nth-child(4) {
		animation-delay: 1.3s
	}

	.load3 view:nth-child(4) {
		animation-delay: 1.43s
	}

	@-webkit-keyframes load {
		0% {
			opacity: 1
		}

		100% {
			opacity: .2
		}
	}

	.evaluale {
		height: 300rpx;
		display: flex;
		align-items: center;

		.imageg {
			width: 250rpx;
			height: 250rpx;
			margin-right: 15rpx;

			image {
				width: 250rpx;
				height: 250rpx;
				margin: 0 auto;
			}
		}

		text {
			font-size: 28rpx;
			color: #666;
		}
	}
</style>
