<template>
	<view class="orderdetil" v-if="loading">
		<view class="head">
			<view class="headtitle">
				<navigator class="cell-icon yticon icon-zuo" open-type="navigateBack" style="z-index: 99;"></navigator>
				<h4>订单详情</h4>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==103">
				<view class="ord_main_con fl">
					<h4 class="con_Title">开团成功</h4>
					<text class="explain">快去邀请好友参团吧···</text>
				</view>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==1">
				<view class="ord_main_con fl">
					<h4 class="con_Title">待付款 {{orderArr.goods_amount*1+orderArr.shipping_fee*1}}</h4>
					<text class="explain" v-if="orderArr.hyk==1">付款后即可无限借阅绘本哦</text>
					<text class="explain" v-else>付款后将在24小时内发货</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/readyFor.png" style="width: 122rpx; height: 99rpx;"  mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==2">
				<view class="ord_main_con fl">
					<h4 class="con_Title">待发货</h4>
					<text class="explain">快速备货中...</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/shipments.png" style="width: 112rpx; height: 105rpx;"  mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==3">
				<view class="ord_main_con fl">
					<h4 class="con_Title">待收货</h4>
					<text class="explain">物流急速运输中...</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/Receiving.png" style="width: 106rpx; height: 118rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==4">
				<view class="ord_main_con fl" v-if="orderArr.ru_id==0">
					<h4 class="con_Title" v-if='orderArr.ru_id==0'>待归还</h4>
					<text class="explain" v-if="orderArr.Surplusday == 0">京东极速物流运输中...</text>
					<text class="explain" v-else>距离最晚还书日还有{{orderArr.Surplusday}}天</text>
				</view>
				<view class="ord_main_con fl" v-else-if="orderArr.ru_id>0">
					<h4 class="con_Title" v-if='orderArr.ru_id==0'>已收货</h4>
					<text class="explain">物流运输中...</text>
				</view>
				<view class="ord_main_con fl" v-else>
					<h4 class="con_Title">已收货</h4>
					<text class="explain">感谢您的支持</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/ueseReturn.png" style="width: 94rpx; height:104rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==8">
				<view class="ord_main_con fl">
					<h4 class="con_Title">取件中</h4>
					<text class="explain">京东小哥上门取件中...</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/Receiving.png" style="width: 106rpx; height:118rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==5">
				<view class="ord_main_con fl">
					<h4 class="con_Title">还书中</h4>
					<text class="explain">快递取走后可继续下单哦...</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/ueseReturn.png" style="width: 94rpx; height:104rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==6">
				<view class="ord_main_con fl">
					<h4 class="con_Title">已完成</h4>
					<text class="explain" v-if="orderArr.hyk == 1">您已成为会员啦</text>
					<text class="explain" v-else>感谢您对图书的爱护</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/Done.png" style="width: 89rpx; height:101rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==101">
				<view class="ord_main_con fl">
					<h4 class="con_Title">部分支付(预售订单)</h4>
					<!-- <text class="explain" v-if="orderArr.hyk == 1">您已成为会员啦</text> -->
					<text class="explain">请在有效期内支付尾款</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/Done.png" style="width: 89rpx; height:101rpx;" mode=""></image>
			</view>
			<view class="heard_main" v-if="orderArr.detail_status==7">
				<view class="ord_main_con fl">
					<h4 class="con_Title">已关闭</h4>
					<text class="explain">取消订单交易关闭</text>
				</view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user/closeOrder.png" style="width: 90rpx; height:107rpx;" mode=""></image>
			</view>
			<view class="bj">
				<view class="xx"></view>
			</view>
		</view>
		<view class="page_con">
			<view class="bjzz"></view>
			<view class="page_con_title" v-if="orderArr.ru_id>0">
				<view class="shop_name">{{orderArr.user_cat}}</view>
				<text class="shipping_name">送货到家</text>
			</view>
			<view class="page_con_title" v-else>
				<view class="shop_name">{{orderArr.shop_name}}</view>
				<text class="shipping_name">{{orderArr.shipping_name}}</text>
			</view>

			<view class="page_expert_main clear booksinfolist" v-if="orderArr.hyk === 1 || orderArr.ru_id>0" style="display: flex;align-items: center;">
				<image class="fl" :src="orderArr.goods_list[0].goods_thumb" mode=""></image>
				<view class="right fl">
					<text class="title clamp">{{orderArr.goods_list[0].goods_name}}</text>
					<text class="pirc" v-if="orderArr.ru_id>0">{{orderArr.goods_list[0].sale_price}}</text>
				</view>
			</view>
			<view v-else class="page_expert_main clear booksinfolist">
				<image v-for="(item,index) in orderArr.goods_list" :key='indexx' :src="item.goods_thumb" mode="aspectFill"></image>
			</view>

			<view class="flow-checkout-adr padding-all" v-if="orderArr.hyk!==1 ">
				<!-- <image src="https://www.abcbook2019.com/mobile/public/img/user/position_order.png" mode=""></image> -->
				<text class="addressor">收货</text>

				<view class="flow-have-adr">
					<h4 class="f-h-adr-title">{{orderArr.consignee}} {{orderArr.mobile}}</h4>
					<text class="f-h-adr-con t-remark m-top04">{{orderArr.detail_address}}</text>
				</view>
			</view>

			<view class="flow-checkout-adr padding-all" v-if="(orderArr.detail_status==5||orderArr.detail_status==6||orderArr.detail_status==8)&&orderArr.return_address!=''">
				<text class="addressor">还书</text>
				<!-- <image src="https://www.abcbook2019.com/mobile/public/img/user/position_order.png" mode=""></image> -->
				<view class="flow-have-adr">
					<h4 class="f-h-adr-title">{{orderArr.return_username}} {{orderArr.return_userphone}}</h4>
					<text class="f-h-adr-con t-remark m-top04">{{orderArr.return_address}}</text>
				</view>
			</view>
			<view class="order_Info">
				<text>订单编号：{{orderArr.order_sn}}</text>
				<text>下单时间：{{orderArr.formated_add_time}} </text>
				<!-- 买的商品显示物流信息 -->
				<text v-if="orderArr.detail_status==3 && orderArr.ru_id>0">物流单号：{{orderArr.invoice_no}}</text>
				<text>支付方式：{{orderArr.pay_name}}</text>

				<!-- 	<text v-if="orderArr.detail_status==101">尾款支付时间：{{orderArr.presale.desc}}</text>
				<text style="color: #FF824B;" v-if="orderArr.presale.start_time>newTime">即将开始    {{start_time}}</text>
				<text style="color: #FF824B;" v-else-if="orderArr.presale.end_time>newTime">即将结束    {{end_time}}</text> -->
				<!-- <text v-if="orderArr.pay_name=='微信支付' && 'transid' ">微信支付号:{{orderArr.transid}}</text> -->
			</view>
			<view class="orderpay_Info clear" v-if="orderArr.zujin!=0 || orderArr.deposit != 0 || orderArr.shipping_fee!=0">
				<block v-if="orderArr.detail_status==101">
					<view class="clear">
						<text class="fl">定金</text>
						<text class="fr" style="color:#FF824B;">{{orderArr.money_paid}}</text>
					</view>
					<view class="clear">
						<text class="fl">还需支付尾款</text>
						<text class="fr">{{orderArr.order_amount}}</text>
					</view>
				</block>
				<block v-if="orderArr.ru_id>0">
					<view class="clear">
						<text class="fl">会员专享价</text>
						<text class="fr">￥{{orderArr.goods_amount}}</text>
					</view>
				</block>
				<block v-else-if="orderArr.ru_id==0 && orderArr.extension_code!='presale'">
					<view class="clear" >
						<text class="fl">押金</text>
						<view class="fr" style="color:#FF824B;" v-if="orderArr.deposit_type==1"><text class="deposit">{{orderArr.deposit}}</text>(已免除)</view>
						<text class="fr" style="color:#FF824B;" v-else>{{orderArr.deposit}}</text>
					</view>
					<view class="clear" v-if="orderArr.is_free_shipping!=0">
						<text class="fl">往返运费</text>
						<text class="fr">{{orderArr.shipping_fee}}</text>
					</view>
					<view class="clear" v-else-if="orderArr.card_type==1">
						<text class="fl">租金</text>
						<text class="fr">{{orderArr.zujin}}</text>
					</view>
					<view class="clear" v-else-if="orderArr.card_type!=1">
						<text class="fl">购卡金额</text>
						<text class="fr">{{orderArr.zujin}}</text>
					</view>
				</block>


				<!-- <block v-if="orderArr.discount>0">
					<view class="clear">
						<text class="fl">{{orderArr.discount}}</text>
						<text class="fr">{{orderArr.formated_discount}}</text>
					</view>
				</block> -->


				<block v-if="orderArr.coupons.cou_moneya>0">
					<block v-if="orderArr.coupons.cou_type==5">
						<text class="fl">运费</text>
						<text class="fr">免邮</text>
					</block>
					<block v-else>
						<text class="fl">优惠券</text>
						<text class="fr">-{{orderArr.coupons.cou_money}}</text>
					</block>
				</block>

				<view class="fr" v-if="orderArr.detail_status==1 && orderArr.deposit_type!=1">
					<text>应付金额：</text>
					<text style="font-weight: bold;">￥{{orderArr.goods_amount - orderArr.coupons.cou_moneya-orderArr.discount+orderArr.shipping_fee*1}}</text>
				</view>
				<view class="fr" v-else-if="orderArr.extension_code=='presale' && orderArr.detail_status==6&&  orderArr.deposit_type!=1">
					<text>实付金额：</text>
					<text style="font-weight: bold;">￥{{orderArr.money_paid}}</text>
				</view>
			</view>
			<view v-else-if="orderArr.extension_code!='presale' && orderArr.detail_status==6 && orderArr.deposit_type!=1" class="orderpay_Info clear">
				<view class="fr">
					<text>实付金额：</text>
					<text style="font-weight: bold;">￥0.00</text>
				</view>
			</view>
			<image class="di" src="https://www.abcbook2019.com/mobile/public/img/user/jag.png" mode=""></image>
		</view>
		<view class="contactUs">
			<text>客服微信：abcbookkf</text>
			<text v-if="orderArr.ru_id>0">客服电话：400-659-9993</text>
			<text v-else>客服电话：400-850-8556</text>
		</view>

		<view class="filter-btn" v-if="orderArr.failure>0">
			<button class="btn grey" type="primary">订单过期</button>
			<button class="btn" type="primary" @click.stop="navToindx()">重新选书</button>
		</view>
		<block v-else>
			<view class="filter-btn" v-if="orderArr.detail_status==1">
				<button class="btn grey" type="primary" @click.stop="cancelOrder(orderArr.order_id)">取消订单</button>
				<button class="btn" type="primary" v-if="(orderArr.goods_amount>0 || orderArr.deposit_type==1) && (orderArr.hyk === 1 || orderArr.ru_id>0)"
				 @click="nopayscore(orderArr)">立即支付</button>
				<button class="btn" type="primary" v-else-if="orderArr.goods_amount>0 || orderArr.deposit_type==1" @click="gotopay(orderArr)">立即支付</button>
				<button class="btn" type="primary" v-else @click.stop="navToindx()">返回首页</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==2">
				<!-- <button class="btn grey" type="primary" open-type='contact'>联系客服</button> -->
				<!-- <button class="btn" type="primary" @click.stop="navToindx()">再去逛逛</button> -->
				<button class="btn grey" type="primary" @click.stop="cancelOrder(orderArr.order_id)">取消订单</button>
				<button class="btn" type="primary" @click.stop="navToindx()" v-if="orderArr.ru_id>0">返回首页</button>
				<button class="btn grey" type="primary " @click.stop="looklogistics('show')" v-else>查看物流</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==3">
				<!-- #ifdef MP -->
				<button class="btn grey" type="primary" open-type='contact'>联系客服</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn" type="primary" @click.stop="navToindx()">再去逛逛</button>
				<!-- #endif -->
				<button class="btn" type="primary" @click.stop="navToindx()" v-if="orderArr.ru_id>0">返回首页</button>
				<button class="btn" type="primary" @click.stop="looklogistics('show')" v-else>查看物流</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==4">
				<!-- #ifdef MP -->
				<button class="btn grey" type="primary" v-if="orderArr.user_ranks==5" @click.stop="delayReturn(orderArr)">延期还书</button>
				<button class="btn grey" type="primary" v-else open-type='contact'>联系客服</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn grey" type="primary" v-if="orderArr.user_ranks==5" @click.stop="delayReturn(orderArr)">延期还书</button>
				<button class="btn grey" type="primary" @click.stop="navToindx()">返回首页</button>
				<!-- #endif -->
				<button class="btn" type="primary" v-if="orderArr.ru_id==0" @click.stop="yoreturn(orderArr.order_id,orderArr.return_rec_id)">预约还书</button>
				<button class="btn" type="primary" v-else @click.stop="navToindx()">再去逛逛</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==5">
				<!-- #ifdef MP -->
				<button class="btn grey" type="primary" open-type='contact'>联系客服</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn grey" type="primary" @click.stop="navToindx()">返回首页</button>
				<!-- #endif -->
				<button class="btn" type="primary" @click.stop="navToindx()">再去逛逛</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==6">
				<block v-if="orderArr.hyk==1">
					<block v-if="orderArr.member_status != 88">
						<button class="btn grey" type="primary" v-if="orderArr.pay_id>0 && orderArr.money_paid>0 && orderArr.extension_code!='presale' && orderArr.rec_type!==6 && orderArr.rec_type!==84"
						 @click.stop="refund(orderArr.order_id)">申请退卡</button>
						<button class="btn grey" type="primary" v-else @click.stop="navToindx()">前去选书</button>
						<button class="btn" type="primary" @click.stop="gotomem(orderArr.order_id)">立即激活</button>
					</block>
					<block v-else>
						<button class="btn grey" type="primary" @click.stop="navToindx()">前去选书</button>
						<button class="btn grey" type="primary">已激活</button>
					</block>
				</block>
				<block v-else>
					<!-- #ifdef MP -->
					<button class="btn grey" type="primary" open-type='contact'>联系客服</button>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<button class="btn grey" type="primary" @click.stop="navToindx()">返回首页</button>
					<!-- #endif -->
					<button class="btn" type="primary" @click.stop="navToindx()">重新选书</button>
				</block>


			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==7">
				<!-- #ifdef MP -->
				<button class="btn grey" type="primary" open-type='contact'>联系客服</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn grey" type="primary" @click.stop="navToindx()">返回首页</button>
				<!-- #endif -->
				<button class="btn" type="primary" @click.stop="navToindx()">重新选书</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==8">
				<!-- #ifdef MP -->
				<button class="btn grey" type="primary" open-type='contact'>联系客服</button>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<button class="btn grey" type="primary" @click.stop="navToindx()">返回首页</button>
				<!-- #endif -->
				<button class="btn" type="primary" @click.stop="navToindx()">再去逛逛</button>
			</view>
			<view class="filter-btn" v-if="orderArr.detail_status==103">
				<button class="btn grey" type="primary">等待成团</button>
				<button class="btn" type="primary" @click.stop="navToindx()">再去逛逛</button>
			</view>
			<!-- <view class="filter-btn" v-if="orderArr.detail_status==101">
				<button class="btn grey" open-type='contact' type="primary" >联系客服</button>
				<button class="btn" v-if="newTime>orderArr.presale.start_time && newTime<orderArr.presale.end_time" type="primary" @click.stop="gotopay(orderArr)">支付尾款</button>
				<button class="btn grey" v-if="newTime<orderArr.presale.start_time" type="primary">未到时间</button>
				<button class="btn grey" v-if="orderArr.presale.end_time<newTime" type="primary" >超出时间</button>
			</view> -->
		</block>

		<!-- 物流 -->
		<view class="mask" :class="maskState===0 ? 'none' : maskState===1 ? 'show' : ''" @click="looklogistics">
			<!-- <view class="nolist" v-if="list2.length==0">
				您的图书在快速打包中..
			</view> -->
			<uni-steps class="mask-content" :options="list2" :active="active" direction="column" />
		</view>
		<!-- 弹框 -->
		<view class="pop-up" v-if="popup">

			<view class="upcon">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
				<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/upcon.png" mode="widthFix"></image>
				<view class="upopinion">
					<text @click="opinion('n')">先不用</text>
					<text class="main" @click="opinion('y')">免押金租书</text>
				</view>
			</view>
		</view>
		
		<view class="popup" v-if="success">
			<view class="message">
				<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/success.png" mode="widthFix"></image>
				<view class="textit">恭喜成为{{rankName}}</view>
				<view class="tex">快去首页选书吧 每次可借阅10本哦</view>
				<button class="btn" type="primary" @click="gotoind()">去选书</button>
			</view>
			
		</view>
		
		<!-- 延期还书弹框 -->
		<view class="pop-up delayup" v-if="delayup">
			<view class="upcon">
				<image class="close" src="https://www.abcbook2019.com/mobile/public/img/pop-up/close.png" mode="" @click.stop="close()"></image>
				
				<view class="conpage">
					<view class="titletop">温馨提示</view>
					<view class="conmain">选择延期还书后将扣除您一次借阅次数</view>
				</view>
				<view class="upopinion">
					<text @click.stop="close()">先不用</text>
					<text class="lasttext"  @click.stop="delay()">延期还书</text>
				</view>
			</view>
		</view>
		<!-- 返回首页 -->
		<goHome></goHome>
	</view>
	<mixLoading v-else></mixLoading>
</template>

<script>
	// #ifdef H5
	import H5wxjs from "../../common/jwx.js";
	// #endif
	import uniSteps from '@/components/uni-steps/uni-steps.vue'
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	import goHome from '@/components/home.vue';
	export default {
		data() {
			return {
				popup: false, //弹框
				loading: false,
				maskState: 0,
				Surplusday: null,
				delayup:false,   //延期弹框
				order_sn: null,
				itemclick:[],
				success:false,   //激活成功弹框
				rankName:'',
				orderArr: [],
				logistics: false,
				list2: [],
				list3: [],
				start_time: '',
				end_time: '',
				newTime: '',
				deCode: '',
				active: 5
			}
		},
		components: {
			uniSteps,
			mixLoading,
			goHome
		},
		onLoad(option) {
			let that = this
			this.detindex=option.id
			//商品数据
			console.log(option);
			this.init()

		},
		methods: {
			init(){
				this.$api.quest('user/order/detail', {
					id: this.detindex
				}, (res) => {
					// console.log(res, 'd')
					// that.detail_status = res.data.data.detail_status
					// that.deposit_type = res.data.data.deposit_type
					// that.goods_amount = res.data.data.goods_amount
					// that.hyk = res.data.data.hyk
					this.orderArr = res.data.data
					this.list2 = this.orderArr.invo_list
					this.loading = true
					// that.orderid = res.data.data.order_id
				})
				// #ifdef H5			
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					this.deCode = option.deCode
				}
				// #endif
			},
			// 弹框
			close() {
				console.log('关闭弹框')
				this.popup = false;
				this.delayup=false;   //延期体验弹框
			},
			// 去选书
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			delay(){
				console.log(this.itemclick)
				this.$api.quest('user/delayReturn',{
					order_id:this.itemclick.order_id
				},(res)=>{
					// console.log(res.data.code)
					if(res.data.code==0){
						this.delayup=false;  
						this.$api.msg(res.data.data)
						this.$api.quest('user/order/detail', {
							id: this.itemclick.order_id
						}, (res) => {
							// console.log(res, 'd')
							// this.detail_status = res.data.data.detail_status
							// this.deposit_type = res.data.data.deposit_type
							// this.goods_amount = res.data.data.goods_amount
							// this.hyk = res.data.data.hyk
							this.orderArr = res.data.data
							this.list2 = this.orderArr.invo_list
							this.loading = true
							// this.orderid = res.data.data.order_id
						})
					}else{
						// console.log(1111)
						this.delayup=false; 
						this.$api.msg(res.data.data)
					}
					// console.log(res.data)
				})
			},
			// 延期还书
			delayReturn(item){
				this.delayup=true
				this.itemclick=item
			},
			// 判断是否是支付分
			opinion(type) {
				this.$api.quest('flow/againorder', {
					order_id: this.orderArr.order_id,
					type: type == 'y' ? 1 : 0
				}, (res) => {
					if (res.data.code == 0) {
						// this.payment=options.payment
						uni.setStorageSync('ordersn', res.data.error)
						if (type == 'y') {
							// console.log('调用支付分')
							this.gopay()
							this.deposittype = 1
						} else {
							// console.log('没有使用支付分')
							this.nopayscore(this.orderArr)
						}
					}else{
						this.$api.msg(res.data.data)
					}
					


				})


			},
			// 微信支付  没有使用支付分
			nopayscore(payli) {

				if(payli.order_amount==0){
					uni.navigateTo({
						url: '/pages/money/paySuccess?id=' + payli.order_id + '&payok=0&payment=' + payli.order_amount
					})
				}else{
					uni.navigateTo({ 
						url: '/pages/money/pay?id=' + payli.order_id + '&payment=' + payli.order_amount,
						// #ifdef H5
						success: (res) => {
							if (res.errMsg == 'navigateTo:ok') {
								window.location.reload(true);
							}
						}
						// #endif
					})
				}
				// console.log(payli.extension_code)
				// 预售活动 presale
				// if(payli.extension_code=='presale'){
				// 	uni.navigateTo({
				// 		url:'/pages/money/pay?id='+payli.order_id+'&payment='+payli.order_amount
				// 	})
				// }else{
				// 	uni.navigateTo({
				// 		url:'/pages/money/pay?id='+payli.order_id+'&payment='+payli.goods_amount
				// 	})
				// }

				// this.$api.quest('flow/againorder',{
				// 	order_id:payli.order_id,
				// 	type:0
				// },(res)=>{
				// 	if(res.data.code==0){
				// 		// this.payment=options.payment
				// 		// 预售活动 presale
				// 		if(payli.extension_code=='presale'){
				// 			uni.navigateTo({
				// 				url:'/pages/money/pay?id='+payli.order_id+'&payment='+payli.order_amount
				// 			})
				// 		}else{
				// 			uni.navigateTo({
				// 				url:'/pages/money/pay?id='+payli.order_id+'&payment='+payli.goods_amount
				// 			})
				// 		}
				// 	}
				// })
			},
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			countDown(it, type) {
				console.log(it)
				var interval = setInterval(() => {
					// 获取当前时间，同时得到活动结束时间数组
					let newTime = Date.parse(new Date()) / 1000;
					this.newTime = newTime
					// 对结束时间进行处理渲染到页面
					let endTime = it
					let obj = null;
					// 如果活动未结束，对时间进行处理
					if (endTime - newTime > 0) {
						// console.log(endTime,newTime)
						let time = (endTime - newTime);
						// 获取天、时、分、秒
						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
						// console.log(type)
						if (type == 'start_time') {
							// console.log('sta')
							this.start_time = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';

						} else if (type == 'end_time') {
							this.end_time = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
						}
						// console.log(this.start_time,this.end_time)
					} else { // 活动已结束，全部设置为'00'
						if (type == 'start_time') {
							this.start_time = '';
						} else if (type == 'end_time') {
							this.end_time = '';
						}
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00'
						};
						this.onLoad()
						if (type == 'start_time') {
							// console.log('sta')
							this.start_time = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';

						} else if (type == 'end_time') {
							this.end_time = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
						}
						clearInterval(interval);
					}
				}, 1000);
			},
			gotopay(payli) {
				// #ifdef MP
				this.popup = true
				// #endif
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					this.popup = true
				} else {
					this.nopayscore(this.orderArr)
				}
				// #endif

			},
			looklogistics(type) {
				if (this.list2.length == 0) {
					this.$api.msg('您的图书在加速打包中..')
				} else {
					let timer = type === 'show' ? 10 : 300;
					let state = type === 'show' ? 1 : 0;
					this.maskState = 2;
					setTimeout(() => {
						this.maskState = state;
					}, timer)
				}

			},
			
			// 取消订单
			cancelOrder(id) {
				// uni.showLoading({
				// 	title: '请稍后'
				// })
				this.$api.quest('user/order/cancel', {
					id: id
				}, (res) => {
					if (res.data.code == 1) {
						this.$api.msg(res.data.data)
						this.init()
						// uni.navigateTo({
						// 	url: '/pages/user/user'
						// })
					} else {
						this.$api.msg(res.data.data)
						
					}
					// uni.hideLoading();
				})
			
			},
			yoreturn(order, rec) {
				console.log("order预约还书")
				this.$api.quest('user/checkReturn', {
					rec_id: rec
				}, (res) => {
					console.log(res)
					if (res.data.code == 1) {
						uni.navigateTo({
							url: '/pages/appoint/appoint?rec=' + rec + '&order=' + order
						})
					} else {
						this.$api.msg(res.data.data)
					}
				})

			},
			// 去首页
			navToindx() {
				// this.$store.commit("change_page", 0)
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
			// 去评价
			evaluate(rec) {
				uni.navigateTo({
					url: '/pages/detail/evaluate?rec=' + rec
				})
			},
			// 申请退卡
			refund(id,index){
				this.$api.quest('user/refund',{
					order_id:id
				},(res)=>{
					console.log(res.data.data)
					if(res.data.code==0){
						this.$api.msg("退卡成功")
						// this.dataArr.splice(index,1)
						this.init()
					}else{
						this.$api.msg("退卡失败，请联系客服")
					}
				})
			},
			// 立即激活
			gotomem(id) {
				// uni.navigateTo({
				// 	url: '/pages/members/members'
				// })
				this.$api.quest('user/activity',{
					order_id:id
				},(res)=>{
					console.log(res)
					if(res.data.code==0){
						// this.$api.msg("激活成功")
						this.dataArr.splice(index,1)
						this.rankName=res.data.data.ranks_name
						this.success=true
						this.init()
					}else{
						this.$api.msg(res.data.data)
					}
				})
			},
			// #ifdef H5
			compareVersion(v1, v2) {
				v1 = v1.split('.')
				v2 = v2.split('.')
				const len = Math.max(v1.length, v2.length)
				while (v1.length < len) {
					v1.push('0')
				}
				while (v2.length < len) {
					v2.push('0')
				}
				for (let i = 0; i < len; i++) {
					const num1 = parseInt(v1[i])
					const num2 = parseInt(v2[i])
					if (num1 > num2) {
						return 1
					} else if (num1 < num2) {
						return -1
					}
				}
				return 0
			},
			// #endif	
			// 支付分
			gopay() {
				// #ifdef MP
				console.log('支付分支付接口')
				this.$api.quest('payscore/add', {
					order_sn: uni.getStorageSync("ordersn"),
					user_id: uni.getStorageSync("user_id"),
					book_num: this.orderArr.goods_list.length
				}, (res) => {
					let that = this;
					console.log(res)
					if (res.data.data.code == 1) {
						// this.$api.msg(res.data.data.msg)
						that.$api.quest('payscore/changesn', {
							order_id: that.id
						}, (res) => {
							console.log(res)
							uni.setStorageSync('ordersn', res.data.data)
							console.log(res)
							if (res.data.code == 0) {
								this.gopay()
							} else {
								this.$api.msg('下单失败')
							}
						})
					} else {
						this.anewtype = true;

						if (wx.openBusinessView) {
							wx.openBusinessView({
								businessType: 'wxpayScoreUse',
								extraData: {
									mch_id: res.data.data.mch_id,
									package: res.data.data.package,
									timestamp: res.data.data.timestamp,
									nonce_str: res.data.data.nonce_str,
									sign_type: res.data.data.sign_type,
									sign: res.data.data.sign_sh256
								},
								success(res) {

									that.$api.quest('payscore/searchdb', {
										out_order_no: uni.getStorageSync("ordersn")
									}, (res) => {
										uni.navigateTo({
											url: '/pages/money/paySuccess?id=' + that.orderArr.order_id + '&payok=0&payment=' + that.orderArr.order_amount
										})
										// if(res.data.data.msg_id){
										// 	uni.navigateTo({
										// 		url: '/pages/money/paySuccess?id=' + that.orderArr.order_id+ '&payok=0&payment='+that.orderArr.order_amount
										// 	})
										// }else{
										// 	uni.navigateTo({
										// 		url: '/pages/money/paySuccess?id=' + that.orderArr.order_id+'&payok=1&payment='+that.orderArr.order_amount
										// 	})
										// }

									})
								},
								fail(faill) {
									uni.navigateTo({
										url: '/pages/money/paySuccess?id=' + that.orderArr.order_id + '&payok=1&payment=' + that.orderArr.order_amount
									})
								},
								complete(com) {
									console.log(com)
								}
							});
						} else {
							//引导用户升级微信版本
						}
					}

				})
				// #endif
				// #ifdef H5
				let lis = this
				lis.$api.quest('payment/getticketsign', {
					code: lis.deCode,
					url: decodeURIComponent(window.location.href.split('#')[0])
				}, (reda) => {
					console.log(reda.data.data, 'eee')
					lis.cketsign = reda.data.data.sign
					// alert(lis.cketsign)
					let wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i);
					console.log(wechatInfo);
					let wechatVersion = wechatInfo[1];
					if (lis.compareVersion(wechatVersion, "7.0.5") >= 0) {
						console.log("www");
						// alert("www");
						H5wxjs.config({
							// debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
							appId: reda.data.data.appid, // 必填，公众号的唯一标识wxbdbc05d9a09741f7
							timestamp: reda.data.data.timestamp, // 必填，生成签名的时间戳
							nonceStr: reda.data.data.nonceStr, // 必填，生成签名的随机串
							signature: reda.data.data.sign, // 必填，签名
							jsApiList: ["openBusinessView"] // 必填，需要使用的JS接口列表
						});
						H5wxjs.ready(function() {
							// config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
							H5wxjs.checkJsApi({
								jsApiList: [
									"openBusinessView",
								], // 需要检测的JS接口列表
								success: function(data) {
									console.log(data, "rrr");
									// 以键值对的形式返回，可用的api值true，不可用为false
									// 如：{"checkResult":{"openBusinessView":true},"errMsg":"checkJsApi:ok"}
									if (data.checkResult.openBusinessView) {
										// alert("ddd");
										console.log("ddd");
										// alert(JSON.stringify(res.data.data));
										lis.$api.quest('payscore/add_h5', {
											order_sn: uni.getStorageSync("ordersn"),
											user_id: uni.getStorageSync("user_id"),
											book_num: lis.orderArr.goods_list.length
										}, (res) => {
											console.log(res.data.data, 'add_h5');
											let that = this;
											if (res.data.data.code == 0) {
												lis.anewtype = true;
												H5wxjs.invoke(
													"openBusinessView", {
														businessType: "wxpayScoreUse",
														queryString: "mch_id=" + res.data.data.mch_id + "&package=" + res.data.data.package +
															"&timestamp=" + res.data.data.timestamp + "&nonce_str=" + res.data.data.nonce_str +
															"&sign_type=" + res.data.data.sign_type + "&sign=" + res.data.data.sign_sh256
													},
													function(res) {
														console.log(res, "l");
														// alert(JSON.stringify(res), '450');
														// 从微信侧小程序返回时会执行这个回调函数
														if (parseInt(res.err_code) == 0) {

															window.location.href = 'https://www.abcbook2019.com/mobile/h5/#/pages/money/paySuccess?id=' +
																lis.id + '&payok=0&payment=' + lis.orderArr.order_amount

														} else {
															// url: '/pages/money/paySuccess?id=' + that.orderArr.order_id + '&payok=1&payment=' + that.orderArr.order_amount

															window.location.href = 'https://www.abcbook2019.com/mobile/h5/#/pages/money/paySuccess?id=' +
																lis.orderArr.order_id + '&payok=1&payment=' + lis.orderArr.order_amount
															// 返回失败
														}
													}
												);

											} else {

												// this.$api.msg(res.data.data.msg)
												lis.$api.quest('payscore/changesn', {
													order_id: lis.itemclick.order_id
												}, (res) => {
													// console.log(res)
													uni.setStorageSync('ordersn', res.data.data)
													// console.log(res)
													if (res.data.code == 0) {
														this.gopay()
													}
												})

											}
										})

									}
								}
							});
						});
					} else {
						// 提示用户升级微信客户端版本
						console.log("vvv");
						// alert("vvv");
						window.location.href =
							"https://support.weixin.qq.com/cgi-bin/readtemplate?t=page/common_page__upgrade&text=text005&btn_text=btn_text_0";
					}
				})

				// #endif




			},

		}
	}
</script>

<style lang="scss">
	// .f-h-adr-con{
	// 	flex: 1;
	// }
	
	.popup{
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		background: rgba(0,0,0,.5);
		z-index: 999;
		.message{
			position: absolute;
			top: 30%;
			left: 50%;
			transform: translate(-50%);
			width:488rpx;
			height:366rpx;
			background:rgba(255,255,255,1);
			border-radius:24rpx;
			text-align:center;
			image{
				position: absolute;
				top: -75rpx;
				left:50%;
				transform: translate(-50%);
				width: 306rpx;
				height: 225rpx;
			}
			.textit{
				color:#FF824B;
				font-size: 34rpx;
				margin-top:139rpx;
				margin-bottom: 10rpx;
			}
			.tex{
				font-size: 26rpx;
				color: #666;
			}
			.btn{
				width:408rpx;
				line-height:88rpx;
				color: #fff;
				font-size: 32rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0rpx 4rpx 8rpx 0rpx rgba(255,130,75,0.5);
				border-radius:49rpx;
				margin-top: 30rpx;
			}
			
		}
	}
	
	
	
	.headtitle {
		/* #ifdef H5 */
		margin-top: -86rpx;
		/* #endif */
	}
	.yaj{
		display: flex;
		width: 100%;
		align-items: center;
		justify-content: space-between;
	}
	.deposit {
		color: #FF824B !important;
		text-decoration: line-through;
	}

	.delayup{
		.upopinion{
			border-top: 1rpx solid #e6e6e6;
			text{
				// width: 200rpx !important;
				// line-height: 60rpx !important;
			}
			.lasttext{
				background:linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				color: #fff !important;
				border: none !important;
			}
		}
	}
	.pop-up {
		width: 100vw;
		height: 100vh;
		background: rgba(0, 0, 0, .6);
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;
		.conpage{
			.titletop{
				margin: 50rpx 0 30rpx 0;
				font-size: 42rpx;
				color: #333;
			}
			.conmain{
				font-size: 28rpx;
				color: #666;
				margin-bottom: 20rpx;
			}
		}
		.upcon {
			/* height: 500rpx; */
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background: #fff;
			border-radius: 24rpx;
			text-align: center;
	
			image {
				width: 660rpx;
				height: 752rpx;
			}
	
			.close {
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				top: 20rpx;
				right: 25rpx;
				z-index: 9;
			}
	
			.upopinion {
				display: flex;
				width: 660rpx;
				margin: 0 auto;
				height: 148rpx;
				justify-content: space-around;
				align-items: center;
	
				text {
					width: 300rpx;
					line-height: 84rpx;
					border: 2rpx solid #666;
					border-radius: 44rpx;
					font-size: 32rpx;
					color: #666;
				}
	
				.main {
					color: #fff;
					line-height: 88rpx;
					border: none;
					background: linear-gradient(135deg, #fea364 0%, #fa6c3a 100%);
				}
			}
	
		}
	}
	
	

	.addressor {
		width: 80rpx;
		color: #FF824B;
		margin-right: 20rpx;
	}

	@import '../../static/css/orderdetil.scss';

	page {
		padding-bottom: 100upx;
	}

	page {
		display: flex;
		flex-direction: column;
		box-sizing: border-box;
		background-color: #fafafa;
	}

	view {
		font-size: 28upx;
		line-height: inherit
	}

	.page_expert_main {
		.right {
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			height: 144rpx;
			margin-left: 20rpx;
			flex-wrap: wrap;
			overflow: hidden;

			.title {
				width: 400rpx;
				word-break: break-all
			}
		}
	}

	.example {
		padding: 0 30upx 30upx
	}

	.example-title {
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 32upx;
		color: #464e52;
		padding: 30upx 30upx 30upx 50upx;
		margin-top: 20upx;
		position: relative;
		background-color: #fdfdfd;
		border-bottom: 1px #f5f5f5 solid
	}

	.example-title__after {
		position: relative;
		color: #031e3c
	}

	.example-title:after {
		content: '';
		position: absolute;
		left: 30upx;
		margin: auto;
		top: 0;
		bottom: 0;
		width: 6upx;
		height: 32upx;
		background-color: #ccc
	}

	.example .example-title {
		margin: 40upx 0
	}

	.example-body {
		padding: 30upx;
		background: #fff
	}

	.example-info {
		padding: 30upx;
		color: #3b4144;
		background: #fff
	}

	button {
		margin: 30upx;
	}

	.address-section {
		padding: 30upx 0;
		background: #fff;
		position: relative;

		.order-content {
			display: flex;
			align-items: center;
		}

		.icon-shouhuodizhi {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 90upx;
			color: #888;
			font-size: 44upx;
		}

		.cen {
			display: flex;
			flex-direction: column;
			flex: 1;
			font-size: 28upx;
			color: $font-color-dark;
		}

		.name {
			font-size: 34upx;
			margin-right: 24upx;
		}

		.address {
			margin-top: 16upx;
			margin-right: 20upx;
			color: $font-color-light;
		}

		.icon-you {
			font-size: 32upx;
			color: $font-color-light;
			margin-right: 30upx;
		}

		.a-bg {
			position: absolute;
			left: 0;
			bottom: 0;
			display: block;
			width: 100%;
			height: 5upx;
		}
	}

	.goods-section {
		margin-top: 16upx;
		background: #fff;
		padding-bottom: 1px;

		.g-header {
			display: flex;
			align-items: center;
			height: 84upx;
			padding: 0 30upx;
			position: relative;
		}

		.logo {
			display: block;
			width: 50upx;
			height: 50upx;
			border-radius: 100px;
		}

		.name {
			font-size: 30upx;
			color: $font-color-base;
			margin-left: 24upx;
		}

		.g-item {
			display: flex;
			margin: 20upx 30upx;

			image {
				flex-shrink: 0;
				display: block;
				width: 140upx;
				height: 140upx;
				border-radius: 4upx;
			}

			.right {
				flex: 1;
				padding-left: 24upx;
				overflow: hidden;
				flex-direction: column;

				.title {
					font-size: 30upx;
					color: $font-color-dark;
				}
			}



			.spec {
				font-size: 26upx;
				color: $font-color-light;
			}

			.price-box {
				display: flex;
				align-items: center;
				font-size: 32upx;
				color: $font-color-dark;
				padding-top: 10upx;

				.price {
					margin-bottom: 4upx;
				}

				.number {
					font-size: 26upx;
					color: $font-color-base;
					margin-left: 20upx;
				}
			}

			.step-box {
				position: relative;
			}
		}
	}

	.yt-list {
		margin-top: 16upx;
		background: #fff;
	}

	.yt-list-cell {
		display: flex;
		align-items: center;
		padding: 10upx 30upx 10upx 40upx;
		line-height: 70upx;
		position: relative;

		&.cell-hover {
			background: #fafafa;
		}

		&.b-b:after {
			left: 30upx;
		}

		.cell-icon {
			height: 32upx;
			width: 32upx;
			font-size: 22upx;
			color: #fff;
			text-align: center;
			line-height: 32upx;
			background: #f85e52;
			border-radius: 4upx;
			margin-right: 12upx;

			&.hb {
				background: #ffaa0e;
			}

			&.lpk {
				background: #3ab54a;
			}

		}

		.cell-more {
			align-self: center;
			font-size: 24upx;
			color: $font-color-light;
			margin-left: 8upx;
			margin-right: -10upx;
		}

		.cell-tit {
			flex: 1;
			font-size: 26upx;
			color: $font-color-light;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: 26upx;
			color: $font-color-dark;

			&.disabled {
				color: $font-color-light;
			}

			&.active {
				color: $base-color;
			}

			&.red {
				color: $base-color;
			}
		}

		&.desc-cell {
			.cell-tit {
				max-width: 90upx;
			}
		}

		.desc {
			flex: 1;
			font-size: $font-base;
			color: $font-color-dark;
		}
	}

	/* 支付列表 */
	.pay-list {
		padding-left: 40upx;
		margin-top: 16upx;
		background: #fff;

		.pay-item {
			display: flex;
			align-items: center;
			padding-right: 20upx;
			line-height: 1;
			height: 110upx;
			position: relative;
		}

		.icon-weixinzhifu {
			width: 80upx;
			font-size: 40upx;
			color: #6BCC03;
		}

		.icon-alipay {
			width: 80upx;
			font-size: 40upx;
			color: #06B4FD;
		}

		.icon-xuanzhong2 {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 40upx;
			color: $base-color;
		}

		.tit {
			font-size: 32upx;
			color: $font-color-dark;
			flex: 1;
		}
	}

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 995;
		display: flex;
		align-items: center;
		width: 100%;
		height: 90upx;
		justify-content: space-between;
		font-size: 30upx;
		background-color: #fff;
		z-index: 998;
		color: $font-color-base;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, .1);

		.price-content {
			padding-left: 30upx;
		}

		.price-tip {
			color: $base-color;
			margin-left: 8upx;
		}

		.price {
			font-size: 36upx;
			color: $base-color;
		}

		.submit {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 280upx;
			height: 100%;
			color: #fff;
			font-size: 32upx;
			background-color: $base-color;
		}
	}

	/* 优惠券面板 */
	.mask {
		display: flex;
		align-items: flex-end;
		position: fixed;
		left: 0;
		top: var(--window-top);
		bottom: 0;
		width: 100%;
		background: rgba(0, 0, 0, 0);
		z-index: 9995;
		transition: .3s;

		.mask-content {
			position: absolute;
			width: 80%;
			top: 25vh;
			left: 50%;
			border-radius: 10rpx;
			margin-left: -40%;
			min-height: 30vh;
			max-height: 50vh;
			background: #f3f3f3;
			// transform: translate(-50%,0);
			transition: .3s;
			overflow-y: scroll;
			-webkit-overflow-scrolling: touch;
		}

		&.none {
			display: none;
		}

		&.show {
			background: rgba(0, 0, 0, .4);

			.mask-content {
				transform: translateY(0);
			}
		}
	}

	/* 优惠券列表 */
	.coupon-item {
		display: flex;
		flex-direction: column;
		margin: 20upx 24upx;
		background: #fff;

		.con {
			display: flex;
			align-items: center;
			position: relative;
			height: 120upx;
			padding: 0 30upx;

			&:after {
				position: absolute;
				left: 0;
				bottom: 0;
				content: '';
				width: 100%;
				height: 0;
				border-bottom: 1px dashed #f3f3f3;
				transform: scaleY(50%);
			}
		}

		.left {
			display: flex;
			flex-direction: column;
			justify-content: center;
			flex: 1;
			overflow: hidden;
			height: 100upx;
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			margin-bottom: 10upx;
		}

		.time {
			font-size: 24upx;
			color: $font-color-light;
		}

		.right {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-size: 26upx;
			color: $font-color-base;
			height: 100upx;
		}

		.price {
			font-size: 44upx;
			color: $base-color;

			&:before {
				content: '￥';
				font-size: 34upx;
			}
		}

		.tips {
			font-size: 24upx;
			color: $font-color-light;
			line-height: 60upx;
			padding-left: 30upx;
		}

		.circle {
			position: absolute;
			left: -6upx;
			bottom: -10upx;
			z-index: 10;
			width: 20upx;
			height: 20upx;
			background: #f3f3f3;
			border-radius: 100px;

			&.r {
				left: auto;
				right: -6upx;
			}
		}
	}

	.logistics {
		position: fixed;
		top: 20%;
		left: 50%;
		margin-left: -345rpx;
		width: 690rpx;
		height: 600rpx;
		overflow-y: auto;
		background: #fff;
		opacity: .8;
		border-radius: 10rpx;

		&.none {
			display: none;
		}

		&.show {
			background: rgba(0, 0, 0, .4);

			.mask-content {
				transform: translateY(0);
			}
		}
	}
</style>
