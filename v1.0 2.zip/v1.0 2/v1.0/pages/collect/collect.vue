<template>
	<view v-if="load" class="container">
		<!-- 空白页 -->
		<view v-if="collList.length!=0">
			<!-- 列表 -->
			<view class="cart-list">
				<!-- 列表详情 -->
				<view class="bookcarklist">
					<block v-for="(item, index) in collList">
						<view class="cart-item clear" @click="gotodet(item.goods_id)">
							<view class="cart-itemcon fr">
								<image :src="item.goods_thumb" class="fl" :class="[item.loaded]" mode="aspectFill" lazy-load @load="onImageLoad('cartList', index)"
									 @error="onImageError('cartList', index)"></image>
								<view class="title">
									{{item.goods_name}}
								</view>
								<view class="infofr">
									<view class="del" @click.stop="deleteconItem(item,index)">
										<view class="deltop">
											<image src="/static/det.png" mode=""></image>
										</view>
										<text class="del-btn fr" 
										:class="item.is_collect?'iscollect':''" 
										>删除</text>
									</view>
								</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>
		<view v-else class="empty">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>还没有收藏商品哦</view>
				<view>快去寻找自己喜欢的绘本吧~</view>
				<view class="navigator" @click="navToLogin">去逛逛</view>
			</view>
		</view>
		<view class="main-content">
			<footer>
				<bottom-nav class="" ref="bottomNav"></bottom-nav>
			</footer>
		</view>
		<view :class="{'classon':classon}">{{classoninfo}}</view>
	</view>
</template>

<script>
	import Vue from 'vue'
	import bottomNav from "@/pages/navbar/navbar.vue";
	
	import {
		mapState
	} from 'vuex';
	export default {
		components: {
			bottomNav
		},
		data() {
			return {
				num: 0, //选中总数量
				allChecked: 0, //全选状态  true|false
				empty: false, //空白页现实  true|false
				collList: [],
				address:false,  //判断有没有地址
				load:false,
				page:1,
				classoninfo:"" ,//加载展示内容
				hasno:false    ,//判断有没有消息
				success:false,
				classon:false
			};
		},
		onReachBottom(){
			this.scroll();
		},
		onLoad() {
			let that = this
			this.$api.quest('user/collectgoods',{
				page:1,
				size:10
			},(res)=>{
				console.log(res)
				that.collList = res.data.data
				this.load=true
			})
		},
		watch: {
		}, 
		computed: {
		},
		methods: {
			gotodet(id){
				uni.navigateTo({
					url: '/pages/detail/detail?id='+id
				})
			},
			// 下拉加载
			scroll(){
				const that=this;
				console.log(that.classon,"classon")
				that.classon=true;
				that.classoninfo="正在努力加载..."
				this.loadingType=1;
				this.$api.quest('user/collectgoods',{
					page:++that.page,
					size:10
				},(res)=>{
					console.log(res.data.data.length)
					if (res.data.data.length == 0) {  //没有数据
					    this.loadingType = 2;
						that.classon=true;
						that.classoninfo="我也是有底线的哦~"
					    return;
					}
						that.collList.push(...res.data.data) 
						 that.classon=false   //判断模块框
				})
				
			},
			//监听image加载完成
			onImageLoad(key, index) {
			},
			//监听image加载失败
			onImageError(key, index) {
				// this[key][index].image = '/static/errorImage.jpg';
			},
			navToLogin() {
				uni.navigateBack()
				// this.$store.commit("change_page", 0)
				// uni.navigateTo({
				// 	url: '/pages/index/index'
				// })
			},
			//删除
			deleteconItem(e,index) {
				uni.showLoading()
				let list = this.collList;
				let row = list[index];
				let id = row.goods_id;
				console.log(row)
				this.$api.quest('user/collect/add',{
					id : id,
					uid : uni.getStorageSync("user_id")
				},(res)=>{
					// that.cartList = res.data.data.cart_list[0]
					console.log(res)
					uni.hideLoading();
					uni.showToast({
						title: '删除成功',
						icon: 'none',
						duration: 2000
					});
					list.splice(index, 1);
					
				})
				
				
			}
		}
	}
</script>

<style lang='scss'>
	@import '../../static/css/public.scss';
	@import '../../static/css/shujia.scss';
	.classon{
		font-size: 26rpx;
		color: rgba(153,153,153,1);
		text-align: center;
		margin-top: 20rpx;
	}
	.cart-itemcon{
		width: 100% !important;
		margin-left: 20rpx !important;
	}
	.infofr{
		width: auto !important;
		justify-content: center !important;
	}
	.onechecked{
		width: 40rpx;
		height: 40rpx;
	}
	.total-box{
		.num{
			font-size: 30rpx;
		}
	}
	.empty{
		image{
			width: 287rpx;
			height: 181rpx;
		}
		.empty-tips{
			text{
				display: block;
			}
		}
	}
</style>

