<template>
	<view class="user">
		<!-- 顶部 -->
		<view class="head">
			<view class="user_info">
				<view class="fl" @click="gotologin">
					<view class="userrank">
						<image class="portrait" :src="userArr.userInfo.user_picture || '/static/missing-face.png'"></image>
						<view class="info">
							<!-- 如果是游客就只显示登录 如果是用户就显示用户名及会员级别 -->
							<text class="username">{{userArr.userInfo.nick_name?userArr.userInfo.nick_name:'登录'}}</text>
							<!-- <text v-else>登录</text> -->
							<view class="login_user oklogin">
								<!-- <image src="https://www.abcbook2019.com/mobile/public/img/user/mentp.png" mode=""></image> -->
								<text>普通会员</text>
							</view>
						</view>
					</view>
					<view class="sign" @click="navTo('/pages/sign/sign')">
						<view class="imgue">
							<image src="https://www.abcbook2019.com/mobile/public/img/user/qian_qd.png" mode=""></image>
						</view>
						<text >签到有礼</text>
					</view>
				</view>
				
				<!-- 年卡会员 -->

			</view>
			<view class="Yearmember">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/user_vip.png" mode=""></image>
				<view class="yearmeninfo" v-if="userArr.userInfo.user_ranks==2">
					<!-- 月卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/yueka.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==3">
					<!--季卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/jika.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==4">
					<!--年卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/nianka.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==5">
					<!--次卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/cika.png" mode=""></image>
					<text>剩余体验次数:{{userArr.userInfo.free_number}} 次</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==6">
					<!--畅想会员图片 -->
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/reading.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==7">
					<!--超级会员图片 -->
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/supermem.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==1">
					<image src="https://www.abcbook2019.com/mobile/public/img/user/putong.png" mode=""></image>
					<text>上万本精装图书畅读</text>
				</view>
				<view class="yearmeninfo" v-else>
					<text>省钱月卡</text>
					<text>| 帮你省194元</text>
				</view>
				<view class="fr">
					<navigator url="/pages/index/addjoin">{{loginok?'领144元通用券':'加入会员'}}</navigator>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
		</view>
		<!-- 4条 -->
		<view class="nav">
			<view class="pagetitle">
				<text class="title">我的订单</text>
				<navigator url="">
					<text>查看全部</text>
					<text class="more-icon yticon icon-you"></text>
				</navigator>
			</view>
			<view class="navpage">
				<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/usernav1.png" mode=""></image>
					<text>待付款</text>
				</view>
				<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/usernav2.png" mode=""></image>
					<text>待分享</text>
				</view>
				<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/usernav3.png" mode=""></image>
					<text>待发货</text>
				</view>
				<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/usernav4.png" mode=""></image>
					<text>待收货</text>
				</view>
				<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/usernav5.png" mode=""></image>
					<text>待评价</text>
				</view>
			</view>
		</view>
		<view class="listinfo">
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userlist1.png" mode=""></image>
				<text>优惠券</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userlist2.png" mode=""></image>
				<text>商品收藏</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userlist3.png" mode=""></image>
				<text>历史记录</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userlist4.png" mode=""></image>
				<text>退款售后</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userlist5.png" mode=""></image>
				<text>我的评价</text>
			</view>
		</view>
		<!-- 设置 客服 -->
		<view class="listinfo">
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userhelp1.png" mode=""></image>
				<text>收货地址</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userhelp2.png" mode=""></image>
				<text>官方客服</text>
			</view>
			<view class="navcon" @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/userhelp3.png" mode=""></image>
				<text>设置</text>
			</view>
		</view>
		
		<!-- 精选推荐 -->
		<view class="pagemain">
			<view class="titleMain">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/user/titleicon.png" mode=""></image>
				<text>精选推荐</text>
			</view>
			<view class="miancon">
				<view class="eleve" v-for="item in 10">
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/kefu.png" mode=""></image>
					<view class="eTitle">
						这里是标题啦啦啦啦  一行
					</view>
					<view class="label">
						<text>标签1</text>
						<text>标签2</text>
					</view>
					<view class="pirinfo">
						<view class="peice">
							<text class="pir">15.9</text>
							<text class="brief">已拼10万+件</text>
						</view>
						<view class="pic">
							<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/missing-face.png" mode=""></image>
							<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/missing-face.png" mode=""></image>
						</view>
					</view>
				</view>
			</view>
		</view>
		<footer>
			<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
			<bottom-nav class="" ref="bottomNav"></bottom-nav>
		</footer>
	</view>
	
	<!-- <mixLoading v-else></mixLoading> -->
</template>
<script>
	import bottomNav from "@/pages/navbar/navbar.vue";
	// import listCell from '@/components/mix-list-cell';
	// import mixLoading from '@/components/mix-loading/mix-loading.vue'
	import {mapState} from 'vuex';
	let startY = 0,
		moveY = 0,
		pageAtTop = true;
	export default {
		components: {
			// listCell,
			bottomNav
			// mixLoading
		},
		data() {
			return {
				loading:false,
				coverTransform: 'translateY(0px)',
				coverTransition: '0s',
				moving: false,
				loginok:uni.getStorageSync("token"),
				all: 2, //模拟数据 全部订单数字显示
				userArr: {},

			}
		},
		onShow() {
			this.load()
		},
		onLoad: function(options) {},

		computed: {},
		onPullDownRefresh:function(){
		  this.load()
		  setTimeout(function () {
			  uni.stopPullDownRefresh();  //停止下拉刷新动画
		  }, 1000);
		
		 },
		methods: {
			load() {
				let token = uni.getStorageSync("token");
				let hc_mobile = uni.getStorageSync("mobile");
				this.$store.commit("change_page", 4)
			
				if (token == false) {
					uni.clearStorage();
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})
			
					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
				} else {
					var that = this
					this.$api.quest('user', {}, (res) => {
						
						
						if (res.data.data.error == 1) {
							//清数据 缓存  
							uni.clearStorage();
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})
			
							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
						}else{
							//uni.setStorageSync('user_ranks', res.data.data.userInfo.user_ranks);
							uni.setStorageSync('user_rank', res.data.data.userInfo.user_rank);
							//uni.setStorageSync('total_number', res.data.data.cart.cart_count);
							//uni.setStorageSync('no_apply', res.data.data.no_apply);    //当前又没有待激活的卡
							//this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
						}
						// console.log(res.data.data.error)
						console.log(res.data.data)
						that.userArr = res.data.data
						this.loading = true;
					})
					// #ifdef MP
					if (hc_mobile == false) {
						uni.navigateTo({
							url: '/pages/public/register'
						})
					}
					// #endif
				}
			},
		}
	}
</script>
<style lang='scss'>
	page{
		padding-bottom: 180rpx;
	}
	.user{
		.head{
			position: relative;
			height: 378rpx;
			background: #fff;
			background-size: cover;
			box-shadow:0rpx 2rpx 6rpx 0rpx rgba(0,0,0,0.1);
			.title{
				position: relative;
				top: 94rpx;
				height: 88rpx;
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding: 0 20rpx;
				image{
					width: 46rpx;
					height: 46rpx;
					z-index: 8;
				}
				h4{
					position: absolute;
					top: 50%;
					left: 50%;
					transform: translate(-50%,-50%);
					font-size: 34rpx;
					color: #333;
					text-align: center;
				}
				.fr{
					align-self: flex-end;
					image{
						margin-left: 20rpx;
					}
				}
			}
			.user_info{
				position: relative;
				height:130rpx;
				padding-top: 130rpx;
				.fl{
					display: flex;
					width: 100%;
					height:130rpx;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;
					.userrank{
						display: flex;
						flex-direction: row;
					}
					.portrait{
						width: 130rpx;
						height: 130rpx;
						border-radius: 50%;
						margin-left:38rpx;
					}
					.info{
						display:flex;
						
						flex-direction: column;
						justify-content: center;
						height: 130rpx;
						align-items: flex-start;
						margin-left: 25rpx;
						.username{
							color: #333;
							font-size: 34rpx;
						}
						.login_user{
							display: flex;
							align-items: center;
							margin-top: 20rpx;
							text{
								font-size: 24rpx;
								color: #666;
							}
						}
					}
				}
				// 签到有礼
				.sign{
					display: flex;
					align-items: center;
					width:195rpx;
					height:60rpx;
					background:rgba(255,255,255,0.3);
					border: 1rpx solid #e6e6e6;
					z-index: 9;
					margin-right: -30rpx;
					margin-top:60rpx;
					border-radius:100rpx;
					.imgue{
						width: 44rpx;
						height: 44rpx;
						background:#FF6F2F;
						border-radius: 50%;
						display: flex;
						margin-left: 7rpx;
						margin: 0 10rpx;
						
						image{
							height: 26rpx;
							width: 26rpx;
							margin: 9rpx;
						}
					}
					text{
						font-size: 24rpx;
						font-weight: 300;
						color: #666;
						margin-right: 24rpx;
					}
					
				}
				
			}
			.Yearmember{
				position: absolute;
				bottom: 0;
				left: 50%;
				margin-left: -355rpx;
				width:710rpx;
				height:90rpx;
				background:#fdeeee;
				/* box-shadow:0rpx 0rpx 4rpx 0rpx rgba(190,65,30,0.8),1rpx 1rpx 0rpx 0rpx rgba(250,255,133,1); */
				border-radius:16rpx 16rpx 0rpx 0rpx;
				display: flex;
				align-items: center;
				flex-direction: row;
				justify-content: flex-start;
				>image{
					width: 60rpx;
					height: 52rpx;
					margin-left: 40rpx;
				}
				.yearmeninfo{
					text{
						font-size: 28rpx;
						color:#e02d25;
						margin-left: 20rpx;
					}
					image{
						width: 114rpx;
						height: 36rpx;
						margin-left: 30rpx;
						position: relative;
						top: 8rpx;
					}
				}
				.fr{
					flex: 1;
					text-align: right;
					margin-right: 20rpx;
					>navigator{
						display: inline-block;
						font-size: 28rpx;
						font-weight: 600;
						color: #68360A;
					}
					text{
						font-size: 28rpx;
						font-weight: 600;
						color: #68360A;
					}
					.icon-you{
						font-size: 28rpx;
						margin-left: 17rpx;
					}
				}
			}
		}
		.nav{
			width:750rpx;
			background: #fff;
			padding-bottom: 30rpx;
			margin-bottom: 20rpx;
			box-shadow:0rpx 2rpx 6rpx 0rpx rgba(0,0,0,0.1);
			.pagetitle{
				display: flex;
				justify-content: space-between;
				padding: 10rpx 30rpx;
				line-height: 74rpx;
				.title{
					font-size:28rpx;
					color: #333;
					font-weight: 500;
				}
				navigator{
					font-size: 25rpx;
					color: #666;
				}
			}
			.navpage{
				width: 100%;
				text-align: center;
				/* padding-top: 20rpx; */
				.navcon{
					width: calc(100%/5);
					display: inline-block;
					
				}
				image{
					width: 45rpx;
					height: 45rpx;
					display: block;
					margin: 0 auto;
					margin-bottom: 10rpx;
				}
				text{
					color: #666;
					font-size: 28rpx;
				}
			}
		}
		
		.listinfo{
			width: 750rpx;
			padding:30rpx 0rpx;
			
			background: #fff;
			margin-top: 20rpx;
			box-shadow:0rpx 2rpx 6rpx 0rpx rgba(0,0,0,0.1);
			.navcon{
				width: calc(100%/5);
				display: inline-block;
				text-align: center;
			}
			image{
				width: 50rpx;
				height:50rpx;
				display: block;
				margin: 0 auto;
				margin-bottom: 10rpx;
			}
			text{
				color: #666;
				font-size: 28rpx;
			}
		}
		/* 精选推荐 */
		.pagemain{
			width: 750rpx;
			margin-top: 20rpx;
			.titleMain{
				height:90rpx;
				text-align: center;
				background: #fff;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 0;
				image{
					width: 50rpx;
					height: 50rpx;
					margin-right: 20rpx;
				}
				text{
					color: #e12d25;
					font-size: 30rpx;
				}
			}
			.miancon{
				display: flex;
				justify-content: space-between;
				flex-wrap: wrap;
				.eleve{
					display: inline-block;
					background: #fff;
					width: 372rpx;
					margin-bottom: 5rpx;
					>image{
						width: 372rpx;
						height: 374rpx;
					}
					.eTitle{
						font-size: 26rpx;
						color: #666;
						text-overflow: ellipsis;
						overflow: hidden;
						white-space: nowrap;
						margin-left: 15rpx;
					}
					.label{
						margin-top: 5rpx;
						margin-left: 15rpx;
						text{
							display: inline-block;
							padding: 5rpx 10rpx;
							background: #fff2e9;
							border-radius: 5rpx;
							margin-right: 5rpx;
							color: #ff6013;
							font-size: 20rpx;
						}
					}
					.pirinfo{
						display: flex;
						justify-content: space-between;
						margin-left: 15rpx;
						.peice{
							.pir{
								color: #c93134;
								font-size: 24rpx;
								&:before{
									display: inline-block;
									content: '￥';
									font-size:18rpx;
								}
							}
							.brief{
								font-size: 18rpx;
								color: #666;
								margin-left: 15rpx;
							}
						}
					}
					.pic{
						margin-right: 15rpx;
						image{
							width:40rpx;
							height: 40rpx;
							border-radius: 50%;
							margin-left: -15rpx;
						}
					}
				}
			}
			
		}
	}
</style>
