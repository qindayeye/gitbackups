<template>
	<view class="user" v-if="loading">
		<!-- 顶部 -->
		<view class="head">
			<view class="title">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/set.png" mode="widthFix" @click="navTo('/pages/set/set')"></image>
				<h4>个人中心</h4>
			</view>
			<view class="user_info">
				<view class="fl" @click="gotologin">
					<image class="portrait" :src="userArr.userInfo.user_picture || '/static/missing-face.png'"></image>
					<view class="info">
						<!-- 如果是游客就只显示登录 如果是用户就显示用户名及会员级别 -->
						<text>{{userArr.userInfo.nick_name?userArr.userInfo.nick_name:'登录'}}</text>
						<!-- <text v-else>登录</text> -->
						<view class="login_user oklogin" v-if="userArr.userInfo.user_ranks>1">
							<image src="https://www.abcbook2019.com/mobile/public/img/user/mentp.png" mode=""></image>
							<text>{{userArr.userInfo.rank_name}}</text>
						</view>
					</view>
				</view>
				<view class="fr sign" @click="navTo('/pages/sign/sign')">
					<view class="imgue">
						<image src="https://www.abcbook2019.com/mobile/public/img/user/qian_qd.png" mode=""></image>
					</view>
					<text >签到有礼</text>
				</view>
				<!-- 年卡会员 -->

			</view>
			<view class="Yearmember">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/user_vip.png" mode=""></image>
				<view class="yearmeninfo" v-if="userArr.userInfo.user_ranks==2">
					<!-- 月卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/yueka.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==3">
					<!--季卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/jika.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==4">
					<!--年卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/nianka.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==5">
					<!--次卡会员图片 -->
					<image src="https://www.abcbook2019.com/mobile/public/img/user/cika.png" mode=""></image>
					<text>剩余体验次数:{{userArr.userInfo.free_number}} 次</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==6">
					<!--畅想会员图片 -->
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/reading.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==7">
					<!--超级会员图片 -->
					<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/supermem.png" mode=""></image>
					<text>{{userArr.userInfo.end_time_format}} 到期</text>
				</view>
				<view class="yearmeninfo" v-else-if="userArr.userInfo.user_ranks==1">
					<image src="https://www.abcbook2019.com/mobile/public/img/user/putong.png" mode=""></image>
					<text>上万本精装图书畅读</text>
				</view>
				<view class="yearmeninfo" v-else>
					<text>加入会员</text>
					<text>上万本精装图书畅读</text>
				</view>
				<view class="fr">
					<navigator url="/pages/index/addjoin">{{loginok?'立即续费':'加入会员'}}</navigator>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
		</view>
		<!-- 4条 -->
		<view class="nav">
			<navigator :url="'/pages/index/account?num='+userArr.userInfo.frozen_money" open-type="navigate">
				<text class="number">{{userArr.userInfo.frozen_money?userArr.userInfo.frozen_money*1:"0.00"}}</text>
				<text>可退押金</text>
			</navigator>
			<navigator @click="navTo('/pages/collect/collect')">
				<text class="number">{{userArr.funds.goods_count?userArr.funds.goods_count:"0"}}</text>
				<text>收藏</text>
			</navigator>
			<navigator @click="navTo('/pages/index/coupont')">
				<text class="number">{{userArr.funds.coupons_count?userArr.funds.coupons_count:"0"}}</text>
				<text>优惠券</text>
			</navigator>
			<navigator @click="navTo('/pages/Candy/Candy')">
				<text class="number">{{userArr.userInfo.pay_points?userArr.funds.pay_points:"0"}}</text>
				<text>糖豆</text>
			</navigator>
		</view>
		<view class="usestate">
			<view @click="navTo('/pages/order/order?states=0&index=0')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon8.png" mode=""></image>
				<text>全部订单</text>
			</view>
			<view @click="navTo('/pages/order/order?states=500&index=1')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon2.png" mode=""></image>
				<text>待付款</text>
				<view class="user-list-num" v-if="userArr.order.no_paid_num != 0">{{userArr.order.no_paid_num}}</view>
			</view>
			<view @click="navTo('/pages/order/order?states=502&index=2')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon1.png" mode=""></image>
				<text>待发货</text>
				<view class="user-list-num" v-if="userArr.order.no_invo_num !=0 ">{{userArr.order.no_invo_num}}</view>
			</view>
			<view @click="navTo('/pages/order/order?states=512&index=3')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon6.png" mode=""></image>
				<text>待收货</text>
				<view class="user-list-num" v-if="userArr.order.no_received_num!=0 ">{{userArr.order.no_received_num}}</view>
			</view>
			<view @click="navTo('/pages/order/order?states=522&index=4')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon3.png" mode=""></image>
				<text>待归还</text>
				<view class="user-list-num" v-if="userArr.order.no_back_num != 0">{{userArr.order.no_back_num}}</view>
			</view>
			<view @click="navTo('/pages/order/order?states=992&index=5')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon.png" mode=""></image>
				<text>还书中</text>
				<view class="user-list-num" v-if="userArr.order.no_backing_num!= 0">{{userArr.order.no_backing_num}}</view>
			</view>
			<view @click="navTo('/pages/order/order?states=10102&index=6')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon4.png" mode=""></image>
				<text>已完成</text>
			</view>
			<!-- <navigator @click="navTo('/pages/order/order?index=7')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon5.png" mode=""></image>
				<text>待评价</text>
				<view class="user-list-num" v-if="userArr.order.not_comment!= 0">{{userArr.order.not_comment}}</view>
			</navigator> -->
			<view @click="navTo('/pages/order/shoporder?states=0&index=0')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/icon5.png" mode=""></image>
				<text>商城订单</text>
				<!-- <view class="user-list-num" v-if="userArr.order.not_comment!= 0">{{userArr.order.not_comment}}</view> -->
			</view> 
			<!-- <navigator @click="navTo('/pages/groupList/groupList')"> -->
				<!-- <image src="https://www.abcbook2019.com/mobile/public/img/user/icon5.png" mode=""></image> -->
				<!-- <text>我的拼团</text> -->
				<!-- <view class="user-list-num" v-if="userArr.order.not_comment!= 0">{{userArr.order.not_comment}}</view> -->
			<!-- </navigator> -->
		</view>
		<view class="listinfo">
			<view @click="navTo('/pages/members/members')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/mymember.png" mode=""></image>
				<view class="fr">
					<text class="textcc">会员计划</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
			<view @click="navTo('/pages/bcustome/bcustome')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/huiyuanduihuan.png" mode=""></image>
				<view class="fr">
					<text class="textcc">会员兑换</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
		</view>
		<view class="listinfo">
			<view @click="navTo('/pages/Wishlist/Wishlist')">
				<image src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/wishbooks.png" mode=""></image>
				<view class="fr">
					<text class="textcc">心愿书单</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
			<view @click="navTo('/pages/index/coupont')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/coupon.png" mode=""></image>
				<view class="fr">
					<text class="textcc">领取优惠券</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
			<view  @click="navTo('/pages/Candy/CandyStore')">
			<!-- <view  @click="notAvble()"> -->
				<image src="https://www.abcbook2019.com/mobile/public/img/user/tangd.png" mode=""></image>
				<view class="fr">
					<text class="textcc">商城</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
		</view>
		<view class="listinfo">
			<view @click="navTo('/pages/address/address')">
				<image src="https://www.abcbook2019.com/mobile/public/img/user/address.png" mode=""></image>
				<view class="fr">
					<text class="textcc">收货地址</text>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
			<!-- #ifdef MP -->
			<view>
				<image src="https://www.abcbook2019.com/mobile/public/img/user//help.png" mode=""></image>
				<view class="fr">
					<!-- <text>联系客服</text> -->
					<button class="textcc" type="primary" open-type="contact">联系客服</button>
					<text class="cell-icon yticon icon-you"></text>
				</view>
			</view>
			<!-- #endif -->
		</view>
		<footer>
			<!-- //插入组件，ref 把子主键元素注册到夫组件$refs,然后可以在父组件操作子组件元素 -->
			<bottom-nav class="" ref="bottomNav"></bottom-nav>
		</footer>

	</view>
	<mixLoading v-else></mixLoading>
</template>
<script>
	import bottomNav from "@/pages/navbar/navbar.vue";
	import listCell from '@/components/mix-list-cell';
	import mixLoading from '@/components/mix-loading/mix-loading.vue'
	import {mapState} from 'vuex';
	let startY = 0,
		moveY = 0,
		pageAtTop = true;
	export default {
		components: {
			listCell,
			bottomNav,
			mixLoading
		},
		data() {
			return {
				loading:false,
				coverTransform: 'translateY(0px)',
				coverTransition: '0s',
				moving: false,
				loginok:uni.getStorageSync("token"),
				all: 2, //模拟数据 全部订单数字显示
				userArr: {},

			}
		},
		onShow() {
			this.load()
		},
		onLoad: function(options) {
			
		},

		computed: {
			...mapState(['hasLogin', 'userInfo'])
		},
		onPullDownRefresh:function(){
		  this.load()
		  setTimeout(function () {
			  uni.stopPullDownRefresh();  //停止下拉刷新动画
		  }, 1000);
		
		 },
		methods: {
			load() {
				let token = uni.getStorageSync("token");
				let hc_mobile = uni.getStorageSync("mobile");
				this.$store.commit("change_page", 4)

				if (token == false) {
					uni.clearStorage();
					// #ifdef MP
					uni.navigateTo({
						url: '/pages/public/login'
					})
					// #endif
					// #ifdef H5
					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						uni.navigateTo({
							url: '/pages/public/login'
						})

					} else {
						uni.navigateTo({
							url: '/pages/public/registerSJ'
						})
					}
					// #endif
				} else {
					var that = this
					this.$api.quest('user', {}, (res) => {
						
						
						if (res.data.data.error == 1) {
							//清数据 缓存  
							uni.clearStorage();
							// #ifdef MP
							uni.navigateTo({
								url: '/pages/public/login'
							})
							// #endif
							// #ifdef H5
							// 判断微信内外
							var ua = window.navigator.userAgent.toLowerCase();
							console.log(ua)
							// console.log(ua.indexOf('micromessenger') != -1)
							// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
							if (ua.match(/MicroMessenger/i) == 'micromessenger') {
								// 微信内浏览器（公众号）
								console.log("公众号")
								uni.navigateTo({
									url: '/pages/public/login'
								})

							} else {
								uni.navigateTo({
									url: '/pages/public/registerSJ'
								})
							}
							// #endif
						}else{
							//uni.setStorageSync('user_ranks', res.data.data.userInfo.user_ranks);
							uni.setStorageSync('user_rank', res.data.data.userInfo.user_rank);
							//uni.setStorageSync('total_number', res.data.data.cart.cart_count);
							//uni.setStorageSync('no_apply', res.data.data.no_apply);    //当前又没有待激活的卡
							//this.$store.commit("getgoodsnum", uni.getStorageSync("total_number"))
						}
						// console.log(res.data.data.error)
						console.log(res.data.data)
						that.userArr = res.data.data
						this.loading = true;
					})
					// #ifdef MP
					if (hc_mobile == false) {
						uni.navigateTo({
							url: '/pages/public/register'
						})
					}
					// #endif
				}
			},
			gotourl(url){
				uni.navigateTo({
					url: url
					// `/pages/set/set?data=${JSON.stringify({
					// 	 userArr: this.userArr
					// 	})}`
				})
			},
			// 去设置
			gotoset() {
				uni.navigateTo({
					url: `/pages/set/set?data=${JSON.stringify({
						 userArr: this.userArr
						})}`
				})
			},
			// 签到有礼
			// gotosign(){
			// 	uni.navigateTo({
			// 		url:'/pages/sign/sign'
			// 	})
			// },
			notAvble() {
				this.$api.msg("暂未开放 敬请期待")
			},
			gotologin() {
				console.log(11)
				// #ifdef MP
				uni.navigateTo({
					url: '/pages/public/login',
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
				// #endif
				// #ifdef H5
				this.gotoset()
				// #endif
			},
			navTo(url) {
				if (uni.getStorageSync("token") == false) {
					// #ifdef MP
					url = '/pages/public/login';
					// #endif	
					// #ifdef H5

					// 判断微信内外
					var ua = window.navigator.userAgent.toLowerCase();
					console.log(ua)
					// console.log(ua.indexOf('micromessenger') != -1)
					// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
					if (ua.match(/MicroMessenger/i) == 'micromessenger') {
						// 微信内浏览器（公众号）
						console.log("公众号")
						url = '/pages/public/login';

					} else {
						url = '/pages/public/registerSJ';
					}
					// #endif			
				}
				uni.navigateTo({
					url
				})
			},
		}
	}
</script>
<style lang='scss'>

	@import '../../static/css/user.scss';
	.title{
		/* #ifdef H5 */
		margin-top: -86rpx;		
		/* #endif */
	}
</style>
