<template>
	<view class="accdetile">
		<view class="commercial">
			<!-- <view class="tit">ABCbook国际亲子阅读</view> -->
			<view class="money">0.02<text>元</text></view>
			<!-- <view class="status">{{list.order_status}}</view> -->
		</view>
		<view class="con">
			<view class="clear" >
				<text class="fl">费用说明</text>
				<view class="fr" >押金{{list.deposit}}元，微信支付分满550可免押金租借，<text>59元/33天</text>(普通会员),会员免费<br>超过33天，1元/天</view>
			</view>
			<view class="clear" >
				<text class="fl">借阅时长</text>
				<text class="fr" >{{countDownList}}</text>
			</view>
			<view class="clear" >
				<text class="fl">支付方式</text>
				<text class="fr" >{{list.deposit_type==1?'微信支付分支付':'微信支付'}}</text>
			</view>
			
		</view>
		<view class="list">
			
			<view class="clear" >
				<text class="fl">订单号</text>
				<text class="fr">{{list.order_sn}}</text>
			</view>
			<view class="clear" >
				<text class="fl">借阅开始时间</text>
				<text class="fr">{{list.begintime}}</text>
			</view>
			<view class="clear" >
				<text class="fl">借阅地点</text>
				<text class="fr">{{list.address}}</text>
			</view>
			<view class="clear" >
				<text class="fl">借阅截止时间</text>
				<text class="fr">{{list.endtime}}</text>
			</view>
			<view class="clear" >
				<text class="fl">还书地址</text>
				<text class="fr">{{list.r_address}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				list:{},
				actEndTime:'2019-12-12 00:00:00',
				countDownList:''
			}
		},
		onLoad(option) {
			console.log(option)
			let list=JSON.parse(option.data)
			console.log(list)
			this.list=list.list
			this.actEndTime=this.list.add_time
			
			this.oktime=this.list.oktime
			// this.countDown()
			// this.oktime=null
		},
		mounted() {
			this.countDown()
		},
		methods:{
			timeFormat(param) {
				return param < 10 ? '0' + param : param;
			},
			countDown(it) {
				console.log(121)
				let that=this;
				var interval = setInterval(() => {
					// 获取当前时间，同时得到活动结束时间数组
					let newTime = that.oktime?new Date(that.oktime).getTime():new Date().getTime();
					// let newTime =new Date(that.oktime).getTime();    //结束时间或者当前时间
					// 对结束时间进行处理渲染到页面
					let endTime = new Date(this.actEndTime).getTime();
					let obj = null;
					// 如果活动未结束，对时间进行处理
					if (newTime-endTime > 0) {
						let time = ( newTime-endTime) / 1000;
						// 获取天、时、分、秒
						let day = parseInt(time / (60 * 60 * 24));
						let hou = parseInt(time % (60 * 60 * 24) / 3600);
						let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
						let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
						obj = {
							day: this.timeFormat(day),
							hou: this.timeFormat(hou),
							min: this.timeFormat(min),
							sec: this.timeFormat(sec)
						};
						
						
						
						
					} else { // 活动已结束，全部设置为'00'
						obj = {
							day: '00',
							hou: '00',
							min: '00',
							sec: '00' ,
							
						};
						
						this.finished=false
						
						
						
						
						
						clearInterval(interval);
						// this.onLoad()
					}
					// console.log(obj)
					this.countDownList = obj.day + '天' + obj.hou + '时' + obj.min + '分' + obj.sec + '秒';
				}, 1000);
			},
		}
	}
</script>

<style lang="scss">
	.fr{
		text-align:right;
		width: 500rpx;
		text{
			color: #FF824B;
		}
	}
	.accdetile{
		width: 100%;
		border-radius:10rpx;
		// box-shadow: 0px -1px 0px 0px rgba(230,230,230,1);
		// margin: 20rpx auto;
		.commercial{
			height: 200rpx;
			text-align: center;
			background: #fff;
			.tit{
				padding-top: 60rpx;
				font-size: 28rpx;
				color: #333;
			}
			.money{
				padding-top:80rpx;
				color: #FF824B;
				font-size: 48rpx;
				text{
					font-size: 30rpx;
					color: #333;
					margin-left: 10rpx;
				}
			}
			.status{
				font-size: 24rpx;
				color: #333;
			}
		}
		.con{
			background: #fff;
			padding:20rpx 30rpx;
			.clear{
				// border-top: 1rpx dashed #e6e6e6;
				line-height: 50rpx;
				font-size: 26rpx;
				color: #000;
				letter-spacing: 1rpx;
			}
		}
		.list{
			padding:20rpx 30rpx;
			.clear{
				// border-top: 1rpx dashed #e6e6e6;
				line-height:50rpx;
				font-size: 24rpx;
				color: #999;
			}
			
		}
	}
</style>
