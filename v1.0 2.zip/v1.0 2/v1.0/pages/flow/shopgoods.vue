<template>
	<view class="contentok">
		<view class="goods-section">
			<view class="g-header b-b">
				<image class="logo" src="https://ktoss.oss-cn-beijing.aliyuncs.com/mini/images/logo.png"></image>
				<text class="name">ABCbook国际亲子阅读</text>
				<!-- <text class="fr shopname">{{shipping_name}}</text> -->
			</view>
			<!-- 商品列表 -->
			<view class="g-item page_expert_main clear booksinfolist">
				<image :src="goods_thumb" mode=""></image>
				<view class="goodsinfo">
					<text>{{goodsDet.goods_name}}</text>
					<text>￥{{market_price}}</text>
				</view>
			</view>
		</view>
		<!-- 地址 -->
		<navigator url="/pages/address/address?source=2" class="address-section">
			<view class="order-content">
				<text class="yticon icon-shouhuodizhi"></text>
				<view class="cen">
					<view class="top">
						<text class="name">{{addressData.consignee}}</text>
						<text class="mobile">{{addressData.mobile}}</text>
					</view>
					<text class="address" >{{addressData.country}}{{addressData.city}}{{addressData.district}}{{addressData.address}}</text>
					
				</view>
				<text class="yticon icon-you"></text>
			</view>
		</navigator>
		<view class="yt-list">
			<view class="yt-list-cell b-b">
				<text class="cell-tit clamp">会员专享价</text>
				<text class="cell-tip red">{{payment}}</text>
			</view>
			<!-- <view class="yt-list-cell desc-cell">
				<text class="cell-tit clamp">备注</text>
				<input class="desc" type="text" v-model="desc" placeholder="请填写备注信息" placeholder-class="placeholder" />
			</view> -->
			<view class="nedmoney fr">
				<text>需付金额:</text>
				<text class="price">{{payment}}</text>
			</view>
		</view>
		<!-- 底部 -->
		<view class="footer" :class="{isIphoneX:isIphoneX}">
			<view class="price-content">
				<text>实付款</text>
				<text class="price">{{payment}}</text>
			</view>
			<text class="submit" :disabled="disable" @click="sun()">提交订单</text>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				g_id: 0,
				goods_thumb:'',
				payment:'',
				market_price:'',  //会员专享价
				addressData: {}, //商品列表 书
				goodsDet:{},
				disable:false,
				froms: "",
				referer: "",
				isIphoneX:false
			}
		},
		onShow() {
			uni.getSystemInfo({
				success: res=>{
					// console.log('手机信息res'+res.model)
					let modelmes = res.model;
						if (modelmes.search('iPhone X') != -1) {
							// console.log('1111')
						this.isIphoneX = true
						}
					}
			})
		},
		onLoad(option) {
			//商品数据
			// let ol = JSON.parse(option);
			console.log(option);
			let goid = option.goid
			let ruid=option.ruid
			// console.log(goid,ruid)
			// console.log(uni.getStorageSync("user_ranks"))
			if (uni.getStorageSync("user_ranks") > 1) {
				this.user_ranks = false
			} else {
				this.user_ranks = true
			}
			this.type =option.type
			this.$api.quest('user/address/list', {}, (res) => {
				console.log(res, "res")
				if (res.data.data.length == 0) {
					uni.navigateTo({
						url: '/pages/address/addressManage?type=shopgood'
					})
				} else { 
					this.$api.quest('flow/shopgoods', {
						 ru_id:uni.getStorageSync("ruid"),
						 g_id:uni.getStorageSync("goid"),
						flow_type: 10,
					}, (res) => {
						this.goods_thumb=res.data.data.goods_thumb
						this.addressData = res.data.data.default_address
						this.market_price=res.data.data.market_price
						console.log(this.addressData,'shopgoods')
						this.payment = res.data.data.shop_price_formated   //实际付款
						this.goodsDet=res.data.data
						if(this.type=='addre'){
							console.log("==2shop")
							this.addressData=JSON.parse(option.addressData)
							console.log(this.addressData,'addre')
						}
					})
				}
			})
		},
		methods: {
			sun(){
				console.log(1515)
				// #ifdef H5
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					this.froms = 'touch'
					this.referer = 'touch'
				
				} else {
					console.log("H5")
					this.froms = 'IE'
					this.referer = 'IE'
				}
				// #endif
				this.$api.quest('flow/downshopgoods',{
					consignee: this.addressData.address_id,
					shipping: 0,
					u_id: uni.getStorageSync("user_id"),
					flow_type: 10,
					team_id: 0,
					t_id: 0,
					goods_id: this.goodsDet.goods_id
				},(res)=>{
					console.log(res)
					if (res.data.code == 0) {
						this.disable=true

						uni.navigateTo({
							url: '/pages/money/pay?id=' + res.data.data + '&payment=' + this.payment + '&ordersn=' + this.ordersn,
							// #ifdef H5
							success: (res) => {
								if (res.errMsg == 'navigateTo:ok') {
									window.location.reload(true);
								}
							}
							// #endif
						})
					}
				})
				
			}
		}
	}
</script>

<style lang="scss">
	.isIphoneX{
		height: 118rpx !important;
		padding-bottom: 25rpx;
	}
	.contentok{
		width: 710rpx;
		background: #fff;
		border-radius: 10rpx;
		margin: 20rpx auto;
		box-shadow:0px 2rpx 8rpx 0px rgba(0,0,0,0.05);
		overflow: hidden;
	}
	page {
		background:#F5F5F5;
		padding-bottom: 100upx;
	}
	.nodiv{
		min-height: 30vh;
		max-height: 70vh;
		display: flex;
		align-items: center;
		justify-content: center;

	}
	.nocou{
		font-size: 28rpx;
		text-align: center;
		color: #999;
	}
	.list {
		// width: 750rpx;
		margin: 0 auto;
		box-sizing: border-box;
		// padding: 20rpx;
		margin: 0 30rpx;
		background: #fff;

		.ann {
			font-size: 28rpx;
			color: #FF824B;
			padding-bottom: 20rpx;
		}
			
		.cardli {
			width: 650rpx;
			height: 108rpx;
			display: flex;
			align-items: center;
			box-sizing: border-box;
			margin-top: 20rpx;
			// padding: 10rpx 20rpx;
			// height: 140rpx;
			border: 1rpx solid #e6e6e6;
			// margin-top: 20rpx;
			border-radius: 10rpx;
			.cardlimg{
				width: 132rpx;
				height: 84rpx;
				margin-right: 10rpx;
			}
			.cardlcon{
				flex: 1;
			}
			.fl {
				text {
					display: block;
					font-size: 26rpx;
					color: #666;
				}

				.tit {
					font-size: 26rpx;
					color: #666;
					font-weight: bold;
					margin-bottom: 10rpx;
				}

				.con {
					color: #666;
					font-size: 20rpx;
				}
			}

			.fr {
				display: flex;
				align-items: center;
				// align-self: flex-end;
				color: #f69b18;
				font-size: 28rpx;
				margin-right: 30rpx;

			}
		}
		.packup{
			display: flex;
			text-align: center;
			justify-content: center;
			content: center;
			font-size: 26rpx;
			color: #999;
			margin-top: 30rpx;
			.xiangx{
				text-align: center;
				transform:rotate(90deg);
			}
			.shang{
				text-align: center;
				transform:rotate(90deg);
			}
		}
		.active {
			border: 1rpx solid #fe941f;
			background: #fffaef;
		}
	}

	.booksinfolist {
		height: 206rpx;
		border-bottom: 1rpx dashed #e6e6e6;
		padding: 0;
		
		image {
			width: 144rpx;
			height: 144rpx;
			margin-right: 10rpx;
			margin-top: 30rpx;
		}
		.goodsinfo{
			height: 144rpx;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			margin-left: 20rpx;
			text{
				display: block;
				font-size:28rpx;
				color: #333;
				line-height: 40rpx;
			}
		}
	}

	.address-section {
		margin:0 30upx;
		background: #fff;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;
		.order-content {
			display: flex;
			height: 133rpx;
			align-items: center;
		}

		.icon-shouhuodizhi {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 90upx;
			color: #888;
			font-size: 44upx;
		}

		.cen {
			display: flex;
			flex-direction: column;
			flex: 1;
			font-size: 28upx;
			color: $font-color-dark;
		}

		.name {
			font-size: 34upx;
			margin-right: 24upx;
		}

		.address {
			margin-top: 16upx;
			margin-right: 20upx;
			color: $font-color-light;
		}

		.icon-you {
			font-size: 32upx;
			color: $font-color-light;
			// margin-right: 30upx;
		}

		.a-bg {
			position: absolute;
			left: 0;
			bottom: 0;
			display: block;
			width: 100%;
			height: 5upx;
		}
	}

	.goods-section {
		// margin-top: 16upx;
		background: #fff;
		padding-bottom: 1px;

		.g-header {
			display: flex;
			align-items: center;
			height: 79upx;
			margin: 0 30upx;
			position: relative;
			border-bottom: 1rpx dashed #e6e6e6;
			.shopname{
				width: 118rpx;
				line-height: 44rpx;
				background:rgba(255,205,120,0.3);
				border-radius: 6rpx;
				color: #FF824B;
				font-size: 24rpx;
				text-align: center;
			}
		}

		.logo {
			display: block;
			width: 50upx;
			height: 50upx;
			border-radius: 100px;
		}

		.name {
			font-size: 28upx;
			color: $font-color-base;
			margin-left: 24upx;
			flex: 1;
		}

		.g-item {
			display: flex;
			margin:0upx 30upx;
			height: 206rpx;
			align-items: center;
			justify-content: center;
			image {
				flex-shrink: 0;
				display: block;
				width: 140upx;
				height: 140upx;
				border-radius: 4upx;
			}

			.right {
				flex: 1;
				padding-left: 24upx;
				overflow: hidden;
			}

			.title {
				font-size: 30upx;
				color: $font-color-dark;
			}

			.spec {
				font-size: 26upx;
				color: $font-color-light;
			}

			.price-box {
				display: flex;
				align-items: center;
				font-size: 32upx;
				color: $font-color-dark;
				padding-top: 10upx;

				.price {
					margin-bottom: 4upx;
				}

				.number {
					font-size: 26upx;
					color: $font-color-base;
					margin-left: 20upx;
				}
			}

			.step-box {
				position: relative;
			}
		}
	}

	.yt-list {
		margin-top: 16upx;
		background: #fff;
		.nedmoney{
			font-size: 28rpx;
			color: #333;
			.price{
				font-weight: bold;
				margin-right: 30rpx;
				line-height: 90rpx;
			}
		}
	}

	.yt-list-cell {
		display: flex;
		align-items: center;
		margin: 10upx 30upx;
		line-height: 70upx;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;

		&.cell-hover {
			background: #fafafa;
		}

		&.b-b:after {
			left: 30upx;
		}

		.cell-icon {
			height: 32upx;
			width: 32upx;
			font-size: 22upx;
			color: #fff;
			text-align: center;
			line-height: 32upx;
			background: #f85e52;
			border-radius: 4upx;
			margin-right: 12upx;

			&.hb {
				background: #ffaa0e;
			}

			&.lpk {
				background: #3ab54a;
			}

		}

		.cell-more {
			align-self: center;
			font-size: 24upx;
			color: $font-color-light;
			margin-left: 8upx;
			margin-right: -10upx;
		}

		.cell-tit {
			flex: 1;
			font-size: 26upx;
			color: $font-color-light;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: 26upx;
			color: $font-color-dark;

			&.disabled {
				color: $font-color-light;
			}

			&.active {
				color: $base-color;
			}

			&.red {
				color: $base-color;
			}
		}

		&.desc-cell {
			.cell-tit {
				max-width: 120upx;
			}
		}

		.desc {
			flex: 1;
			font-size: $font-base;
			color: $font-color-dark;
		}
	
	}

	/* 支付列表 */
	.pay-list {
		padding-left: 40upx;
		margin-top: 16upx;
		background: #fff;

		.pay-item {
			display: flex;
			align-items: center;
			padding-right: 20upx;
			line-height: 1;
			height: 110upx;
			position: relative;
		}

		.icon-weixinzhifu {
			width: 80upx;
			font-size: 40upx;
			color: #6BCC03;
		}

		.icon-alipay {
			width: 80upx;
			font-size: 40upx;
			color: #06B4FD;
		}

		.icon-xuanzhong2 {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 40upx;
			color: $base-color;
		}

		.tit {
			font-size: 32upx;
			color: $font-color-dark;
			flex: 1;
		}
	}

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 995;
		display: flex;
		align-items: center;
		width: 100%;
		height: 98upx;
		justify-content: space-between;
		font-size: 30upx;
		background-color: #fff;
		z-index: 998;
		color: $font-color-base;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, .1);

		.price-content {
			padding-left: 30upx;
		}

		.price-tip {
			color: $base-color;
			margin-left: 8upx;
		}

		.price {
			font-size: 36upx;
			color: $base-color;
		}

		.submit {
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 0;
			border-radius: 0;
			width: 296upx;
			height: 100%;
			color: #fff;
			font-size: 32upx;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		}
	}

	/* 优惠券面板 */
	.mask {
		display: flex;
		align-items: flex-end;
		position: fixed;
		left: 0;
		top: var(--window-top);
		bottom: 0;
		width: 100%;
		background: rgba(0, 0, 0, 0);
		z-index: 9995;
		transition: .3s;

		.mask-content {
			width: 100%;
			min-height: 30vh;
			max-height: 70vh;
			background: #f3f3f3;
			transform: translateY(100%);
			transition: .3s;
			overflow-y: scroll;
			-webkit-overflow-scrolling: touch;
		}

		&.none {
			display: none;
		}

		&.show {
			background: rgba(0, 0, 0, .4);

			.mask-content {
				transform: translateY(0);
			}
		}
	}

	/* 优惠券列表 */
	.coupon-item {
		display: flex;
		flex-direction: column;
		margin: 20upx 24upx;
		background: #fff;

		.con {
			display: flex;
			align-items: center;
			position: relative;
			height: 120upx;
			padding: 0 30upx;

			&:after {
				position: absolute;
				left: 0;
				bottom: 0;
				content: '';
				width: 100%;
				height: 0;
				border-bottom: 1px dashed #f3f3f3;
				transform: scaleY(50%);
			}
		}

		.left {
			display: flex;
			flex-direction: column;
			justify-content: center;
			flex: 1;
			overflow: hidden;
			height: 100upx;
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			margin-bottom: 10upx;
		}

		.time {
			font-size: 24upx;
			color: $font-color-light;
		}

		.right {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-size: 26upx;
			color: $font-color-base;
			height: 100upx;
		}

		.price {
			font-size: 44upx;
			color: $base-color;

			&:before {
				content: '￥';
				font-size: 34upx;
			}
		}

		.tips {
			font-size: 24upx;
			color: $font-color-light;
			line-height: 60upx;
			padding-left: 30upx;
		}

		.circle {
			position: absolute;
			left: -6upx;
			bottom: -10upx;
			z-index: 10;
			width: 20upx;
			height: 20upx;
			background: #f3f3f3;
			border-radius: 100px;

			&.r {
				left: auto;
				right: -6upx;
			}
		}
	}
</style>
