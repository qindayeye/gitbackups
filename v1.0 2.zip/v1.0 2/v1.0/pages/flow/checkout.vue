<template>
	<view v-if="nodata" class="contentok">
		<view class="goods-section">
			<view class="g-header b-b">
				<image class="logo" src="https://ktoss.oss-cn-beijing.aliyuncs.com/mini/images/logo.png"></image>
				<text class="name">ABCbook国际亲子阅读</text>
				<text class="fr shopname">{{shipping_name}}</text>
			</view>
			<!-- 商品列表 -->
			<view class="g-item page_expert_main clear booksinfolist">
				<image v-for="(item,index) in goodsData" :src="item.goods_thumb" mode=""></image>
			</view>
		</view>
		<!-- 地址 -->
		<navigator url="/pages/address/address?source=1" class="address-section">
			<view class="order-content">
				<text class="yticon icon-shouhuodizhi"></text>
				<view class="cen">
					<view class="top">
						<text class="name">{{addressData.consignee}}</text>
						<text class="mobile">{{addressData.mobile}}</text>
					</view>
					<text class="address">{{addressData.country}}{{addressData.city}}{{addressData.district}}{{addressData.address}}</text>
				</view>
				<text class="yticon icon-you"></text>
			</view>
		</navigator>
		
		<view class="list" v-if="user_ranks">
			<text class="ann">选择适合宝宝的借阅计划</text>
			<view class="cardli clear" :class="{active : index===curId}" v-for="(item,index) in VScard" @click="tab(index,item.goods_id)">
				<image class="fl cardlimg" :src="item.goods_thumb" mode=""></image>
				<view class="fl cardlcon">
					<text class="tit">{{item.goods_name}}</text>
					<text class="con">{{item.goods_brief}}</text>
				</view>
				<view class="fr">
					{{item.shop_price_formated}}
				</view>
			</view>
			<view class="packup" v-if="VScardok" @click="cardok('6')">
				<text>展开</text>
				<view class="yticon icon-you shang"></view>
			</view>
			<view class="packup" v-else @click="cardok('3')">
				<text>收起</text>
				<view class="yticon icon-zuo xiangx"></view>
			</view>
			
		</view>
		<!-- 金额明细 -->
		<view class="yt-list">
			<view class="yt-list-cell b-b">
				<text class="cell-tit clamp">押金(可退)</text>
				<text class="cell-tip">{{deposit}}</text>
				<text class="fr shopname" v-if="deposittype">支付分免押金</text>
			</view>
			<view class="yt-list-cell b-b" @click="toggleMask('show')">
				<text class="cell-tit clamp">优惠券</text>
				<text class="cell-tip active">
					{{disc}}
				</text>
				<text class="cell-more wanjia wanjia-gengduo-d"></text>
			</view>
			<view class="yt-list-cell b-b" v-if="coupon">
				<text class="cell-tit clamp">优惠金额</text>
				<text class="cell-tip red">-￥{{coupon}}</text>
			</view>
			
			<view class="yt-list-cell desc-cell">
				<text class="cell-tit clamp">订单备注</text>
				<input class="desc" type="text" v-model="desc" placeholder="选填,最多50个字" maxlength="50" placeholder-class="placeholder" />
			</view>
			
			<view class="nedmoney fr">
				<text>需付金额:</text>
				<text class="price">{{payment}}</text>
			</view>
		</view>

		<!-- 底部 -->
		<view class="footer">
			<view class="price-content">
				<text>需付款：</text>
				<!-- <text class="price-tip">￥</text> -->
				<text class="price">{{payment}}</text>
			</view>
			<button class="submit" :disabled="disable" @click="submit" >提交订单</button>
		</view>

		<!-- 优惠券面板 -->
		<view class="mask" :class="maskState===0 ? 'none' : maskState===1 ? 'show' : ''" @click="toggleMask">
			<view class="mask-content">
				<!-- 优惠券页面，仿mt -->
				<view v-if="couponList.length==0" class="nodiv">	
					<view class="nocou">暂无可用优惠券</view>
				</view>
				<view v-else class="coupon-item" v-for="(item,index) in couponList" :key="index" @click.stop.prevent="stopPrevent(item.uc_id,item.cou_name)">
					<view class="con">
						<view class="left">
							<text class="title">{{item.cou_name}}</text>
							<text class="time">{{item.cou_start_time}}至{{item.cou_end_time}}</text>
						</view>
						<view class="right">
							<text class="price">{{item.cou_money}}</text>
							<text>满{{item.cou_man}}可用</text>
						</view>

						<view class="circle l"></view>
						<view class="circle r"></view>
					</view>
					<text class="tips">限新用户使用</text>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				nodata:false,
				maskState: 0, //优惠券面板显示状态
				desc: '', //备注
				curId: 0,
				g_id: 0,
				disable:false,
				couponList: [], //优惠券
				addressData: {},
				goodsData: {}, //商品列表 书
				VScard: {},
				disc: "选择优惠券", //选择优惠券
				coupon: null, //优惠金额
				summoney: 0,
				payment: 0,
				deposit: 0,
				user_ranks: false, //显示加入会员计划   true显示   false 不显示   不显示是会员 显示不是会员
				caid: "",
				flow_type:0,
				shipping_name:'',
				VScardok:true,
				VScardarr:[],
				anewtype:false
			}
		},
		onShow() {
			if(this.anewtype){
				// console.log('点击之后进')
				// this.anew()
				
			}else{
				// console.log('第一次进')
			}
			// console.log('返回重新刷')
		},
		onLoad(option) {
			console.log(option,"option");
			this.goid = option.goid?option.goid:4299
			console.log(uni.getStorageSync("user_ranks"))
			if(this.type=='addre'){
				this.addressData=JSON.parse(option.addressData)
				console.log(this.addressData)
			}
			this.deposittype=uni.getStorageSync("deposittype")
			this.onloadgo()
		},
		methods: {
			onloadgo(){
				//商品数据
				if (uni.getStorageSync("user_ranks") > 1) {
					this.user_ranks = false
				} else {
					this.user_ranks = true
				}
				if(this.type=="parentchil"){
					this.flow_type=11
					this.$api.quest('flow', {
						flow_type:this.flow_type,
						bs_id: 0,
						team_id: 0,
						t_id: 0,
						g_id: this.user_ranks ? this.goid : 0,
						// order_sn:uni.getStorageSync("ordersn"),
						// deposit_type:uni.getStorageSync("deposittype")?uni.getStorageSync("deposittype"):0
					}, (res) => {
						if(res.data.code==1){
							uni.navigateTo({
								url:'/pages/bookrack/bookrack'
							})
							this.$api.msg(res.data.data.data)
						}else{
							this.nodata=true
								console.log(res.data.data)
								this.goodsData = res.data.data.cart_goods_list.list[0].shop_list;
								this.addressData = res.data.data.default_address
								this.VScardarr = res.data.data.member_card_list
								this.couponList = res.data.data.coupons_list
								this.summoney = res.data.data.cart_goods_list.order_total //总金额
								this.shipping_name=res.data.data.cart_goods_list.list[0].shop_info[0].shipping_name
								console.log(this.shipping_name)
								// this.coupon=0    //优惠金额
								this.deposit = res.data.data.cart_goods_list.deposit
								this.payment = res.data.data.cart_goods_list.order_total_formated //实际付款
								this.ordersn=res.data.data.order_sn
								// this.flow_type=res.data.data.flow_type
								let goodid = 0
								this.goodsData.forEach((item, index) => {
									if (item.is_real == 0) {
										console.log(item.goods_id)
										goodid = item.goods_id
									}
								})
								let arr=[]
								try{
									this.VScardarr.forEach((ite, ind) => {
										if (ite.goods_id == goodid) {
											this.curId = ind
										}
										if(ind==3){
											throw new Error('EndIt')
										}else{
											// arr.push(ite)
										}
									})
								}catch(e){
									if(e.message!='EndIt'){
										 throw e;
									} 
									//TODO handle the exception
								}
								
								this.VScard=arr
								console.log(arr,"arr")
							
						}
					})
				}else{
					console.log(this.ordersn,this.deposittype)
					this.$api.quest('flow', {
						flow_type: 0,
						bs_id: 0,
						team_id: 0,
						t_id: 0,
						g_id: this.user_ranks ? this.goid : 0,
						// order_sn:uni.getStorageSync("ordersn"),
						// deposit_type:uni.getStorageSync("deposittype")?uni.getStorageSync("deposittype"):0
					}, (res) => {
						console.log(res)
						if(res.data.code==1){
							uni.navigateTo({
								url:'/pages/order/order?states=0&index=0'
							})
							this.$api.msg(res.data.data.data)
						}else{
							this.nodata=true
								console.log(res.data.data)
								this.goodsData = res.data.data.cart_goods_list.list[0].shop_list;
								this.addressData = res.data.data.default_address
								this.VScardarr = res.data.data.member_card_list
								this.couponList = res.data.data.coupons_list
								this.summoney = res.data.data.cart_goods_list.order_total //总金额
								this.shipping_name=res.data.data.cart_goods_list.list[0].shop_info[0].shipping_name
								// this.coupon=0    //优惠金额
								this.deposit = res.data.data.cart_goods_list.deposit
								this.payment = res.data.data.cart_goods_list.order_total_formated //实际付款
								this.ordersn=res.data.data.order_sn
								// this.flow_type=res.data.data.flow_type
								let goodid = 0
								
								this.goodsData.forEach((item, index) => {
									if (item.is_real == 0) {
										console.log(item.goods_id)
										goodid = item.goods_id
									}
								})
								let arr=[]
								try{
									this.VScardarr.forEach((ite, ind) => {
										if (ite.goods_id == goodid) {
											this.curId = ind
										}
										if(ind==3){
											throw new Error('EndIt')
										}else{
											arr.push(ite)
										}
									})
								}catch(e){
									if(e.message!='EndIt'){
										 throw e;
									} 
									//TODO handle the exception
								}
								
								this.VScard=arr
								console.log(arr,"arr")
							
						}
					})
				}
			},
			// 重新请求
			anew(){
				uni.request({
					url:'https://www.abcbook2019.com/mobile/public/api/wx/payscore/add',
					data:{
						order_sn:this.ordersn,
						user_id:uni.getStorageSync("user_id"),
					},
					method: "POST",
					header: {
						'Content-Type': 'application/json',
						'X-ECTouch-Authorization':uni.getStorageSync("token")
					},
					success: (res) =>{
						this.onloadgo()
					},
				})
			},
			
			cardok(type){
				if(type==3){
					let arr =[]
					try{
						this.VScardarr.forEach((ite, ind) => {
							if(ind==3){
								throw new Error('EndIt')
							}else{
								arr.push(ite)
							}
						})
					}catch(e){
						if(e.message!='EndIt'){
							// EndIt
							 throw e;
						} 
						//TODO handle the exception
					}
					this.VScardok=true
					this.VScard=arr
				}else if(type==6){
					this.VScardok=false
					this.VScard=this.VScardarr
				}
			},
			//显示优惠券面板
			toggleMask(type) {
				console.log(this.couponList)
				let timer = type === 'show' ? 10 : 300;
				let state = type === 'show' ? 1 : 0;
				this.maskState = 2;
				setTimeout(() => {
					this.maskState = state;
				}, timer)
			},
			// 会员卡切换
			tab(index, id) {
				this.curId = index; //改变样式
				console.log(id) //卡id
				this.g_id = id
				this.$api.quest('flow/check', {
					flow_type: this.flow_type,
					bs_id: 0,
					team_id: 0,
					t_id: 0,
					g_id: id,
					rec_type:0,
					// order_sn:uni.getStorageSync("ordersn"),
					// deposit_type:uni.getStorageSync("deposittype")?uni.getStorageSync("deposittype"):0,
				}, (res) => {
					console.log(res.data.data)
					this.goodsData = res.data.data.cart_goods_list.list[0].shop_list;
					this.summoney = res.data.data.cart_goods_list.order_total //总金额
					this.deposit = res.data.data.cart_goods_list.deposit
					this.payment = res.data.data.cart_goods_list.order_total_formated //实际付款
					this.disc = "选择优惠券"
					this.coupon = 0
				})

			},

			// 提交订单
			submit() {
				this.disable=true
				let goodsId = []
				this.goodsData.forEach((item, index) => {
					goodsId.push(item.goods_id)
				})

				this.$api.quest('flow/down', {
					consignee: this.addressData.address_id,
					shipping: 0,
					u_id: uni.getStorageSync("user_id"),
					uc_id: this.caid,
					flow_type: this.flow_type,
					team_id: 0,
					t_id: 0,
					goods_id: goodsId
				}, (res) => {
					console.log(res)
					if (res.data.code == 0) {
						uni.setStorageSync('total_number', uni.getStorageSync("total_number")-this.goodsData.length+1);
						// console.log(this.payment.substr(1) > 0)
						
						if (this.payment.substr(1) > 0) {
							uni.navigateTo({
								url: '/pages/money/pay?id=' + res.data.data,
								// #ifdef H5
								success: (res) => {
									if (res.errMsg == 'navigateTo:ok') {
										window.location.reload(true);
									}
								}
								// #endif
							})
						} else {
							uni.redirectTo({
								url: '/pages/money/paySuccess?id=' + res.data.data.order_id + '&code=' + res.data.code +
									'&payok=0&payment=' + res.data.data.order_amount
							})
						}
					}else{
						this.disable=false
						this.$api.msg(res.data.data)
					}
				})


			},
			// 选中优惠券
			stopPrevent(id, name) {
				this.maskState = 0; //将优惠券列表关闭
				let caid = id
				this.caid = id
				// console.log(pirce)
				this.disc = name
				this.$api.quest('flow/changecou', {
					uc_id: caid,
					flow_type: this.flow_type,
					g_id: this.g_id
				}, (res) => {
					console.log(res)
					// this.summoney=res.data.data.order_total //总金额
					this.coupon = res.data.data.cou_money ? res.data.data.cou_money : 0 //优惠金额
					this.payment = res.data.data.order_total_formated //实际付款
				})
			}
		}
	}
</script>

<style lang="scss">
	.contentok{
		width: 710rpx;
		background: #fff;
		border-radius: 10rpx;
		margin: 20rpx auto;
		box-shadow:0px 2rpx 8rpx 0px rgba(0,0,0,0.05);
		overflow: hidden;
	}
	page {
		background:#F5F5F5;
		padding-bottom: 100upx;
	}
	.nodiv{
		min-height: 30vh;
		max-height: 70vh;
		display: flex;
		align-items: center;
		justify-content: center;

	}
	.nocou{
		font-size: 28rpx;
		text-align: center;
		color: #999;
	}
	.list {
		// width: 750rpx;
		margin: 0 auto;
		box-sizing: border-box;
		// padding: 20rpx;
		margin: 0 30rpx;
		background: #fff;

		.ann {
			font-size: 28rpx;
			color: #FF824B;
			padding-bottom: 20rpx;
		}
			
		.cardli {
			width: 650rpx;
			height: 108rpx;
			display: flex;
			align-items: center;
			box-sizing: border-box;
			margin-top: 20rpx;
			// padding: 10rpx 20rpx;
			// height: 140rpx;
			border: 1rpx solid #e6e6e6;
			// margin-top: 20rpx;
			border-radius: 10rpx;
			.cardlimg{
				width: 132rpx;
				height: 84rpx;
				margin-right: 10rpx;
			}
			.cardlcon{
				flex: 1;
			}
			.fl {
				text {
					display: block;
					font-size: 26rpx;
					color: #666;
				}

				.tit {
					font-size: 26rpx;
					color: #666;
					font-weight: bold;
					margin-bottom: 10rpx;
				}

				.con {
					color: #666;
					font-size: 20rpx;
				}
			}

			.fr {
				display: flex;
				align-items: center;
				// align-self: flex-end;
				color: #f69b18;
				font-size: 28rpx;
				margin-right: 30rpx;

			}
		}
		.packup{
			display: flex;
			text-align: center;
			justify-content: center;
			content: center;
			font-size: 26rpx;
			color: #999;
			margin-top: 30rpx;
			.xiangx{
				text-align: center;
				transform:rotate(90deg);
			}
			.shang{
				text-align: center;
				transform:rotate(90deg);
			}
		}
		.active {
			border: 1rpx solid #FF824B;
			background: #FFF0D6;
			color: #FF824B;
			.tit,.con{
				color: #FF824B !important;
			}
		}
	}

	.booksinfolist {
		height: 206rpx;
		overflow-x: scroll;
		white-space: nowrap;
		border-bottom: 1rpx dashed #e6e6e6;
		padding: 0;
		
		image {
			width: 144rpx;
			height: 144rpx;
			margin-right: 10rpx;
			margin-top: 30rpx;
		}

		&::-webkit-scrollbar {
			display: none
		}
	}

	.address-section {
		margin:0 30upx;
		background: #fff;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;
		.order-content {
			display: flex;
			height: 133rpx;
			align-items: center;
		}

		.icon-shouhuodizhi {
			flex-shrink: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 90upx;
			color: #888;
			font-size: 44upx;
		}

		.cen {
			display: flex;
			flex-direction: column;
			flex: 1;
			font-size: 28upx;
			color: $font-color-dark;
		}

		.name {
			font-size: 34upx;
			margin-right: 24upx;
		}

		.address {
			margin-top: 16upx;
			margin-right: 20upx;
			color: $font-color-light;
		}

		.icon-you {
			font-size: 32upx;
			color: $font-color-light;
			// margin-right: 30upx;
		}

		.a-bg {
			position: absolute;
			left: 0;
			bottom: 0;
			display: block;
			width: 100%;
			height: 5upx;
		}
	}

	.goods-section {
		// margin-top: 16upx;
		background: #fff;
		padding-bottom: 1px;

		.g-header {
			display: flex;
			align-items: center;
			height: 79upx;
			margin: 0 30upx;
			position: relative;
			border-bottom: 1rpx dashed #e6e6e6;
			.shopname{
				width: 118rpx;
				line-height: 44rpx;
				background:rgba(255,205,120,0.3);
				border-radius: 6rpx;
				color: #FF824B;
				font-size: 24rpx;
				text-align: center;
			}
		}

		.logo {
			display: block;
			width: 50upx;
			height: 50upx;
			border-radius: 100px;
		}

		.name {
			font-size: 28upx;
			color: $font-color-base;
			margin-left: 24upx;
			flex: 1;
		}

		.g-item {
			display: flex;
			margin:0upx 30upx;
			height: 206rpx;
			image {
				flex-shrink: 0;
				display: block;
				width: 140upx;
				height: 140upx;
				border-radius: 4upx;
			}

			.right {
				flex: 1;
				padding-left: 24upx;
				overflow: hidden;
			}

			.title {
				font-size: 30upx;
				color: $font-color-dark;
			}

			.spec {
				font-size: 26upx;
				color: $font-color-light;
			}

			.price-box {
				display: flex;
				align-items: center;
				font-size: 32upx;
				color: $font-color-dark;
				padding-top: 10upx;

				.price {
					margin-bottom: 4upx;
				}

				.number {
					font-size: 26upx;
					color: $font-color-base;
					margin-left: 20upx;
				}
			}

			.step-box {
				position: relative;
			}
		}
	}

	.yt-list {
		margin-top: 16upx;
		background: #fff;
		.nedmoney{
			font-size: 28rpx;
			color: #333;
			.price{
				font-weight: bold;
				margin-right: 30rpx;
				line-height: 90rpx;
			}
		}
	}

	.yt-list-cell {
		display: flex;
		align-items: center;
		margin: 10upx 30upx;
		line-height: 70upx;
		position: relative;
		border-bottom: 1rpx dashed #e6e6e6;

		&.cell-hover {
			background: #fafafa;
		}

		&.b-b:after {
			left: 30upx;
		}
		.shopname{
			width: 170rpx;
			margin-left: 20rpx;
			line-height: 44rpx;
			background:rgba(255,205,120,0.3);
			border-radius: 6rpx;
			color: #FF824B;
			font-size: 24rpx;
			text-align: center;
		}
		.cell-icon {
			height: 32upx;
			width: 32upx;
			font-size: 22upx;
			color: #fff;
			text-align: center;
			line-height: 32upx;
			background: #f85e52;
			border-radius: 4upx;
			margin-right: 12upx;

			&.hb {
				background: #ffaa0e;
			}

			&.lpk {
				background: #3ab54a;
			}

		}

		.cell-more {
			align-self: center;
			font-size: 24upx;
			color: $font-color-light;
			margin-left: 8upx;
			margin-right: -10upx;
		}

		.cell-tit {
			flex: 1;
			font-size: 26upx;
			color: $font-color-light;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: 26upx;
			color: $font-color-dark;

			&.disabled {
				color: $font-color-light;
			}

			&.active {
				color: $base-color;
			}

			&.red {
				color: $base-color;
			}
		}

		&.desc-cell {
			.cell-tit {
				max-width: 120upx;
			}
		}

		.desc {
			flex: 1;
			font-size: $font-base;
			color: $font-color-dark;
		}
	
	}

	/* 支付列表 */
	.pay-list {
		padding-left: 40upx;
		margin-top: 16upx;
		background: #fff;

		.pay-item {
			display: flex;
			align-items: center;
			padding-right: 20upx;
			line-height: 1;
			height: 110upx;
			position: relative;
		}

		.icon-weixinzhifu {
			width: 80upx;
			font-size: 40upx;
			color: #6BCC03;
		}

		.icon-alipay {
			width: 80upx;
			font-size: 40upx;
			color: #06B4FD;
		}

		.icon-xuanzhong2 {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 40upx;
			color: $base-color;
		}

		.tit {
			font-size: 32upx;
			color: $font-color-dark;
			flex: 1;
		}
	}

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 995;
		display: flex;
		align-items: center;
		width: 100%;
		height: 98upx;
		justify-content: space-between;
		font-size: 30upx;
		background-color: #fff;
		z-index: 998;
		color: $font-color-base;
		box-shadow: 0 -1px 5px rgba(0, 0, 0, .1);

		.price-content {
			padding-left: 30upx;
		}

		.price-tip {
			color: $base-color;
			margin-left: 8upx;
		}

		.price {
			font-size: 36upx;
			color: $base-color;
		}

		.submit {
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 0;
			border-radius: 0;
			width: 296upx;
			height: 100%;
			color: #fff;
			font-size: 32upx;
			background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		}
	}

	/* 优惠券面板 */
	.mask {
		display: flex;
		align-items: flex-end;
		position: fixed;
		left: 0;
		top: var(--window-top);
		bottom: 0;
		width: 100%;
		background: rgba(0, 0, 0, 0);
		z-index: 9995;
		transition: .3s;

		.mask-content {
			width: 100%;
			min-height: 30vh;
			max-height: 70vh;
			background: #f3f3f3;
			transform: translateY(100%);
			transition: .3s;
			overflow-y: scroll;
			-webkit-overflow-scrolling: touch;
		}

		&.none {
			display: none;
		}

		&.show {
			background: rgba(0, 0, 0, .4);

			.mask-content {
				transform: translateY(0);
			}
		}
	}

	/* 优惠券列表 */
	.coupon-item {
		display: flex;
		flex-direction: column;
		margin: 20upx 24upx;
		background: #fff;

		.con {
			display: flex;
			align-items: center;
			position: relative;
			height: 120upx;
			padding: 0 30upx;

			&:after {
				position: absolute;
				left: 0;
				bottom: 0;
				content: '';
				width: 100%;
				height: 0;
				border-bottom: 1px dashed #f3f3f3;
				transform: scaleY(50%);
			}
		}

		.left {
			display: flex;
			flex-direction: column;
			justify-content: center;
			flex: 1;
			overflow: hidden;
			height: 100upx;
		}

		.title {
			font-size: 32upx;
			color: $font-color-dark;
			margin-bottom: 10upx;
		}

		.time {
			font-size: 24upx;
			color: $font-color-light;
		}

		.right {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-size: 26upx;
			color: $font-color-base;
			height: 100upx;
		}

		.price {
			font-size: 44upx;
			color: $base-color;

			&:before {
				content: '￥';
				font-size: 34upx;
			}
		}

		.tips {
			font-size: 24upx;
			color: $font-color-light;
			line-height: 60upx;
			padding-left: 30upx;
		}

		.circle {
			position: absolute;
			left: -6upx;
			bottom: -10upx;
			z-index: 10;
			width: 20upx;
			height: 20upx;
			background: #f3f3f3;
			border-radius: 100px;

			&.r {
				left: auto;
				right: -6upx;
			}
		}
	}
</style>
