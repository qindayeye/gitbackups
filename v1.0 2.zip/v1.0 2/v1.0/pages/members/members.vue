<template>
	<view class="members">
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="navbar">
			<view 
				v-for="(item, index) in navList" :key="index" 
				class="nav-item" 
				:class="{current: tabCurrentIndex === index}"
				@click="tabClick(index)"
			>
				{{item}}
			</view>
		</view>
		<view class="icon_concard" >
			<view class="yu " v-if="dataArr.length!=0">
				<view v-for="(item,index) in dataArr" :class="{vipicon:item.order_goods[0].goods_id==4311 ||item.order_goods[0].goods_id==4312}">
					<navigator :url="'../detail/detail?id='+item.order_goods[0].goods_id" class="card"  :class="{onbox: tabCurrentIndex === 2,}" >
						<image :src="item.order_goods[0].goods_thumb" mode=""></image>
						<view class="cardinfo">
							<view class="infocon clear">
								<view class="tit  fl">{{item.order_goods[0].goods_name}}</view>
								<view class="right fr">
									<view class="classfis">
										<text>{{item.goods_tag}}次</text>
										<text>借书次数</text>
									</view>
									<view class="classfis">
										<text>{{item.seller_note}}天</text>
										<text>借阅天数</text>
									</view>
								</view>
							</view>
							<view class="infohint">{{item.order_goods[0].goods_brief}}</view>
							<view class="card_price" v-if="tabCurrentIndex == 2">
								<view class="explain fl">
									<text>已失效</text>
								</view>
							</view>
							<view class="card_price" v-else-if="tabCurrentIndex == 1">
								<view class="explain fl">
									<text>待激活</text>
								</view>
								<!-- <view class="btn fl tu" v-if="item.money_paid>0&&item.pay_id>0 && item.rec_type!==6&&item.rec_type!==84"  @click.stop="refund(item.order_id,index)">立即退卡</view> -->
								<view class="btn fr" @click.stop="activat_card(item.order_id,index)">立即激活</view>
							</view>
							<view class="card_price" v-else>
								<view class="explain fl">
									<text>该卡已激活</text>
								</view>
							</view>
							
						</view>
					</navigator>
								
				</view>
			</view>
			<view v-else class="empty">
				<image src="https://www.abcbook2019.com/mobile/public/img/icon/boxs.png" mode="aspectFit"></image>
				<view class="empty-tips">
					<view>您还没有计划哦</view>
					<view class="navigator" @click="gotoIndex">去逛逛</view>
				</view>
			</view>
			
			<view class="popup" v-if="success">
				<view class="message">
					<image src="https://www.abcbook2019.com/mobile/public/img/bcustome/success.png" mode="widthFix"></image>
					<view class="textit">恭喜成为{{rankName}}</view>
					<view class="tex">快去首页选书吧 每次可借阅10本哦</view>
					<button class="btn" type="primary" @click="gotoind()">去选书</button>
				</view>
				
			</view>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default {
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "会员计划",
				navList:["已激活","未激活","已取消"],
				tabCurrentIndex:1,
				rankName:'',
				dataArr:[],
				success:false
			}
		},
		onLoad() {
			this.$api.quest('user/userProject',{
				page:1,
				status:2
			},(res)=>{
				this.dataArr=res.data.data
				console.log(res.data.data,'e')
			})
		},
		methods: {
			tabClick(index){
				this.tabCurrentIndex=index
				this.$api.quest('user/userProject',{
					page:1,
					status:index+1
				},(res)=>{
					this.dataArr=res.data.data
					console.log(res.data.data)
				})
			},
			// 去选书
			gotoind(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			refund(id,index){
				this.$api.quest('user/refund',{
					order_id:id
				},(res)=>{
					console.log(res.data.data)
					if(res.data.code==0){
						this.$api.msg("退卡成功")
						this.dataArr.splice(index,1)
					}else{
						this.$api.msg("退卡失败，请联系客服")
					}
				})
			},
			activat_card(id,index){
				this.$api.quest('user/activity',{
					order_id:id
				},(res)=>{
					console.log(res)
					if(res.data.code==0){
						// this.$api.msg("激活成功")
						this.dataArr.splice(index,1)
						this.rankName=res.data.data.ranks_name
						this.success=true
						
					}else{
						this.$api.msg(res.data.data)
					}
				})
			},
			gotoIndex(){
				uni.navigateBack()
				// this.$store.commit("change_page", 0)
				// uni.navigateTo({
				// 	url:'/pages/index/index'
				// })
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/cardcon.scss';
	// 弹框
	.popup{
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		background: rgba(0,0,0,.5);
		z-index: 999;
		.message{
			position: absolute;
			top: 30%;
			left: 50%;
			transform: translate(-50%);
			width:488rpx;
			height:366rpx;
			background:rgba(255,255,255,1);
			border-radius:24rpx;
			text-align:center;
			image{
				position: absolute;
				top: -75rpx;
				left:50%;
				transform: translate(-50%);
				width: 306rpx;
				height: 225rpx;
			}
			.textit{
				color:#FF824B;
				font-size: 34rpx;
				margin-top:139rpx;
				margin-bottom: 10rpx;
			}
			.tex{
				font-size: 26rpx;
				color: #666;
			}
			.btn{
				width:408rpx;
				line-height:88rpx;
				color: #fff;
				font-size: 32rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0rpx 4rpx 8rpx 0rpx rgba(255,130,75,0.5);
				border-radius:49rpx;
				margin-top: 30rpx;
			}
			
		}
	}
	
	
	
	
	.members{
		.noy{
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 30rpx;
			width:710rpx;
			margin: 20rpx auto;
			text{
				position: relative;
				display: block;
				font-size: 24rpx;
				color: #999;
			}
			.xl,.xr{
				width: 275rpx;
				height: 1rpx;
				background: #e6e6e6;
			}
		}
	}
	.card_price{
		.explain{
			font-size: 28rpx;
			color:#FA6C3A;
			line-height: 60rpx;
			margin-top: 30rpx;
		}
		.fr{
			margin-left: auto;
		}
	}
	.onbox{
		 filter: grayscale(100%); 
		 -webkit-filter: grayscale(100%);
		 opacity: .6;
	}
	.tu{
		border:1rpx solid #fea364 !important;
		color: #fea364 !important;
		background: #fff !important;
		box-shadow: none !important;
	}
	.navbar{
		display: flex;
		height: 88rpx;
		background: #fff;
		position: relative;
		z-index: 10;
		box-shadow:0px 2rpx 8rpx 0px rgba(0,0,0,0.1),0px -1rpx 0px 0px rgba(230,230,230,1);
		.nav-item{
			flex: 1;
			display: flex;
			justify-content: center;
			align-items: center;
			font-size: 30rpx;
			line-height: 50rpx;
			color: $font-color-dark;
			position: relative;
			
			// position: relative;
			// display: inline-block;
			// margin-left: 50rpx;
			// color: #666;
			// font-size: 30rpx;
			// line-height: 50rpx;
			// &.current{
			// 	color: $base-color;
			// 	&:after{
			// 		content: '';
			// 		position: absolute;
			// 		left: 50%;
			// 		bottom: 0;
			// 		transform: translateX(-50%);
			// 		width: 44px;
			// 		height: 0;
			// 		border-bottom: 2px solid $base-color;
			// 	}
			// }
			
			
			&.current {
				color: #FF824B;
				position: relative;
				font-size: 36rpx;
				&:before {
					display: block;
					content: "";
					position: absolute;
					width: 26rpx;
					height: 8rpx;
					bottom: 12rpx;
					left: 50%;
					transform: translate(-50%, 0%);
					background: #FF824B;
					border-radius: 4rpx;
				}
			}
				
			
		}
	}
</style>
