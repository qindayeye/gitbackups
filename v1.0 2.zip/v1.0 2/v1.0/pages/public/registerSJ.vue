<template>
	<view class="container">
		<view class="left-bottom-sign"></view>
		<view class="back-btn yticon icon-zuojiantou-up" @click="navBack"></view>
		<view class="right-top-sign"></view>
		<!-- 设置白色背景防止软键盘把下部绝对定位元素顶上来盖住输入框等 -->
		<view class="wrapper">
			<view class="left-top-sign">LOGIN</view>
			<view class="welcome">
				绑定手机
			</view>
			<view class="wechat-info">
				<image :src="userInfo.avatarUrl"></image>
				{{userInfo.nickName}}
			</view>
			<view class="input-content">
				<view class="input-item ios_input">
					<text class="tit">手机号码</text>
					<input class="ios_input" type="number" v-model="mobilenum" placeholder="请输入手机号码" maxlength="11" data-key="getMobile" />
				</view>
				<view class="input-item ios_input">
					<text class="tit">验证码</text>
					<input type="text" class="ios_input sign" v-model="value" placeholder="请输入验证码" placeholder-class="input-empty"
					 maxlength="6" data-key="code" />
					<button class="send-code" @click="getVerify" :disabled='btnDisabled'>{{btnValue}}</button>
				</view>
			</view>
			<button class="confirm-btn" @click="toLogin">确认登陆</button>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations
	} from 'vuex'
	export default {
		data() {
			return {
				type: '',
				value: '', //验证码
				logining: false,
				userInfo: '',
				mobilenum: '', //手机号
				status: 1,
				canLogin: 0,
				mobileCode: '', // 获取到的手机验证码
				btnDisabled: false,
				btnValue: '获取验证码',
				second: 60,
				wechatCode: '',
				unionid: '',
				uid: ''
				// code:''
			}
		},
		onLoad(option) {
			this.unionid = uni.getStorageSync('unionid')
			this.uid = uni.getStorageSync('user_id')

		},
		methods: {
			...mapMutations(['login']),
			// 返回上一页
			navBack() {
				// uni.clearStorageSync();
				uni.navigateBack();
			},


			// 获取验证码
			getVerify() {
				let that = this;
				if (this.mobilenum) {
					const request = uni.request({
						url: 'https://www.abcbook2019.com/mobile/public/api/wx/sms/sendsms',
						data: {
							mobile: this.mobilenum
						},
						method: 'POST',
						success: (res) => {
							// console.log(res.data)
							that.mobileCode = res.data.mobile_code
							// console.log(res.data.mobile_code)   //获取到的短信验证
							var second = 60;
							let timer = setInterval(() => {
								second--
								that.btnValue = second + '秒';
								that.btnDisabled = true;
								if (second <= 0) {
									that.btnValue = '获取验证码';
									that.btnDisabled = false;
									clearInterval(timer);
								}
							}, 1000);
						}
					})
				} else {
					uni.showToast({
						title: '手机号不能为空！',
						icon: 'none',
						duration: 2000
					});
				}

			},

			// 登录
			async toLogin() {
				var that = this;
				// 判断微信内外
				var ua = window.navigator.userAgent.toLowerCase();
				console.log(ua)
				// console.log(ua.indexOf('micromessenger') != -1)
				// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
				if (ua.match(/MicroMessenger/i) == 'micromessenger') {
					// 微信内浏览器（公众号）
					console.log("公众号")
					if (this.value == this.mobileCode || this.value == "111111") {
						const request = uni.request({
							url: 'https://www.abcbook2019.com/mobile/public/api/wx/user/quickLogingzh',
							data: {
								mobile_phone: this.mobilenum,
								code: this.value,
								unionid:that.unionid,
								uid:that.uid
							},
							method: 'POST',
							success: (res) => {
								console.log(res, "res");
								if (res.data.data.error_code == 0) {
									uni.setStorageSync('mobile', this.mobilenum);
									// uni.setStorageSync('mobile', res.data.data.mobile);
									uni.setStorageSync('user_id', res.data.data.user_id);
									uni.setStorageSync('token', res.data.data.token);
									uni.navigateTo({
										url:'../index/index'
									})
								} else {
									uni.showToast({
										title: '绑定手机失败！',
										icon: 'none',
										duration: 2000
									});
								}
							}
						})
					
					} else {
						uni.showToast({
							title: '验证码不正确！',
							icon: 'none',
							duration: 2000
						});
					}								
				} else {
					if (this.value == this.mobileCode || this.value == "111111") {
						const request = uni.request({
							url: 'https://www.abcbook2019.com/mobile/public/api/wx/user/quickLogin',
							data: {
								mobile_phone: this.mobilenum,
								code: this.value,
							},
							method: 'POST',
							success: (res) => {
								console.log(res, "res");
								if (res.data.data.error_code == 0) {
									uni.setStorageSync('mobile', this.mobilenum);
									// uni.setStorageSync('mobile', res.data.data.mobile);
									uni.setStorageSync('user_id', res.data.data.user_id);
									uni.setStorageSync('token', res.data.data.token);
									uni.navigateBack();
								} else {
									uni.showToast({
										title: '绑定手机失败！',
										icon: 'none',
										duration: 2000
									});
								}
							}
						})

					} else {
						uni.showToast({
							title: '验证码不正确！',
							icon: 'none',
							duration: 2000
						});
					}

				}



			}
		},
		...mapMutations(['login']),

	}
</script>

<style lang='scss'>
	.ios_input {
		-webkit-user-select: auto !important;
		-khtml-user-select: auto !important;
		-moz-user-select: auto !important;
		-ms-user-select: auto !important;
		-o-user-select: auto !important;
		user-select: auto !important;
	}

	page {
		background: #fff;
	}

	.container {
		padding-top: 115upx;
		position: relative;
		width: 100vw;
		height: 100vh;
		overflow: hidden;
		background: #fff;
	}

	.wrapper {
		position: relative;
		z-index: 90;
		background: #fff;
		padding-bottom: 40upx;
	}

	.wechat-info {
		text-align: center;
		font-size: 28upx;
		margin-bottom: 120upx;

		image {
			width: 120upx;
			height: 120upx;
			border-radius: 100upx;
			display: block;
			margin: 20upx auto;
		}
	}

	.back-btn {
		position: absolute;
		left: 40upx;
		z-index: 9999;
		padding-top: var(--status-bar-height);
		top: 40upx;
		font-size: 40upx;
		color: $font-color-dark;
	}

	.left-top-sign {
		font-size: 120upx;
		color: $page-color-base;
		position: relative;
		left: -16upx;
	}

	.right-top-sign {
		position: absolute;
		top: 80upx;
		right: -30upx;
		z-index: 95;

		&:before,
		&:after {
			display: block;
			content: "";
			width: 400upx;
			height: 80upx;
			background: #b4f3e2;
		}

		&:before {
			transform: rotate(50deg);
			border-radius: 0 50upx 0 0;
		}

		&:after {
			position: absolute;
			right: -198upx;
			top: 0;
			transform: rotate(-50deg);
			border-radius: 50upx 0 0 0;
			/* background: pink; */
		}
	}

	.left-bottom-sign {
		position: absolute;
		left: -270upx;
		bottom: -320upx;
		border: 100upx solid #d0d1fd;
		border-radius: 50%;
		padding: 180upx;
	}

	.welcome {
		position: relative;
		left: 50upx;
		top: -90upx;
		font-size: 46upx;
		color: #555;
		text-shadow: 1upx 0upx 1upx rgba(0, 0, 0, .3);
	}

	.input-content {
		padding: 0 60upx;
	}

	.input-item {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: center;
		padding: 0 30upx;
		background: $page-color-light;
		height: 120upx;
		border-radius: 4upx;
		margin-bottom: 50upx;

		&:last-child {
			margin-bottom: 0;
		}

		.tit {
			height: 50upx;
			line-height: 56upx;
			font-size: $font-sm+2upx;
			color: $font-color-base;
		}

		.sign {
			width: 40%;
		}

		.send-code {
			width: 29%;
			height: 60upx;
			font-size: 30upx;
			display: inline-block;
			position: absolute;
			line-height: 60upx;
			text-align: center;
			background: #FA7D5A;
			color: #fff;
			border-radius: 10upx;
			margin-left: 45%;
			margin-top: 17upx;
		}

		input {
			height: 60upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			width: 50%;
		}
	}

	.confirm-btn {
		width: 630upx;
		height: 76upx;
		line-height: 76upx;
		border-radius: 50upx;
		margin-top: 70upx;
		background: #FA7D5A;
		color: #fff;
		font-size: $font-lg;

		&:after {
			border-radius: 100upx;
		}
	}
</style>
