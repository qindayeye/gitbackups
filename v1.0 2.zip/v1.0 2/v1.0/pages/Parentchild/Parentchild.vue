<template>
	<view class="Parentchild">
	<!-- #ifdef H5 -->
	<listCell :title.default="msg"></listCell>
	<!-- #endif -->
		<view class="banner">
			<image src="https://www.abcbook2019.com/mobile/public/img/parenting/banner.png" mode=""></image>
		</view>
		<view class="evaluating">
			<h4>评估结果</h4>
			<view class="plan">您一年大约陪伴宝宝阅读<text>{{paList.year_num}}</text>本书籍哦</view>
			<view class="iconimg">
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/erke.png" mode=""></image>
					<text>更有效的陪伴</text>
				</view> 
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/yuedu.png" mode=""></image>
					<text>更多的知识</text>
				</view>
				<view class="iconinfo">
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/toubu.png" mode=""></image>
					<text>促进智力发展</text>
				</view>
			</view>
			<view class="clockcard">
				<view class="expe">
					第<text>1</text>期
				</view>
				<h4>我和宝宝的10本阅读计划</h4>
				<view class="periods">
					<view class="num">
						<text class="numb">0</text>
						<text class="add">/10</text>
						<text class="add font">本</text>
					</view>
					<view class="stocks">书单处标记已读完成打卡</view>
					<image src="https://www.abcbook2019.com/mobile/public/img/parenting/LOGO.png" mode=""></image>
				</view>
				<view class="progress">
					<view class="within"></view>
					<view class="remark">
						<text class="remark_read">起点</text>
						<text>1</text>
						<text>2</text>
						<text>3</text>
						<text>4</text>
						<text>5</text>
						<text>6</text>
						<text>7</text>
						<text>8</text>
						<text>9</text>
					</view>
					<image class="medal_h" src="https://www.abcbook2019.com/mobile/public/img/parenting/medal_h.png" mode=""  ></image>
				</view>
			</view>
			<view class="Recommendation page">
				<view class="page_title title">
					<image src="https://ktoss.oss-cn-beijing.aliyuncs.com/app_image/pageicon.png" mode=""></image>
					<text>定制书单</text>
				</view>
				<view class="detailbooklist" >
					<navigator v-for="(item,index) in paList.books" :url="'../detail/detail?id='+item.goods_id" class="everybook" >
						<image class="bookimg" :src="item.goods_thumb" mode="widthFix"></image>
						<view class="hot_main_con">
							<view class="bookinfo">
								<view class="fl">
									<text class="bookinfotitl">{{item.goods_name}}</text>
									<view class="boxint">
										<text class="introduce">
										{{item.goods_brief}}
										</text>
									</view>
								</view>
								<view class="excha" @click.stop="Changebook(item,item.goods_id,index)">换一本</view>
							</view>
						</view>
						<view class="czdkuaile" v-if="item.fmbd==3">
							家长必读
						</view>
					</navigator>
				</view>
			</view>
		</view>
		<view class="floor_di">
			<view class="with btn" @click="gotohom()">返回首页</view>
			<view class="che btn" @click="planlist()">立即借阅</view>
		</view>
	</view>
</template>

<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default{
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "亲子书单",
				paList:[]
			}
		},
		onLoad(option) {
			  let list = JSON.parse(decodeURIComponent(option.list))
			this.paList=list
		},
		methods:{
			Changebook(item,id,index){
				this.$api.quest('plan/changebook',{
					id:id,
					goods_ids:this.paList.goods_id
				},(res)=>{
					this.paList.books.splice(index,1,res.data.data[0])
					this.goods_ids=res.data.data.goods_ids
				})
			},
			gotohom(){
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url:'/pages/index/index'
				})
			},
			planlist(){
				let goodids=[]
				this.paList.books.forEach(el=>{
					goodids.push(el.goods_id)
					
				})
				// goodids.toString()
				// console.log()
				this.$api.quest('cart/addPlanBookToCart',{
					ids:goodids.toString()
				},(rescar)=>{
					console.log(rescar.data.error)
					if(rescar.data.error==0){
						this.$api.quest('user/address/list', {}, (res) => {
							console.log(res, "res")
							if (res.data.data.length == 0) {
								uni.navigateTo({
									url: '/pages/address/addressManage'
								})
							} else {
								this.$api.quest('flow/checkuserorder', {
									flow_type:11
								}, (res) =>{
									console.log(res)
									if(res.data.code==1){
										this.$api.msg(res.data.data.data)
									}else{
										uni.navigateTo({
											url: '/pages/deposit/deposit?type=parentchil'
										})
									}
								})
							}
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	@import '../../static/css/Parentchild.scss';
	@import '../../static/css/detiallist.scss';
	.everybook{
		position: relative;
	}
	.czdkuaile{
		position: absolute;
		top: 0;
		left: 0;
		width: 128rpx;
		line-height: 39rpx;
		text-align: center;
		color: #fff;
		background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		border-radius:0px 100rpx 100rpx 0px;
		font-size: 24rpx;
	}
	.within{
		width: 0 !important;
	}
	.bookimg{
		width: 187rpx !important;
		height: 187rpx !important;
	}
	.page .detailbooklist .everybook .hot_main_con .bookinfo .bookinfotitl{
		width: 300rpx !important;
	}
	.page .detailbooklist .everybook .hot_main_con .bookinfo .boxint {
		width: 300rpx !important;
	}
	.excha{
		width:124rpx;
		height:60rpx;
		background:rgba(255,255,255,1);
		border-radius:40rpx;
		border:1rpx solid rgba(255,130,75,1);
		color: #FF824B;
		font-size: 28rpx;
		line-height: 60rpx;
		text-align: center;
	}
</style>
