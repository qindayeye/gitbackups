<template>
	<view class="warehouse">
		<view class="banner">
			<image src="https://www.abcbook2019.com/mobile/public/img/warehouse/warehouse1.png" mode="widthFix"></image>
		</view>
		<view class="video">
			<image src="https://www.abcbook2019.com/mobile/public/img/warehouse/warehouse_k.png" mode="widthFix"></image>
			<video id="video" class="" 
			 controls 
			 controlsList='nofullscreen nodownload noremote footbar' 
			 style="width:632rpx;height:356rpx" preload poster="https://www.abcbook2019.com/mobile/public/img/warehouse/video_bj.png" src="https://www.abcbook2019.com/mobile/public/video/video.mp4">
			</video>
		</view>
		<view class="viedo">
			<image src="https://www.abcbook2019.com//mobile/public/img/warehouse/warehouse2.png" mode="widthFix"></image>
			<image src="https://www.abcbook2019.com//mobile/public/img/warehouse/warehouse3.png" mode="widthFix"></image>
			<image src="https://www.abcbook2019.com//mobile/public/img/warehouse/warehouse4.png" mode="widthFix"></image>
			<image src="https://www.abcbook2019.com//mobile/public/img/warehouse/warehouse5.png" mode="widthFix"></image>
			<image src="https://www.abcbook2019.com//mobile/public/img/warehouse/warehouse6.png" mode="widthFix"></image>
		</view>
	</view>
</template>

<script>
</script>

<style lang="scss">
	page{
		padding: 0;
	}
	image{
		width: 750rpx;
		padding: 0;
		margin: 0;
		vertical-align: top;
		margin-top: -1rpx;
	}
	.video{
		position: relative;
		height: 373rpx;
		background:#fff5db;
		position: relative;
		image{
			position: absolute;
			left: 50%;
			top: -68rpx;
			transform: translate(-50%);
			width: 653rpx;
		}
		video{
			position: absolute;
			left: 50%;
			top: -62rpx;
			transform: translate(-50%);
		}
	}
</style>
