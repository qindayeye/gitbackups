<template>
	<view class="account">
		<view class="carousel-section">
			<swiper class="swiper-box" :indicator-dots="indicator" :current="cur" :circular="circular" :autoplay="autoplay" :interval="interval" :duration="duration">
				<block v-for="(item, index) in bannerArr" :key="index">
					<swiper-item @click="gotoban(item.app_link)"><image class="banner-img" :src="item.ad_code"></image></swiper-item>
				</block>
			</swiper>
		</view>
		<!-- 导航 -->
		<view class="nav" :class="{ navTop: navTop === true }">
			<text :class="{ active: index === curId }" v-for="(item, index) in indexArr" :key="index" @click="gotoactivity(index, item.cat_id)">{{ item.cat_name }}</text>
		</view>
		<view class="hotmain" v-if="goodArr.length != 0">
			<!-- <bookdetail ></bookdetail> -->
			<block v-for="(item, index) in goodArr" :key="index">
				<navigator :url="'../detail/detail?id='+item.goods_id" open-type="navigate">
				<!-- <navigator :url="'../detail/knowdetail?id=' + item.goods_id" open-type="navigate"> -->
					<view class="hot_main_con">
						<image class="bookimg" :src="item.goods_thumb" mode=""></image>
						<view class="bookinfo">
							<text class="bookinfotitl">{{ item.goods_name }}</text>
							<view class="label">
								<text class="label1" v-if="item.goods_discount">{{item.goods_discount}}折</text>
								<text class="label2" v-else-if="item.warn_num">
									{{ item.warn_num}}
								</text>
								<text class="label2" v-else-if="item.goodsCategory[0]">
									{{item.goodsCategory[0].cat_name}}
								</text>
								<text class="label2" v-if="item.goodsCategory[1]">{{item.goodsCategory[1].cat_name}}</text>
							</view>
							<view class="moneyBox">
								<view class="money">
									<view class="present">
										{{ item.shop_price_1 }}
										<text v-if="item.shop_price_2 > 0">.{{ item.shop_price_2 }}</text>
									</view>
									<view class="original" v-if="item.market_price_1 > 0">
										￥{{ item.market_price_1 }}
										<text v-if="item.market_price_2>0">.{{item.market_price_2}}</text>
									</view>
								</view>
								<view class="buy" @click.stop="shopgoods(item.goods_id, item.ru_id)">购买</view>
							</view>
						</view>
					</view>
				</navigator>
			</block>
		</view>
		<!-- 没有商品空白页 -->
		<view class="empt" v-else>
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/boxs.png" mode="aspectFit"></image>
			<view class="empty-tips"><view>当前没有更多商品哦~</view></view>
		</view>
		<!-- 加载更多提示信息 -->
		<view class="flocon" v-if="classon">{{ classoninfo }}</view>

		<!-- 返回顶部向上箭头 -->
		<view id="scrollToTop" class="to-top" :class="{ hide: hide }" @click="gotop"><image src="https://www.abcbook2019.com/mobile/public/img/index/gotoTop.png"></image></view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			PayPoint: [],
			pay_points: 0,
			curId: 0, //导航下标
			navTop: false,
			classon: false, //判断提示语
			hide: true,
			indicator: true, //是否显示指示点
			interval: 5000, //自动切换时间间隔
			duration: 400, //滑动动画时长
			autoplay: true, //是否自动切换
			circular: true, //是否采用衔接滑动
			cur: 0, //当前所在滑块的index
			classoninfo: '正在努力加载...', //加载展示内容
			indexArr: {
				cat_id: 0,
				cat_name: '全部'
			}, //导航数据
			bannerArr: [], //banner数据
			goodArr: [], //产品数据
			page: 1
		};
	},
	// 实时获取滚动的值，到一定位置显示返回顶部
	onPageScroll: function(Object) {
		if (Object.scrollTop > 164.8) {
			this.navTop = true;
		} else {
			this.navTop = false;
		}
		if (Object.scrollTop > 400) {
			this.hide = false;
		} else {
			this.hide = true;
		}
		if (this.classoninfo == '我也是有底线的哦~') {
			this.classon = false;
		}
	},
	// 分享
	onShareAppMessage(res) {
		if (res.from === 'button') {
			// 来自页面内分享按钮
			console.log(res.target);
		}
		return {
			title: 'ABCbook国际亲子阅读-商城',
			path: '/pages/Candy/CandyStore'
		};
	},
	onShow() {
		// this.getgoods()
	},
	onLoad() {
		this.getgoods();
	},
	methods: {
		getgoods() {
			this.$api.quest(
				'goods/pointsGoods',
				{
					cat_id: 0,
					page: 1
				},
				res => {
					// console.log(res)
					if (res.data.data.error == 1) {
						// #ifdef H5
						// 判断微信内外
						var ua = window.navigator.userAgent.toLowerCase();
						console.log(ua);
						// console.log(ua.indexOf('micromessenger') != -1)
						// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
						if (ua.match(/MicroMessenger/i) == 'micromessenger') {
							// 微信内浏览器（公众号）
							console.log('公众号');
							uni.navigateTo({
								url: '/pages/public/login'
							});
						} else {
							uni.navigateTo({
								url: '/pages/public/registerSJ'
							});
						}
						// #endif

						// #ifdef MP
						uni.navigateTo({
							url: '/pages/public/login'
						});
						// #endif
					} else {
						if (res.data.code == 0) {
							this.bannerArr = res.data.data.nav;
							let inarr = [];
							let shi = {
								cat_id: 0,
								cat_name: '全部'
							};
							inarr = res.data.data.category;
							inarr.unshift(shi);
							this.indexArr = inarr;
							// console.log(this.indexArr)

							this.goodArr = res.data.data.goods;
							// console.log(this.goodArr)
						} else {
							this.$api.msg(res.data.data);
						}
					}
				}
			);
		},
		// 返回顶部点击事件
		gotop() {
			uni.pageScrollTo({
				scrollTop: 0,
				duration: 300
			});
		},
		onReachBottom() {
			this.scroll();
		},
		shopgoods(goodsid, ruid) {
			this.$api.quest('user/address/list', {}, res => {
				// console.log(res, "res")
				uni.setStorageSync('goid', goodsid);
				uni.setStorageSync('ruid', ruid);
				if (res.data.data.length == 0) {
					uni.navigateTo({
						url: '/pages/address/addressManage?type=shopgood'
					});
				} else {
					this.$api.quest(
						'cart/addshopgoods',
						{
							id: goodsid,
							num: 1,
							ru_id: ruid,
							rec_type: 10,
							is_checked: 1,
							act_id: 0
						},
						res => {
							// console.log(res,'res')
							if (res.data.code == 0) {
								uni.navigateTo({
									url: '/pages/flow/shopgoods?goid=' + goodsid + '&ruid=' + ruid
								});
							} else if (res.data.data.error) {
								this.$store.commit('change_page', 4);
								// #ifdef H5
								// 判断微信内外
								var ua = window.navigator.userAgent.toLowerCase();
								console.log(ua);
								// console.log(ua.indexOf('micromessenger') != -1)
								// console.log(ua.match(/MicroMessenger/i) == 'micromessenger')
								if (ua.match(/MicroMessenger/i) == 'micromessenger') {
									// 微信内浏览器（公众号）
									console.log('公众号');
									uni.navigateTo({
										url: '/pages/public/login'
									});
								} else {
									uni.navigateTo({
										url: '/pages/public/registerSJ'
									});
								}
								// #endif

								// #ifdef MP
								uni.navigateTo({
									url: '/pages/public/login'
								});
								// #endif
							}
						}
					);
				}
			});
		},
		// bannner跳转链接
		gotoban(url) {
			uni.navigateTo({
				url: url
			});
		},
		scroll() {
			const that = this;
			that.classon = true;
			this.loadingType = 1;
			this.$api.quest(
				'goods/pointsGoods',
				{
					page: ++that.page,
					cat_id: that.id ? that.id : 0
				},
				res => {
					// console.log(res.data.data)
					if (res.data.data.goods.length == 0) {
						//没有数据
						this.loadingType = 2;
						that.classon = true;
						that.classoninfo = '我也是有底线的哦~';
						uni.hideNavigationBarLoading(); //关闭加载动画
						return;
					}
					that.goodArr.push(...res.data.data.goods);
					uni.hideNavigationBarLoading(); //关闭加载动画
					that.classon = false; //判断模块框
					// console.log(that.hotmain,'hot',that.page,'page')
					uni.hideNavigationBarLoading(); //关闭加载动画
				}
			);
		},
		gotoCandy() {
			uni.navigateTo({
				url: './Candy'
			});
		},
		gotoactivity(index, id) {
			this.curId = index;

			if (index == 0) {
				this.id = 0;
			} else {
				this.id = id;
			}
			this.page = 1;
			this.$api.quest(
				'goods/pointsGoods',
				{
					cat_id: this.id,
					page: 1
				},
				res => {
					// console.log(res)
					if (res.data.code == 0) {
						// this.bannerArr=res.data.data.nav
						// this.indexArr = res.data.data.category
						this.goodArr = res.data.data.goods;
						// console.log(this.goodArr)
						if (this.goodArr.length == 0) {
						}
					} else {
						this.$api.msg('请求失败');
					}
				}
			);
		},
		navToGainCandy() {
			uni.navigateTo({
				url: './GainCandy'
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: #fafafa;
}

.empt {
	display: flex;
	justify-content: center;
	flex-direction: column;
	align-items: center;

	image {
		margin-top: 140rpx;
		width: 287rpx;
		height: 181rpx;
	}

	.empty-tips {
		text-align: center;
		font-size: 24rpx;
		line-height: 33rpx;
		color: #999;
		margin-top: 50rpx;

		text {
			display: block;
		}
	}
}

// 头部轮播
.carousel-section {
	width: 750rpx;
	height: 260upx;

	.swiper-box {
		height: 100%;

		.wx-swiper-dot {
			bottom: 6upx;
			width: 12upx;
			display: inline-flex;
			margin-left: 7upx;
			height: 12upx;
			justify-content: space-between;
		}

		image {
			width: 100%;
			height: 260upx;
			overflow: hidden;
		}
	}

	.swiper-box .wx-swiper-dot::before {
		content: '';
		flex-grow: 1;
		// background: rgba(255,255,255,.3 );
		border-radius: 50%;
	}

	.swiper-box .wx-swiper-dot-active::before {
		background: #fff;
	}
}

.account {
	.headerd {
		position: relative;
		width: 750rpx;
		height: 388rpx;
		background-image: url('https://www.abcbook2019.com/mobile/public/img/user/user_bj.png');
		background-size: cover;

		.title {
			position: relative;
			height: 88rpx;
			padding-top: 60rpx;
			color: #fff;

			h4 {
				text-align: center;
				font-size: 34rpx;
			}

			.icon-zuo {
				position: absolute;
				z-index: 999;
				left: 34rpx;
				font-size: 40rpx;
			}
		}

		.con {
			text-align: center;
			margin-top: 80rpx;

			.deposit {
				// display: block;
				font-size: 24rpx;
				color: #fffa79;
				text-align: center;
			}

			.store {
				color: #fff;
				font-size: 28rpx;

				text {
					font-size: 48rpx;
					font-weight: bold;
					margin: 0 10rpx;
				}
			}

			.btn {
				width: 130rpx;
				line-height: 52rpx;
				background: transparent;
				border-radius: 30rpx;
				font-size: 24rpx;
				color: #fff;
				border: 1rpx solid #fff;
				margin-top: 20rpx;
			}
		}

		.pint {
			width: 142rpx;
			height: 54rpx;
			font-size: 24rpx;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: rgba(111, 50, 23, 1);
			line-height: 54rpx;
			text-align: center;
			background: rgba(255, 205, 120, 0.6);
			border-radius: 100rpx 0rpx 0rpx 100rpx;
			position: absolute;
			right: 0;
			top: 36%;
		}
	}

	.navTop {
		z-index: 9998;
		position: fixed;
		top: 0;
		left: 0;
	}

	.nav {
		display: flex;
		align-items: center;
		white-space: nowrap;
		justify-content: space-around;
		line-height: 36rpx;
		overflow-x: scroll;
		-webkit-overflow-scrolling: touch;
		white-space: nowrap;
		width: 750rpx;
		height: 88rpx;
		background: rgba(255, 255, 255, 1);
		box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.06), 0px -1px 0px 0px rgba(230, 230, 230, 1);

		text {
			position: relative;
			display: inline-block;
			// margin-left: 50rpx;
			color: #666;
			font-size: 30rpx;
			line-height: 50rpx;
		}

		.active {
			color: #ff824b;
			position: relative;
			font-size: 36rpx;
			font-weight: bold;
		}

		.active::before {
			display: block;
			content: '';
			position: absolute;
			width: 26rpx;
			height: 8rpx;
			bottom: -12rpx;
			left: 50%;
			transform: translate(-50%, 0%);
			background: #ff824b;
			border-radius: 4rpx;
		}
	}

	.nav::-webkit-scrollbar {
		display: none;
	}

	.flocon {
		position: fixed;
		bottom: 50rpx;
		left: 50%;
		transform: translate(-50%, 0);
		font-size: 26rpx;
		color: #999999;
		text-align: center;
	}

	.hotmain {
		box-sizing: border-box;
		padding: 20rpx;
		padding-top: 0;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;

		.hot_main_con {
			background: #fff;
			width: 345upx;
			box-sizing: border-box;
			padding: 20upx;
			margin-top: 20upx;
			border-radius: 10rpx;

			.bookimg {
				display: block;
				margin: 0 auto;
				width: 292upx;
				height: 292upx;
				margin-top: 13upx;
			}

			.bookinfo {
				position: relative;

				> text {
					width: 300upx;
					display: block;
					font-size: 30upx;
					color: rgba(51, 51, 51, 1);
					margin-top: 29upx;
					margin-bottom: 20upx;
					word-spacing: -1rpx;
					overflow: hidden;
					text-overflow: ellipsis; //文本溢出显示省略号
					white-space: nowrap; //文本不会换行（单行文本溢出）
				}

				.label {
					display: flex;
					margin-bottom: 15rpx;

					> text {
						display: inline-block;
						font-size: 22upx;
						padding: 5rpx 15rpx;
						border-radius: 22rpx;
						margin-right: 10rpx;
					}

					.label1 {
						background: linear-gradient(135deg, rgba(254, 163, 100, 1) 0%, rgba(250, 108, 58, 1) 100%);
						color: #fff;
					}

					.label2 {
						background: rgba(255, 230, 220, 1);
						color: #ff824b;
						// margin-left: 10rpx;
					}
				}

				.moneyBox {
					display: flex;
					justify-content: space-between;

					// align-items: center;
					.money {
						display: flex;
						align-items: flex-end;

						// flex-direction: column;
						.present {
							font-size: 36rpx;
							// display: inline-block;
							color: rgba(224, 32, 32, 1);
							font-weight: bold;

							&::before {
								content: '￥';
								color: rgba(224, 32, 32, 1);
								font-size: 28rpx;
							}

							text {
								font-size: 28rpx;
								color: rgba(224, 32, 32, 1);
								font-weight: normal;
							}
						}

						.original {
							// display: inline-block;
							margin-left: 5rpx;
							font-size: 20rpx;
							color: rgba(153, 153, 153, 1);
							text-decoration: line-through;
						}
					}

					.buy {
						width: 128rpx;
						border-radius: 30rpx;
						border: 2rpx solid rgba(255, 130, 75, 1);
						font-size: 28rpx;
						font-weight: 400;
						color: rgba(255, 130, 75, 1);
						line-height: 50rpx;
						text-align: center;
						align-self: flex-start;
					}
				}
			}
		}
	}

	// 小火箭返回顶部
	.to-top {
		position: fixed;
		bottom: 150rpx;
		right: 13rpx;
		width: 84rpx;
		height: 84rpx;
		border-radius: 50%;
		background: #fff;
		box-shadow: 0rpx 2rpx 8rpx 0rpx rgba(255, 130, 75, 0.3);
		border: 2rpx solid rgba(255, 205, 120, 1);

		image {
			width: 38rpx;
			height: 57rpx;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}
	}

	.hide {
		display: none;
	}
}
</style>
