<template>
	<view class="account">
		<view class="headerd">
			<view class="title">
				<navigator class="cell-icon yticon icon-zuo"  open-type="navigateBack"></navigator>
				<h4>糖豆</h4>
			</view>
			<view class="con">
				<text>糖豆总量</text>
				<h2>{{pay_points}}</h2>
				<button type="primary" class="btn"  @click="navToho">逛一逛</button>
			</view>
		</view>	
		<view class="pint">
			每日签到，可以获得更多糖豆哦
		</view>
		<view class="accList">
			<view class="accinfo firselis">
				糖豆
			</view>
			<view class="accinfo clear" v-for="(item,index) in PayPoint">
				<view class="fl left">
					<view class="infoti">{{item.short_change_desc}}</view>
					<view class="infotime">{{item.change_time}}</view>
				</view>
				<view class="fr money">
					<text>+{{item.pay_points}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				PayPoint:[],
				pay_points:0
			}
		},
		onLoad() {
			
			this.$api.quest('user/getPayPoints',{
				page:1
			},(res)=>{
				console.log(res)
				if(res.data.code==0){
					this.PayPoint=res.data.data.list
					this.pay_points=res.data.data.pay_points
				}else{
					this.$api.msg("请求失败")
				}
			})
		},
		methods:{
			navToho() {
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
		}
	}
	
</script>

<style lang="scss">
	@import '../../static/css/account.scss';
</style>
