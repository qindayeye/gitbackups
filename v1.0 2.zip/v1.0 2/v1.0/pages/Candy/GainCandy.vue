<template>
	<view class="account">
		<view class="headerd">
			<view class="title">
				<navigator class="cell-icon yticon icon-zuo" open-type="navigateBack"></navigator>
				<h4>赚糖豆</h4>
			</view>
			<view class="con">
				<h2>当前{{pay_points}}糖豆</h2>
				<text>可抵现20元</text>
			</view>
			<view class="pint" @click="gotoCandy">
				糖豆明细
			</view>
			<view class="candytob">
				<view class="tobitem">
					<image src="https://www.abcbook2019.com/mobile/public/img/beansZ/beansnav1.png" mode=""></image>
					<text>换购抵现</text>
				</view>
				<view class="tobitem">
					<image src="https://www.abcbook2019.com/mobile/public/img/beansZ/beansnav2.png" mode=""></image>
					<text>换购会员</text>
				</view>
				<view class="tobitem">
					<image src="https://www.abcbook2019.com/mobile/public/img/beansZ/beansnav3.png" mode=""></image>
					<text>兑超值卷</text>
				</view>
				<view class="tobitem">
					<image src="https://www.abcbook2019.com/mobile/public/img/beansZ/beansnav4.png" mode=""></image>
					<text>糖豆抽奖</text>
				</view>
			</view>
		</view>
		<view class="taskTitle">
			完成任务赚糖豆
		</view>
		<view class="taskItem" v-for="(item,index) in listImage" :key="item">
			<view class="taskItemZuo">
				<image :src="item.img" mode=""></image>
				<view class="taskdes">
					<H3 class="taskdesitem">{{item.title}}<text>+{{item.num}}</text></H3>
					<text>{{item.explain}}</text>
				</view>				
			</view>
			<view class="button" v-if="index==0">
				去签到
			</view>
			<view class="button" v-if="index==1">
				去分享
			</view>
			<view class="button" v-if="index==2">
				去评价
			</view>
			<view class="button" v-if="index==3">
				已完成
			</view>
			<view class="button" v-if="index==4">
				已完成
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				PayPoint: [],
				pay_points: 0,
				curId: 1,
				navTop: false,
				hide: true,
				listImage: [
					{
						img:'https://www.abcbook2019.com/mobile/public/img/beansZ/beanslist1.png',
						title:'签到',
						num:5,
						explain:'连续签到7天糖豆翻倍',
						link:'/pages/sign/sign'
					},
					{
						img:'https://www.abcbook2019.com/mobile/public/img/beansZ/beanslist2.png',
						title:'邀请好友',
						num:10,
						explain:'好友加入会员再送60颗糖豆',
						link:'/pages/sign/sign'
					},
					{
						img:'https://www.abcbook2019.com/mobile/public/img/beansZ/beanslist3.png',
						title:'评价订单',
						num:10,
						explain:'评价已完成订单赚10糖豆',
						link:'/pages/sign/sign'
					},
					{
						img:'https://www.abcbook2019.com/mobile/public/img/beansZ/beanslist4.png',
						title:'首次购买会员',
						num:1000,
						explain:'首次购买年卡会员赚1000糖豆',
						link:'/pages/sign/sign'
					},
					{
						img:'https://www.abcbook2019.com/mobile/public/img/beansZ/beanslist5.png',
						title:'完善个人信息',
						num:10,
						explain:'编辑完善个人信息赚10糖豆',
						link:'/pages/sign/sign'
					}
				]
			}
		},
		// 实时获取滚动的值，到一定位置显示返回顶部
		onPageScroll: function(Object) {
			// console.log(Object.scrollTop)
			if (Object.scrollTop > 164.8) {
				this.navTop = true;
			} else {
				this.navTop = false;
			};
			if (Object.scrollTop > 800) {
				this.hide = false;
			} else {
				this.hide = true;
			}
		},
		onLoad() {

			this.$api.quest('user/pointsInfo', {}, (res) => {
				console.log(res)
				if (res.data.code == 0) {
					this.listImage=res.data.data.listImage
				} else {
				}
			})
		},
		methods: {
			// 返回顶部点击事件
			gotop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			gotoCandy() {
				uni.navigateTo({
					url: "./Candy"
				})
			},
			gotoactivity(index) {
				this.curId = index
			},
			navToho() {
				this.$store.commit("change_page", 0)
				uni.navigateTo({
					url: '/pages/index/index'
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.account {
		.headerd {
			position: relative;
			width: 750rpx;
			height: 388rpx;
			background-image: url('https://www.abcbook2019.com/mobile/public/img/user/user_bj.png');
			background-size: cover;

			.title {
				position: relative;
				height: 88rpx;
				padding-top: 60rpx;
				color: #fff;

				h4 {
					text-align: center;
					font-size: 34rpx;
				}

				.icon-zuo {
					position: absolute;
					z-index: 999;
					left: 34rpx;
					font-size: 40rpx;
				}
			}

			.con {
				text-align: center;
				margin-top: 80rpx;

				text {
					display: block;
					font-size: 24rpx;
					color: #fff;
					font-weight: 400;
					text-align: center;
				}

				h2 {
					color: #fff;
					font-size: 40rpx;
					font-weight: bold;
					font-family: DINAlternate-Bold, DINAlternate;

				}

				.btn {
					width: 146rpx;
					line-height: 52rpx;
					background: rgba(255, 255, 255, 0.2);
					border-radius: 25rpx;
					font-size: 24rpx;
					color: #fff;
					border: none;
					margin-top: 20rpx;
				}
			}

			.pint {
				width: 142rpx;
				height: 54rpx;
				font-size: 24rpx;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: rgba(111, 50, 23, 1);
				line-height: 54rpx;
				text-align: center;
				background: rgba(255, 205, 120, 0.6);
				border-radius: 100rpx 0rpx 0rpx 100rpx;
				position: absolute;
				right: 0;
				top: 36%;
			}

			.candytob {
				width: 710rpx;
				height: 160rpx;
				background: rgba(255, 255, 255, 1);
				box-shadow: 0rpx -2rpx 6rpx 0rpx rgba(0, 0, 0, 0.1);
				border-radius: 10rpx;
				position: absolute;
				left: 20rpx;
				bottom: -80rpx;
				display: flex;
				justify-content: space-around;
				align-items: center;

				.tobitem {
					display: flex;
					justify-content: center;
					align-items: center;
					flex-direction: column;

					image {
						width: 72rpx;
						height: 72rpx;
					}

					text {
						font-size: 24rpx;
					}
				}
			}

		}

		.taskTitle {
			margin: 120rpx 0 20rpx 40rpx;
			font-size:32rpx;
			font-family:PingFangSC-Medium,PingFang SC;
			font-weight:500;
			color:rgba(102,102,102,1);
			line-height:30rpx;
		}
		.taskItem{
			margin: 20rpx;
			width:710rpx;
			height:148rpx;
			background:rgba(255,255,255,1);
			border-radius:9rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			
			.taskItemZuo{
				display: flex;
				justify-content: flex-start;
				align-items: center;
				image{
					width: 120rpx;
					height: 120rpx;
				}
				.taskdes{
					display: flex;
					justify-content: center;
					align-items: flex-start;
					flex-direction: column;
					.taskdesitem{
						font-size:30rpx;
						font-family:PingFangSC-Regular,PingFang SC;
						font-weight:400;
						color:rgba(51,51,51,1);
						line-height:30rpx;
						
						text{
							color: #FF824B;
						}
					}
					text{
						font-size:24rpx;
						font-family:PingFangSC-Regular,PingFang SC;
						font-weight:400;
						color:rgba(153,153,153,1);
						line-height:30rpx;
					}
				}
			}
			.button{
				margin-right: 20rpx;
				width:169rpx;
				height:60rpx;
				background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
				box-shadow:0rpx -12rpx 28rpx 0rpx rgba(255,58,29,1),0rpx 8rpx 19rpx 0rpx rgba(255,220,104,0.58),0px -5rpx 9rpx 0px rgba(255,180,104,0.5);
				border-radius:31rpx;
				font-size:28rpx;
				font-family:PingFangSC-Medium,PingFang SC;
				font-weight:500;
				color:rgba(255,255,255,1);
				line-height:60rpx;
				text-align: center;
			}
		}
	}
</style>
