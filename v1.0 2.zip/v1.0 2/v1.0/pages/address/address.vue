<template>
	<view>
		<!-- #ifdef H5 -->
		<listCell :title.default="msg"></listCell>
		<!-- #endif -->
		<view class="content b-t" v-if="addressList.length!=0">
			<view class="list b-b" v-for="(item, index) in addressList" :key="index" @click="checkAddress(item)">
				<view class="wrapper">
					<view class="address-box">
						<text v-if="item.default" class="tag">默认</text>
						<text class="address">{{item.address}}</text>
					</view>
					<view class="u-box">
						<text class="name">{{item.consignee}}</text>
						<text class="mobile">{{item.mobile}}</text>
					</view>
				</view>
				<text class="abcbook deletesearch" @click.stop="deleteAddress(item,index)">&#xe62f;</text>
				<!-- <view @click.stop="deleteAddress(item,index)">删除</view> -->
				<text class="yticon icon-bianji" @click.stop="addAddress('edit', item)"></text>
			</view>
			<button class="add-btn" @click="gotoadd('add')">新增收货人信息</button>
		</view>
		<view v-else class="empty">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>您还没有收货信息哦</view>
				<view>快去新增收货人信息吧~</view>
				<view class="navigator" @click="gotoadd('add')">去新增</view>
			</view>
		</view>
	</view>
</template>
<script>
	// #ifdef H5
	import listCell from '@/components/title-top';
	// #endif
	export default {
		components: {
			// #ifdef H5
			listCell
			// #endif
		},
		data() {
			return {
				msg: "收货地址",
				source: 0,
				addressList: []
			}
		},
		onLoad(option) {
			console.log(option);
			this.source = option.source;
			this.$api.quest('user/address/list', {}, (res) => {
				console.log(res, "list")
				this.addressList = res.data.data
				console.log(this.addressList)
				// uni.navigateTo({
				// 	url:'/pages/address/address'
				// })
			})
		},
		methods: {
			gotoadd() {
				uni.navigateTo({
					url: '/pages/address/addressManage?source=' + this.source
				})
			},
			deleteAddress(item, index) {
				this.$api.quest('user/address/delete', {
					id: item.address_id
				}, (res) => {
					console.log(res)
					if (res.data.code == 0) {
						this.$api.msg("删除成功")
						this.addressList.splice(index, 1);
					} else {
						this.$api.msg("删除失败")
					}
				})
			},
			//选择地址
			checkAddress(item) {
				// ==1 支付分   ==2中奥商品  ==3预约还书
				if (this.source == 1) {
					console.log("返回订单页，并赋值")
					console.log(item)
					uni.navigateTo({
						url: `/pages/deposit/deposit?type=addre&addressData=${JSON.stringify(item)}`
					})
				}else if(this.source == 2){
					console.log('==2')
					console.log(item)
					uni.navigateTo({
						url: `/pages/flow/shopgoods?type=addre&addressData=${JSON.stringify(item)}`
					})
				} else if(this.source == 3){
					console.log('==3')
					console.log(item)
					uni.navigateTo({
						url: `/pages/appoint/appoint?type=addre&addressData=${JSON.stringify(item)}`
					})
				} else {
					uni.navigateBack()
				}

			},
			addAddress(type, item) {
				console.log(item, "1111")
				this.$api.quest('user/address/detail', {
					id: item.address_id
				}, (res) => {
					// that.cartList = res.data.data.cart_list[0]
					console.log(res)
					uni.navigateTo({
						url: `/pages/address/addressManage?type=${type}&data=${JSON.stringify(res.data.data.address)}`
					})
				})

			},
			//添加或修改成功之后回调
			refreshList(data, type) {
				//添加或修改后事件，这里直接在最前面添加了一条数据，实际应用中直接刷新地址列表即可
				this.addressList.unshift(data);

				console.log(data, type);
			}
		}
	}
</script>

<style lang='scss'>
	page {
		padding-bottom: 120upx;
	}

	.content {
		position: relative;
	}

	.list {
		display: flex;
		align-items: center;
		padding: 20upx 30upx;
		;
		background: #fff;
		position: relative;
	}

	.wrapper {
		display: flex;
		flex-direction: column;
		flex: 1;
	}

	.address-box {
		display: flex;
		align-items: center;

		.tag {
			width: 100rpx;
			text-align: center;
			font-size: 24upx;
			color: #FA6E3C;
			margin-right: 10upx;
			background: #fffafb;
			border: 1px solid #FA6E3C;
			border-radius: 4upx;
			padding: 4upx 10upx;
			line-height: 1;
		}

		.address {
			font-size: 30upx;
			color: $font-color-dark;
		}
	}

	.u-box {
		font-size: 28upx;
		color: $font-color-light;
		margin-top: 16upx;

		.name {
			margin-right: 30upx;
		}
	}

	.icon-bianji,
	.deletesearch {
		display: flex;
		align-items: center;
		height: 80upx;
		font-size: 40upx;
		color: $font-color-light;
		padding-left: 30upx;
	}

	.deletesearch {
		font-size: 52rpx;
		position: relative;
		top: -6rpx;
	}

	.add-btn {
		position: fixed;
		left: 30upx;
		right: 30upx;
		bottom: 40upx;
		z-index: 95;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 690upx;
		height: 80upx;
		font-size: 32upx;
		color: #fff;
		background-color: #FA6C3A;
		border-radius: 10upx;
		/* box-shadow: 1px 2px 5px rgba(219, 63, 96, 0.4);		 */
	}

	.empty {
		image {
			width: 287rpx;
			height: 181rpx;
		}

		.empty-tips {
			text {
				display: block;
			}
		}
	}
</style>
