<template>
	<view class="list">
		<view  v-if='datalist.length==0' class="empty">
			<image src="https://www.abcbook2019.com/mobile/public/img/icon/addBook.png" mode="aspectFit"></image>
			<view class="empty-tips">
				<view>您还没有上传记录哦</view>
				<view>快去上传自己喜欢的绘本吧~</view>
				<view class="navigator" @click="navTolist">去上传</view>
			</view>
		</view>
		<navigator v-else v-for="(item,index) in datalist" :key='index' :url="'/pages/Wishlist/Wishlist?type=list&id='+item.id" class="pagecon"  >
			<view class="title clear">
				<text class="bookname fl">{{item.book}}</text>
				<text class="fr" :class="item.status==1?'green':item.status==2?'org':''">{{item.status_dsc}}</text>
			</view>
			<view class="pscon clear">
				<text class="psdet fl">{{item.remarks}}</text>
				<text class="time fr">{{item.add_time}}</text>
			</view>
			<image v-if="item.status==1" src="http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/adopt.png" mode="aspectFit"></image>
		</navigator>
		
	</view>
</template>

<script>
	export default{
		data(){
			return{
				datalist:[]
			}
		},
		onLoad() {
			this.$api.quest('user/wishbooklist',{
				page:1,
				status:4
			},(res)=>{
				console.log(res)
				if(res.data.code==0){
					this.datalist=res.data.data
				}
			})
		},
		methods:{
			navTolist(){
				uni.navigateTo({
					url:'/pages/Wishlist/Wishlist'
				})
			}
		}
	}
</script>

<style lang="scss">
	
	.pagecon{
		position: relative;
		width: 710rpx;
		height: 136rpx;
		background: #fff;
		border-radius: 10rpx;
		margin: 0 auto;
		margin-top: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		padding: 0 30rpx;
		.title{
			margin-bottom: 15rpx;
			.bookname{
				font-size: 30rpx;
				color: #333;
			}
			.fr{
				color: #999;
				font-size: 26rpx;
			}
			
		}
		
		image{
			position: absolute;
			right: 0;
			bottom: 0;
			width: 111rpx;
			height: 114rpx;
			// z-index: -1;
			// opacity: .2;
		}
		.pscon{
			font-size: 26rpx;
			color: #999;
			.psdet{
				width: 406rpx;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
			}
		}
	}
	.green{
		color:#4BA032 !important;
	}
	.org{
		color:#FF824B !important;
	}
</style>
