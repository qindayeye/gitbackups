<template>
	<view class="wishlist">
		<!-- banner -->
		<view class="banner">
			<!-- 心愿书单 -->
			<view class="title clear">
				<navigator class="cell-icon yticon icon-zuo fl" open-type="navigateBack"></navigator>
				<view class="h1">心愿书单</view>
				<!-- <navigator  class="list fr"  url="/pages/Wishlist/list">上传记录</navigator> -->
				<!-- <text class="list fr"  @click="gotourl('/pages/Wishlist/list')">上传记录</text> -->
			</view>
			<view class="banbom">
				您可以提交想陪宝宝看的书籍，被采纳后会赠送30颗糖豆
			</view>
		</view>
		<!-- 内容 -->
		<view class="con">
			<view class="main clear">
				<text class="left1 fl">书名</text>
				<input class="inp" type="text fr" v-model='bookname'  placeholder="请填写书名"/>
			</view>
			<view class="main psmain clear">
				<view class="left1 fl">备注</view>
				<textarea class="pscon fr"  
				:disable-default-padding='true' 
				:auto-height='true'
				v-model="pscmain"
				placeholder="填写作者、系列、出版社、推荐理由等信息" />
			</view>
		</view>
		<goHome></goHome>
		
		<navigator  class="list"  url="/pages/Wishlist/list">查看上传记录 <text class="cell-icon yticon icon-you"></text></navigator>
		<button type="primary" v-if="detArr.status==1&&detArr.points==0" class="btn" @click="wishpoints()">领取糖豆</button>
		<button type="primary" v-if="detArr.points==1 || detArr.status==2 || detArr.status==0" class="btn noall">{{detArr.points==1?'糖豆已领取':detArr.status==0?'等待审核':'书单被拒'}}</button>
	
		<button type="primary" v-if="!bookdet" :disabled="bookname&&pscmain?false:true" :class="bookname&&pscmain?'':'noall'"  class="btn" @click="SubList()">上传书单</button>
	</view>
</template>

<script>
	import goHome from '@/components/home.vue';
	export default{
		data(){
			return{
				bookname:'',   //书名
				pscmain:''     ,//备注
				bookdet:false,   //是否是详情页
				detArr:[]
			}
			
		},
		onLoad(option) {
			
			if(option.type=='list'){
				this.id=option.id
				this.init()
			}
		},
		components: {
			goHome
		},
		methods:{
			// 页面初始
			init(){
				this.$api.quest('user/wishbookdetail',{
					id:this.id
				},(res)=>{
					if(res.data.code==0){
						this.detArr=res.data.data
						this.bookname=res.data.data.book
						this.pscmain=res.data.data.remarks
						this.bookdet=true    //审核过
					}
					console.log(res)
				})
			},
			// 审核通过领取糖豆
			wishpoints(){
				
				this.$api.quest('user/wishpoints',{
					id:this.detArr.id
				},(res)=>{
					console.log(res)
					if(res.data.code==0){
						this.init()
					}
				})
			},
			// 跳转页面
			gotourl(url){
				uni.navigateTo({
					url
				})
			},
			// 上传书单
			SubList(){
				console.log(this.bookname,this.pscmain)
				this.$api.quest('user/addwishbook',{
					book:this.bookname,
					remarks:this.pscmain
				},(res)=>{
					console.log(res)
					if(res.data.data.error==1){
						uni.navigateTo({
							url:'/pages/public/login'
						})
					}else{
						this.bookname=''
						this.pscmain=''
						uni.navigateTo({
							url:'/pages/Wishlist/list'
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.noall{
		opacity: .6;
	}
	.banner{
		position: relative;
		height: 435rpx;
		background:url('http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/wishlist.png');
		background-size: cover;
		.title{
			position: fixed;
			// display: flex;
			justify-content: space-between;
			width: 750rpx;
			padding: 0 30rpx;
			/* #ifdef MP */
			top: 88rpx;
			/* #endif */
			// height: 88rpx;
			line-height: 88rpx;
			align-items: center;
			color: #fff;
			.yticon{
				font-size: 41rpx;
			}
			.h1{
				position: absolute;
				left: 50%;
				transform: translate(-50%);
				text-align: center;
				font-size: 34rpx;
			}
			
		}
		.banbom{
			position: absolute;
			bottom: 0;
			width: 750rpx;
			// height: 76rpx; 
			background: rgba(0,0,0,.5);
			color: rgba(255,255,255,.8);
			font-size: 26rpx;
			line-height: 76rpx;
			text-align: center;
		}
	}
	.con{
		.main{
			width: 710rpx;
			background: #fff;
			border-radius: 10rpx;
			margin: 0 auto;
			margin-top: 20rpx;
			box-shadow:0px 2rpx 6rpx 0px rgba(0,0,0,.1);
			padding: 30rpx;
			.left1{
				font-size: 30rpx;
				color: #333;
				margin-right: 30rpx;
			}
			.inp{
				color: #666;
			}
			.pscon{
				display: block;
				width:560rpx;
				line-height:34rpx;
				color: #666;
			}
		}
		.psmain{
			// box-sizing: content-box;
			height: auto;
			min-height: 130rpx;
			display: flex;
		}
		
	}
	.btn{
		width:710rpx;
		line-height:88rpx;
		margin: 0 auto;
		margin-top: 40rpx;
		font-size: 32rpx;
		color: #fff;
		background:linear-gradient(135deg,rgba(254,163,100,1) 0%,rgba(250,108,58,1) 100%);
		box-shadow:0px 4rpx 10rpx 0px rgba(255,130,75,0.5);
		border-radius:49rpx;
	}
	.gray{
		background: #333;
		box-shadow: 0px 4rpx 10rpx 0px rgba(0,0,0,0.2);
	}
	.list{
		position: fixed;
		bottom: 150rpx;
		left: 50%;
		transform: translate(-50%);
		font-size: 26rpx;
		color: #666;
		.icon-you{
			font-size: 26rpx;
		}
	}
</style>
