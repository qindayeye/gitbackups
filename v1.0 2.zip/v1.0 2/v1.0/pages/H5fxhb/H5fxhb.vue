<template>
	<!-- #ifdef H5 -->
	<view class="content">
		<view class="zsm">
			<image :src="cat_icon" class="zsm_img" mode=""></image>
			<h4>{{cat_name}}</h4>
			<view class="wr-info">
				{{cat_desc}}
			</view>
		</view>

		<!-- <view class="beijing"> -->
		<view class="post" v-show="tishi==1" @click="guanbi">
			<p style="color: #ffffff;font-size: 30upx;margin-top: 70upx;">点击空白处返回</p>
			<view class="content" style="text-align: center;width: 85%;margin: 0 auto;">
				<view style="padding-top: 20upx;margin-top: 30upx;background: #ffffff;">
					<view>
						<img id="test" style="width: 580upx;height: 954upx;" />
					</view>
				</view>
			</view>
		</view>
		<!-- </view> -->
	</view>
	<!-- #endif -->
</template>

<script>
	// #ifdef H5
	import canvas_x from '../../common/H5hbJs/canvas_x.js';
	export default {

		data() {
			return {
				tishi: 0,
				qrShow: false,
				canvasId: 'default_PosterCanvasId',
				val: "",
				cat_icon: "",
				cat_name: "",
				cat_desc: ""
			};
		},
		onLoad(option) {
			//二维码地址（可从后台获取地址进行赋值）
			// this.val='http://www.taobao.com';
			this.val = option.url
			this.cat_icon = option.cat_icon
			this.cat_name = option.cat_name
			this.cat_desc = option.cat_desc
			this.erweima()
			console.log(this.url)
		},
		methods: {

			guanbi: function() {
				this.tishi = 0;
				uni.navigateBack()
			},
			erweima: function() {
				this.tishi = 1;
				canvas_x.makeImage({
					type: 'url',
					parts: [
						// {
						// 	type: 'image',
						// 	url: "../../static/select.png",
						// 	width: 680,
						// 	height: 1264,
						// 	// backgroundSize:680,
						// },
						{
							type: 'qrcode',
							text: this.val,
							x: 80,
							y: -50,
							width: 230,
							height: 230,
							padding: 0,
							background: '#fff',
							level: 3
						},
						{
							type: 'text',
							text: '长按识别二维码',
							textAlign: 'left',
							lineAlign: 'TOP',
							x: 400,
							y: 1015,
							color: 'black',
							size: '35px',
							// bold: true
						},
						{
							type: 'text',
							text: '进入书单',
							textAlign: 'left',
							lineAlign: 'TOP',
							x: 400,
							y: 1125,
							color: 'black',
							size: '35px',
							// bold: true
						}
					],
					width: 680,
					height: 1264
				}, (err, data) => {
					document.getElementById('test').src = data
				})
			}
		}
	};
	// #endif
</script>

<style lang="scss">
	/* #ifdef H5 */
	.zsm {
		width: 80%;
		// height: 208rpx;
		position: fixed;
		top: 150rpx;
		left: 10%;
		z-index: 100001;
		.zsm_img {
			width: 100%;
			height: 250rpx;
		}
		h4{
			color: red;
			margin: 20rpx auto;
		}
		.wr-info {
			font-size: 30rpx;
			color: grey;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 9; // 超出九行显示省略号
			overflow: hidden;
		}
	}



	.post {
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.7);
		position: fixed;
		top: 0upx;
		z-index: 10000;
		text-align: center;

		.wrapper {
			height: 1420upx;
			width: 610upx;
			margin: 0 auto;
			margin-top: -150upx;

			// margin-top: 50upx;
		}
	}

	.tupian {
		width: 100%;
		height: 1360upx;
		background-image: url('http://ktoss.oss-cn-beijing.aliyuncs.com/app_image/select.png');
		background-size: 750upx 1360upx;
	}
  /* #endif */
</style>
